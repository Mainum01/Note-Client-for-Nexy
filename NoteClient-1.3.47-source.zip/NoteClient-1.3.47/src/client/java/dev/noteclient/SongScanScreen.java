package dev.noteclient;

import dev.noteclient.nbs.NbsReader;
import dev.noteclient.nbs.NbsSong;
import dev.noteclient.plan.NoteBlockPlanner;
import dev.noteclient.plan.PlanExporter;
import dev.noteclient.network.BuildRequestPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Responsive song-scanner page. Content and status have separate bounded regions. */
public final class SongScanScreen extends Screen {
    private final Screen parent;
    private final Path selectedSong;
    private final boolean autoBuildAfterScan;

    private volatile boolean scanning = true;
    private volatile ScanReport report;
    private volatile String unexpectedError;
    private int panelX;
    private int panelY;
    private int panelWidth;
    private int panelHeight;
    private int contentX;
    private int contentWidth;
    private int contentTop;
    private int contentBottom;
    private int statusY;

    public SongScanScreen(Screen parent, Path selectedSong) {
        this(parent, selectedSong, false);
    }

    public SongScanScreen(Screen parent, Path selectedSong, boolean autoBuildAfterScan) {
        super(Component.literal("NoteClient Song Scan"));
        this.parent = parent;
        this.selectedSong = selectedSong;
        this.autoBuildAfterScan = autoBuildAfterScan;
    }

    @Override
    protected void init() {
        panelWidth = Math.max(1, Math.min(790, width - 16));
        panelHeight = Math.max(1, Math.min(560, height - 16));
        panelX = (width - panelWidth) / 2;
        panelY = (height - panelHeight) / 2;
        contentX = panelX + 18;
        contentWidth = panelWidth - 36;
        contentTop = panelY + 54;
        statusY = panelY + panelHeight - 90;
        contentBottom = statusY - 8;

        int footerY = panelY + panelHeight - 25;
        int buttonGap = 6;
        int buttonWidth = Math.max(1, Math.min(176, (panelWidth - 44 - buttonGap * 2) / 3));
        int groupWidth = buttonWidth * 3 + buttonGap * 2;
        int startX = panelX + (panelWidth - groupWidth) / 2;
        String buildLabel = buttonWidth < 112 ? (autoBuildAfterScan ? "Play Swap" : "Direct Play")
                : (autoBuildAfterScan ? "Build Song Swap" : "Build Arrangement");
        String redstoneLabel = buttonWidth < 112 ? "Redstone" : "Redstone Setup";
        String backLabel = buttonWidth < 112 ? "Back" : "Back to Library";
        this.addRenderableWidget(Button.builder(Component.literal(buildLabel), button -> requestBuild(false))
                .bounds(startX, footerY, buttonWidth, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal(redstoneLabel), button -> requestBuild(true))
                .bounds(startX + buttonWidth + buttonGap, footerY, buttonWidth, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal(backLabel), button -> onClose())
                .bounds(startX + (buttonWidth + buttonGap) * 2, footerY, buttonWidth, 20).build());
    }

    public void beginScan() {
        scanning = true;
        report = null;
        unexpectedError = null;
        BuildClientState.reset("Scanning selected NBS file…");
        NoteClientHud.show("Scanning " + selectedSong.getFileName() + "…");

        CompletableFuture.supplyAsync(() -> scan(selectedSong)).whenComplete((result, throwable) -> {
            Minecraft client = Minecraft.getInstance();
            client.execute(() -> {
                if (throwable != null) {
                    unexpectedError = throwable.getMessage() == null
                            ? throwable.getClass().getSimpleName() : throwable.getMessage();
                    BuildClientState.reset("NBS scan failed: " + unexpectedError);
                    NoteClientHud.warn("NBS scan failed: " + unexpectedError);
                } else {
                    report = result;
                    if (result.exportError != null) {
                        BuildClientState.reset("Song scanned, but export failed: " + result.exportError);
                        NoteClientHud.warn("Song scan finished but CSV export failed: " + result.exportError);
                    } else if (result.fallbackReason != null) {
                        BuildClientState.reset("NBS parsing failed. A reference grid was exported, but it has no playable timeline.");
                        NoteClientHud.warn("This NBS file could not be parsed. The fallback grid is reference-only and cannot play a song.");
                    } else {
                        BuildClientState.reset("Scan complete. Review the layout summary, then choose Build arrangement.");
                        NoteClientHud.show("Scanned " + result.song.notes().size() + " notes into "
                                + result.plan.placements().size() + " instrument/pitch slots.");
                    }
                }
                scanning = false;

                if (autoBuildAfterScan && client.gui.screen() == this
                        && report != null && report.plan != null && report.exportError == null
                        && report.fallbackReason == null) {
                    requestBuild(false);
                }
            });
        });
    }

    private static ScanReport scan(Path selected) {
        try {
            NbsSong song = NbsReader.read(selected);
            NoteBlockPlanner.PlanResult plan = NoteBlockPlanner.planSong(song);
            Path layout = PlanExporter.writeLayout(selected, plan);
            Path timeline = PlanExporter.writeTimeline(selected, song);
            return new ScanReport(song, plan, layout, timeline, null, null);
        } catch (Exception exception) {
            String reason = exception.getMessage() == null
                    ? exception.getClass().getSimpleName() : exception.getMessage();
            NoteBlockPlanner.PlanResult fallback = NoteBlockPlanner.universalGrid(reason);
            try {
                Path layout = PlanExporter.writeLayout(selected, fallback);
                return new ScanReport(null, fallback, layout, null, reason, null);
            } catch (IOException exportException) {
                return new ScanReport(null, null, null, null, reason,
                        "Could not export fallback grid: " + exportException.getMessage());
            }
        }
    }

    private void requestBuild(boolean redstoneSetup) {
        if (scanning || report == null || report.plan == null) {
            BuildClientState.reset("Wait for the song scan to finish first.");
            NoteClientHud.warn("Wait for the song scan to finish before building.");
            return;
        }
        if (report.fallbackReason != null || report.song == null) {
            BuildClientState.reset("The fallback grid is reference-only. A parsed NBS song is required for playback.");
            NoteClientHud.warn("This file did not produce a playable timeline. Choose a valid .nbs song instead.");
            return;
        }
        int cellCount = report.plan.placements().size();
        if (cellCount <= 0 || report.plan.timeline().isEmpty()) {
            BuildClientState.reset("This song has no supported built-in notes to build.");
            NoteClientHud.warn("No playable built-in note-block events were found in this song.");
            return;
        }
        if (report.plan.skippedNoteEvents() > 0) {
            String message = "This song contains " + report.plan.skippedNoteEvents()
                    + " note event(s) with NBS keys outside the supported 0–87 range. Those events cannot be mapped to a vanilla note-block pitch, so NoteClient will not build a knowingly incomplete arrangement.";
            BuildClientState.reset(message);
            NoteClientHud.warn(message);
            return;
        }
        if (this.minecraft == null || this.minecraft.player == null) {
            BuildClientState.reset("Join a world before building.");
            NoteClientHud.warn("Join a world before building a song arrangement.");
            return;
        }

        int tempo = report.song.tempoHundredths();
        int songLength = Math.max(report.song.songLengthTicks(),
                report.song.notes().stream().mapToInt(NbsSong.Note::tick).max().orElse(-1) + 1);

        // Physical redstone is now a client-only feature. It is constructed with
        // ordinary Creative block interactions and server acknowledgements, just
        // like schematic placement; no NoteClient server companion is required.
        if (redstoneSetup) {
            if (RedstoneSequencerBuilder.start(this.minecraft, report.plan, tempo)) {
                this.minecraft.gui.setScreen(null);
            } else {
                NoteClientHud.warn(BuildClientState.message());
            }
            return;
        }

        // Keep the optional server companion as the fast path for ordinary note
        // arrangements. If it is unavailable/denies the request, the existing
        // client-only note-block arrangement builder remains the fallback.
        if (ClientPlayNetworking.canSend(BuildRequestPayload.TYPE)) {
            if (cellCount > BuildRequestPayload.MAX_CELLS) {
                String message = "The arrangement exceeds the optional server companion's cell limit.";
                BuildClientState.reset(message + " Trying ordinary player interactions instead.");
                NoteClientHud.warn(BuildClientState.message());
                startOrdinaryBuild(tempo, songLength);
                return;
            }
            if (report.plan.timeline().size() > BuildRequestPayload.MAX_EVENTS) {
                String message = "The song exceeds the optional server companion's event limit.";
                BuildClientState.reset(message + " Trying ordinary player interactions instead.");
                NoteClientHud.warn(BuildClientState.message());
                startOrdinaryBuild(tempo, songLength);
                return;
            }

            int[] cells = new int[cellCount * BuildRequestPayload.VALUES_PER_CELL];
            int cursor = 0;
            for (NoteBlockPlanner.Placement placement : report.plan.placements()) {
                cells[cursor++] = placement.instrumentId();
                cells[cursor++] = placement.noteBlockPitch();
                cells[cursor++] = placement.nbsKey();
                cells[cursor++] = placement.noteX();
                cells[cursor++] = placement.noteY();
                cells[cursor++] = placement.noteZ();
            }
            int[] events = new int[report.plan.timeline().size() * BuildRequestPayload.VALUES_PER_EVENT];
            cursor = 0;
            for (NoteBlockPlanner.TimedNote note : report.plan.timeline()) {
                events[cursor++] = note.tick();
                events[cursor++] = note.cellIndex();
                events[cursor++] = note.volume();
                events[cursor++] = note.panning();
                events[cursor++] = note.finePitchCents();
            }
            BuildClientState.reset("Sending the arrangement to the optional server companion. If this account is not authorized, NoteClient will use ordinary player interactions instead.");
            NoteClientHud.show(BuildClientState.message());
            NoteClient.setPendingCompanionFallback(report.plan, tempo, songLength);
            ClientPlayNetworking.send(new BuildRequestPayload(
                    cells, events, tempo, songLength,
                    BuilderPreferences.anchorX(this.minecraft),
                    BuilderPreferences.anchorY(this.minecraft),
                    BuilderPreferences.anchorZ(this.minecraft),
                    BuilderPreferences.replaceExisting(),
                    false
            ));
            this.minecraft.gui.setScreen(null);
            return;
        }

        startOrdinaryBuild(tempo, songLength);
    }

    /** Uses normal player interactions only; no command or reach workaround exists here. */
    private void startOrdinaryBuild(int tempo, int songLength) {
        // Ordinary multiplayer stages materials in Creative, builds and tunes the
        // arrangement with normal Creative interactions, then waits for the player
        // to switch to Survival manually. No commands are sent by this client.
        // Playback uses ordinary Survival note-block attack interactions.
        // Custom absolute anchors and replacement require explicit server authorization.
        if (BuilderPreferences.isCustomAnchor()) {
            BuildClientState.reset("Custom coordinates require the optional server companion. Choose Use Player Anchor to build around your position with normal interactions.");
            NoteClientHud.warn(BuildClientState.message());
            return;
        }
        if (BuilderPreferences.replaceExisting()) {
            BuildClientState.reset("Normal Creative placement never replaces existing blocks. Turn Replace OFF to use the ordinary server builder.");
            NoteClientHud.warn(BuildClientState.message());
            return;
        }
        if (VanillaServerBuilder.start(this.minecraft, report.plan, tempo, songLength)) {
            this.minecraft.gui.setScreen(null);
        } else {
            NoteClientHud.warn(BuildClientState.message());
        }
    }

    @Override
    public void onClose() {
        this.minecraft.gui.setScreen(parent);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        graphics.fill(0, 0, width, height, 0xA8000000);
        drawMinecraftWindow(graphics, panelX, panelY, panelWidth, panelHeight);
        graphics.fill(panelX + 4, panelY + 4, panelX + panelWidth - 4, panelY + 44, 0xFF39291D);
        graphics.fill(panelX + 4, panelY + 4, panelX + panelWidth - 4, panelY + 5, 0xFFFFD36B);
        graphics.fill(panelX + 4, panelY + 43, panelX + panelWidth - 4, panelY + 44, 0xFF17120E);
        graphics.fill(panelX + 9, panelY + 9, panelX + 11, panelY + 37, 0xFFFFC65D);
        drawMinecraftPanel(graphics, contentX, contentTop, contentWidth, Math.max(1, contentBottom - contentTop));
        drawMinecraftPanel(graphics, contentX, statusY, contentWidth,
                Math.max(1, panelY + panelHeight - 31 - statusY));

        graphics.text(font, clip("NOTECLIENT  /  SONG SCANNER", panelWidth - 32),
                panelX + 16, panelY + 9, 0xFFFFE08A, true);
        graphics.text(font, clip("NBS DETAILS  •  DIRECT PLAY OR PHYSICAL REDSTONE", panelWidth - 32),
                panelX + 16, panelY + 25, 0xFFE2E2E2, false);
        graphics.text(font, clip(selectedSong.getFileName().toString(), contentWidth - 24),
                contentX + 12, contentTop + 12, 0xFFFFFFFF, true);

        int bodyY = contentTop + 34;
        int bodyBottom = contentBottom - 8;
        if (scanning) {
            graphics.centeredText(font, "SCANNING SONG", width / 2, bodyY + 22, 0xFFFFE08A);
            drawWrapped(graphics, "Reading the NBS header, note events, instrument IDs, pitch levels, and timing.",
                    contentX + 14, bodyY + 48, contentWidth - 28, 13, 4, 0xFFEDEDED);
        } else if (unexpectedError != null) {
            graphics.text(font, "SCAN ERROR", contentX + 14, bodyY, 0xFFFF8585, true);
            drawWrapped(graphics, unexpectedError, contentX + 14, bodyY + 20,
                    contentWidth - 28, 13, Math.max(1, (bodyBottom - bodyY - 20) / 13), 0xFFFF8585);
        } else if (report == null) {
            drawWrapped(graphics, "No scan result was returned. Return to the library and try the file again.",
                    contentX + 14, bodyY, contentWidth - 28, 13, 4, 0xFFFF8585);
        } else if (report.exportError != null) {
            graphics.text(font, "EXPORT ERROR", contentX + 14, bodyY, 0xFFFF8585, true);
            drawWrapped(graphics, report.exportError, contentX + 14, bodyY + 20,
                    contentWidth - 28, 13, Math.max(1, (bodyBottom - bodyY - 20) / 13), 0xFFFF8585);
        } else {
            renderReport(graphics, contentX, contentWidth, bodyY, bodyBottom);
        }

        graphics.text(font, "STATUS", contentX + 12, statusY + 6, 0xFFFFE08A, true);
        String status = BuildClientState.message().isBlank()
                ? "Scan complete. Choose Build Arrangement when ready."
                : BuildClientState.message();
        drawWrapped(graphics, status, contentX + 12, statusY + 22,
                contentWidth - 24, 12, 2, 0xFFEDEDED);

        // Interactive widgets render last to guarantee that the buttons remain
        // visible and clickable above the custom Minecraft-style panels.
        super.extractRenderState(graphics, mouseX, mouseY, delta);
    }

    private void drawMinecraftWindow(GuiGraphicsExtractor graphics, int x, int y, int w, int h) {
        if (w <= 0 || h <= 0) return;
        graphics.fill(x + 4, y + 5, x + w + 4, y + h + 5, 0x99000000);
        graphics.fill(x, y, x + w, y + h, 0xFF090909);
        graphics.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFFB7B7B7);
        graphics.fill(x + 2, y + 2, x + w - 2, y + h - 2, 0xFF555555);
        graphics.fill(x + 3, y + 3, x + w - 3, y + h - 3, 0xFF454545);
        for (int py = y + 5; py < y + h - 5; py += 8) {
            for (int px = x + 5; px < x + w - 5; px += 8) {
                int hash = (px * 31 + py * 17) & 7;
                if (hash == 0 || hash == 3) {
                    graphics.fill(px, py, Math.min(x + w - 4, px + 3),
                            Math.min(y + h - 4, py + 2), hash == 0 ? 0xFF4B4B4B : 0xFF3D3D3D);
                }
            }
        }
        graphics.fill(x + 3, y + 3, x + w - 3, y + 4, 0xFF9A9A9A);
        graphics.fill(x + 3, y + h - 4, x + w - 3, y + h - 3, 0xFF242424);
    }

    private void drawMinecraftPanel(GuiGraphicsExtractor graphics, int x, int y, int w, int h) {
        if (w <= 0 || h <= 0) return;
        graphics.fill(x, y, x + w, y + h, 0xFF171717);
        if (w > 2 && h > 2) graphics.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFF8A8A8A);
        if (w > 4 && h > 4) graphics.fill(x + 2, y + 2, x + w - 2, y + h - 2, 0xFF393939);
        if (w > 4 && h > 3) graphics.fill(x + 2, y + 2, x + w - 2, y + 3, 0xFF9B9B9B);
        if (w > 4 && h > 4) graphics.fill(x + 2, y + h - 3, x + w - 2, y + h - 2, 0xFF202020);
    }

    private void renderReport(GuiGraphicsExtractor graphics, int x, int panelContentWidth,
                              int y, int bottom) {
        int maxWidth = panelContentWidth - 28;
        if (report.fallbackReason != null || report.song == null) {
            graphics.text(font, "UNIVERSAL REFERENCE GRID", x + 14, y, 0xFFFFE08A, true);
            y += 19;
            int warningLines = Math.min(3, Math.max(0, (bottom - y - 4) / 13));
            y = drawWrapped(graphics,
                    "This file could not be decoded as a supported NBS song. The reference grid has no timeline and cannot be played.",
                    x + 14, y, maxWidth, 13, warningLines, 0xFFFFD479);
            int reasonLines = Math.max(0, (bottom - y - 4) / 12);
            if (reasonLines > 0) {
                drawWrapped(graphics, "Reason: " + report.fallbackReason, x + 14, y + 4,
                        maxWidth, 12, reasonLines, 0xFFEDEDED);
            }
            return;
        }

        graphics.text(font, "SONG SUMMARY  •  NBS v" + report.song.formatVersion(),
                x + 14, y, 0xFFFFE08A, true);
        y += 20;
        y = drawWrapped(graphics, "Title: " + safeName(report.song.name()), x + 14, y,
                maxWidth, 13, Math.min(2, Math.max(0, (bottom - y - 8) / 13)), 0xFFEDEDED);
        y += 5;

        String[] values = {
                String.format("%.1fs", report.song.durationSeconds()),
                Integer.toString(report.song.notes().size()),
                Integer.toString(report.plan.placements().size()),
                Integer.toString(report.plan.skippedNoteEvents())
        };
        String[] labels = {"DURATION", "NBS NOTES", "PITCH SLOTS", "SKIPPED"};

        // On short windows use a compact text summary instead of drawing a
        // four-tile dashboard that could run into the status/footer regions.
        if (bottom - y < 132) {
            String compact = "Duration " + values[0] + "  •  Notes " + values[1]
                    + "  •  Pitch slots " + values[2] + "  •  Skipped " + values[3];
            drawWrapped(graphics, compact, x + 14, y, maxWidth, 12,
                    Math.max(1, (bottom - y) / 12), 0xFFEDEDED);
            return;
        }

        int columns = panelContentWidth < 470 ? 2 : 4;
        int gap = 6;
        int tileWidth = (panelContentWidth - 28 - gap * (columns - 1)) / columns;
        int tileHeight = 42;
        for (int i = 0; i < values.length; i++) {
            int row = i / columns;
            int column = i % columns;
            int tx = x + 14 + column * (tileWidth + gap);
            int ty = y + row * (tileHeight + gap);
            graphics.fill(tx, ty, tx + tileWidth, ty + tileHeight, 0xFF454545);
            graphics.centeredText(font, values[i], tx + tileWidth / 2, ty + 6, 0xFFFFFFFF);
            graphics.centeredText(font, labels[i], tx + tileWidth / 2, ty + 25, 0xFFC2C2C2);
        }
        y += ((values.length + columns - 1) / columns) * (tileHeight + gap) + 5;

        if (y < bottom - 16) {
            graphics.text(font, "ARRANGEMENT", x + 14, y, 0xFFFFE08A, true);
            y += 17;
            y = drawWrapped(graphics,
                    "The builder creates placeholder supports, instrument blocks, and tuned note blocks. It maps simultaneous NBS events to the generated slots.",
                    x + 14, y, maxWidth, 12, Math.min(3, Math.max(1, (bottom - y) / 12)), 0xFFEDEDED);
        }

        if (y < bottom - 12 && !report.plan.warnings().isEmpty()) {
            y += 3;
            graphics.text(font, "COMPATIBILITY", x + 14, y, 0xFFFFE08A, true);
            y += 16;
            drawWrapped(graphics, report.plan.warnings().get(0), x + 14, y, maxWidth,
                    12, Math.max(1, (bottom - y) / 12), 0xFFFFD479);
        }
    }

    private void drawProgressBar(GuiGraphicsExtractor graphics, int x, int y, int w, int h, int percent) {
        graphics.fill(x, y, x + w, y + h, 0xFF242424);
        graphics.fill(x, y, x + Math.max(0, Math.min(w, w * percent / 100)), y + h, 0xFF7BA653);
    }

    private int drawWrapped(GuiGraphicsExtractor graphics, String text, int x, int y, int maxWidth,
                            int lineHeight, int maxLines, int color) {
        if (text == null || text.isBlank() || maxWidth < 24 || maxLines <= 0) return y;
        StringBuilder line = new StringBuilder();
        int drawn = 0;
        for (String word : text.replace('\n', ' ').split("\\s+")) {
            if (line.isEmpty() && font.width(word) > maxWidth) word = clip(word, maxWidth);
            String candidate = line.isEmpty() ? word : line + " " + word;
            if (font.width(candidate) > maxWidth && !line.isEmpty()) {
                graphics.text(font, line.toString(), x, y, color, true);
                y += lineHeight;
                drawn++;
                line.setLength(0);
                if (drawn >= maxLines) return y;
                line.append(font.width(word) > maxWidth ? clip(word, maxWidth) : word);
            } else {
                line.setLength(0);
                line.append(candidate);
            }
        }
        if (!line.isEmpty() && drawn < maxLines) {
            graphics.text(font, line.toString(), x, y, color, true);
            y += lineHeight;
        }
        return y;
    }

    private String clip(String value, int maxWidth) {
        if (maxWidth <= 0 || value == null) return "";
        if (font.width(value) <= maxWidth) return value;
        String result = value;
        while (!result.isEmpty() && font.width(result + "…") > maxWidth) {
            result = result.substring(0, result.length() - 1);
        }
        return result + "…";
    }

    private static String safeName(String name) {
        if (name == null || name.isBlank()) return "Untitled";
        return name.replace('\n', ' ').replace('\r', ' ');
    }

    private record ScanReport(
            NbsSong song,
            NoteBlockPlanner.PlanResult plan,
            Path layout,
            Path timeline,
            String fallbackReason,
            String exportError
    ) {}
}
