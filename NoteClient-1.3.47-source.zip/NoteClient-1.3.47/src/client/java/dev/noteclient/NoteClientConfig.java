package dev.noteclient;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Persistent client preferences plus a temporary, server-specific reach planning hint. */
public final class NoteClientConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("noteclient.properties");
    private static final int[] BUILD_PRESETS = {2, 3, 4};
    private static final int[] TUNING_PRESETS = {48, 72, 96, 144};
    private static final int[] PLAYBACK_PRESETS = {1, 2, 3, 4};

    private static volatile boolean hudEnabled = true;
    private static volatile int buildActionsPerTick = 4;
    private static volatile int tuningActionsPerTick = 144;
    private static volatile int playbackAttacksPerTick = 4;
    // 0 = use server-synchronized reach; 100 = the user requested /reach 100.
    private static volatile int serverReachOverride = 0;

    private NoteClientConfig() {}

    public static void load() {
        Properties properties = new Properties();
        if (Files.isRegularFile(FILE)) {
            try (InputStream input = Files.newInputStream(FILE)) {
                properties.load(input);
            } catch (IOException exception) {
                System.err.println("[NoteClient] Could not read preferences: " + exception.getMessage());
            }
        }
        hudEnabled = Boolean.parseBoolean(properties.getProperty("hud.enabled", "true"));
        int configVersion = parseInt(properties, "config.version", 0);
        int storedBuildRate = parseInt(properties, "performance.buildActionsPerTick", 4);
        if (configVersion < 3 && storedBuildRate == 3) storedBuildRate = 4;
        buildActionsPerTick = clampPreset(storedBuildRate, BUILD_PRESETS);

        // Older versions stored a tiny per-note click batch (1–4). 1.3.8 stores
        // a global actions-per-tick budget instead; migrate old configs to 96.
        int storedTuneRate = parseInt(properties, "performance.tuneActionsPerTick", -1);
        if (storedTuneRate < 0) storedTuneRate = 144;
        tuningActionsPerTick = clampPreset(storedTuneRate, TUNING_PRESETS);
        playbackAttacksPerTick = clampPreset(
                parseInt(properties, "performance.playbackAttacksPerTick", 4), PLAYBACK_PRESETS);

        // Custom reach is session/server-specific and is intentionally never
        // restored from disk. It resets on disconnect to avoid carrying a 100
        // block assumption onto an unrelated server.
        serverReachOverride = 0;
        save();
    }

    public static void save() {
        Properties properties = new Properties();
        properties.setProperty("config.version", "5");
        properties.setProperty("hud.enabled", Boolean.toString(hudEnabled));
        properties.setProperty("performance.buildActionsPerTick", Integer.toString(buildActionsPerTick));
        properties.setProperty("performance.tuneActionsPerTick", Integer.toString(tuningActionsPerTick));
        properties.setProperty("performance.playbackAttacksPerTick", Integer.toString(playbackAttacksPerTick));
        properties.setProperty("safety.userInitiatedReachCommandOnly", "true");
        properties.setProperty("safety.serverValidatesEveryInteraction", "true");
        try {
            Files.createDirectories(FILE.getParent());
            try (OutputStream output = Files.newOutputStream(FILE)) {
                properties.store(output,
                        "NoteClient client preferences. Safety settings are enforced and cannot be disabled.");
            }
        } catch (IOException exception) {
            System.err.println("[NoteClient] Could not save preferences: " + exception.getMessage());
        }
    }

    public static boolean hudEnabled() { return hudEnabled; }
    public static void setHudEnabled(boolean enabled) {
        hudEnabled = enabled;
        save();
    }

    public static int buildActionsPerTick() { return buildActionsPerTick; }
    public static int nextBuildActionsPerTick() {
        buildActionsPerTick = nextPreset(buildActionsPerTick, BUILD_PRESETS);
        save();
        return buildActionsPerTick;
    }

    /** Total normal note-block interactions the fast tuner may send in one game tick. */
    public static int tuningActionsPerTick() { return tuningActionsPerTick; }
    public static int nextTuningActionsPerTick() {
        tuningActionsPerTick = nextPreset(tuningActionsPerTick, TUNING_PRESETS);
        save();
        return tuningActionsPerTick;
    }

    /** A one-tick confirmation grace keeps tuning responsive without assuming acceptance. */
    public static int tuningConfirmationTicks() { return 1; }
    public static int tuningBatchSize() { return 24; }

    public static int playbackAttacksPerTick() { return playbackAttacksPerTick; }
    public static int serverReachOverride() { return serverReachOverride; }

    public static void setServerReachOverride(int reach) {
        serverReachOverride = reach == 100 ? 100 : 0;
    }

    public static int nextPlaybackAttacksPerTick() {
        playbackAttacksPerTick = nextPreset(playbackAttacksPerTick, PLAYBACK_PRESETS);
        save();
        return playbackAttacksPerTick;
    }

    public static void resetDefaults() {
        hudEnabled = true;
        buildActionsPerTick = 4;
        tuningActionsPerTick = 144;
        playbackAttacksPerTick = 4;
        serverReachOverride = 0;
        save();
    }

    private static int parseInt(Properties properties, String key, int fallback) {
        try {
            return Integer.parseInt(properties.getProperty(key, Integer.toString(fallback)).trim());
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }

    private static int clampPreset(int value, int[] presets) {
        int best = presets[0];
        for (int preset : presets) {
            if (Math.abs(preset - value) < Math.abs(best - value)) best = preset;
        }
        return best;
    }

    private static int nextPreset(int current, int[] presets) {
        for (int i = 0; i < presets.length; i++) {
            if (presets[i] == current) return presets[(i + 1) % presets.length];
        }
        return presets[0];
    }
}
