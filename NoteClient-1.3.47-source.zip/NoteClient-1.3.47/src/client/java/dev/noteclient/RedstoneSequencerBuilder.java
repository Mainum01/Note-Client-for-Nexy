package dev.noteclient;

import dev.noteclient.schematic.SchematicBuilder;

import dev.noteclient.plan.NoteBlockPlanner;
import dev.noteclient.plan.NoteBlockPlanner.PlanResult;
import dev.noteclient.plan.NoteBlockPlanner.Placement;
import dev.noteclient.plan.NoteBlockPlanner.TimedNote;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.BlockItemStateProperties;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Builds a real, button-started redstone note-block sequencer using ordinary
 * Creative-mode block interactions. No NoteClient server companion is needed.
 * Every placement waits for the world state to confirm it before continuing.
 */
public final class RedstoneSequencerBuilder {
    private static final int WORKING_SLOT = 8;
    // Keep the physical chain within the same default 512-block forward-offset
    // budget used by the optional server implementation (2 blocks per stage).
    private static final int MAX_STAGES = 255;
    private static final int MAX_ATTEMPTS = 3;
    private static final int ACK_TIMEOUT_TICKS = 16;
    private static final int STATUS_INTERVAL_TICKS = 30;

    private static Job activeJob;

    private RedstoneSequencerBuilder() {}

    public static boolean hasActiveJob() {
        return activeJob != null;
    }

    public static boolean start(Minecraft client, PlanResult plan, int tempoHundredths) {
        if (client == null || client.player == null || client.level == null || client.gameMode == null) {
            fail("Join a world before building a redstone sequencer.");
            return false;
        }
        if (activeJob != null) {
            fail("A redstone sequencer build is already running. Press P to pause or O to stop.");
            return false;
        }
        if (VanillaServerBuilder.hasActiveJob() || SchematicBuilder.hasActiveJob()
                || PlayerStatueBuilder.isBuilding() || PlayerStatueBuilder.isRemoving()) {
            fail("Another NoteClient block build is already active. Let it finish or stop it before starting Redstone Setup.");
            return false;
        }
        if (client.gameMode.getPlayerMode() != GameType.CREATIVE) {
            fail("Redstone Setup uses ordinary Creative block interactions. Switch to Creative and try again.");
            return false;
        }
        if (plan == null || plan.placements().isEmpty() || plan.timeline().isEmpty() || tempoHundredths <= 0) {
            fail("This song does not contain a playable NBS timeline for a physical sequencer.");
            return false;
        }

        try {
            List<CircuitBlock> blocks = createCircuit(client, plan, tempoHundredths);
            if (blocks.isEmpty()) {
                fail("The song did not produce any physical redstone blocks.");
                return false;
            }
            LocalPlayer player = client.player;
            activeJob = new Job(client.level, blocks, player.getInventory().getSelectedSlot(),
                    player.getInventory().getItem(WORKING_SLOT).copy());
            BuildClientState.reset("Building client-side redstone sequencer • 0 / " + blocks.size()
                    + " confirmed • follow the circuit when prompted. Do not press its button until the build finishes.");
            BuildClientState.updateLocal(0, blocks.size(), 0, 1, false, false, BuildClientState.message());
            NoteClientHud.show(BuildClientState.message());
            return true;
        } catch (IllegalArgumentException exception) {
            fail(exception.getMessage());
            return false;
        } catch (RuntimeException exception) {
            String reason = exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage();
            fail("Could not plan the redstone circuit: " + reason);
            return false;
        }
    }

    public static void tick(Minecraft client) {
        Job job = activeJob;
        if (job == null) return;
        if (client == null || client.player == null || client.level == null || client.gameMode == null) {
            finish(client, job, "Redstone build stopped after disconnect. Confirmed circuit blocks remain in the world.");
            return;
        }
        if (client.level != job.level) {
            finish(client, job, "Redstone build stopped after the dimension changed. Confirmed circuit blocks remain in the previous dimension.");
            return;
        }
        if (client.gameMode.getPlayerMode() != GameType.CREATIVE) {
            finish(client, job, "Redstone build stopped because Creative mode is no longer active. Confirmed blocks were retained.");
            return;
        }
        if (job.paused) return;

        long now = client.level.getGameTime();
        if (job.pending != null) {
            BlockState observed = client.level.getBlockState(job.pending.position);
            if (job.pending.foundation && !observed.isAir()
                    && observed.isFaceSturdy(client.level, job.pending.position, Direction.UP)) {
                confirm(job, now);
                return;
            }
            if (observed.equals(job.pending.expected)) {
                confirm(job, now);
                return;
            }
            if (!observed.isAir()) {
                finish(client, job, "Redstone build stopped: another block appeared at "
                        + job.pending.position.toShortString() + ". That block was left untouched; the confirmed circuit remains.");
                return;
            }
            if (now - job.pending.sentAt >= ACK_TIMEOUT_TICKS) {
                job.pending = null;
                job.attempts++;
                if (job.attempts >= MAX_ATTEMPTS) {
                    job.waitingForPlayer = true;
                    setStatus(job, now, "The server has not confirmed the next circuit block. Move closer to the build position or check Creative placement permissions.");
                } else {
                    job.nextAction = now + 3L * job.attempts;
                }
                return;
            }
            return;
        }
        if (now < job.nextAction) return;

        if (job.index >= job.blocks.size()) {
            finish(client, job, "Redstone sequencer complete • " + job.placed + " blocks confirmed. Anyone who can reach the stone button can start it. The circuit is retained.");
            BuildClientState.updateLocal(job.placed, job.blocks.size(), 0, 4, true, false, BuildClientState.message());
            return;
        }

        CircuitBlock block = job.blocks.get(job.index);
        BlockPos target = block.position;
        if (!client.level.getWorldBorder().isWithinBounds(target) || client.level.isOutsideBuildHeight(target)) {
            finish(client, job, "Redstone build stopped: " + target.toShortString()
                    + " is outside the world border or build height. Confirmed blocks were retained.");
            return;
        }
        if (!client.level.hasChunkAt(target)) {
            setStatus(job, now, "Waiting for the next circuit chunk at " + target.toShortString() + ". Move closer to load it.");
            return;
        }
        if (block.clearAbove != null) {
            if (!client.level.hasChunkAt(block.clearAbove)) {
                setStatus(job, now, "Waiting for the note-block sound space to load. Move closer to the next circuit section.");
                return;
            }
            if (!client.level.getBlockState(block.clearAbove).isAir()) {
                finish(client, job, "Redstone build stopped: the space above a note block is obstructed at "
                        + block.clearAbove.toShortString() + ". Existing blocks were not changed.");
                return;
            }
        }

        BlockState existing = client.level.getBlockState(target);
        if (block.foundation) {
            if (!existing.isAir() && existing.isFaceSturdy(client.level, target, Direction.UP)) {
                advance(job, now, false);
                return;
            }
            if (!existing.isAir()) {
                finish(client, job, "Redstone build stopped: the required foundation position is occupied by a non-solid block at "
                        + target.toShortString() + ". Nothing was replaced.");
                return;
            }
        } else {
            if (existing.equals(block.expected)) {
                advance(job, now, false);
                return;
            }
            if (!existing.isAir()) {
                finish(client, job, "Redstone build stopped: " + target.toShortString()
                        + " is occupied. Existing blocks were not replaced.");
                return;
            }
        }

        BlockHitResult hit = findPlacementHit(client, target);
        if (hit == null) {
            job.waitingForPlayer = true;
            setStatus(job, now, "Move closer to the next circuit block at " + target.toShortString()
                    + ". Follow alongside the repeater line; the build will resume automatically.");
            return;
        }
        job.waitingForPlayer = false;

        Item item = block.expected.getBlock().asItem();
        if (item == Items.AIR) {
            finish(client, job, "Redstone build stopped: " + block.expected.getBlock().getDescriptionId()
                    + " has no placeable item. Confirmed blocks were retained.");
            return;
        }

        ItemStack stack = new ItemStack(item, 1);
        Map<String, String> properties = serializedProperties(block.expected);
        if (!properties.isEmpty()) {
            stack.set(DataComponents.BLOCK_STATE, new BlockItemStateProperties(properties));
        }
        LocalPlayer player = client.player;
        player.getInventory().setSelectedSlot(WORKING_SLOT);
        player.getInventory().setItem(WORKING_SLOT, stack.copy());
        client.gameMode.handleCreativeModeItemAdd(stack.copy(), 36 + WORKING_SLOT);
        InteractionResult result = client.gameMode.useItemOn(player, InteractionHand.MAIN_HAND, hit);
        if (result != null && result.consumesAction()) {
            job.pending = new PendingBlock(target, block.expected, block.foundation, now);
            job.attempts = 0;
            job.nextAction = now + 1;
        } else {
            job.attempts++;
            if (job.attempts >= MAX_ATTEMPTS) {
                job.waitingForPlayer = true;
                setStatus(job, now, "The server did not accept this block placement at " + target.toShortString()
                        + ". Move closer or check server permissions and block support.");
            } else {
                job.nextAction = now + 2L * job.attempts;
            }
        }
    }

    public static void togglePause(Minecraft client) {
        Job job = activeJob;
        if (job == null) return;
        job.paused = !job.paused;
        String message = job.paused
                ? "Redstone build paused • P to resume • O to stop and keep confirmed blocks"
                : "Redstone build resumed • " + job.placed + " / " + job.blocks.size() + " confirmed";
        BuildClientState.updateLocal(job.placed, job.blocks.size(), 0, 1, false, job.paused, message);
        NoteClientHud.show(message);
    }

    public static void cancel(Minecraft client) {
        Job job = activeJob;
        if (job == null) return;
        finish(client, job, "Redstone build stopped • " + job.placed
                + " confirmed blocks were left in the world. No automatic cleanup was performed.");
    }

    public static void onDisconnect(Minecraft client) {
        Job job = activeJob;
        if (job == null) return;
        restoreHand(client, job);
        activeJob = null;
    }

    private static void confirm(Job job, long now) {
        job.placed++;
        job.pending = null;
        job.attempts = 0;
        job.index++;
        job.nextAction = now + 1;
        if (job.placed == job.blocks.size() || job.placed % 10 == 0) {
            setStatus(job, now, "Building physical redstone sequencer • " + job.placed + " / "
                    + job.blocks.size() + " confirmed • move alongside the repeater line when prompted");
        }
    }

    private static void advance(Job job, long now, boolean placed) {
        if (placed) job.placed++;
        job.index++;
        job.attempts = 0;
        job.nextAction = now + 1;
        if (job.index == job.blocks.size() || job.index % 10 == 0) {
            setStatus(job, now, "Building physical redstone sequencer • " + job.placed + " / "
                    + job.blocks.size() + " confirmed • move alongside the repeater line when prompted");
        }
    }

    private static void setStatus(Job job, long now, String message) {
        if (job.lastStatus == Long.MIN_VALUE || now - job.lastStatus >= STATUS_INTERVAL_TICKS
                || job.index == job.blocks.size()) {
            job.lastStatus = now;
            BuildClientState.updateLocalQuietly(job.placed, job.blocks.size(), 0, 1, false, job.paused, message);
            NoteClientHud.show(message);
        }
    }

    private static void finish(Minecraft client, Job job, String message) {
        restoreHand(client, job);
        activeJob = null;
        BuildClientState.updateLocal(job.placed, job.blocks.size(), 0, 4, true, false, message);
        NoteClientHud.show(message);
    }

    private static void restoreHand(Minecraft client, Job job) {
        if (client == null || client.player == null) return;
        client.player.getInventory().setItem(WORKING_SLOT, job.originalWorkingStack.copy());
        if (client.gameMode != null && client.gameMode.getPlayerMode() == GameType.CREATIVE) {
            client.gameMode.handleCreativeModeItemAdd(job.originalWorkingStack.copy(), 36 + WORKING_SLOT);
        }
        client.player.getInventory().setSelectedSlot(job.originalSelectedSlot);
    }

    private static List<CircuitBlock> createCircuit(Minecraft client, PlanResult plan, int tempoHundredths) {
        TreeMap<Integer, List<PhysicalNote>> grouped = new TreeMap<>();
        for (TimedNote event : plan.timeline()) {
            if (event.volume() <= 0) continue;
            if (event.cellIndex() < 0 || event.cellIndex() >= plan.placements().size()) {
                throw new IllegalArgumentException("The NBS timeline contains an invalid note-to-block reference.");
            }
            Placement placement = plan.placements().get(event.cellIndex());
            if (placement.instrumentId() < 0 || placement.instrumentId() >= NoteBlockPlanner.instruments().size()
                    || placement.noteBlockPitch() < 0 || placement.noteBlockPitch() > 24) {
                throw new IllegalArgumentException("A note uses an unsupported vanilla instrument or pitch.");
            }
            long tickLong = Math.max(1L, Math.round(event.tick() * 1000.0 / tempoHundredths));
            if (tickLong > MAX_STAGES * 4L) {
                throw new IllegalArgumentException("This song's duration requires more than "
                        + MAX_STAGES + " repeater stages. Use a shorter song or Direct Play.");
            }
            int redstoneTick = (int) tickLong;
            List<PhysicalNote> chord = grouped.computeIfAbsent(redstoneTick, ignored -> new ArrayList<>());
            chord.add(new PhysicalNote(placement.instrumentId(), placement.noteBlockPitch()));
            if (chord.size() > 3) {
                throw new IllegalArgumentException("A chord contains more than three simultaneous notes after redstone timing is rounded to 0.1-second ticks. Use Direct Play for this song.");
            }
        }
        if (grouped.isEmpty()) throw new IllegalArgumentException("No audible notes remain after filtering silent events.");

        List<RedstoneStage> stages = new ArrayList<>();
        int elapsed = 0;
        for (Map.Entry<Integer, List<PhysicalNote>> entry : grouped.entrySet()) {
            int gap = entry.getKey() - elapsed;
            while (gap > 4) {
                stages.add(new RedstoneStage(4, List.of()));
                elapsed += 4;
                gap -= 4;
            }
            if (gap < 1) gap = 1;
            stages.add(new RedstoneStage(gap, List.copyOf(entry.getValue())));
            elapsed += gap;
        }
        if (stages.size() > MAX_STAGES) {
            throw new IllegalArgumentException("This song needs " + stages.size()
                    + " repeater stages. The client-side circuit limit is " + MAX_STAGES
                    + " stages to keep the build manageable. Try a shorter song or Direct Play.");
        }

        LocalPlayer player = client.player;
        Direction forward = Direction.fromYRot(player.getYRot());
        Direction side = forward.getClockWise();
        Direction oppositeSide = side.getOpposite();
        BlockPos anchor = player.blockPosition();
        // Raise the timing rail one block above the player's feet. Its stone
        // foundations sit at the feet level, while side note supports sit on the
        // existing ground beneath them, matching the tested companion layout.
        BlockPos circuitBase = anchor.relative(forward, 2).above();
        LinkedHashMap<BlockPos, CircuitBlock> planned = new LinkedHashMap<>();

        // The floor-mounted stone button powers the initial conductor, which
        // feeds the first repeater. Place the conductor now but install the
        // button last, so nobody can accidentally start a partially built song.
        addFoundation(client, planned, circuitBase.below());
        addRequired(client, planned, circuitBase, Blocks.STONE.defaultBlockState(), null);

        List<NoteBlockPlanner.Instrument> instruments = NoteBlockPlanner.instruments();
        for (int stageIndex = 0; stageIndex < stages.size(); stageIndex++) {
            RedstoneStage stage = stages.get(stageIndex);
            BlockPos repeaterPos = circuitBase.relative(forward, stageIndex * 2 + 1);
            BlockPos outputPos = circuitBase.relative(forward, stageIndex * 2 + 2);
            BlockState repeater = withProperty(Blocks.REPEATER.defaultBlockState(), "facing", forward.getName());
            repeater = withProperty(repeater, "delay", Integer.toString(stage.delay));
            addFoundation(client, planned, repeaterPos.below());
            addRequired(client, planned, repeaterPos, repeater, null);

            BlockState output = Blocks.STONE.defaultBlockState();
            if (stage.notes.size() == 3) {
                PhysicalNote top = stage.notes.get(2);
                if (!isSafeConductor(top.instrumentId)) {
                    throw new IllegalArgumentException("A three-note chord uses a non-conductive or transparent support for its top note. Use Direct Play or choose a song with no three-note chord at that moment.");
                }
                output = supportState(top.instrumentId, instruments);
            }
            addFoundation(client, planned, outputPos.below());
            addRequired(client, planned, outputPos, output, null);

            for (int chordIndex = 0; chordIndex < stage.notes.size(); chordIndex++) {
                PhysicalNote note = stage.notes.get(chordIndex);
                BlockPos notePos;
                BlockPos noteSupportPos;
                if (stage.notes.size() == 3 && chordIndex == 2) {
                    notePos = outputPos.above();
                    noteSupportPos = outputPos;
                } else {
                    notePos = outputPos.relative(chordIndex == 0 ? side : oppositeSide);
                    noteSupportPos = notePos.below();
                    addFoundation(client, planned, noteSupportPos.below());
                    BlockState noteSupport = supportState(note.instrumentId, instruments);
                    addRequired(client, planned, noteSupportPos, noteSupport, null);
                }
                BlockState noteState = withProperty(Blocks.NOTE_BLOCK.defaultBlockState(), "instrument",
                        instruments.get(note.instrumentId).noteBlockInstrument());
                noteState = withProperty(noteState, "note", Integer.toString(note.pitch));
                addRequired(client, planned, notePos, noteState, notePos.above());
            }
        }

        // Install the physical start button only after the complete timing chain
        // and every note position have been built. The player may need to return
        // to the beginning to place it within ordinary interaction reach.
        BlockState button = withProperty(Blocks.STONE_BUTTON.defaultBlockState(), "face", "floor");
        button = withProperty(button, "facing", forward.getName());
        addRequired(client, planned, circuitBase.above(), button, null);

        // The path is laid in dependency order so the user can follow its leading
        // edge while the client waits for normal block reach at each next section.
        List<CircuitBlock> result = new ArrayList<>(planned.values());
        for (CircuitBlock block : result) {
            if (block.expected.getBlock().asItem() == Items.AIR) {
                throw new IllegalArgumentException("The block " + block.expected.getBlock().getDescriptionId()
                        + " has no placeable item and cannot be used in the physical circuit.");
            }
        }
        return result;
    }

    private static void addFoundation(Minecraft client, LinkedHashMap<BlockPos, CircuitBlock> planned,
                                      BlockPos position) {
        BlockPos pos = position.immutable();
        if (planned.containsKey(pos)) return;
        // A foundation is optional: an existing sturdy block is reused. If it is
        // air, a stone block is inserted here and acknowledged like every other
        // placement. Occupied non-sturdy blocks are never replaced.
        planned.put(pos, new CircuitBlock(pos, Blocks.STONE.defaultBlockState(), true, null));
    }

    private static void addRequired(Minecraft client, LinkedHashMap<BlockPos, CircuitBlock> planned,
                                    BlockPos position, BlockState expected, BlockPos clearAbove) {
        if (expected == null) throw new IllegalArgumentException("An instrument support block is unavailable.");
        BlockPos pos = position.immutable();
        CircuitBlock previous = planned.get(pos);
        if (previous != null) {
            if (!previous.expected.equals(expected)) {
                throw new IllegalArgumentException("The physical redstone layout overlaps two different blocks at "
                        + pos.toShortString() + ". Choose another clear building area.");
            }
            if (previous.foundation) {
                // If a required circuit block occupies a position previously
                // considered as an optional floor, it must be placed/verified as
                // the exact required state instead of reusing any sturdy block.
                planned.put(pos, new CircuitBlock(pos, expected, false, clearAbove));
            }
            return;
        }
        planned.put(pos, new CircuitBlock(pos, expected, false, clearAbove));
    }

    private static BlockState supportState(int instrumentId, List<NoteBlockPlanner.Instrument> instruments) {
        if (instrumentId < 0 || instrumentId >= instruments.size()) {
            throw new IllegalArgumentException("The song uses an unsupported note-block instrument.");
        }
        String id = instruments.get(instrumentId).supportBlock();
        try {
            return BuiltInRegistries.BLOCK.getOptional(Identifier.parse(id))
                    .map(Block::defaultBlockState)
                    .orElseThrow(() -> new IllegalArgumentException("Instrument support block is unavailable: " + id));
        } catch (RuntimeException exception) {
            if (exception instanceof IllegalArgumentException illegal) throw illegal;
            throw new IllegalArgumentException("Invalid instrument support block: " + id, exception);
        }
    }

    private static boolean isSafeConductor(int instrumentId) {
        // These are full opaque support blocks. The other built-in instrument
        // materials may be transparent, non-conductive or unsuitable as a
        // redstone stage output conductor.
        return switch (instrumentId) {
            case 0, 1, 2, 3, 5, 6, 7, 9, 10, 12, 13, 14, 16, 17, 18, 19 -> true;
            default -> false;
        };
    }

    private static BlockHitResult findPlacementHit(Minecraft client, BlockPos target) {
        LocalPlayer player = client.player;
        double reach = player.getAttributeValue(Attributes.BLOCK_INTERACTION_RANGE);
        double maxDistance = Math.max(0.5, reach - 0.5);
        Vec3 eye = player.getEyePosition();
        BlockHitResult best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Direction offset : Direction.values()) {
            BlockPos neighbor = target.relative(offset);
            BlockState anchor = client.level.getBlockState(neighbor);
            if (anchor.isAir() || anchor.hasBlockEntity()
                    || !anchor.isFaceSturdy(client.level, neighbor, offset.getOpposite())) continue;
            Vec3 location = Vec3.atCenterOf(neighbor).add(
                    offset.getOpposite().getStepX() * 0.5,
                    offset.getOpposite().getStepY() * 0.5,
                    offset.getOpposite().getStepZ() * 0.5);
            double distance = eye.distanceTo(location);
            if (distance > maxDistance || distance >= bestDistance) continue;
            best = new BlockHitResult(location, offset.getOpposite(), neighbor, false);
            bestDistance = distance;
        }
        return best;
    }

    private static Map<String, String> serializedProperties(BlockState state) {
        Map<String, String> values = new java.util.HashMap<>();
        for (Property<?> property : state.getProperties()) propertyValueUnchecked(property, state, values);
        return values;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void propertyValueUnchecked(Property property, BlockState state, Map<String, String> target) {
        Comparable value = (Comparable) state.getValue(property);
        target.put(property.getName(), property.getName(value));
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static BlockState withProperty(BlockState state, String name, String value) {
        Property property = state.getBlock().getStateDefinition().getProperty(name);
        if (property == null) throw new IllegalArgumentException("Missing block state property: " + name);
        java.util.Optional parsed = property.getValue(value);
        if (parsed.isEmpty()) throw new IllegalArgumentException("Invalid block property " + name + "=" + value);
        return state.setValue(property, (Comparable) parsed.get());
    }

    private record PhysicalNote(int instrumentId, int pitch) {}
    private record RedstoneStage(int delay, List<PhysicalNote> notes) {}
    private record CircuitBlock(BlockPos position, BlockState expected, boolean foundation, BlockPos clearAbove) {}
    private record PendingBlock(BlockPos position, BlockState expected, boolean foundation, long sentAt) {}

    private static final class Job {
        private final net.minecraft.client.multiplayer.ClientLevel level;
        private final List<CircuitBlock> blocks;
        private final int originalSelectedSlot;
        private final ItemStack originalWorkingStack;
        private int index;
        private int placed;
        private int attempts;
        private boolean waitingForPlayer;
        private boolean paused;
        private long nextAction;
        private long lastStatus = Long.MIN_VALUE;
        private PendingBlock pending;

        private Job(net.minecraft.client.multiplayer.ClientLevel level, List<CircuitBlock> blocks,
                    int originalSelectedSlot, ItemStack originalWorkingStack) {
            this.level = level;
            this.blocks = List.copyOf(blocks);
            this.originalSelectedSlot = originalSelectedSlot;
            this.originalWorkingStack = originalWorkingStack;
            this.nextAction = level.getGameTime();
        }
    }

    private static void fail(String message) {
        String safe = message == null || message.isBlank() ? "Redstone setup could not start." : message;
        BuildClientState.reset(safe);
        NoteClientHud.warn(safe);
    }
}
