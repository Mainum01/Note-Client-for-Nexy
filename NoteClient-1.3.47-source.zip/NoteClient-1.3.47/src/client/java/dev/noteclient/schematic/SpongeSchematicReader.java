package dev.noteclient.schematic;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/** Reader for Sponge Schematic v2/v3 files (.schem). Block-entity NBT is intentionally not imported. */
public final class SpongeSchematicReader {
    public static final int MAX_DIMENSION = 512;
    public static final int MAX_VOLUME = 2_000_000;
    public static final int MAX_BLOCKS = 500_000;
    private static final int MAX_NBT_BYTES = 128 * 1024 * 1024;
    private static final int MAX_NBT_ENTRIES = 16_000_000;
    private static final int MAX_DEPTH = 64;

    private SpongeSchematicReader() {}

    public static Schematic read(Path file) throws IOException {
        if (file == null || !Files.isRegularFile(file)) throw new IOException("Schematic file does not exist.");
        long size = Files.size(file);
        if (size <= 0 || size > MAX_NBT_BYTES) {
            throw new IOException("Schematic file size is outside the safe 1 byte–128 MiB range.");
        }

        try (InputStream raw = new BufferedInputStream(Files.newInputStream(file));
             InputStream decoded = openMaybeGzip(raw);
             DataInputStream in = new DataInputStream(decoded)) {
            int rootType = in.readUnsignedByte();
            if (rootType != 10) throw new IOException("The file is not a valid NBT compound schematic.");
            readString(in); // root name
            Object rootValue = readPayload(in, rootType, 0, new Budget());
            if (!(rootValue instanceof Map<?, ?> root)) throw new IOException("Missing schematic root compound.");
            return decodeSchematic(root);
        } catch (EOFException exception) {
            throw new IOException("The schematic NBT data is truncated.", exception);
        } catch (IllegalArgumentException exception) {
            throw new IOException("Invalid schematic data: " + exception.getMessage(), exception);
        }
    }

    private static InputStream openMaybeGzip(InputStream input) throws IOException {
        input.mark(2);
        int first = input.read();
        int second = input.read();
        input.reset();
        if (first == 0x1F && second == 0x8B) return new GZIPInputStream(input);
        return input;
    }

    private static Schematic decodeSchematic(Map<?, ?> root) throws IOException {
        int version = number(root.get("Version"), -1);
        if (version != 2 && version != 3) {
            throw new IOException("Only Sponge Schematic format versions 2 and 3 are supported (found " + version + ").");
        }
        int width = number(root.get("Width"), 0);
        int height = number(root.get("Height"), 0);
        int length = number(root.get("Length"), 0);
        if (width < 1 || height < 1 || length < 1
                || width > MAX_DIMENSION || height > MAX_DIMENSION || length > MAX_DIMENSION) {
            throw new IOException("Schematic dimensions must each be between 1 and " + MAX_DIMENSION + ".");
        }
        long volumeLong = (long) width * height * length;
        if (volumeLong > MAX_VOLUME) {
            throw new IOException("Schematic volume exceeds the safe limit of " + MAX_VOLUME + " cells.");
        }
        int volume = (int) volumeLong;

        Map<?, ?> blocks = asMap(root.get("Blocks"));
        Object paletteObject = blocks == null ? root.get("Palette") : blocks.get("Palette");
        Object dataObject = blocks == null ? root.get("BlockData") : blocks.get("Data");
        if (paletteObject == null && blocks != null) paletteObject = root.get("Palette");
        if (dataObject == null) dataObject = root.get("BlockData");
        Map<?, ?> rawPalette = asMap(paletteObject);
        if (rawPalette == null || !(dataObject instanceof byte[] blockData)) {
            throw new IOException("Missing Sponge Blocks.Palette or Blocks.Data data.");
        }
        if (rawPalette.isEmpty() || rawPalette.size() > MAX_VOLUME) {
            throw new IOException("Schematic block palette is empty or too large.");
        }

        Map<Integer, String> palette = new LinkedHashMap<>();
        int maximumPaletteId = -1;
        for (Map.Entry<?, ?> entry : rawPalette.entrySet()) {
            if (!(entry.getKey() instanceof String state) || !(entry.getValue() instanceof Number value)) continue;
            int id = value.intValue();
            if (id < 0 || id >= MAX_VOLUME) throw new IOException("Schematic palette contains an invalid state index.");
            palette.put(id, state);
            maximumPaletteId = Math.max(maximumPaletteId, id);
        }
        if (palette.isEmpty()) throw new IOException("Schematic block palette contains no valid block states.");

        List<BlockEntry> entries = new ArrayList<>(Math.min(volume, MAX_BLOCKS));
        int[] cursor = {0};
        for (int index = 0; index < volume; index++) {
            int paletteId = readVarInt(blockData, cursor);
            String stateText = palette.get(paletteId);
            if (stateText == null) {
                throw new IOException("Block data references missing palette id " + paletteId + ".");
            }
            ParsedState state = parseBlockState(stateText);
            if (state.blockId.equals("minecraft:air") || state.blockId.equals("minecraft:cave_air")
                    || state.blockId.equals("minecraft:void_air")) continue;
            if (entries.size() >= MAX_BLOCKS) {
                throw new IOException("Schematic contains more than " + MAX_BLOCKS + " non-air blocks.");
            }
            int x = index % width;
            int z = (index / width) % length;
            int y = index / (width * length);
            entries.add(new BlockEntry(x, y, z, state.blockId, state.properties));
        }

        if (cursor[0] < blockData.length) {
            // Sponge writes exactly one palette varint per cell. Extra bytes usually mean a malformed or
            // incompatible encoding; tolerate only zero padding so we don't silently shift block data.
            for (int i = cursor[0]; i < blockData.length; i++) {
                if (blockData[i] != 0) throw new IOException("Unexpected trailing bytes in Sponge block data.");
            }
        }
        return new Schematic(width, height, length, version, entries, maximumPaletteId + 1);
    }

    private static ParsedState parseBlockState(String text) throws IOException {
        String value = text.trim();
        int open = value.indexOf('[');
        String blockId = open < 0 ? value : value.substring(0, open);
        if (blockId.isBlank() || !blockId.contains(":")) throw new IOException("Invalid block state id: " + text);
        Map<String, String> properties = new LinkedHashMap<>();
        if (open >= 0) {
            int close = value.lastIndexOf(']');
            if (close < open) throw new IOException("Invalid block-state properties: " + text);
            String list = value.substring(open + 1, close).trim();
            if (!list.isEmpty()) {
                for (String part : list.split(",")) {
                    int equals = part.indexOf('=');
                    if (equals <= 0 || equals == part.length() - 1) continue;
                    properties.put(part.substring(0, equals).trim(), part.substring(equals + 1).trim());
                }
            }
        }
        return new ParsedState(blockId, Collections.unmodifiableMap(properties));
    }

    private static int readVarInt(byte[] bytes, int[] cursor) throws IOException {
        int result = 0;
        int shift = 0;
        while (shift < 35) {
            if (cursor[0] >= bytes.length) throw new IOException("Block data ended before all palette entries were read.");
            int value = bytes[cursor[0]++] & 0xFF;
            result |= (value & 0x7F) << shift;
            if ((value & 0x80) == 0) return result;
            shift += 7;
        }
        throw new IOException("Block data contains an overlong palette varint.");
    }

    private static Object readPayload(DataInputStream in, int type, int depth, Budget budget) throws IOException {
        if (depth > MAX_DEPTH) throw new IOException("NBT nesting is too deep.");
        return switch (type) {
            case 1 -> in.readByte();
            case 2 -> in.readShort();
            case 3 -> in.readInt();
            case 4 -> in.readLong();
            case 5 -> in.readFloat();
            case 6 -> in.readDouble();
            case 7 -> readByteArray(in, budget);
            case 8 -> readString(in);
            case 9 -> readList(in, depth, budget);
            case 10 -> readCompound(in, depth, budget);
            case 11 -> readIntArray(in, budget);
            case 12 -> readLongArray(in, budget);
            default -> throw new IOException("Unknown NBT tag id " + type + ".");
        };
    }

    private static byte[] readByteArray(DataInputStream in, Budget budget) throws IOException {
        int length = readLength(in, budget);
        byte[] data = new byte[length];
        in.readFully(data);
        return data;
    }

    private static int[] readIntArray(DataInputStream in, Budget budget) throws IOException {
        int length = readLength(in, budget);
        int[] values = new int[length];
        for (int i = 0; i < length; i++) values[i] = in.readInt();
        return values;
    }

    private static long[] readLongArray(DataInputStream in, Budget budget) throws IOException {
        int length = readLength(in, budget);
        long[] values = new long[length];
        for (int i = 0; i < length; i++) values[i] = in.readLong();
        return values;
    }

    private static List<Object> readList(DataInputStream in, int depth, Budget budget) throws IOException {
        int childType = in.readUnsignedByte();
        int length = readLength(in, budget);
        if (childType == 0 && length != 0) throw new IOException("Invalid non-empty NBT end-tag list.");
        List<Object> values = new ArrayList<>(length);
        for (int i = 0; i < length; i++) values.add(readPayload(in, childType, depth + 1, budget));
        return values;
    }

    private static Map<String, Object> readCompound(DataInputStream in, int depth, Budget budget) throws IOException {
        Map<String, Object> values = new LinkedHashMap<>();
        while (true) {
            int childType = in.readUnsignedByte();
            if (childType == 0) return values;
            budget.add(1);
            String name = readString(in);
            values.put(name, readPayload(in, childType, depth + 1, budget));
        }
    }

    private static int readLength(DataInputStream in, Budget budget) throws IOException {
        int length = in.readInt();
        if (length < 0 || length > MAX_NBT_ENTRIES) throw new IOException("NBT array/list length is invalid or exceeds the safe limit.");
        budget.add(length);
        return length;
    }

    private static String readString(DataInputStream in) throws IOException {
        int length = in.readUnsignedShort();
        byte[] bytes = new byte[length];
        in.readFully(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    private static Map<?, ?> asMap(Object value) {
        return value instanceof Map<?, ?> map ? map : null;
    }

    private static int number(Object value, int fallback) {
        return value instanceof Number number ? number.intValue() : fallback;
    }

    private static final class Budget {
        private long entries;
        private void add(long value) throws IOException {
            entries += value;
            if (entries > MAX_NBT_ENTRIES) throw new IOException("NBT payload has too many nested entries.");
        }
    }

    private record ParsedState(String blockId, Map<String, String> properties) {}

    public record BlockEntry(int x, int y, int z, String blockId, Map<String, String> properties) {}

    public record Schematic(int width, int height, int length, int version,
                            List<BlockEntry> blocks, int paletteSize) {
        public Schematic {
            blocks = List.copyOf(blocks);
        }
    }
}
