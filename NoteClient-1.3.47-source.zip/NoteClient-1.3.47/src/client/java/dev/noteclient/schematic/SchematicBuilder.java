package dev.noteclient.schematic;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.noteclient.NoteClientHud;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.LightCoordsUtil;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelPart;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.component.BlockItemStateProperties;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Sponge schematic preview and normal-interaction builder. */
public final class SchematicBuilder {
    private static final int WORKING_SLOT = 8;
    private static final int MAX_RENDERED_PREVIEW_BLOCKS = 12_000;
    private static final int MAX_RENDER_DISTANCE = 96;
    private static final int CONFIRM_TIMEOUT_TICKS = 12;
    private static final int MAX_ATTEMPTS_PER_BLOCK = 3;

    private static volatile Preview preview;
    private static BuildJob activeJob;
    private static String status = "Place Sponge .schem files in the NoteClient/schematics folder.";
    private static long loadGeneration;

    private SchematicBuilder() {}

    public static void initialize() {
        try {
            Files.createDirectories(NoteClientSchematics.folder());
        } catch (IOException exception) {
            status = "Could not create schematics folder: " + exception.getMessage();
        }
        LevelRenderEvents.COLLECT_SUBMITS.register(SchematicBuilder::renderPreview);
    }

    public static String status() { return status; }
    public static boolean hasPreview() { return preview != null; }
    public static boolean hasActiveJob() { return activeJob != null; }
    public static String previewName() { Preview current = preview; return current == null ? "" : current.name; }

    public static void load(Path file, Minecraft client, java.util.function.Consumer<String> completion) {
        if (file == null || client == null) return;
        long generation = ++loadGeneration;
        status = "Reading " + file.getFileName() + "…";
        java.util.concurrent.CompletableFuture.supplyAsync(() -> {
            try {
                SpongeSchematicReader.Schematic schematic = SpongeSchematicReader.read(file);
                List<PreparedBlock> prepared = prepareBlocks(schematic);
                return new PreparedSchematic(schematic, prepared, null);
            } catch (Exception exception) {
                String message = exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage();
                return new PreparedSchematic(null, List.of(), message);
            }
        }).whenComplete((result, error) -> client.execute(() -> {
            if (generation != loadGeneration) return;
            if (error != null || result == null || result.error != null || result.schematic == null) {
                String message = result != null && result.error != null ? result.error
                        : error == null ? "Could not read schematic." : rootMessage(error);
                status = "Schematic load failed: " + message;
                if (completion != null) completion.accept(status);
                NoteClientHud.warn(status);
                return;
            }
            if (client.player == null) {
                status = "Join a world to preview this schematic.";
                if (completion != null) completion.accept(status);
                return;
            }
            Direction forward = Direction.fromYRot(client.player.getYRot());
            preview = new Preview(file.getFileName().toString(), result.schematic,
                    result.blocks, forward, true);
            status = "Preview loaded • " + result.blocks.size() + " placeable blocks • left arrow to build";
            if (completion != null) completion.accept(status);
            NoteClientHud.show(status);
        }));
    }

    private static List<PreparedBlock> prepareBlocks(SpongeSchematicReader.Schematic schematic) throws IOException {
        List<PreparedBlock> result = new ArrayList<>(schematic.blocks().size());
        for (SpongeSchematicReader.BlockEntry entry : schematic.blocks()) {
            Identifier id;
            try {
                id = Identifier.parse(entry.blockId());
            } catch (RuntimeException exception) {
                continue;
            }
            Block block = BuiltInRegistries.BLOCK.getOptional(id).orElse(null);
            if (block == null || block == Blocks.AIR) continue;
            BlockState state = block.defaultBlockState();
            for (Map.Entry<String, String> propertyEntry : entry.properties().entrySet()) {
                Property<?> property = block.getStateDefinition().getProperty(propertyEntry.getKey());
                if (property == null) continue;
                try {
                    state = withProperty(state, property, propertyEntry.getValue());
                } catch (RuntimeException ignored) {
                    // Unknown values from modded/newer schematic versions fall back to the block default.
                }
            }
            Item item = block.asItem();
            if (item == Items.AIR) continue;
            result.add(new PreparedBlock(entry.x(), entry.y(), entry.z(), state, item));
        }
        result.sort(Comparator.comparingInt(PreparedBlock::y)
                .thenComparingInt(PreparedBlock::z).thenComparingInt(PreparedBlock::x));
        if (result.isEmpty()) throw new IOException("The schematic contains no registered placeable blocks for this Minecraft version.");
        return List.copyOf(result);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static BlockState withProperty(BlockState state, Property property, String serializedValue) {
        java.util.Optional parsed = property.getValue(serializedValue);
        if (parsed.isEmpty()) throw new IllegalArgumentException("Invalid block property value: " + serializedValue);
        return state.setValue(property, (Comparable) parsed.get());
    }

    public static void rotatePreview() {
        Preview current = preview;
        if (current == null || activeJob != null) return;
        preview = new Preview(current.name, current.schematic, current.blocks,
                current.forward.getClockWise(), true);
        status = "Preview rotated • facing " + preview.forward.getName().toUpperCase();
    }

    public static void clearPreview() {
        if (activeJob != null) return;
        preview = null;
        status = "Schematic preview cleared.";
    }

    public static boolean startBuild(Minecraft client) {
        Preview current = preview;
        if (current == null || client == null || client.player == null || client.level == null || client.gameMode == null) {
            status = "Select a schematic and join a world first.";
            NoteClientHud.warn(status);
            return false;
        }
        if (activeJob != null) {
            status = "A schematic build is already running. Press P to pause or O to stop.";
            NoteClientHud.warn(status);
            return false;
        }
        if (client.gameMode.getPlayerMode() != GameType.CREATIVE) {
            status = "Schematic construction currently requires Creative mode so the client can supply the needed blocks.";
            NoteClientHud.warn(status);
            return false;
        }
        BlockPos origin = originFor(client.player, current);
        activeJob = new BuildJob(current, origin, client.player.getInventory().getSelectedSlot(),
                client.player.getInventory().getItem(WORKING_SLOT).copy());
        preview = new Preview(current.name, current.schematic, current.blocks, current.forward, false);
        status = "Building " + current.name + " • 0 / " + current.blocks.size() + " confirmed • move within normal reach";
        NoteClientHud.show(status);
        return true;
    }

    public static void tick(Minecraft client) {
        BuildJob job = activeJob;
        if (job == null) {
            Preview current = preview;
            if (current != null && current.followPlayer && client != null && client.player != null) {
                // Keep the hologram in front of the player until construction starts.
                current.origin = originFor(client.player, current);
            }
            return;
        }
        if (client == null || client.player == null || client.level == null || client.gameMode == null) {
            finish(client, job, "Disconnected. Confirmed schematic blocks remain in the world.");
            return;
        }
        if (client.gameMode.getPlayerMode() != GameType.CREATIVE) {
            finish(client, job, "Build stopped because Creative mode is no longer active. Already confirmed blocks were left in place.");
            return;
        }
        if (job.paused) return;

        long now = client.level.getGameTime();
        if (job.pending != null) {
            BlockState observed = client.level.getBlockState(job.pending.position);
            if (observed.equals(job.pending.expected)) {
                job.placed++;
                job.index++;
                job.pending = null;
                job.attempts = 0;
                if (job.placed % 20 == 0 || job.index >= job.blocks.size()) {
                    status = "Schematic build • " + job.placed + " / " + job.blocks.size() + " confirmed";
                    NoteClientHud.show(status);
                }
            } else if (!observed.isAir()) {
                job.skipped++;
                job.index++;
                job.pending = null;
                job.attempts = 0;
            } else if (now - job.pending.sentAt >= CONFIRM_TIMEOUT_TICKS) {
                job.pending = null;
                job.attempts++;
                if (job.attempts >= MAX_ATTEMPTS_PER_BLOCK) {
                    job.waitingForPlayer = true;
                    status = "Waiting at block " + (job.index + 1) + ": move closer or check server placement permissions/reach.";
                    NoteClientHud.warn(status);
                }
            }
            if (job.pending != null || job.waitingForPlayer) return;
        }

        if (job.waitingForPlayer) {
            if (job.index >= job.blocks.size()) {
                job.waitingForPlayer = false;
            } else {
                PreparedBlock waitingBlock = job.blocks.get(job.index);
                BlockPos waitingPos = worldPosition(job, waitingBlock);
                if (!client.level.hasChunkAt(waitingPos)) return;
                if (!client.level.getBlockState(waitingPos).isAir()) {
                    job.skipped++;
                    job.index++;
                    job.attempts = 0;
                    job.waitingForPlayer = false;
                } else if (findPlacementHit(client, waitingPos) == null) {
                    return;
                } else {
                    job.waitingForPlayer = false;
                    job.attempts = 0;
                }
            }
        }

        if (job.index >= job.blocks.size()) {
            finish(client, job, "Schematic complete • " + job.placed + " placed • " + job.skipped
                    + " occupied cells skipped. The placed blocks are retained.");
            return;
        }

        PreparedBlock source = job.blocks.get(job.index);
        BlockState expected = source.state.rotate(rotationFor(job.preview.forward));
        BlockPos target = worldPosition(job, source);
        if (!client.level.hasChunkAt(target)) {
            job.waitingForPlayer = true;
            status = "Waiting for the target chunk to load at " + target.toShortString() + ". Move closer.";
            NoteClientHud.warn(status);
            return;
        }
        BlockState existing = client.level.getBlockState(target);
        if (!existing.isAir()) {
            job.skipped++;
            job.index++;
            job.attempts = 0;
            return;
        }

        BlockHitResult hit = findPlacementHit(client, target);
        if (hit == null) {
            job.waitingForPlayer = true;
            status = "Waiting for a reachable solid support next to " + target.toShortString()
                    + ". Move closer or provide a support block; no scaffold is created.";
            NoteClientHud.warn(status);
            return;
        }
        job.waitingForPlayer = false;
        ItemStack stack = new ItemStack(source.item, 1);
        Map<String, String> properties = serializedProperties(expected);
        if (!properties.isEmpty()) stack.set(DataComponents.BLOCK_STATE, new BlockItemStateProperties(properties));
        LocalPlayer player = client.player;
        player.getInventory().setSelectedSlot(WORKING_SLOT);
        player.getInventory().setItem(WORKING_SLOT, stack.copy());
        client.gameMode.handleCreativeModeItemAdd(stack.copy(), 36 + WORKING_SLOT);
        net.minecraft.world.InteractionResult interaction = client.gameMode.useItemOn(
                player, InteractionHand.MAIN_HAND, hit);
        if (interaction != null && interaction.consumesAction()) {
            job.pending = new PendingBlock(target, expected, now);
        } else {
            job.attempts++;
            if (job.attempts >= MAX_ATTEMPTS_PER_BLOCK) {
                job.waitingForPlayer = true;
                status = "Server did not accept this placement at " + target.toShortString()
                        + ". Check block support, server permissions, and normal reach.";
                NoteClientHud.warn(status);
            }
        }
    }

    private static Map<String, String> serializedProperties(BlockState state) {
        Map<String, String> values = new HashMap<>();
        for (Property<?> property : state.getProperties()) {
            propertyValueUnchecked(property, state, values);
        }
        return values;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void propertyValueUnchecked(Property property, BlockState state, Map<String, String> target) {
        Comparable value = (Comparable) state.getValue(property);
        target.put(property.getName(), property.getName(value));
    }

    private static BlockPos originFor(LocalPlayer player, Preview current) {
        Direction forward = current.forward;
        // Center the schematic in front of the player. The user can rotate the preview
        // before build; moving the player while browsing carries the ghost with them.
        return player.blockPosition().relative(forward, 4);
    }

    private static BlockPos worldPosition(BuildJob job, PreparedBlock block) {
        int centeredX = block.x - job.preview.schematic.width() / 2;
        int centeredZ = block.z - job.preview.schematic.length() / 2;
        return job.origin.relative(job.preview.forward.getClockWise(), centeredX)
                .relative(job.preview.forward, centeredZ).above(block.y);
    }

    private static Rotation rotationFor(Direction forward) {
        return switch (forward) {
            case SOUTH -> Rotation.NONE;
            case WEST -> Rotation.CLOCKWISE_90;
            case NORTH -> Rotation.CLOCKWISE_180;
            case EAST -> Rotation.COUNTERCLOCKWISE_90;
            default -> Rotation.NONE;
        };
    }

    private static BlockHitResult findPlacementHit(Minecraft client, BlockPos target) {
        LocalPlayer player = client.player;
        double reach = player.getAttributeValue(Attributes.BLOCK_INTERACTION_RANGE);
        double maxDistance = Math.max(0.5, reach - 0.5);
        Vec3 eye = player.getEyePosition();
        BlockHitResult best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Direction offset : Direction.values()) {
            BlockPos neighbor = target.relative(offset);
            BlockState anchor = client.level.getBlockState(neighbor);
            if (anchor.isAir() || anchor.hasBlockEntity()
                    || !anchor.isFaceSturdy(client.level, neighbor, offset.getOpposite())) continue;
            Vec3 location = Vec3.atCenterOf(neighbor).add(
                    offset.getOpposite().getStepX() * 0.5,
                    offset.getOpposite().getStepY() * 0.5,
                    offset.getOpposite().getStepZ() * 0.5);
            double distance = eye.distanceTo(location);
            if (distance > maxDistance || distance >= bestDistance) continue;
            best = new BlockHitResult(location, offset.getOpposite(), neighbor, false);
            bestDistance = distance;
        }
        return best;
    }

    public static void togglePause(Minecraft client) {
        BuildJob job = activeJob;
        if (job == null) return;
        job.paused = !job.paused;
        status = job.paused ? "Schematic build paused • P to resume • O to stop"
                : "Schematic build resumed • " + job.placed + " / " + job.blocks.size() + " confirmed";
        NoteClientHud.show(status);
    }

    public static void cancel(Minecraft client) {
        BuildJob job = activeJob;
        if (job == null) return;
        finish(client, job, "Schematic build stopped • " + job.placed
                + " confirmed blocks were left in the world. No automatic cleanup was performed.");
    }

    public static void onDisconnect(Minecraft client) {
        BuildJob job = activeJob;
        if (job != null) {
            // Restore only our temporary hotbar selection locally. Do not send
            // removal packets: confirmed world changes remain owned by the server.
            if (client != null && client.player != null) {
                client.player.getInventory().setItem(WORKING_SLOT, job.originalWorkingStack.copy());
                client.player.getInventory().setSelectedSlot(job.originalSlot);
            }
            activeJob = null;
        }
        loadGeneration++;
    }

    private static void finish(Minecraft client, BuildJob job, String message) {
        if (client != null && client.player != null) {
            client.player.getInventory().setItem(WORKING_SLOT, job.originalWorkingStack.copy());
            if (client.gameMode != null && client.gameMode.getPlayerMode() == GameType.CREATIVE) {
                client.gameMode.handleCreativeModeItemAdd(job.originalWorkingStack.copy(), 36 + WORKING_SLOT);
            }
            client.player.getInventory().setSelectedSlot(job.originalSlot);
        }
        activeJob = null;
        status = message;
        NoteClientHud.show(message);
    }

    private static void renderPreview(net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext context) {
        Preview current = preview;
        Minecraft client = Minecraft.getInstance();
        if (current == null || client.level == null || client.player == null) return;
        BuildJob job = activeJob;
        BlockPos origin = job == null ? current.origin : job.origin;
        if (origin == null) return;
        Vec3 camera = context.gameRenderer().mainCamera().position();
        PoseStack pose = context.poseStack();
        int rendered = 0;
        for (PreparedBlock block : current.blocks) {
            BlockPos pos;
            if (job == null) {
                int x = block.x - current.schematic.width() / 2;
                int z = block.z - current.schematic.length() / 2;
                pos = origin.relative(current.forward.getClockWise(), x)
                        .relative(current.forward, z).above(block.y);
            } else {
                pos = worldPosition(job, block);
            }
            double dx = pos.getX() + 0.5 - camera.x;
            double dy = pos.getY() + 0.5 - camera.y;
            double dz = pos.getZ() + 0.5 - camera.z;
            if (dx * dx + dy * dy + dz * dz > (double) MAX_RENDER_DISTANCE * MAX_RENDER_DISTANCE) continue;
            BlockState state = block.state.rotate(rotationFor(current.forward));
            if (state.getRenderShape() == RenderShape.INVISIBLE) continue;
            try {
                BlockStateModel model = client.getModelManager().getBlockStateModelSet().get(state);
                List<BlockStateModelPart> parts = new ArrayList<>();
                model.collectParts(RandomSource.create(state.getSeed(pos)), parts);
                if (parts.isEmpty()) continue;
                pose.pushPose();
                try {
                    pose.translate(pos.getX() - camera.x, pos.getY() - camera.y, pos.getZ() - camera.z);
                    int outline = client.level.getBlockState(pos).isAir() ? 0xFF42E879 : 0xFFFF4A4A;
                    context.submitNodeCollector().submitBlockModel(pose, RenderTypes.translucentMovingBlock(),
                            parts, new int[0], LightCoordsUtil.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, outline);
                } finally {
                    pose.popPose();
                }
            } catch (RuntimeException ignored) {
                // A broken resource-pack model should not prevent other schematic cells from rendering.
            }
            rendered++;
            if (rendered >= MAX_RENDERED_PREVIEW_BLOCKS) break;
        }
    }

    private static String rootMessage(Throwable error) {
        Throwable current = error;
        while (current.getCause() != null) current = current.getCause();
        return current.getMessage() == null ? current.getClass().getSimpleName() : current.getMessage();
    }

    private static final class Preview {
        final String name;
        final SpongeSchematicReader.Schematic schematic;
        final List<PreparedBlock> blocks;
        final Direction forward;
        final boolean followPlayer;
        BlockPos origin;
        Preview(String name, SpongeSchematicReader.Schematic schematic, List<PreparedBlock> blocks,
                Direction forward, boolean followPlayer) {
            this.name = name;
            this.schematic = schematic;
            this.blocks = blocks;
            this.forward = forward;
            this.followPlayer = followPlayer;
        }
    }

    private static final class BuildJob {
        final Preview preview;
        final List<PreparedBlock> blocks;
        final BlockPos origin;
        final int originalSlot;
        final ItemStack originalWorkingStack;
        int index;
        int placed;
        int skipped;
        int attempts;
        boolean paused;
        boolean waitingForPlayer;
        PendingBlock pending;
        BuildJob(Preview preview, BlockPos origin, int originalSlot, ItemStack originalWorkingStack) {
            this.preview = preview;
            this.blocks = preview.blocks;
            this.origin = origin;
            this.originalSlot = originalSlot;
            this.originalWorkingStack = originalWorkingStack;
        }
    }

    private record PreparedBlock(int x, int y, int z, BlockState state, Item item) {}
    private record PendingBlock(BlockPos position, BlockState expected, long sentAt) {}
    private record PreparedSchematic(SpongeSchematicReader.Schematic schematic,
                                     List<PreparedBlock> blocks, String error) {}

    /** Separate holder to keep the file-system root public to the browser without exposing mutable state. */
    public static final class NoteClientSchematics {
        private NoteClientSchematics() {}
        public static Path folder() {
            return net.fabricmc.loader.api.FabricLoader.getInstance().getGameDir()
                    .resolve("noteclient").resolve("schematics");
        }
    }
}
