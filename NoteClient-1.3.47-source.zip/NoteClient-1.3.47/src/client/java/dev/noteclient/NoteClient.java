package dev.noteclient;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import dev.noteclient.network.BuildProgressPayload;
import dev.noteclient.network.BuildRequestPayload;
import dev.noteclient.network.BuildControlPayload;
import dev.noteclient.network.AuraControlPayload;
import dev.noteclient.network.AuraStatusPayload;
import dev.noteclient.plan.NoteBlockPlanner.PlanResult;
import dev.noteclient.voxel.client.VoxelStudioClient;
import dev.noteclient.voxel.client.VoxelStudioScreen;
import dev.noteclient.voxel.core.VoxelStudioConfig;
import dev.noteclient.schematic.SchematicBuilder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class NoteClient implements ClientModInitializer {
    private static final String MOD_ID = "noteclient";
    private static KeyMapping openNotebotKey;
    private static KeyMapping pauseBuildKey;
    private static KeyMapping cancelBuildKey;
    private static KeyMapping retryStatueKey;
    private static PendingCompanionFallback pendingCompanionFallback;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MOD_ID, "main")
        );
        NoteClientConfig.load();
        PlayerStatueBuilder.initialize();
        SchematicBuilder.initialize();
        NoteClientHud.setEnabled(NoteClientConfig.hudEnabled());
        installPresets();
        NoteClientHud.register();
        VoxelStudioClient.initialize();

        // Register this client's view of the custom payload types before any
        // receiver is installed. The optional server companion registers the
        // same IDs on its own side; that registration does not populate the
        // client's local payload registry. Without these calls Fabric rejects
        // registerGlobalReceiver with "no payload type has been registered".
        PayloadTypeRegistry.serverboundPlay().register(
                BuildRequestPayload.TYPE, BuildRequestPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(
                BuildControlPayload.TYPE, BuildControlPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(
                BuildProgressPayload.TYPE, BuildProgressPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(
                AuraControlPayload.TYPE, AuraControlPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(
                AuraStatusPayload.TYPE, AuraStatusPayload.CODEC);

        ClientPlayNetworking.registerGlobalReceiver(BuildProgressPayload.TYPE, (payload, context) ->
                acceptBuildProgress(payload));
        ClientPlayNetworking.registerGlobalReceiver(AuraStatusPayload.TYPE, (payload, context) ->
                AuraEffect.acceptServerStatus(Minecraft.getInstance(), payload));

        // A custom /reach command is specific to the server that exposes it.
        // Never carry the 100-block planning hint to another server.
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            NoteClientConfig.setServerReachOverride(0);
            AuraEffect.onDisconnect();
            PlayerStatueBuilder.onDisconnect();
            SchematicBuilder.onDisconnect(client);
            RedstoneSequencerBuilder.onDisconnect(client);
        });

        openNotebotKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.noteclient.open_notebot",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_N,
                category
        ));
        pauseBuildKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.noteclient.pause_build",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_P,
                category
        ));
        cancelBuildKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.noteclient.cancel_build",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_O,
                category
        ));
        retryStatueKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.noteclient.retry_statue",
                InputConstants.Type.KEYSYM,
                VoxelStudioConfig.KEY_REBUILD,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // No slash-command backend is loaded. Ordinary multiplayer uses
            // physical interactions; an installed NoteClient companion remains
            // an explicit, server-authorized optional backend.
            VanillaServerBuilder.tick(client);
            RedstoneSequencerBuilder.tick(client);
            AuraEffect.tick(client);
            PlayerStatueBuilder.tick(client);
            SchematicBuilder.tick(client);
            while (openNotebotKey.consumeClick()) {
                if (client.player != null) {
                    client.gui.setScreen(new SongBrowserScreen(client.gui.screen()));
                }
            }
            while (pauseBuildKey.consumeClick()) {
                if (RedstoneSequencerBuilder.hasActiveJob()) {
                    RedstoneSequencerBuilder.togglePause(client);
                } else if (PlayerStatueBuilder.hasTrackedStatue()) {
                    PlayerStatueBuilder.togglePause(client);
                } else {
                    sendBuildControl(client, BuildControlPayload.TOGGLE_PAUSE);
                }
            }
            while (retryStatueKey.consumeClick()) {
                if (client.gui.screen() instanceof VoxelStudioScreen studio) {
                    VoxelStudioClient.rebuild(studio.modelForBuild());
                } else if (PlayerStatueBuilder.hasTrackedStatue()) {
                    PlayerStatueBuilder.retry(client);
                } else {
                    NoteClientHud.warn("R retries a tracked player statue. Open the Player tab and build/load a skin first.");
                }
            }
            while (cancelBuildKey.consumeClick()) {
                if (RedstoneSequencerBuilder.hasActiveJob()) {
                    RedstoneSequencerBuilder.cancel(client);
                } else if (PlayerStatueBuilder.hasTrackedStatue()) {
                    PlayerStatueBuilder.remove(client);
                } else {
                    sendBuildControl(client, BuildControlPayload.CANCEL);
                }
            }
        });

        System.out.println("[NoteClient] Loaded. N = control center, P = pause/resume, R = retry statue, O = undo newest statue or clean up song. Server Aura uses owner-authorized temporary world blocks through the optional server companion; Player Builder builds full 3D layered skin cuboids.");
    }

    static void sendBuildControl(Minecraft client, int action) {
        if (client.player == null) return;
        if (RedstoneSequencerBuilder.hasActiveJob()) {
            if (action == BuildControlPayload.TOGGLE_PAUSE) RedstoneSequencerBuilder.togglePause(client);
            else RedstoneSequencerBuilder.cancel(client);
            return;
        }
        if (SchematicBuilder.hasActiveJob()) {
            if (action == BuildControlPayload.TOGGLE_PAUSE) SchematicBuilder.togglePause(client);
            else SchematicBuilder.cancel(client);
            return;
        }
        if (VanillaServerBuilder.hasActiveJob() || !ClientPlayNetworking.canSend(BuildControlPayload.TYPE)) {
            VanillaServerBuilder.control(client, action);
            return;
        }
        ClientPlayNetworking.send(new BuildControlPayload(action));
    }

    /** Retains a parsed arrangement until the optional server companion accepts or denies it. */
    static void setPendingCompanionFallback(PlanResult plan, int tempoHundredths, int songLengthTicks) {
        pendingCompanionFallback = new PendingCompanionFallback(plan, tempoHundredths, songLengthTicks);
    }

    private static void acceptBuildProgress(BuildProgressPayload payload) {
        PendingCompanionFallback fallback = pendingCompanionFallback;
        if (fallback != null && isPermissionOrPolicyDenial(payload)) {
            pendingCompanionFallback = null;
            Minecraft client = Minecraft.getInstance();

            // A denied server-side request is not retried or worked around. When
            // possible, use the same ordinary player-interaction builder that is
            // used on servers without the companion. Custom anchors/replacement
            // remain server-only options and are never translated into a bypass.
            if (BuilderPreferences.isCustomAnchor() || BuilderPreferences.replaceExisting()) {
                String message = "The server companion denied this request. Normal multiplayer fallback needs Use Player Anchor and Replace OFF; the server's permission decision was respected.";
                BuildClientState.reset(message);
                NoteClientHud.warn(message);
                return;
            }

            BuildClientState.reset("The server companion did not authorize this build. Switching to normal player interactions; no privileged retry will be sent.");
            if (!VanillaServerBuilder.start(client, fallback.plan,
                    fallback.tempoHundredths, fallback.songLengthTicks)) {
                NoteClientHud.warn(BuildClientState.message());
            } else {
                NoteClientHud.show("Using the standard no-command builder. The server's companion permission check was respected.");
            }
            return;
        }

        // Any non-denial progress response means the companion accepted or is
        // processing the request, so no fallback should be attempted later.
        pendingCompanionFallback = null;
        BuildClientState.accept(payload);
    }

    private static boolean isPermissionOrPolicyDenial(BuildProgressPayload payload) {
        return payload.finished() && payload.total() == 0 && payload.layer() == 0
                && payload.message() != null
                && payload.message().startsWith("Owner build denied");
    }

    private record PendingCompanionFallback(PlanResult plan, int tempoHundredths, int songLengthTicks) {}

    static Path getSongsFolder() {
        return FabricLoader.getInstance().getGameDir().resolve("noteclient").resolve("songs");
    }

    static Path getSchematicsFolder() {
        return SchematicBuilder.NoteClientSchematics.folder();
    }

    private static void installPresets() {
        Path presetFolder = getSongsFolder().resolve("presets");
        String[] presets = {"major_steps.nbs", "copper_signals.nbs", "block_groove.nbs"};
        try {
            Files.createDirectories(presetFolder);
            for (String preset : presets) {
                Path destination = presetFolder.resolve(preset);
                if (Files.exists(destination)) continue;
                try (var stream = NoteClient.class.getResourceAsStream("/presets/" + preset)) {
                    if (stream != null) Files.copy(stream, destination);
                }
            }
        } catch (IOException exception) {
            System.err.println("[NoteClient] Could not install demo presets: " + exception.getMessage());
        }
    }
}
