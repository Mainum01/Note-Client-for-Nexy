package dev.noteclient.server;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Server-owner-controlled limits for the privileged bulk builder. */
public final class NoteClientServerConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir()
            .resolve("noteclient-server.properties");

    public final int maxBlockChangesPerTick;
    public final int maxCells;
    public final int maxOffset;
    public final int maxAnchorDistance;
    public final boolean allowReplaceExisting;
    public final boolean restoreAfterSong;
    public final boolean autoSwitchToSurvival;
    public final boolean allowServerAura;
    public final int maxAuraBlocks;
    public final int auraUpdateIntervalTicks;
    public final int maxActiveAuras;
    public final boolean serverAuraRequiresOp;

    private NoteClientServerConfig(Properties p) {
        maxBlockChangesPerTick = clamp(integer(p, "maxBlockChangesPerTick", 256), 1, 2048);
        maxCells = clamp(integer(p, "maxCells", 4000), 1, 4000);
        maxOffset = clamp(integer(p, "maxOffset", 512), 1, 512);
        maxAnchorDistance = clamp(integer(p, "maxAnchorDistance", 1024), 16, 30_000_000);
        allowReplaceExisting = bool(p, "allowReplaceExisting", false);
        // New key deliberately ignores the legacy autoRestore entry. Existing server
        // configs that once opted into destructive cleanup now retain arrangements
        // safely unless the owner explicitly sets restoreAfterSong=true.
        restoreAfterSong = bool(p, "restoreAfterSong", false);
        autoSwitchToSurvival = bool(p, "autoSwitchToSurvival", true);
        // Real world Aura animation is opt-in because it performs temporary
        // server-authoritative block updates visible to nearby players.
        allowServerAura = bool(p, "allowServerAura", false);
        maxAuraBlocks = clamp(integer(p, "maxAuraBlocks", 200), 48, 240);
        auraUpdateIntervalTicks = clamp(integer(p, "auraUpdateIntervalTicks", 5), 3, 20);
        maxActiveAuras = clamp(integer(p, "maxActiveAuras", 1), 1, 4);
        serverAuraRequiresOp = bool(p, "serverAuraRequiresOp", true);
    }

    public static NoteClientServerConfig load() {
        Properties p = new Properties();
        try {
            Files.createDirectories(FILE.getParent());
            boolean writeConfig = !Files.exists(FILE);
            if (Files.exists(FILE)) {
                try (InputStream in = Files.newInputStream(FILE)) { p.load(in); }
            } else {
                p.setProperty("maxBlockChangesPerTick", "256");
                p.setProperty("maxCells", "4000");
                p.setProperty("maxOffset", "512");
                p.setProperty("maxAnchorDistance", "1024");
                p.setProperty("allowReplaceExisting", "false");
                p.setProperty("autoSwitchToSurvival", "true");
                p.setProperty("allowServerAura", "false");
                p.setProperty("maxAuraBlocks", "200");
                p.setProperty("auraUpdateIntervalTicks", "5");
                p.setProperty("maxActiveAuras", "1");
                p.setProperty("serverAuraRequiresOp", "true");
            }
            // Migrate existing files, including those with legacy autoRestore=true.
            // That old key is intentionally ignored; the new explicit setting defaults
            // to retention so a prior installation cannot undo a completed build.
            if (!p.containsKey("restoreAfterSong")) {
                p.setProperty("restoreAfterSong", "false");
                writeConfig = true;
            }
            if (writeConfig) {
                try (OutputStream out = Files.newOutputStream(FILE)) {
                    p.store(out, "NoteClient 1.3.45 server-owner configuration");
                }
            }
        } catch (IOException exception) {
            System.err.println("[NoteClient] Could not read/write server config: " + exception.getMessage());
        }
        return new NoteClientServerConfig(p);
    }

    private static int integer(Properties p, String key, int fallback) {
        try { return Integer.parseInt(p.getProperty(key, Integer.toString(fallback)).trim()); }
        catch (RuntimeException ignored) { return fallback; }
    }

    private static boolean bool(Properties p, String key, boolean fallback) {
        return Boolean.parseBoolean(p.getProperty(key, Boolean.toString(fallback)).trim());
    }

    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }

}
