package dev.noteclient.network;

import io.netty.handler.codec.DecoderException;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/**
 * Owner-authorized construction request.
 * Cell tuples are [instrumentId, pitchLevel, originalNbsKey, right, up, forward].
 * Event tuples are [songTick, cellIndex, effectiveVolume, effectivePanning, finePitchCents].
 * Coordinates are relative to the anchor block supplied in the same payload.
 */
public record BuildRequestPayload(
        int[] cells,
        int[] events,
        int tempoHundredths,
        int songLengthTicks,
        int anchorX,
        int anchorY,
        int anchorZ,
        boolean replaceExisting,
        boolean redstoneSetup
) implements CustomPacketPayload {
    public static final int MAX_CELLS = 4_000;
    public static final int MAX_EVENTS = 65_536;
    public static final int VALUES_PER_CELL = 6;
    public static final int VALUES_PER_EVENT = 5;
    public static final int MAX_OFFSET = 512;
    public static final Identifier ID = Identifier.fromNamespaceAndPath("noteclient", "build_request_v5");
    public static final Type<BuildRequestPayload> TYPE = new Type<>(ID);

    public static final StreamCodec<RegistryFriendlyByteBuf, BuildRequestPayload> CODEC = StreamCodec.of(
            BuildRequestPayload::encode,
            BuildRequestPayload::decode
    );

    public BuildRequestPayload {
        if (cells == null || events == null || cells.length == 0
                || cells.length % VALUES_PER_CELL != 0
                || cells.length / VALUES_PER_CELL > MAX_CELLS
                || events.length % VALUES_PER_EVENT != 0
                || events.length / VALUES_PER_EVENT > MAX_EVENTS
                || tempoHundredths < 0 || tempoHundredths > 100_000
                || (events.length > 0 && tempoHundredths == 0)
                || songLengthTicks < 0 || songLengthTicks > 2_000_000
                || Math.abs((long) anchorX) > 30_000_000L
                || anchorY < -2048 || anchorY > 4096
                || Math.abs((long) anchorZ) > 30_000_000L) {
            throw new IllegalArgumentException("Invalid NoteClient build request size, anchor, or timing.");
        }

        int cellCount = cells.length / VALUES_PER_CELL;
        for (int i = 0; i < cells.length; i += VALUES_PER_CELL) {
            int instrument = cells[i];
            int pitch = cells[i + 1];
            int nbsKey = cells[i + 2];
            int right = cells[i + 3];
            int up = cells[i + 4];
            int forward = cells[i + 5];
            if (instrument < 0 || instrument >= 20 || pitch < 0 || pitch >= 25
                    || nbsKey < 0 || nbsKey > 87
                    || Math.abs((long) right) > MAX_OFFSET
                    || Math.abs((long) up) > MAX_OFFSET
                    || Math.abs((long) forward) > MAX_OFFSET) {
                throw new IllegalArgumentException("Invalid NoteClient cell instrument, pitch, or coordinate.");
            }
        }

        int previousTick = -1;
        for (int i = 0; i < events.length; i += VALUES_PER_EVENT) {
            int tick = events[i];
            int cellIndex = events[i + 1];
            int volume = events[i + 2];
            int panning = events[i + 3];
            int finePitchCents = events[i + 4];
            if (tick < previousTick || tick < 0 || cellIndex < 0 || cellIndex >= cellCount
                    || volume < 0 || volume > 100 || panning < 0 || panning > 200
                    || finePitchCents < -1200 || finePitchCents > 1200) {
                throw new IllegalArgumentException("Invalid NoteClient event timeline or playback mix values.");
            }
            previousTick = tick;
        }

        cells = cells.clone();
        events = events.clone();
    }

    @Override public int[] cells() { return cells.clone(); }
    @Override public int[] events() { return events.clone(); }

    private static void encode(RegistryFriendlyByteBuf buffer, BuildRequestPayload payload) {
        buffer.writeVarInt(payload.cells.length);
        for (int value : payload.cells) buffer.writeVarInt(value);
        buffer.writeVarInt(payload.events.length);
        for (int value : payload.events) buffer.writeVarInt(value);
        buffer.writeVarInt(payload.tempoHundredths);
        buffer.writeVarInt(payload.songLengthTicks);
        buffer.writeVarInt(payload.anchorX);
        buffer.writeVarInt(payload.anchorY);
        buffer.writeVarInt(payload.anchorZ);
        buffer.writeBoolean(payload.replaceExisting);
        buffer.writeBoolean(payload.redstoneSetup);
    }

    private static BuildRequestPayload decode(RegistryFriendlyByteBuf buffer) {
        int cellLength = buffer.readVarInt();
        if (cellLength <= 0 || cellLength % VALUES_PER_CELL != 0
                || cellLength > MAX_CELLS * VALUES_PER_CELL) {
            throw new DecoderException("Invalid NoteClient cell packet length: " + cellLength);
        }
        int[] cells = new int[cellLength];
        for (int i = 0; i < cellLength; i++) cells[i] = buffer.readVarInt();

        int eventLength = buffer.readVarInt();
        if (eventLength < 0 || eventLength % VALUES_PER_EVENT != 0
                || eventLength > MAX_EVENTS * VALUES_PER_EVENT) {
            throw new DecoderException("Invalid NoteClient event packet length: " + eventLength);
        }
        int[] events = new int[eventLength];
        for (int i = 0; i < eventLength; i++) events[i] = buffer.readVarInt();

        return new BuildRequestPayload(
                cells, events,
                buffer.readVarInt(), buffer.readVarInt(),
                buffer.readVarInt(), buffer.readVarInt(), buffer.readVarInt(),
                buffer.readBoolean(), buffer.readBoolean()
        );
    }

    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
