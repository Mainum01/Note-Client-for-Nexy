package dev.noteclient;

import dev.noteclient.network.BuildControlPayload;
import dev.noteclient.network.BuildProgressPayload;
import dev.noteclient.network.BuildRequestPayload;
import dev.noteclient.network.AuraControlPayload;
import dev.noteclient.network.AuraStatusPayload;
import dev.noteclient.plan.NoteBlockPlanner;
import dev.noteclient.server.NoteClientServerConfig;
import dev.noteclient.voxel.server.VoxelStudioServerManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Server companion for NoteClient Owner Mode.
 *
 * This is an explicit, operator-authorized server feature. It uses the server's
 * world API rather than faking player interactions, so it can place floating
 * note blocks at configured remote coordinates and trigger real block events.
 * The server owner controls limits in config/noteclient-server.properties.
 */
public final class NoteClientCommon implements ModInitializer {
    private static final int PLAYBACK_DELAY_TICKS = 20;
    private static final Map<UUID, BuildJob> JOBS = new HashMap<>();
    private static NoteClientServerConfig config;

    @Override
    public void onInitialize() {
        config = NoteClientServerConfig.load();

        PayloadTypeRegistry.serverboundPlay().register(BuildRequestPayload.TYPE, BuildRequestPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(BuildControlPayload.TYPE, BuildControlPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(BuildProgressPayload.TYPE, BuildProgressPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(AuraControlPayload.TYPE, AuraControlPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(AuraStatusPayload.TYPE, AuraStatusPayload.CODEC);

        // Optional server-authoritative voxel character builder and cleanup journal.
        VoxelStudioServerManager.initialize();

        ServerPlayNetworking.registerGlobalReceiver(AuraControlPayload.TYPE,
                (payload, context) -> AuraServerEffect.handleRequest(context.player(), payload.enabled(), config));
        ServerPlayNetworking.registerGlobalReceiver(BuildRequestPayload.TYPE,
                (payload, context) -> beginBuild(context.player(), payload));
        ServerPlayNetworking.registerGlobalReceiver(BuildControlPayload.TYPE,
                (payload, context) -> controlBuild(context.player(), payload));
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tickJobs(server);
            AuraServerEffect.tick(server, config);
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            AuraServerEffect.stopAll();
            restoreAllOnShutdown(server);
        });

        System.out.println("[NoteClient] Owner server component ready. Multiplayer bulk builds require operator permission. "
                + "Budget=" + config.maxBlockChangesPerTick + " blocks/tick, maxCells=" + config.maxCells
                + ", maxOffset=" + config.maxOffset
                + ", serverAura=" + config.allowServerAura
                + ". Targets must already be in loaded chunks. Config: config/noteclient-server.properties");
    }


    /** Restore all active in-memory journals during a normal server shutdown. */
    private static void restoreAllOnShutdown(MinecraftServer server) {
        for (BuildJob job : JOBS.values()) {
            // Phase 4 is an explicitly retained arrangement. Do not undo a finished
            // song or physical redstone sequencer just because the server is stopping.
            // The in-memory undo journal is not persisted across restarts, so owners
            // should keep a backup and manually remove retained structures after restart.
            if (job.phase != 4) {
                List<JournalEntry> journal = job.journal;
                for (int i = journal.size() - 1; i >= 0; i--) {
                    JournalEntry entry = journal.get(i);
                    if (job.level.getBlockState(entry.position).equals(entry.placedState)) {
                        job.level.setBlock(entry.position, entry.originalState, 3);
                    }
                }
            }
            releaseChunkTickets(job.level, job.heldChunkTickets);
            job.chunkTicketsReleased = true;
        }
        JOBS.clear();
        System.out.println("[NoteClient] Restored unfinished journals; completed retained arrangements were left in the world.");
    }

    private static void beginBuild(ServerPlayer player, BuildRequestPayload payload) {
        MinecraftServer server = player.level().getServer();
        if (server == null) {
            send(player, 0, 0, 0, 0, true, false, "Owner build denied: server context unavailable.");
            return;
        }
        if (!server.isSingleplayer() && !server.getPlayerList().isOp(player.nameAndId())) {
            send(player, 0, 0, 0, 0, true, false,
                    "Owner build denied. This server requires operator permission for NoteClient bulk construction.");
            return;
        }
        if (payload.cells().length / BuildRequestPayload.VALUES_PER_CELL > config.maxCells) {
            send(player, 0, 0, 0, 0, true, false,
                    "Owner build denied. The server's maxCells setting is " + config.maxCells + ".");
            return;
        }
        if (payload.replaceExisting() && !config.allowReplaceExisting) {
            send(player, 0, 0, 0, 0, true, false,
                    "Owner build denied. The server owner has disabled replaceExisting in noteclient-server.properties.");
            return;
        }

        BuildJob active = JOBS.get(player.getUUID());
        if (active != null) {
            active.pendingBuild = payload;
            active.paused = false;
            active.beginCleanup("Replacing the previous NoteClient arrangement before starting the new song.");
            send(player, active.placed, active.totalCount(), active.skipped, 3, false, false,
                    "Song swap queued. Restoring the previous arrangement first...");
            return;
        }

        prepareAndStart(player, payload);
    }

    private static void prepareAndStart(ServerPlayer player, BuildRequestPayload payload) {
        ServerLevel level = player.level();
        BlockPos anchor = new BlockPos(payload.anchorX(), payload.anchorY(), payload.anchorZ());
        double dx = player.getX() - (anchor.getX() + 0.5);
        double dy = player.getY() - (anchor.getY() + 0.5);
        double dz = player.getZ() - (anchor.getZ() + 0.5);
        double anchorDistanceSquared = dx * dx + dy * dy + dz * dz;
        double maxDistance = config.maxAnchorDistance;
        if (anchorDistanceSquared > maxDistance * maxDistance) {
            send(player, 0, 0, 0, 0, true, false,
                    "Owner build denied. Anchor exceeds the server's maxAnchorDistance=" + config.maxAnchorDistance + ".");
            return;
        }

        if (payload.redstoneSetup()) {
            prepareRedstoneAndStart(player, payload, level, anchor);
            return;
        }

        int[] cells = payload.cells();
        int[] events = payload.events();
        if (events.length > 0 && payload.tempoHundredths() <= 0) {
            send(player, 0, 0, 0, 0, true, false, "Owner build denied. Song tempo must be greater than zero.");
            return;
        }
        int cellCount = cells.length / BuildRequestPayload.VALUES_PER_CELL;
        int[] instrumentIds = new int[cellCount];
        int[] cellKeys = new int[cellCount];
        for (int i = 0; i < cellCount; i++) {
            int cellOffset = i * BuildRequestPayload.VALUES_PER_CELL;
            instrumentIds[i] = cells[cellOffset];
            cellKeys[i] = cells[cellOffset + 2];
        }
        int previousTick = -1;
        for (int i = 0; i < events.length; i += BuildRequestPayload.VALUES_PER_EVENT) {
            int tick = events[i];
            int cell = events[i + 1];
            if (tick < previousTick || tick < 0 || cell < 0 || cell >= cellCount) {
                send(player, 0, 0, 0, 0, true, false, "Owner build denied. Song event timeline is invalid.");
                return;
            }
            previousTick = tick;
        }

        Direction forward = Direction.fromYRot(player.getYRot());
        Direction right = forward.getClockWise();
        List<Operation> operations = new ArrayList<>(cellCount);
        BlockPos[] notePositions = new BlockPos[cellCount];
        BlockState[] expectedStates = new BlockState[cellCount];
        Set<BlockPos> unique = new HashSet<>();
        Set<Long> acquiredChunkTickets = new HashSet<>();
        int skipped = 0;
        int alreadyMatching = 0;
        int skippedOccupied = 0;
        int skippedUnloaded = 0;
        int skippedBounds = 0;
        int skippedSoundSpace = 0;

        List<NoteBlockPlanner.Instrument> instruments = NoteBlockPlanner.instruments();
        Block noteBlock = Blocks.NOTE_BLOCK;
        for (int i = 0; i < cellCount; i++) {
            int offset = i * BuildRequestPayload.VALUES_PER_CELL;
            int instrumentId = cells[offset];
            int pitch = cells[offset + 1];
            // BuildRequestPayload cell tuple is [instrument, pitch, source NBS key,
            // right, up, forward]. The NBS key is metadata, not a coordinate.
            int localRight = cells[offset + 3];
            int localUp = cells[offset + 4];
            int localForward = cells[offset + 5];

            if (instrumentId < 0 || instrumentId >= instruments.size() || pitch < 0 || pitch >= 25
                    || Math.abs(localRight) > config.maxOffset
                    || Math.abs(localUp) > config.maxOffset
                    || Math.abs(localForward) > config.maxOffset) {
                releaseChunkTickets(level, acquiredChunkTickets);
                send(player, 0, 0, 0, 0, true, false,
                        "Owner build denied. A cell exceeds the server's instrument, pitch, or offset limits.");
                return;
            }

            BlockPos pos = anchor.relative(right, localRight)
                    .offset(0, localUp, 0)
                    .relative(forward, localForward);
            if (!unique.add(pos)) {
                skipped++;
                skippedOccupied++;
                continue;
            }

            BlockPos soundSpace = pos.above();
            if (!level.getWorldBorder().isWithinBounds(pos)
                    || !level.getWorldBorder().isWithinBounds(soundSpace)
                    || level.isOutsideBuildHeight(pos)
                    || level.isOutsideBuildHeight(soundSpace)) {
                skipped++;
                skippedBounds++;
                continue;
            }

            // 26.2 does not expose a stable public API for inspecting ownership of
            // existing force-load tickets. Do not add/release tickets blindly: a
            // NoteClient cleanup must never remove a ticket created by an operator
            // or another mod. Owner Mode therefore requires target chunks to already
            // be loaded by the server.
            if (!level.hasChunkAt(pos) || !level.hasChunkAt(soundSpace)) {
                skipped++;
                skippedUnloaded++;
                continue;
            }

            if (!level.getBlockState(soundSpace).isAir()) {
                skipped++;
                skippedSoundSpace++;
                continue;
            }

            NoteBlockPlanner.Instrument instrument = instruments.get(instrumentId);
            BlockState target;
            try {
                target = withProperty(noteBlock.defaultBlockState(), "instrument", instrument.noteBlockInstrument());
                target = withProperty(target, "note", Integer.toString(pitch));
            } catch (RuntimeException exception) {
                releaseChunkTickets(level, acquiredChunkTickets);
                send(player, 0, 0, 0, 0, true, false,
                        "Owner build failed. This Minecraft build does not expose the expected note-block properties.");
                return;
            }

            BlockState current = level.getBlockState(pos);
            if (current.equals(target)) {
                // Reuse an exact matching pre-existing note block without claiming ownership of it.
                notePositions[i] = pos;
                expectedStates[i] = target;
                alreadyMatching++;
                continue;
            }

            if (!current.isAir()) {
                if (!payload.replaceExisting() || !config.allowReplaceExisting
                        || level.getBlockEntity(pos) != null) {
                    skipped++;
                    skippedOccupied++;
                    continue;
                }
            }

            operations.add(new Operation(pos, current, target, i));
            notePositions[i] = pos;
            expectedStates[i] = target;
        }

        boolean hasPlayableSlot = false;
        for (BlockPos notePosition : notePositions) {
            if (notePosition != null) { hasPlayableSlot = true; break; }
        }
        if (!hasPlayableSlot && events.length > 0) {
            releaseChunkTickets(level, acquiredChunkTickets);
            send(player, 0, 0, skipped, 0, true, false,
                    "No playable note-block positions were available. Check occupied positions, chunk loading, world bounds, and server settings.");
            return;
        }

        BuildJob job = new BuildJob(level, operations, notePositions, expectedStates,
                instrumentIds, cellKeys, events, payload.tempoHundredths(), payload.songLengthTicks(), skipped, alreadyMatching,
                acquiredChunkTickets);
        JOBS.put(player.getUUID(), job);
        send(player, job.placed, job.totalCount(), skipped, 1, false, false,
                "Owner Mode: building " + operations.size() + " floating note blocks at "
                        + anchor.getX() + ", " + anchor.getY() + ", " + anchor.getZ()
                        + ". Budget " + config.maxBlockChangesPerTick + " block updates/tick."
                        + " Skipped: occupied=" + skippedOccupied + ", unloaded=" + skippedUnloaded
                        + ", bounds=" + skippedBounds + ", sound-space=" + skippedSoundSpace + ".");
    }

    /**
     * Constructs a real, button-started repeater sequencer. The redstone signal
     * travels through ordinary repeaters and powered full blocks; each note block
     * is physically powered by the signal. This mode deliberately runs only in
     * the operator-authorized server companion, never through command/reach hacks.
     */
    private static void prepareRedstoneAndStart(ServerPlayer player, BuildRequestPayload payload,
                                                ServerLevel level, BlockPos anchor) {
        int[] cells = payload.cells();
        int[] events = payload.events();
        if (payload.tempoHundredths() <= 0 || events.length == 0
                || events.length % BuildRequestPayload.VALUES_PER_EVENT != 0) {
            send(player, 0, 0, 0, 0, true, false,
                    "Redstone setup denied. A valid, non-empty song timeline and tempo are required.");
            return;
        }
        int cellCount = cells.length / BuildRequestPayload.VALUES_PER_CELL;
        int eventCount = events.length / BuildRequestPayload.VALUES_PER_EVENT;
        if (eventCount > config.maxCells) {
            send(player, 0, 0, 0, 0, true, false,
                    "Redstone setup denied. This song has " + eventCount
                            + " note events; the server maxCells setting limits physical note blocks to "
                            + config.maxCells + ". Increase maxCells only if the server owner approves.");
            return;
        }

        // Quantize source NBS times to redstone ticks (0.1 seconds each). A
        // repeater's shortest physical delay is one redstone tick; simultaneous
        // events that land on the same redstone tick form one chord.
        Map<Integer, List<PhysicalNote>> groups = new java.util.TreeMap<>();
        for (int i = 0; i < events.length; i += BuildRequestPayload.VALUES_PER_EVENT) {
            int sourceTick = events[i];
            int cellIndex = events[i + 1];
            int volume = events[i + 2];
            if (sourceTick < 0 || cellIndex < 0 || cellIndex >= cellCount) {
                send(player, 0, 0, 0, 0, true, false,
                        "Redstone setup denied. The song event timeline contains an invalid cell reference.");
                return;
            }
            if (volume <= 0) continue;
            int cellOffset = cellIndex * BuildRequestPayload.VALUES_PER_CELL;
            int instrumentId = cells[cellOffset];
            int pitch = cells[cellOffset + 1];
            if (instrumentId < 0 || instrumentId >= NoteBlockPlanner.instruments().size()
                    || pitch < 0 || pitch >= 25) {
                send(player, 0, 0, 0, 0, true, false,
                        "Redstone setup denied. A note uses an unsupported instrument or pitch.");
                return;
            }
            int redstoneTick = Math.max(1, (int) Math.round(
                    sourceTick * 1000.0 / payload.tempoHundredths()));
            List<PhysicalNote> chord = groups.computeIfAbsent(redstoneTick, ignored -> new ArrayList<>());
            chord.add(new PhysicalNote(instrumentId, pitch));
            if (chord.size() > 3) {
                send(player, 0, 0, 0, 0, true, false,
                        "Redstone setup denied. A chord contains more than 3 simultaneous notes after redstone timing quantization. "
                                + "The physical layout cannot safely fit that chord without changing its timing.");
                return;
            }
        }
        if (groups.isEmpty()) {
            send(player, 0, 0, 0, 0, true, false,
                    "Redstone setup denied. No audible note events remain after filtering silent notes.");
            return;
        }

        List<RedstoneStage> stages = new ArrayList<>();
        int elapsedRedstoneTicks = 0;
        for (Map.Entry<Integer, List<PhysicalNote>> entry : groups.entrySet()) {
            int targetTick = entry.getKey();
            int gap = targetTick - elapsedRedstoneTicks;
            while (gap > 4) {
                stages.add(new RedstoneStage(4, List.of()));
                elapsedRedstoneTicks += 4;
                gap -= 4;
            }
            if (gap < 1) gap = 1;
            stages.add(new RedstoneStage(gap, List.copyOf(entry.getValue())));
            elapsedRedstoneTicks += gap;
        }

        // Each stage uses a repeater and its powered output block. Keep the
        // complete straight chain inside the server owner's configured offset.
        int maxStages = Math.max(0, (config.maxOffset - 2) / 2);
        if (maxStages < 1 || stages.size() > maxStages) {
            send(player, 0, 0, 0, 0, true, false,
                    "Redstone setup denied. This song needs " + stages.size()
                            + " repeater stages, but the configured maxOffset=" + config.maxOffset
                            + " allows " + maxStages + ". Increase maxOffset only if the server owner approves.");
            return;
        }

        Direction forward = Direction.fromYRot(player.getYRot());
        Direction side = forward.getClockWise();
        Direction oppositeSide = side.getOpposite();
        List<Operation> operations = new ArrayList<>();
        Set<BlockPos> planned = new HashSet<>();
        Set<BlockPos> supportFloors = new HashSet<>();
        Map<BlockPos, BlockState> desired = new java.util.LinkedHashMap<>();
        List<NoteBlockPlanner.Instrument> instruments = NoteBlockPlanner.instruments();

        // Keep the circuit two blocks in front of the selected anchor and one
        // block above the player's feet. The player remains clear of the build,
        // and the side-mounted note supports can sit above the existing floor.
        BlockPos circuitBase = anchor.relative(forward, 2);
        BlockPos circuitLevel = circuitBase.above();
        BlockPos buttonBase = circuitLevel;
        BlockPos buttonPosition = buttonBase.above();
        BlockState buttonState;
        try {
            buttonState = withProperty(Blocks.STONE_BUTTON.defaultBlockState(), "face", "floor");
            buttonState = withProperty(buttonState, "facing", forward.getName());
        } catch (RuntimeException exception) {
            send(player, 0, 0, 0, 0, true, false,
                    "Redstone setup failed. This Minecraft version does not expose the expected button properties.");
            return;
        }

        if (!addRequiredAirBlock(level, desired, planned, buttonBase, Blocks.STONE.defaultBlockState())
                || !addRequiredAirBlock(level, desired, planned, buttonPosition, buttonState)) {
            send(player, 0, 0, 0, 0, true, false,
                    "Redstone setup denied. Clear the anchor block and the space directly above it first.");
            return;
        }
        supportFloors.add(buttonBase.below());

        for (int stageIndex = 0; stageIndex < stages.size(); stageIndex++) {
            RedstoneStage stage = stages.get(stageIndex);
            BlockPos repeaterPos = circuitLevel.relative(forward, stageIndex * 2 + 1);
            BlockPos outputPos = circuitLevel.relative(forward, stageIndex * 2 + 2);
            BlockState repeaterState;
            try {
                repeaterState = withProperty(Blocks.REPEATER.defaultBlockState(), "facing", forward.getName());
                repeaterState = withProperty(repeaterState, "delay", Integer.toString(stage.delay));
            } catch (RuntimeException exception) {
                send(player, 0, 0, 0, 0, true, false,
                        "Redstone setup failed. This Minecraft version does not expose the expected repeater properties.");
                return;
            }
            if (!addRequiredAirBlock(level, desired, planned, repeaterPos, repeaterState)) {
                send(player, 0, 0, 0, 0, true, false,
                        "Redstone setup denied. The repeater path is blocked near " + repeaterPos.toShortString() + ". Nothing was changed.");
                return;
            }
            supportFloors.add(repeaterPos.below());

            // The repeater must power an opaque conductor so the next repeater
            // receives the pulse. The first two notes sit beside this conductor,
            // each on its own instrument support. A third chord note sits above
            // the conductor, so its support block must itself safely conduct power.
            BlockState outputState = Blocks.STONE.defaultBlockState();
            if (stage.notes.size() == 3) {
                PhysicalNote topNote = stage.notes.get(2);
                if (!isSafeSequencerConductor(topNote.instrumentId)) {
                    send(player, 0, 0, 0, 0, true, false,
                            "Redstone setup denied. A three-note chord uses a transparent/non-conductive instrument support for its third note. "
                                    + "Reduce that chord to two notes or change the support instrument.");
                    return;
                }
                outputState = supportState(topNote.instrumentId, instruments);
            }
            if (outputState == null) {
                send(player, 0, 0, 0, 0, true, false,
                        "Redstone setup denied. A conductor/instrument support block is unavailable.");
                return;
            }
            if (!addRequiredAirBlock(level, desired, planned, outputPos, outputState)) {
                send(player, 0, 0, 0, 0, true, false,
                        "Redstone setup denied. The repeater output path is blocked near " + outputPos.toShortString() + ". Nothing was changed.");
                return;
            }
            supportFloors.add(outputPos.below());

            for (int chordIndex = 0; chordIndex < stage.notes.size(); chordIndex++) {
                PhysicalNote note = stage.notes.get(chordIndex);
                BlockPos notePos;
                BlockPos noteSupportPos;
                if (stage.notes.size() == 3 && chordIndex == 2) {
                    notePos = outputPos.above();
                    noteSupportPos = outputPos;
                } else {
                    notePos = outputPos.relative(chordIndex == 0 ? side : oppositeSide);
                    noteSupportPos = notePos.below();
                }
                BlockState noteState;
                try {
                    noteState = withProperty(Blocks.NOTE_BLOCK.defaultBlockState(), "instrument",
                            instruments.get(note.instrumentId).noteBlockInstrument());
                    noteState = withProperty(noteState, "note", Integer.toString(note.pitch));
                } catch (RuntimeException exception) {
                    send(player, 0, 0, 0, 0, true, false,
                            "Redstone setup failed. Note-block instrument/pitch properties are unavailable.");
                    return;
                }
                if (!(stage.notes.size() == 3 && chordIndex == 2)) {
                    BlockState support = supportState(note.instrumentId, instruments);
                    if (support == null || !addRequiredAirBlock(level, desired, planned, noteSupportPos, support)) {
                        send(player, 0, 0, 0, 0, true, false,
                                "Redstone setup denied. An instrument support position is occupied at "
                                        + noteSupportPos.toShortString() + ". Clear the area and retry.");
                        return;
                    }
                    supportFloors.add(noteSupportPos.below());
                }
                if (!addRequiredAirBlock(level, desired, planned, notePos, noteState)
                        || !level.getBlockState(notePos.above()).isAir()) {
                    send(player, 0, 0, 0, 0, true, false,
                            "Redstone setup denied. A note block or its sound space is obstructed at "
                                    + notePos.toShortString() + ". Clear the area and retry.");
                    return;
                }
            }
        }

        // Add stone foundations only in air. Existing sturdy floor blocks are
        // reused but are never journaled or removed by NoteClient cleanup.
        for (BlockPos floorPos : supportFloors) {
            BlockState existing = level.getBlockState(floorPos);
            if (existing.isAir()) {
                desired.putIfAbsent(floorPos, Blocks.STONE.defaultBlockState());
            } else if (!existing.isFaceSturdy(level, floorPos, Direction.UP)) {
                send(player, 0, 0, 0, 0, true, false,
                        "Redstone setup denied. A circuit foundation is occupied by a non-sturdy block at "
                                + floorPos.toShortString() + ". Nothing was changed.");
                return;
            }
        }

        // Validate every changed location before the first block is touched.
        for (Map.Entry<BlockPos, BlockState> entry : desired.entrySet()) {
            BlockPos pos = entry.getKey();
            if (!level.getWorldBorder().isWithinBounds(pos) || level.isOutsideBuildHeight(pos)
                    || !level.hasChunkAt(pos)) {
                send(player, 0, 0, 0, 0, true, false,
                        "Redstone setup denied. A circuit block is outside the world border/build height or in an unloaded chunk at "
                                + pos.toShortString() + ". Load the area and retry.");
                return;
            }
            BlockState existing = level.getBlockState(pos);
            if (!existing.isAir() && !existing.equals(entry.getValue())) {
                send(player, 0, 0, 0, 0, true, false,
                        "Redstone setup denied. The circuit would replace an existing block at "
                                + pos.toShortString() + ". Nothing was changed.");
                return;
            }
        }
        List<Map.Entry<BlockPos, BlockState>> orderedDesired = new ArrayList<>(desired.entrySet());
        orderedDesired.sort(java.util.Comparator
                .comparingInt((Map.Entry<BlockPos, BlockState> entry) -> entry.getKey().getY())
                .thenComparingInt(entry -> entry.getKey().getZ())
                .thenComparingInt(entry -> entry.getKey().getX()));
        for (Map.Entry<BlockPos, BlockState> entry : orderedDesired) {
            BlockState current = level.getBlockState(entry.getKey());
            if (!current.equals(entry.getValue())) {
                operations.add(new Operation(entry.getKey(), current, entry.getValue(), -1));
            }
        }
        if (operations.isEmpty()) {
            send(player, 0, 0, 0, 0, true, false,
                    "Redstone setup denied. The selected circuit already exists or there is no safe space to place it.");
            return;
        }

        BuildJob job = new BuildJob(level, operations, new BlockPos[0], new BlockState[0],
                new int[0], new int[0], new int[0], payload.tempoHundredths(),
                payload.songLengthTicks(), 0, 0, Set.of());
        job.redstoneSetup = true;
        job.buttonPosition = buttonPosition;
        JOBS.put(player.getUUID(), job);
        send(player, job.placed, job.totalCount(), 0, 1, false, false,
                "Building real redstone sequencer: " + operations.size() + " block updates across "
                        + stages.size() + " delay stages. It will be button-started and playable by nearby players.");
    }

    private static boolean isSafeSequencerConductor(int instrumentId) {
        // These built-in support materials are full, opaque blocks that can carry
        // strong redstone power from one repeater stage to the next. Glass,
        // packed ice, glowstone, and soul sand are intentionally excluded.
        return switch (instrumentId) {
            case 0, 1, 2, 3, 5, 6, 7, 9, 10, 12, 13, 14, 16, 17, 18, 19 -> true;
            default -> false;
        };
    }

    private static BlockState supportState(int instrumentId, List<NoteBlockPlanner.Instrument> instruments) {
        if (instrumentId < 0 || instrumentId >= instruments.size()) return null;
        try {
            Identifier id = Identifier.parse(instruments.get(instrumentId).supportBlock());
            Block block = BuiltInRegistries.BLOCK.getOptional(id).orElse(null);
            return block == null ? null : block.defaultBlockState();
        } catch (RuntimeException exception) {
            return null;
        }
    }

    private static boolean addRequiredAirBlock(ServerLevel level, Map<BlockPos, BlockState> desired,
                                               Set<BlockPos> planned, BlockPos position, BlockState state) {
        BlockPos pos = position.immutable();
        if (planned.contains(pos)) {
            BlockState plannedState = desired.get(pos);
            return plannedState == null ? level.getBlockState(pos).equals(state) : plannedState.equals(state);
        }
        BlockState existing = level.getBlockState(pos);
        if (!existing.isAir() && !existing.equals(state)) return false;
        planned.add(pos);
        if (existing.isAir()) desired.put(pos, state);
        return true;
    }

    private record PhysicalNote(int instrumentId, int pitch) {}
    private record RedstoneStage(int delay, List<PhysicalNote> notes) {}

    private static void controlBuild(ServerPlayer player, BuildControlPayload payload) {
        BuildJob job = JOBS.get(player.getUUID());
        if (job == null) {
            send(player, 0, 0, 0, 0, true, false, "No NoteClient arrangement is active.");
            return;
        }
        if (payload.action() == BuildControlPayload.TOGGLE_PAUSE) {
            if (job.redstoneSetup && job.phase == 4) {
                send(player, job.placed, job.totalCount(), job.skipped, 4, true, false,
                        "The redstone sequencer is physical circuitry. Press its button to play; use O/Destroy to remove it.");
                return;
            }
            if (!job.paused) {
                job.paused = true;
                job.pausedAt = job.level.getGameTime();
                send(player, job.placed, job.totalCount(), job.skipped, job.phase,
                        false, true, "Paused. Press P to resume or O to restore the arrangement.");
            } else {
                long now = job.level.getGameTime();
                long pauseDuration = Math.max(0, now - job.pausedAt);
                if (job.playbackStart >= 0) job.playbackStart += pauseDuration;
                job.paused = false;
                send(player, job.placed, job.totalCount(), job.skipped, job.phase,
                        false, false, "Resumed.");
            }
            return;
        }
        if (payload.action() == BuildControlPayload.CANCEL || payload.action() == BuildControlPayload.DESTROY) {
            job.pendingBuild = null;
            job.paused = false;
            job.beginCleanup("Restoring the original block states at NoteClient-owned positions.");
            send(player, job.placed, job.totalCount(), job.skipped, 3, false, false,
                    "Restoring arrangement. Blocks changed by other players are left untouched.");
        }
    }

    private static void tickJobs(MinecraftServer server) {
        List<PendingStart> pendingStarts = new ArrayList<>();
        Iterator<Map.Entry<UUID, BuildJob>> iterator = JOBS.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, BuildJob> entry = iterator.next();
            UUID ownerId = entry.getKey();
            BuildJob job = entry.getValue();
            ServerPlayer player = server.getPlayerList().getPlayer(ownerId);

            if (player == null || player.level() != job.level) {
                // A completed phase-4 arrangement is intentionally world-persistent.
                // Owner disconnects/dimension changes must not act like Destroy.
                if (job.phase == 4) continue;
                job.paused = false;
                if (job.phase != 3) job.beginCleanup("Owner left or changed dimension; restoring the unfinished arrangement.");
                if (processCleanup(job)) {
                    BuildRequestPayload pending = job.pendingBuild;
                    iterator.remove();
                    if (player != null && pending != null) pendingStarts.add(new PendingStart(player, pending));
                }
                continue;
            }

            if (job.paused) continue;
            long now = job.level.getGameTime();

            if (job.phase == 1) {
                processBuild(player, job, now);
                continue;
            }
            if (job.phase == 2) {
                processPlayback(player, job, now);
                continue;
            }
            if (job.phase == 3 && processCleanup(job)) {
                BuildRequestPayload pending = job.pendingBuild;
                iterator.remove();
                if (pending != null) pendingStarts.add(new PendingStart(player, pending));
                else send(player, job.placed, job.totalCount(), job.skipped, 3, true, false,
                        "Arrangement restored. All unchanged NoteClient blocks returned to their previous states.");
                continue;
            }
            if (job.phase == 4 && now - job.lastProgress >= 100) {
                job.lastProgress = now;
                send(player, job.placed, job.totalCount(), job.skipped, 4, true, false,
                        "Arrangement is built and retained. Use N → Builder → Destroy to restore it.");
            }
        }

        for (PendingStart pending : pendingStarts) {
            ServerPlayer current = server.getPlayerList().getPlayer(pending.player.getUUID());
            if (current == pending.player) prepareAndStart(current, pending.payload);
        }
    }

    private static void processBuild(ServerPlayer player, BuildJob job, long now) {
        int processed = 0;
        while (job.buildIndex < job.operations.size() && processed < config.maxBlockChangesPerTick) {
            Operation op = job.operations.get(job.buildIndex++);
            BlockState current = job.level.getBlockState(op.position);
            if (!current.equals(op.originalState)) {
                job.skipped++;
                processed++;
                continue;
            }
            if (job.level.setBlock(op.position, op.placedState, 3)) {
                job.journal.add(new JournalEntry(op.position, op.originalState, op.placedState));
                job.placed++;
            } else {
                job.skipped++;
            }
            processed++;
        }

        if (job.buildIndex >= job.operations.size()) {
            if (job.redstoneSetup) {
                job.phase = 4;
                BlockPos button = job.buttonPosition == null ? BlockPos.ZERO : job.buttonPosition;
                send(player, job.placed, job.totalCount(), job.skipped, 4, true, false,
                        "Redstone sequencer built and retained. Anyone can press the physical button at "
                                + button.getX() + ", " + button.getY() + ", " + button.getZ()
                                + " to play it. Timing is quantized to 0.1-second redstone ticks; vanilla note blocks do not preserve NBS volume, panning, fine cents, or custom samples. Use Destroy to remove it.");
            } else if (job.eventCount() > 0 && job.playableCount() > 0) {
                if (config.autoSwitchToSurvival) {
                    // This path runs only in the installed server companion, after
                    // beginBuild has checked operator permission (or singleplayer).
                    // A normal client cannot change a remote server's game mode.
                    player.setGameMode(GameType.SURVIVAL);
                }
                job.phase = 2;
                job.playbackStart = now + PLAYBACK_DELAY_TICKS;
                job.lastProgress = now;
                send(player, job.placed, job.totalCount(), job.skipped, 2, false, false,
                        config.autoSwitchToSurvival
                                ? "Arrangement ready. Switched to Survival automatically; playback begins shortly."
                                : "Arrangement ready. Real note-block playback begins shortly; Creative mode is supported.");
            } else {
                job.phase = 4;
                send(player, job.placed, job.totalCount(), job.skipped, 4, true, false,
                        "Arrangement built and retained. It has no playable song timeline; use Destroy to restore it.");
            }
        } else if (now - job.lastProgress >= 10) {
            job.lastProgress = now;
            send(player, job.placed, job.totalCount(), job.skipped, 1, false, false,
                    "Building floating note blocks: " + job.placed + "/" + job.operations.size() + " confirmed.");
        }
    }

    private static void processPlayback(ServerPlayer player, BuildJob job, long now) {
        if (now < job.playbackStart) return;
        long elapsed = now - job.playbackStart;
        int songTick = (int) Math.min(Integer.MAX_VALUE,
                (elapsed * (long) job.tempoHundredths) / 2000L);

        int eventsProcessed = 0;
        while (job.eventIndex < job.eventCount()) {
            int eventOffset = job.eventIndex * BuildRequestPayload.VALUES_PER_EVENT;
            if (eventOffset + 1 >= job.events.length) {
                job.eventIndex = job.eventCount();
                break;
            }
            int noteTick = job.events[eventOffset];
            if (noteTick > songTick) break;
            int cellIndex = job.events[eventOffset + 1];
            int volumePercent = job.events[eventOffset + 2];
            int panning = job.events[eventOffset + 3];
            int finePitchCents = job.events[eventOffset + 4];
            BlockPos notePos = job.notePositions[cellIndex];
            BlockState expected = job.expectedStates[cellIndex];
            if (notePos != null && expected != null
                    && job.level.getBlockState(notePos).equals(expected)
                    && volumePercent > 0) {
                playSongNote(player, job, cellIndex, notePos,
                        volumePercent, panning, finePitchCents);
            }
            job.eventIndex++;
            eventsProcessed++;
        }

        int lastEventTick = job.eventCount() == 0 ? 0
                : job.events[(job.eventCount() - 1) * BuildRequestPayload.VALUES_PER_EVENT];
        int endTick = Math.max(job.songLengthTicks, lastEventTick + 1);
        if (job.eventIndex >= job.eventCount() && songTick >= endTick) {
            if (config.restoreAfterSong) {
                job.beginCleanup("Song completed. Restoring the original arrangement footprint.");
                send(player, job.placed, job.totalCount(), job.skipped, 3, false, false,
                        "Song finished. Restoring the exact previous block states...");
            } else {
                job.phase = 4;
                send(player, job.placed, job.totalCount(), job.skipped, 4, true, false,
                        "Song finished. Arrangement retained because restoreAfterSong=false. Use Destroy to restore it.");
            }
        } else if (now - job.lastProgress >= 40) {
            job.lastProgress = now;
            send(player, job.placed, job.totalCount(), job.skipped, 2, false, false,
                    "Playing: " + job.eventIndex + "/" + job.eventCount() + " note events.");
        }
    }

    /**
     * Plays the source NBS event on the authoritative server. Unlike a vanilla
     * note-block block event, this preserves NBS fine cents, note/layer velocity,
     * and stereo panning. The physical note block remains in the world as the
     * visible arrangement; audio timing is driven by the original event timeline.
     */
    private static void playSongNote(ServerPlayer player, BuildJob job, int cellIndex,
                                     BlockPos notePos, int volumePercent, int panning,
                                     int finePitchCents) {
        int instrumentId = job.instrumentIds[cellIndex];
        if (instrumentId < 0 || instrumentId >= NoteBlockPlanner.instruments().size()) return;
        String soundName = NoteBlockPlanner.instruments().get(instrumentId).noteBlockInstrument();
        Identifier soundId = Identifier.fromNamespaceAndPath("minecraft", "block.note_block." + soundName);
        var sound = BuiltInRegistries.SOUND_EVENT.getValue(soundId);
        if (sound == null) return;

        // NBS key 45 is F#4, which is the reference pitch (1.0) for each
        // vanilla note-block instrument's sound event. Fine pitch is in cents.
        int nbsKey = job.cellKeys[cellIndex];
        double semitones = (nbsKey - 45) + (finePitchCents / 100.0);
        float pitch = (float) Math.pow(2.0, semitones / 12.0);
        float volume = Math.max(0.0F, Math.min(1.0F, volumePercent / 100.0F));

        // NBS pan is 0=left, 100=center, 200=right. Offset the source up to
        // two blocks relative to the requesting player's current facing.
        Direction right = Direction.fromYRot(player.getYRot()).getClockWise();
        double panOffset = ((Math.max(0, Math.min(200, panning)) - 100) / 100.0) * 2.0;
        double x = notePos.getX() + 0.5 + right.getStepX() * panOffset;
        double y = notePos.getY() + 0.5;
        double z = notePos.getZ() + 0.5 + right.getStepZ() * panOffset;
        job.level.playSound(null, x, y, z, sound, net.minecraft.sounds.SoundSource.RECORDS,
                volume, pitch);
    }

    private static boolean processCleanup(BuildJob job) {
        int processed = 0;
        while (job.cleanupIndex >= 0 && processed < config.maxBlockChangesPerTick) {
            JournalEntry entry = job.journal.get(job.cleanupIndex--);
            BlockState current = job.level.getBlockState(entry.position);
            if (current.equals(entry.placedState)) {
                job.level.setBlock(entry.position, entry.originalState, 3);
            }
            processed++;
        }
        if (job.cleanupIndex < 0 && !job.chunkTicketsReleased) {
            releaseChunkTickets(job.level, job.heldChunkTickets);
            job.chunkTicketsReleased = true;
        }
        return job.cleanupIndex < 0;
    }

    /**
     * The server-companion backend does not add temporary force-load tickets.
     * Existing operator/mod tickets are left entirely untouched. This method
     * only clears the job-local bookkeeping set for compatibility with journals
     * created earlier in the job lifecycle.
     */
    private static void releaseChunkTickets(ServerLevel level, Set<Long> acquired) {
        acquired.clear();
    }

    private static void send(ServerPlayer player, int placed, int total, int skipped,
                             int phase, boolean finished, boolean paused, String message) {
        String safe = message == null ? "" : message;
        ServerPlayNetworking.send(player,
                new BuildProgressPayload(placed, total, skipped, phase, finished, paused, safe));
        player.sendOverlayMessage(Component.literal("[NoteClient] " + safe));
    }

    private static BlockState withProperty(BlockState state, String name, String serializedValue) {
        Property<?> raw = state.getBlock().getStateDefinition().getProperty(name);
        if (raw == null) throw new IllegalStateException("Missing block state property: " + name);
        return setPropertyUnchecked(state, raw, serializedValue);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static BlockState setPropertyUnchecked(BlockState state, Property property, String value) {
        java.util.Optional parsed = property.getValue(value);
        if (parsed.isEmpty()) throw new IllegalStateException("Invalid block state value: " + value);
        return state.setValue(property, (Comparable) parsed.get());
    }

    private record Operation(BlockPos position, BlockState originalState, BlockState placedState, int cellIndex) {}
    private record JournalEntry(BlockPos position, BlockState originalState, BlockState placedState) {}
    private record PendingStart(ServerPlayer player, BuildRequestPayload payload) {}

    private static final class BuildJob {
        private final ServerLevel level;
        private final List<Operation> operations;
        private final BlockPos[] notePositions;
        private final BlockState[] expectedStates;
        private final int[] instrumentIds;
        private final int[] cellKeys;
        private final int[] events;
        private final int tempoHundredths;
        private final int songLengthTicks;
        private final List<JournalEntry> journal = new ArrayList<>();
        private final Set<Long> heldChunkTickets;
        private boolean chunkTicketsReleased;
        private int skipped;
        private int phase = 1; // 1 build, 2 playback, 3 restore, 4 retained arrangement
        private int buildIndex;
        private int cleanupIndex = -1;
        private int eventIndex;
        private int placed;
        private final int totalCount;
        private boolean paused;
        private long pausedAt;
        private long playbackStart = -1;
        private long lastProgress;
        private BuildRequestPayload pendingBuild;
        private boolean redstoneSetup;
        private BlockPos buttonPosition;

        private BuildJob(ServerLevel level, List<Operation> operations,
                         BlockPos[] notePositions, BlockState[] expectedStates,
                         int[] instrumentIds, int[] cellKeys, int[] events, int tempoHundredths,
                         int songLengthTicks, int skipped, int alreadyMatching,
                         Set<Long> heldChunkTickets) {
            this.level = level;
            this.operations = List.copyOf(operations);
            this.notePositions = notePositions.clone();
            this.expectedStates = expectedStates.clone();
            this.instrumentIds = instrumentIds.clone();
            this.cellKeys = cellKeys.clone();
            this.events = events.clone();
            this.tempoHundredths = tempoHundredths;
            this.songLengthTicks = songLengthTicks;
            this.skipped = skipped;
            this.placed = alreadyMatching;
            this.totalCount = operations.size() + alreadyMatching;
            this.heldChunkTickets = new HashSet<>(heldChunkTickets);
            this.lastProgress = level.getGameTime();
        }

        private int totalCount() { return totalCount; }

        private int eventCount() { return events.length / BuildRequestPayload.VALUES_PER_EVENT; }

        private int playableCount() {
            int count = 0;
            for (BlockPos pos : notePositions) if (pos != null) count++;
            return count;
        }

        private void beginCleanup(String reason) {
            if (phase == 3) return;
            phase = 3;
            cleanupIndex = journal.size() - 1;
            paused = false;
            lastProgress = Long.MIN_VALUE;
            System.out.println("[NoteClient] " + reason);
        }
    }
}
