# NoteClient 1.3.47 — optional server companion setup

This project builds two different artifacts. Use the client JAR in the Modrinth/client profile and the server companion JAR only on a Fabric server.

## Build both artifacts

Requires JDK 25. From the project folder:

```bat
gradlew.bat clean build
```

The output files are:

```text
build/release/NoteClient-1.3.47-Minecraft-26.2.jar
build/release/NoteClientServer-1.3.47-Minecraft-26.2.jar
```

## Install

1. Install Fabric Loader 0.19.3+ and Fabric API 0.161.0+26.2 on the dedicated server.
2. Put `NoteClientServer-1.3.47-Minecraft-26.2.jar` into the server's `mods` directory.
3. Restart the server once to create config files.
4. Put `NoteClient-1.3.47-Minecraft-26.2.jar` in the player's Modrinth profile `mods` directory.
5. By default, the requesting player must be an operator. In an integrated world only the actual singleplayer host is implicitly authorized; LAN guests still need operator permission.

## Character Painter and Giant Block Builder

The 1.3.47 Character Painter, Giant Block Builder and Player-tab skin statue builder do **not** use this companion. They build through the client placement pipeline: Creative item staging, ordinary right-click placements on multiplayer, normal reach, server acknowledgements and no replacement of occupied cells. Their Stop action halts future placements and leaves the partial build; Undo Last is separate. No server config is needed for these model features.

The older voxel server manager remains packaged as unused compatibility code, but the 1.3.47 client no longer sends it build requests.

## Legacy Voxel Studio server policy

The following config applies only to older client builds that used the server-authoritative voxel endpoint. The current 1.3.47 client does not create or require it. The companion creates: 

```text
config/noteclient-voxel-server.properties
```

Default values:

```properties
allowOperatorBuilds=true
allowReplaceExisting=false
maxVoxelsPerJob=16384
maxChangesPerTick=128
maxRemovalsPerTick=384
maxDistanceFromPlayer=64
progressEveryTicks=5
```

Keep `allowOperatorBuilds=true` on public or shared servers. The default build mode places into air only; replacement is disabled. The manager does not force-load chunks. If a target chunk is not already loaded, that cell is skipped. Increase the per-tick block budgets only after measuring server MSPT and confirming adequate headroom.

The server accepts safe vanilla full-cube blocks from the expanded Minecraft palette (including solid woods, stones, bricks, ores, terracotta, wool and concrete). It rejects modded IDs, partial blocks, fluids, falling blocks, block entities, hazardous/special blocks and invalid/out-of-world positions. Multiple completed statues can remain built (up to 16 per player), provided each is built in a separate clear footprint. Undo Last restores only the newest statue's prior-state journal; pressing it again undoes the previous build. Removal restores a position only if it still contains the exact state the selected job placed.

## Aura server settings

The same companion also hosts the existing owner-authorized wind Aura. Its separate config is:

```text
config/noteclient-server.properties
```

The Aura is disabled by default. To enable it, stop the server and set `allowServerAura=true`; preserve `serverAuraRequiresOp=true` unless you deliberately administer a private environment where non-operators should be allowed. Restart after editing settings.

## Cleanup and backups

Normal disconnect and graceful shutdown clean unfinished companion-owned NoteClient jobs and Aura blocks, but leave completed phase-4 note-block arrangements in the world. Client-built physical redstone circuits are not tracked by the companion. The retained build journal is in memory only; it is not persisted across restarts. Use **N → Builder → Destroy** before restarting when you want the companion to restore a retained arrangement. A process crash, forced kill or power loss cannot execute cleanup and may leave the last temporary state in the world. Back up the world before enabling server-side world effects. Only use this companion on servers/worlds you own or administer.

## Note-block retention and redstone sequencer

The server config now uses `restoreAfterSong=false` by default. This intentionally ignores the old `autoRestore` key, so a previous `autoRestore=true` setting cannot silently remove a newly completed arrangement. Set `restoreAfterSong=true` only when you explicitly want NoteClient to restore the original note-block footprint after playback. The owner can always use **Destroy** to restore the current in-memory journal. A retained arrangement's journal is not saved across server restarts.

The Song Scanner's **Redstone Setup** option no longer uses this companion. The client constructs a real repeater chain, instrument supports, note blocks and a physical stone button using ordinary Creative interactions. Anyone who can reach the button can start the circuit. The builder waits for server-confirmed block updates and pauses when a target is outside normal interaction reach; follow alongside the growing chain. It never replaces occupied blocks and does not use commands, reach overrides or server-side world writes. Redstone timing is quantized to 0.1-second ticks, chords are limited to three simultaneous notes, and the client circuit is limited to 255 repeater stages. Vanilla note blocks cannot preserve NBS volume, panning, fine cents, or custom samples, so this is a physical approximation. Use **Build arrangement** for NoteClient's more faithful NBS playback.
