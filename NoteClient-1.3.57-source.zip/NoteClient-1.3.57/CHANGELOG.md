## 1.3.57

- Added Creative inventory material stocking for schematic builds, physical redstone sequencers, Player-tab statues, and Character Painter / Giant Block Builder world builds.
- The material stager tops up matching partial stacks or uses empty inventory slots, prioritizes the most-used materials when the palette exceeds available space, and never overwrites unrelated inventory contents.
- Material stacks are preserved when a build finishes or is stopped; temporary working-hand item states are restored to the stocked stack instead of deleting the materials.
- Build status reports how many material types were added, already present, or unable to fit in the player's inventory.
- Song arrangements retain their existing material-staging behavior. All automatic inventory stocking uses vanilla Creative inventory updates; the connected server remains authoritative.

## 1.3.56

- Added automatic pre-tuned Note Block item stacks for Creative song construction. Each block is placed with its requested pitch and instrument already on the item state; the world is still checked after placement, and servers that strip the component fall back to ordinary note-block tuning.
- Raised the default build budget to 16 actions/tick (manual range 1–128) and kept the independent tune budget at 2048 interactions/tick (manual range 1–4096). Existing older slow presets are migrated once.
- Capped the note-tuning time slice at 4 ms per client tick and schedule it after the other builders/input, with bounded work and independent builder tick callbacks so large tune jobs yield to other client actions.
- Forwarded the manual build rate to the optional owner companion as well; the server clamps it to its own maxBlockChangesPerTick policy for both construction and cleanup.
- Updated the release version and documentation for the new fast Creative note-placement path.

## 1.3.54

- Added editable, persistent **Build actions/tick** (1–128) and **Tune interactions/tick** (1–4096) controls in N → Settings. Build speed is shared by note arrangements, schematics, physical redstone sequencers, player statues and tracked cleanup; playback retains its own rate.
- Raised the default build budget to 8 actions/tick and the default tuning budget to 2048 interactions/tick. Existing installations migrate from the old low presets to these defaults once, while custom rates above the old preset range are preserved.
- Reworked schematic and physical redstone construction into bounded multi-placement pipelines. Both now keep multiple normal vanilla interactions in flight, confirm blocks from observed world state, retry delayed updates and continue past deferred/unreachable cells where safe.
- Expanded statue build queue capacity, raised the tracked arrangement-cleanup pipeline, and made the manual build-rate ceiling apply to local integrated-server batches as well as remote placement attempts.
- Split note-block tuning into a short time-sliced client-tick budget, expanded the in-flight note queue, and kept partial-pitch retries per note instead of allowing one slow note to throttle the whole arrangement.
- Updated the release documentation to describe the new controls and the real distinction between local integrated-server writes and server-authoritative remote interactions.

## 1.3.53
- Schematic builds now sort the placement queue by distance from the player's eyes at Build start, so the closest cells are attempted first and construction grows outward.
- Schematic placement now uses the same server-specific reach planning hint as the other builders. The user can activate it with **N → Settings → Request /reach 100**; it does not change client attributes or bypass server validation.
- Blocks outside the current planning reach, and targets in unloaded chunks, are deferred instead of stalling the whole schematic. The builder continues with nearer/loaded cells and automatically retries deferred cells during later passes.
- When the custom reach hint is active, the schematic builder uses up to 100 blocks for its hit-point distance test while still sending ordinary `useItemOn` interactions for the server to accept or reject.

## 1.3.52
- Fixed schematic preview correctness colors: empty cells and cells already containing the expected block are green; only conflicting occupied blocks are red.
- Changed placement confirmation to acknowledge the expected block type even when Minecraft legitimately updates connection, shape, powered, or waterlogged properties after placement.
- Separated available support from interaction reach so a valid support outside reach now asks the player to move closer instead of reporting that no support exists.
- Added a deferred support queue. Gravity-affected blocks such as sand, gravel, concrete powder and anvils wait until a sturdy block is directly underneath; other support-dependent states use Minecraft's `canSurvive` check. Deferred blocks are retried after the rest of the schematic is built and are revisited automatically when more support becomes available.
- Kept placement on ordinary Creative interactions and normal reach; no server permissions or reach checks are bypassed.

## 1.3.51
- Added an **Unload** action to the schematic browser. It clears the current preview and invalidates any pending asynchronous load.
- Fixed schematic browser button hitboxes on narrow windows. The old fixed-width layout could overlap Build with Clear Preview, causing a Build click to unload the preview instead.
- Kept the selected schematic preview anchored at the selection-time position; Build uses those same coordinates.
- Redstone Setup now truncates songs at 255 repeater stages and omits later notes instead of rejecting the entire song for exceeding the physical circuit length.

## 1.3.50
- Added Litematica `.litematic` import with multi-region palettes and packed block states.
- Added vanilla Java structure `.nbt` import and basic legacy MCEdit `.schematic` import for mapped block IDs.
- Schematic browser now lists `.litematic`, `.schem`, `.schematic`, and `.nbt` files.
- Selecting a schematic snapshots the player's block position and facing; preview no longer follows movement.
- The player's selected block position is the bottom-right footprint corner and bottom Y anchor.
- Switching selection clears the old preview immediately and stale async loads cannot replace the newer selection.
- Build uses the same anchored preview coordinates.

## 1.3.49

- Fixed the release-verifier failure in the statue progress HUD by binding `PlayerStatueBuilder.hasTrackedStatue()` while continuing to display the progress panel only during active construction or removal. Completed statues remain in Undo history without leaving a permanent HUD panel.

## 1.3.48

- Rebuilt the client-only physical redstone sequencer as a same-level repeater and redstone-dust rail. The repeater output dust now branches directly beside each note block, so each powered pulse actually triggers its note block; note supports and clear sound spaces are preserved.
- Kept the physical circuit limit at 255 repeater stages and expanded each quantized chord to up to 28 notes (14 on each isolated branch). The builder reports clear errors for oversized chords, server-rejected placements, or missing block confirmations instead of retrying indefinitely.
- Increased the per-block server acknowledgement window and added backoff while waiting for the player to move within normal reach. Existing blocks are not replaced, and completed/confirmed circuit blocks remain in the world.
- Fixed intentional Stop/Build screen closure in the Player Statue tab, Song Scanner, and Character Painter. Those actions now close directly to gameplay instead of invoking `onClose()` paths that reopen the parent GUI; normal Escape/Back still returns to the parent screen.
- The statue progress overlay now appears only while a build/removal is active, not forever just because the completed statue remains in Undo history. Stop continues to wait for already-sent placements to settle without scheduling new blocks, and completed removals no longer report an active removal state.

## 1.3.47

- Fixed the redstone sequencer compile error by importing `SchematicBuilder` from its `dev.noteclient.schematic` package. The active-job guard now resolves the schematic builder class correctly.

## 1.3.46

- Moved **Redstone Setup** off the server-companion request path. The client now builds the button, repeaters, conductors, instrument supports and note blocks using ordinary Creative block interactions, and waits for each server-confirmed block update.
- Added a reach-aware build queue for physical sequencers. Long circuits pause and prompt the player to move alongside the next section; Stop (O) leaves confirmed placements in place and P pauses/resumes.
- Physical redstone mode no longer requires NoteClient installed on the server or operator permission. It never replaces occupied cells or bypasses normal server placement checks. The circuit is limited to 255 repeater stages and three simultaneous notes per quantized chord.
- Updated server setup and README documentation to distinguish client-built physical circuits from optional owner-authorized server features.

## 1.3.45

- Added a **STOP** action to both the Player tab statue builder and Character Painter. It stops new placements, closes the GUI, waits for already-sent interactions to settle, and leaves placed blocks in the world; Undo Last remains separate.
- Switched Character Painter and Giant Block Builder world construction to the existing client-side statue placement pipeline. Model builds no longer send voxel build/control payloads or require the NoteClient Server Companion.
- Client-side model builds use Creative inventory staging, normal vanilla block interactions on multiplayer servers, server update confirmation, normal reach, and no-replace checks.
- Preserved tracked Undo Last history for client-built models; Rebuild starts a new tracked build rather than requiring a server-side removal request.

## 1.3.44

- Fixed the Sponge schematic preview renderer imports for Minecraft 26.2: `LightCoordsUtil.FULL_BRIGHT` replaces the removed `LightTexture` reference, and `OverlayTexture` is imported from `net.minecraft.client.renderer.texture`.

## 1.3.43

- Fixed the optional server companion's cell-coordinate decoder: local right/up/forward values now come from the correct tuple fields instead of accidentally interpreting the NBS key as the right offset.
- Completed note-block arrangements now remain in the world by default. The new `restoreAfterSong` config key defaults to `false` and deliberately ignores legacy `autoRestore` values; owner disconnects and normal shutdown no longer undo finished arrangements. Destroy remains the explicit cleanup action. The in-memory undo journal is not persisted across server restarts.
- Added a separate physical redstone sequencer build option. It creates repeaters, note blocks, support blocks and a start button ahead of the selected anchor through the operator-authorized server companion. Its timing is quantized to vanilla's 0.1-second redstone ticks and simultaneous chords are limited to three notes; vanilla note blocks cannot preserve NBS volume, panning, fine cents, or custom samples.
- Added a profile-local `noteclient/schematics` folder and a searchable Sponge `.schem` v2/v3 browser. Selecting a file creates an in-world block-model hologram, Rotate changes its orientation, and Left Arrow starts construction.
- The schematic builder uses ordinary Creative block interactions, waits for server-confirmed placements, respects actual reach and permissions, never replaces occupied cells, and retains confirmed blocks when stopped. Block-entity NBT (for example chest contents and sign text) is not imported.

## 1.3.42
- Player-tab statues now generate the base head, torso, arms, and legs as hollow outer shells instead of filling every depth layer.
- Character Painter's default white mannequin also uses hollow cuboid shells, preserving all six visible faces as paint targets while leaving center cells empty.
- Imported skin models and separate hat, jacket, sleeve, and pants overlay layers remain unchanged; added smoke checks for empty head/torso interior cells.

## 1.3.41
- Fixed the release-verifier failure by sampling unculled baked block-model quads (`getQuads(null)`) as well as directional face quads when building the vanilla block colour database.
- Kept texture sampling resource-pack-aware and retained tint/map-colour fallback for contextual faces.

## 1.3.40

- Added a separate **Giant Block Builder** entry point from the Character Painter. The picker searches all non-air block registry entries (vanilla and installed mods) by localized name or identifier, rather than maintaining a hard-coded block list.
- Added 16³ one-source-texel-per-world-voxel output for vanilla 16×16 block textures and a 32³ output intended for 32px HD resource-pack textures; lower-resolution textures are enlarged with nearest-neighbour sampling. Texture layout is preserved, while each texel colour is matched to the closest safe full-cube material available in Minecraft.
- Reads each of the six directional baked block-model face sprites from the active resource-pack stack and converts source texels into voxel positions independently. Edge/corner voxels average the face samples that meet at the shared world block.
- Matches every output texel to the existing OKLab-scored safe full-cube vanilla material palette, so even non-cube/interactive source blocks can be represented without placing the source block itself.
- Builds an exterior shell instead of filling the entire 16³/32³ volume, preserving the visible giant-block surface while keeping multiplayer build sizes bounded. The generated model reuses the existing voxel editor, save, preview and server-authorized build pipeline.

## 1.3.39

- Added a conditional second vanilla placement attempt for each Player-tab statue cell on remote servers. A cell is retried only after its first interaction fails to survive the ping-aware confirmation window and the target is still air.
- Before every normal or retry interaction, the builder checks the target block state: the exact desired block is marked confirmed and skipped; a different occupied block is left untouched.
- Retries use the existing two-interactions-per-tick budget and are prioritized as soon as the acknowledgement window expires. No duplicate click is sent after the desired block is visible.
- Kept the integrated singleplayer path unchanged: it performs one direct authoritative block write per empty target, skipping cells already containing the correct block.

## 1.3.38

- Split player-statue construction into a fast integrated-singleplayer path and a server-paced multiplayer path.
- Singleplayer batches up to 128 safe block writes per integrated-server tick, with no simulated right-clicks, hotbar swaps, reach checks, or workstation GUI interactions.
- Multiplayer begins at two vanilla placements per tick (one per tick on very high ping), with a bounded ping-sized confirmation queue and shorter adaptive retry windows.
- Keep final multiplayer integrity/stability scans so delayed server rollbacks are repaired instead of silently accepted.

## 1.3.37
- Reworked the Player tab multiplayer statue builder to send only one block placement at a time. A second placement is not sent until the previous one has remained present through a ping-aware confirmation window; latency changes the wait time, not the number of queued interactions.
- Kept automatic whole-statue integrity scans and repair passes. Missing cells increase the spacing/backoff rather than triggering another burst, and the in-flight queue is always capped at one.
- Added a safe placement-face filter. The builder no longer right-clicks block entities or menu-opening workstations such as crafting, cartography, smithing, fletching and loom tables, stonecutters, grindstones, anvils, furnaces or chests. It searches another sturdy face instead, avoiding accidental container/workstation screens.
- Clarified that client-only placement cannot guarantee a server will accept a block; permissions, claims, reach and server anti-cheat remain authoritative. The owner-authorized server companion remains the reliable server-side path for worlds where it is installed.

## 1.3.36
- Fixed the release verifier's exact block-ownership check in journal restoration. Undo and shutdown cleanup now read the current block state once and restore only when it still equals the state placed by that statue job. No ownership check was removed or weakened.

# Changelog
## 1.3.36

- Fixed the Minecraft 26.2 client compilation error in the Player Statue Builder's count-preview palette. White concrete is now resolved by its registry identifier, with calcite as a safe fallback, instead of referencing a `Blocks.WHITE_CONCRETE` field that is not exposed by the active mappings.


## 1.3.34

- Replaced the legacy Player-tab statue builder's fixed 48 wool/concrete/terracotta swatches with a per-skin palette sampled from safe vanilla full-cube block textures. Dark, midtone and highlight variants are preselected so skin pixels and face shading can use a much broader set of real materials.
- Matched skin colours in OKLab and applied directional shading in linear light, improving subtle gradients and reducing harsh colour banding.
- Split the statue's inner body, hat, jacket, right sleeve, left sleeve, right pant and left pant into ordered build layers. The left sleeve is placed after the inner arm and extrudes one voxel outward without filling the torso seam.
- Allowed multiple completed statues to stay built (up to 16 tracked entries per player). Undo Last removes only the newest statue; pressing it again removes the previous one. Both the Player tab builder and the server-authoritative Character Painter use newest-first undo journals.
- Updated control labels and progress messages to say Undo Last rather than implying that all statue history is deleted at once.
- Expanded the core smoke test to verify that the left sleeve is its own second editor layer and extends exactly one voxel beyond classic and slim inner arms.

## 1.3.33

- Fixed Minecraft 26.2 block-texture palette compilation: imported `BufferedImage` and stopped calling the unavailable `SpriteContents.getOriginalImage()` method.
- Samples block source PNGs through the active Minecraft `ResourceManager`, so current resource packs are respected without accessing private sprite image fields.
- Samples only the first logical frame of animated textures and safely falls back per missing/broken texture instead of aborting the entire palette scan.
- Updated release verification to assert the supported resource-loading path and reject the removed API.

## 1.3.32
- Confirmed and regression-tested separate skin overlay layer IDs for hat/head, jacket, right sleeve, left sleeve, right pant and left pant; the server build queue already emits each enabled layer's own voxel cells.
- Prewarms the resource-pack texture palette on a daemon worker; the default white mannequin now starts from a known white-concrete palette entry so opening the Studio does not scan all block models on the render thread.
- Defers color-wheel matching until the background palette is ready and applies only the newest selected color after sampling completes.
- Expanded block palette discovery so a missing/`MapColor.NONE` entry does not exclude a textured full-cube vanilla block. Such blocks are added only when the active baked model supplies visible texture pixels.
- Increased the imported-skin material palette from 224 to 248 slots, keeping more individual shades while reserving seven palette slots for later brush additions.
- Added a texture-sampled candidate count to the brush status and an explicit failure instead of silently using MapColor-only matching if every model sample fails.
- Samples real resource-pack sprite pixels across all six model directions, averages opaque pixels in linear light, and matches each skin pixel independently using OKLab for more reliable brown, gray, stone, wood and light/dark gradient matches.
- Keeps tint-indexed faces biome-independent via map-colour fallback and retains the server's safe full-cube restrictions (no partial shapes, fluids, block entities, falling blocks or dangerous special blocks).
- Tightened the smoke test to assert exact names for all eight skin model layers, including independent left/right sleeves and pants.

## 1.3.31
- Kept the skin importer split into independent base, hat/head, jacket, right sleeve, left sleeve, right pant, left pant, and custom-accessory layers.
- Replaced coarse MapColor-only matching with live baked block-model texture sampling across all six visible faces.
- Averages each face's active resource-pack texture in linear light, uses map colour only for context-tinted quads/fallbacks, and ranks candidates in OKLab for more accurate dark/light browns and gradients.
- Expands palette selection to keep frequent materials plus perceptually distinct low-frequency shades within the compact 255-material limit.
- Adds stronger directional shading in the Character Painter preview so cuboid faces have clearer depth.
- Keeps server validation limited to safe vanilla full-cube blocks; the palette cannot select partial, fluid, block-entity, falling, hazard, or special destructive blocks.


## 1.3.30
- Split imported Minecraft skin overlays into independent model layers: hat/head, jacket, right sleeve, left sleeve, right pant and left pant; custom accessories remain a separate layer.
- Rebuilt skin cuboid shells so the clothing regions are stored as distinct layer IDs without merging both trouser legs into one layer.
- Replaced the fixed 48-entry wool/concrete/terracotta palette with a runtime scan of safe vanilla full-cube block states across the Minecraft block registry.
- Added perceptual OKLab matching for skin pixels and color-wheel selections, improving dark brown, muted, and light/dark gradient choices.
- Expanded the model palette to 255 materials and upgraded the compact cell packing to format v2; format v1 models remain loadable.
- Made the server companion validate and accept the same broader safe full-cube vanilla block family, while rejecting block entities, fluids, partial blocks, falling blocks and hazardous/special blocks.
- Added source-verifier and dependency-free smoke-test coverage for separate pants, separate sleeve layers, OKLab color matching, and palette compatibility.


## 1.3.29
- Fixed a release-verifier false failure: `VoxelRaycaster` is a dedicated client core class, not text that belongs inside `VoxelStudioScreen.java`.
- Moved ray-picking checks to the actual `VoxelRaycaster.java` and `VoxelStudioDocument.java` sources, verifying the DDA implementation and both paint/pick call paths.
- Added explicit client-JAR contents checks for `VoxelStudioDocument`, `VoxelRaycaster`, `VoxelCamera`, and `VoxelMeshBuilder`, so the integrated Character Painter is checked in the artifact itself.
- No Character Painter runtime behavior or UI was changed.

## 1.3.28
- Fixed Character Painter texture compilation for Minecraft 26.2: use `TextureManager.register(Identifier, AbstractTexture)` and `NativeImage.setPixel(x, y, argb)`.
- Removed obsolete `registerDynamicTexture` and `setPixelRGBA` calls.
- Moved dynamic preview texture creation/upload into the client tick, outside render extraction, to avoid GPU uploads during an active render pass.
- Kept Character Painter integrated into the NoteClient client mod with its white 3D player, color wheel, direct surface painting, undo/redo, and save/load workflow.

## Previous release: 1.3.27

## Integrated Character Painter

- Fixed the Minecraft 26.2 server companion compile error by resolving the `MinecraftServer` through the player's `ServerLevel`; 26.2 `ServerPlayer` does not expose the older `getServer()` call.
- Made the Character Painter's default canvas a solid white, fully 3D player with separate head, torso, arm and leg cuboids.
- Added a generated HSV color wheel. Wheel selections map to the nearest supported vanilla wool, concrete or terracotta block color.
- Added a WHITE reset action to restore the untouched white player.
- Changed base-layer painting to recolor the actual surface voxel instead of adding a new voxel in front of the body.
- Kept the Character Painter inside the NoteClient client source set, under NoteClient's own key category and main client JAR. No separate Voxel Studio mod is required.
- Preserved skin PNG/preset/online-player imports, saved templates, layer tools, orbit camera, undo/redo and server build/remove controls.
- Expanded the dependency-free core smoke test to cover the white player and surface recoloring.
