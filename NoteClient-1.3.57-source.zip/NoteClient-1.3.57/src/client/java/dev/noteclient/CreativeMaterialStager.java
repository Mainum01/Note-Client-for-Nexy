package dev.noteclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.level.GameType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Stocks the player's real Creative inventory with the materials used by a
 * client-side build. Existing stacks are topped up; empty slots are used for
 * new materials; unrelated inventory contents are never overwritten.
 *
 * This intentionally uses vanilla Creative inventory updates. A remote server
 * remains authoritative and may reject them, just as it can reject any other
 * Creative inventory update.
 */
public final class CreativeMaterialStager {
    private CreativeMaterialStager() {}

    public static Result stage(Minecraft client, Map<Item, Integer> requestedMaterials) {
        if (client == null || client.player == null || client.gameMode == null
                || client.gameMode.getPlayerMode() != GameType.CREATIVE) {
            return new Result(0, 0, 0, 0);
        }
        if (requestedMaterials == null || requestedMaterials.isEmpty()) {
            return new Result(0, 0, 0, 0);
        }

        LocalPlayer player = client.player;
        List<Map.Entry<Item, Integer>> materials = new ArrayList<>(requestedMaterials.entrySet());
        // If the palette is larger than the inventory, keep the most-used
        // materials first so the stocked inventory is as useful as possible.
        materials.sort(Comparator
                .<Map.Entry<Item, Integer>>comparingInt(entry -> entry.getValue() == null ? 0 : entry.getValue())
                .reversed());

        List<Grant> grants = new ArrayList<>();
        int alreadyStocked = 0;
        int unableToFit = 0;

        for (Map.Entry<Item, Integer> material : materials) {
            Item item = material.getKey();
            if (item == null || item == Items.AIR) continue;

            ItemStack sample = new ItemStack(item);
            int targetCount = Math.max(1, sample.getMaxStackSize());
            int bestSlot = -1;
            int bestCount = -1;
            int emptySlot = -1;

            for (int slot = 0; slot < 36; slot++) {
                ItemStack existing = player.getInventory().getItem(slot);
                if (existing.isEmpty()) {
                    if (emptySlot < 0) emptySlot = slot;
                    continue;
                }
                if (!existing.is(item)) continue;
                if (existing.getCount() >= targetCount) {
                    bestSlot = slot;
                    bestCount = targetCount;
                    break;
                }
                if (existing.getCount() > bestCount) {
                    bestSlot = slot;
                    bestCount = existing.getCount();
                }
            }

            if (bestSlot >= 0 && bestCount >= targetCount) {
                alreadyStocked++;
                continue;
            }

            if (bestSlot >= 0) {
                ItemStack toppedUp = player.getInventory().getItem(bestSlot).copy();
                toppedUp.setCount(targetCount);
                grants.add(new Grant(bestSlot, toppedUp));
            } else if (emptySlot >= 0) {
                grants.add(new Grant(emptySlot, new ItemStack(item, targetCount)));
            } else {
                unableToFit++;
            }
        }

        // Apply only after the plan has been built, so every grant is assigned
        // to an existing matching stack or a genuinely empty slot.
        for (Grant grant : grants) {
            player.getInventory().setItem(grant.inventorySlot, grant.stack.copy());
            int menuSlot = grant.inventorySlot < 9 ? 36 + grant.inventorySlot : grant.inventorySlot;
            client.gameMode.handleCreativeModeItemAdd(grant.stack.copy(), menuSlot);
        }

        return new Result(requestedMaterials.size(), grants.size(), alreadyStocked, unableToFit);
    }

    public record Result(int requestedTypes, int addedTypes, int alreadyStockedTypes, int unableToFitTypes) {
        public String summary() {
            if (requestedTypes <= 0) return "no extra materials needed";
            StringBuilder text = new StringBuilder("inventory: ")
                    .append(addedTypes).append(" material type(s) added")
                    .append(", ").append(alreadyStockedTypes).append(" already stocked");
            if (unableToFitTypes > 0) {
                text.append(", ").append(unableToFitTypes)
                        .append(" could not fit (free inventory slots to collect the rest)");
            }
            return text.toString();
        }
    }

    private record Grant(int inventorySlot, ItemStack stack) {}
}
