package dev.noteclient;

import dev.noteclient.network.BuildControlPayload;
import dev.noteclient.plan.NoteBlockPlanner;
import dev.noteclient.plan.NoteBlockPlanner.PlanResult;
import dev.noteclient.plan.NoteBlockPlanner.Placement;
import dev.noteclient.plan.NoteBlockPlanner.TimedNote;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.component.BlockItemStateProperties;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Client-only builder for ordinary servers. When started in Creative, it stages
 * the required block stacks and builds/tunes the complete arrangement with normal
 * Creative item interactions. Elevated stable instrument supports are attempted
 * directly in air with normal server-validated interactions; no glass towers are
 * created. Gravity-based supports are placed only where a real sturdy floor exists.
 * An ordinary multiplayer server controls its
 * own game mode, so only singleplayer can be switched automatically here.
 * The only optional command is the user-triggered /reach 100 request in Settings;
 * unrelated blocks are never replaced.
 */
public final class VanillaServerBuilder {
    private static final int TEMP_HOTBAR_SLOT = 8;
    // The build pipeline uses a bounded adaptive queue of ordinary interactions per tick.
    // A bounded acknowledgement window keeps the rate adaptive on laggy servers.
    private static final int MAX_PLAYER_ATTACKS_PER_TICK = 4;
    private static final int TUNING_ACK_TIMEOUT_TICKS = 4;
    private static final int MAX_TUNE_IN_FLIGHT = 128;
    // Creative block breaks are predicted immediately by the client. Wait one
    // server tick for confirmation, then continue. Several breaks can be in flight.
    private static final int CLEANUP_LATE_PLACEMENT_GRACE_TICKS = 6;
    private static final int CLEANUP_BREAK_CONFIRM_GRACE_TICKS = 3;
    private static final int CLEANUP_BREAK_RETRY_TICKS = 5;
    private static final int CLEANUP_BREAK_MAX_ATTEMPTS = 4;
    // Creative can remove blocks immediately. Keep a high but bounded pipeline
    // so large arrangements clear in batches without unbounded packet bursts.
    private static final int MAX_PENDING_CLEANUPS = 384;
    private static final int PLAYBACK_INTEGRITY_CHECKS_PER_TICK = 64;
    private static final int TUNING_INTEGRITY_CHECKS_PER_TICK = 48;
    // Tuning is deliberately time-sliced and runs after the other builders/input.
    // A huge configured budget therefore cannot monopolize the client tick.
    private static final long MAX_TUNING_WORK_NANOS = 4_000_000L;
    private static final int SURVIVAL_CLEANUP_TIMEOUT_TICKS = 600;
    private static final int BUILD_ACTION_INTERVAL_TICKS = 1;
    // Two ticks allows the normal server block update to return without adding
    // the old one-second wait after every placed block.
    private static final int PLACEMENT_CONFIRM_GRACE_TICKS = 1;
    private static final int CREATIVE_PLACEMENT_ACK_TIMEOUT_TICKS = 5;
    private static final int SURVIVAL_PLACEMENT_ACK_TIMEOUT_TICKS = 30;
    private static final int PLACEMENT_RETRY_DELAY_TICKS = 1;
    private static final int MAX_PLANNED_DOME_LIFT = 24;
    private static final int MAX_COMPACT_DOME_RADIUS = 6;
    private static final int PLAYBACK_START_DELAY_TICKS = 4;
    // Use the server-synchronized range, or the explicit 100-block planning hint
    // after the user requests the server's custom /reach 100 command in Settings.
    // The server still validates every interaction.
    private static final double REACH_SAFETY_MARGIN = 0.05;
    private static final double DEFAULT_SURVIVAL_REACH = 4.5;
    private static final Pattern NOTE_VALUE_PATTERN = Pattern.compile("(?:\\[|,\\s*)note=(\\d+)(?:,|\\])");
    private static final Pattern NOTE_INSTRUMENT_PATTERN = Pattern.compile("(?:\\[|,\\s*)instrument=([a-z0-9_]+)(?:,|\\])");
    private static final Map<String, SoundEvent> NOTE_SOUNDS = new HashMap<>();
    private static final Set<String> MISSING_SOUND_WARNINGS = new HashSet<>();

    private static Job activeJob;

    private VanillaServerBuilder() {}

    public static boolean hasActiveJob() {
        return activeJob != null;
    }

    public static boolean start(Minecraft client, PlanResult plan, int tempoHundredths, int songLengthTicks) {
        if (client == null || client.player == null || client.level == null || client.gameMode == null) {
            BuildClientState.reset("Join a world before building.");
            return false;
        }
        if (plan == null || plan.placements().isEmpty()) {
            return reject(client, "This song has no supported vanilla note-block slots to build.");
        }
        if (tempoHundredths <= 0 || plan.timeline().isEmpty()) {
            return reject(client, "This file has no playable NBS timeline. The universal reference grid requires the server-assisted builder.");
        }

        Request request = new Request(plan, tempoHundredths, songLengthTicks);
        if (activeJob != null) {
            if (client.gameMode != null) client.gameMode.stopDestroyBlock();
            activeJob.pendingRequest = request;
            activeJob.paused = false;
            activeJob.beginCleanup("Switching songs: removing the previous NoteClient arrangement first...");
            publish(client, activeJob, "Song swap queued. Cleaning the previous arrangement before building the new one.");
            return true;
        }
        GameType mode = client.gameMode.getPlayerMode();
        if (mode != GameType.CREATIVE && mode != GameType.SURVIVAL) {
            return reject(client, "NoteClient construction requires Creative or Survival mode. Adventure and Spectator cannot place the arrangement.");
        }
        boolean created = createJob(client, request);
        if (!created) sendMessage(client, BuildClientState.message());
        return created;
    }

    public static void control(Minecraft client, int action) {
        if (activeJob == null) {
            BuildClientState.reset("No client-only NoteClient arrangement is active.");
            return;
        }
        Job job = activeJob;
        if (action == BuildControlPayload.TOGGLE_PAUSE) {
            if (!job.paused) {
                job.paused = true;
                job.pausedAt = client.level == null ? 0 : client.level.getGameTime();
                publish(client, job, "Paused. Press P to resume or O to cancel and clean up.");
            } else {
                long now = client.level == null ? job.pausedAt : client.level.getGameTime();
                long pauseDuration = Math.max(0, now - job.pausedAt);
                if (job.phase == Phase.PLAYING && job.playbackStart >= 0) job.playbackStart += pauseDuration;
                job.nextActionGameTime += pauseDuration;
                if (job.phase == Phase.CLEANUP) {
                    for (PendingCleanup pending : job.pendingCleanups) pending.sentAt += pauseDuration;
                    if (job.survivalCleanupStartedAt != Long.MIN_VALUE) job.survivalCleanupStartedAt += pauseDuration;
                    if (job.survivalCleanupConfirmedAt != Long.MIN_VALUE) job.survivalCleanupConfirmedAt += pauseDuration;
                }
                if (job.pendingSupportRecoverySentAt != Long.MIN_VALUE) {
                    job.pendingSupportRecoverySentAt += pauseDuration;
                }
                if (job.pendingSupportRecoveryAirObservedAt != Long.MIN_VALUE) {
                    job.pendingSupportRecoveryAirObservedAt += pauseDuration;
                }
                for (int i = 0; i < job.pendingPlacements.size(); i++) {
                    PendingPlacement pending = job.pendingPlacements.get(i);
                    job.pendingPlacements.set(i, new PendingPlacement(pending.position, pending.expectedBlock,
                            pending.kind, pending.operationIndex,
                            pending.sentAt + pauseDuration, pending.timeoutAt + pauseDuration));
                }
                job.paused = false;
                // A failed placement is retried when the user resumes. Clear its
                // retry state so a previous delay does not slow the resumed job.
                publish(client, job, "Resumed. The next unconfirmed block will be retried.");
            }
            return;
        }
        if (action == BuildControlPayload.CANCEL || action == BuildControlPayload.DESTROY) {
            if (client != null && client.gameMode != null) client.gameMode.stopDestroyBlock();
            // In a locally owned singleplayer world, switch back to Creative before
            // cleanup so the arrangement can be removed in the fast batch pipeline.
            // Multiplayer game mode remains entirely server-controlled.
            boolean switchedToCreative = trySwitchIntegratedServerToCreative(client);
            job.pendingRequest = null;
            job.paused = false;
            job.beginCleanup("Removing only blocks placed by this NoteClient arrangement.");
            publish(client, job, switchedToCreative
                    ? "Switching the singleplayer world back to Creative for fast cleanup..."
                    : "Destroying arrangement. Survival uses normal block-breaking speed; multiplayer game mode is server-controlled. Unrelated blocks are never touched.");
        }
    }

    public static void tick(Minecraft client) {
        Job job = activeJob;
        if (job == null) return;
        if (client.player == null || client.level == null || client.gameMode == null) {
            activeJob = null;
            BuildClientState.reset("Disconnected during a client-only build. Some already-placed blocks may remain.");
            return;
        }
        if (client.level != job.level) {
            activeJob = null;
            String message = "You changed dimensions. The client-only job stopped; its old arrangement may remain in the previous dimension.";
            BuildClientState.reset(message);
            sendMessage(client, message);
            return;
        }
        if (job.paused) return;

        GameType currentMode = client.gameMode.getPlayerMode();
        boolean constructionPhase = job.phase == Phase.BASE_SUPPORTS || job.phase == Phase.SCAFFOLDS
                || job.phase == Phase.RAISED_SUPPORTS || job.phase == Phase.NOTES
                || job.phase == Phase.SCAFFOLD_CLEANUP || job.phase == Phase.VERIFYING_NOTES
                || job.phase == Phase.TUNING;
        boolean fixedHandPhase = constructionPhase || job.phase == Phase.PLAYING;
        if (constructionPhase && !job.repairOnlyPass) {
            GameType requiredBuildMode = job.buildInCreative ? GameType.CREATIVE : GameType.SURVIVAL;
            if (currentMode != requiredBuildMode) {
                job.nextActionGameTime = client.level.getGameTime() + 2;
                if (job.lastMessageTime == Long.MIN_VALUE || client.level.getGameTime() - job.lastMessageTime >= 100) {
                    job.lastMessageTime = client.level.getGameTime();
                    String expected = job.buildInCreative ? "Creative" : "Survival";
                    publish(client, job, "Construction is paused until you are back in " + expected
                            + ". NoteClient will preserve confirmed placements and resume automatically.");
                }
                return;
            }
        } else if (job.repairOnlyPass && currentMode != GameType.CREATIVE && currentMode != GameType.SURVIVAL) {
            publish(client, job, "Automatic note repair needs Creative or Survival mode. The arrangement is preserved.");
            job.nextActionGameTime = client.level.getGameTime() + 10;
            return;
        }
        if (fixedHandPhase && client.player.getInventory().getSelectedSlot() != job.workHotbarSlot) {
            client.player.getInventory().setSelectedSlot(job.workHotbarSlot);
            job.nextActionGameTime = client.level.getGameTime() + 1;
            return;
        }
        if (constructionPhase && client.gui.screen() != null) {
            job.nextActionGameTime = client.level.getGameTime() + 5;
            if (job.lastMessageTime == Long.MIN_VALUE || client.level.getGameTime() - job.lastMessageTime >= 100) {
                job.lastMessageTime = client.level.getGameTime();
                publish(client, job, "Construction paused while a screen is open. Close your inventory, chat, or container to continue placing blocks.");
            }
            return;
        }

        long now = client.level.getGameTime();
        if (now < job.nextActionGameTime) return;

        // Drain confirmed updates, then keep a small adaptive pipeline in flight.
        // This avoids the old one-placement-per-tick ceiling while still backing
        // off naturally when the server stops confirming interactions.
        if (!job.pendingPlacements.isEmpty()) {
            if (tickPendingPlacements(client, job, now)) return;
        }
        if (job.paused) return;
        if (job.pendingSupportRecoveryCell != null) {
            tickSupportRecovery(client, job, now);
            return;
        }
        // A manual destroy or song swap must not race placements that are still
        // awaiting server confirmation. Let the bounded queue settle first.
        if (job.phase == Phase.CLEANUP && !job.pendingPlacements.isEmpty()) {
            job.nextActionGameTime = now + 1;
            return;
        }
        int currentBuildRate = effectiveBuildActionsPerTick(job);
        int maxInFlight = Math.max(3, currentBuildRate * 3);
        if (job.pendingPlacements.size() >= maxInFlight) {
            job.nextActionGameTime = now + 1;
            return;
        }
        switch (job.phase) {
            case BASE_SUPPORTS -> tickBaseSupports(client, job, now);
            case SCAFFOLDS -> tickScaffolds(client, job, now);
            case RAISED_SUPPORTS -> tickRaisedSupports(client, job, now);
            case NOTES -> tickNotes(client, job, now);
            case SCAFFOLD_CLEANUP -> tickScaffoldCleanup(client, job, now);
            case VERIFYING_NOTES -> tickFinalVerification(client, job, now);
            case TUNING -> tickTuning(client, job, now);
            case WAITING_FOR_SURVIVAL -> tickWaitForSurvival(client, job, now);
            case WAITING_FOR_MATERIALS -> tickWaitForMaterials(client, job, now);
            case PLAYING -> tickPlayback(client, job, now);
            case CLEANUP -> tickCleanup(client, job, now);
            case RETAINED -> { /* Wait for the user to press Destroy. */ }
        }
    }

    private static boolean createJob(Minecraft client, Request request) {
        LocalPlayer player = client.player;
        Direction forward = Direction.fromYRot(player.getYRot());
        Direction right = forward.getClockWise();
        BlockPos center = player.blockPosition();
        boolean buildInCreative = client.gameMode.getPlayerMode() == GameType.CREATIVE;
        double currentReach = blockInteractionReach(player);
        // Construction may use the synchronized Creative reach, but every note
        // must remain playable from the player's ordinary Survival reach.
        double survivalReach = Math.max(0.5,
                currentReach - (buildInCreative ? 0.5 : 0.0) - REACH_SAFETY_MARGIN);
        double buildReach = Math.max(0.5, currentReach - REACH_SAFETY_MARGIN);

        /*
         * A vanilla note block has only 25 physical pitch levels. NBS keys may
         * differ by one or more octaves while folding to the same physical pitch,
         * so those keys share a physical note block. Repeated events are retained
         * in the timeline and played as separate attacks.
         */
        Map<PhysicalKey, PhysicalNeed> needsByKey = new HashMap<>();
        for (TimedNote event : request.plan.timeline()) {
            int originalIndex = event.cellIndex();
            if (originalIndex < 0 || originalIndex >= request.plan.placements().size()) {
                return reject(client, "The song contains an invalid note-to-block mapping. No blocks were placed.");
            }
            Placement source = request.plan.placements().get(originalIndex);
            PhysicalKey key = new PhysicalKey(source.instrumentId(), source.noteBlockPitch());
            PhysicalNeed need = needsByKey.computeIfAbsent(key, ignored -> new PhysicalNeed(key, source));
            need.occurrences++;
        }

        List<PhysicalNeed> needs = new ArrayList<>(needsByKey.values());
        for (PhysicalNeed need : needs) {
            // Same instrument + physical pitch can reuse one block; the original
            // event queue still preserves every repeated and simultaneous event.
            need.copies = 1;
        }
        // Reserve ground-level positions for gravity-affected supports (Snare's
        // sand) before stable blocks consume the bottom ring. Otherwise a common
        // stable instrument could occupy every grounded slot and make a later
        // sand cell fail even though the dome had enough space overall.
        needs.sort(Comparator
                .comparing((PhysicalNeed need) -> !(lookupBlock(need.representative.supportBlock()) instanceof FallingBlock))
                .thenComparing(Comparator.comparingInt((PhysicalNeed need) -> need.occurrences).reversed())
                .thenComparingInt(need -> need.key.instrumentId)
                .thenComparingInt(need -> need.key.pitch));

        int requiredPhysicalBlocks = needs.stream().mapToInt(need -> need.copies).sum();
        // Build only the smallest dome that can hold this arrangement. Do not
        // pre-scan the server's entire /reach radius: unused distant candidates
        // made recovery retries scatter a second build across many chunks.
        List<Offset> offsets = accessibleDomeOffsets(player, center, right, forward,
                survivalReach, buildReach, requiredPhysicalBlocks);
        if (requiredPhysicalBlocks > offsets.size()) {
            return reject(client, "This song needs " + requiredPhysicalBlocks
                    + " physical note blocks, but the reachable dome has only " + offsets.size()
                    + " safe positions here. No blocks were placed. Move to a clear, flat area, confirm the server's /reach setting, or choose a smaller song.");
        }

        List<Cell> cells = new ArrayList<>(requiredPhysicalBlocks);
        List<Scaffold> scaffolds = new ArrayList<>();
        Map<PhysicalKey, List<Integer>> cellsByPhysicalKey = new HashMap<>();
        int blockedGround = 0;
        int occupiedSpace = 0;
        int outsideWorld = 0;
        int outOfReach = 0;
        int unsupported = 0;
        int offsetCursor = 0;
        Vec3 eye = player.getEyePosition();

        for (PhysicalNeed need : needs) {
            Placement placement = need.representative;
            Block support = lookupBlock(placement.supportBlock());
            if (support == Blocks.AIR || support.asItem() == null
                    || support.asItem() == net.minecraft.world.item.Items.AIR) {
                unsupported++;
                return reject(client, "The vanilla instrument support for instrument "
                        + placement.instrumentName() + " is unavailable. No blocks were placed.");
            }

            List<Integer> groupCells = new ArrayList<>(need.copies);
            for (int copy = 0; copy < need.copies; copy++) {
                boolean assigned = false;
                while (offsetCursor < offsets.size()) {
                    Offset offset = offsets.get(offsetCursor++);
                    BlockPos basePos = center.relative(right, offset.right)
                            .relative(forward, offset.forward);
                    BlockPos supportPos = basePos.above(offset.up);
                    BlockPos notePos = supportPos.above();
                    BlockPos soundSpace = notePos.above();

                    boolean outside = !client.level.getWorldBorder().isWithinBounds(supportPos)
                            || !client.level.getWorldBorder().isWithinBounds(notePos)
                            || !client.level.getWorldBorder().isWithinBounds(soundSpace)
                            || client.level.isOutsideBuildHeight(supportPos)
                            || client.level.isOutsideBuildHeight(soundSpace);
                    if (outside) {
                        outsideWorld++;
                        continue;
                    }

                    // Most instrument supports are ordinary full blocks and can
                    // be placed with a normal interaction aimed at the air cell
                    // immediately below their target. Falling supports (Snare's
                    // sand) are different: they must have a real sturdy floor.
                    if (support instanceof FallingBlock
                            && !client.level.getBlockState(supportPos.below())
                            .isFaceSturdy(client.level, supportPos.below(), Direction.UP)) {
                        blockedGround++;
                        continue;
                    }

                    boolean occupied = !client.level.getBlockState(supportPos).isAir()
                            || !client.level.getBlockState(notePos).isAir()
                            || !client.level.getBlockState(soundSpace).isAir();
                    if (occupied) {
                        occupiedSpace++;
                        continue;
                    }

                    BlockHitResult supportHit = supportPlacementHit(player, supportPos);
                    Vec3 notePlacementHit = topFacePointToward(eye, supportPos);
                    Vec3 notePlaybackPoint = Vec3.atCenterOf(notePos);
                    boolean reachable = eye.distanceTo(supportHit.getLocation()) <= buildReach
                            && eye.distanceTo(notePlacementHit) <= buildReach
                            && eye.distanceTo(notePlaybackPoint) <= survivalReach;
                    if (!reachable) {
                        outOfReach++;
                        continue;
                    }

                    String soundName = NoteBlockPlanner.instruments()
                            .get(placement.instrumentId()).noteBlockInstrument();
                    int mappedIndex = cells.size();
                    cells.add(new Cell(mappedIndex, support, soundName, supportPos, notePos,
                            placement.noteBlockPitch(), placement.nbsKey(), offset.up > 0));
                    groupCells.add(mappedIndex);
                    assigned = true;
                    break;
                }

                if (!assigned) {
                    return reject(client, "NoteClient could only find " + cells.size() + " of "
                            + requiredPhysicalBlocks + " required note-block positions within normal reach. "
                            + "Blocked floor: " + blockedGround + "; occupied positions: " + occupiedSpace
                            + "; outside world/build height: " + outsideWorld + "; out of reach: "
                            + outOfReach + "; unsupported: " + unsupported
                            + ". No blocks were placed. Move to a clear, flat area and try again.");
                }
            }
            cellsByPhysicalKey.put(need.key, groupCells);
        }

        // Report the layers the selected song actually uses, not every candidate
        // position that happened to be reachable during layout scanning.
        int domeHeightBands = (int) cells.stream()
                .map(cell -> cell.supportPos.getY() - center.getY()).distinct().count();
        int domeMaxLift = cells.stream()
                .mapToInt(cell -> cell.supportPos.getY() - center.getY()).max().orElse(0);
        int domeRadiusBlocks = (int) Math.ceil(cells.stream()
                .mapToDouble(cell -> Math.sqrt(Math.pow(cell.supportPos.getX() - center.getX(), 2)
                        + Math.pow(cell.supportPos.getZ() - center.getZ(), 2))).max().orElse(0.0));

        List<TimedNote> mappedTimeline = new ArrayList<>(request.plan.timeline().size());
        for (TimedNote event : request.plan.timeline()) {
            if (event.cellIndex() < 0 || event.cellIndex() >= request.plan.placements().size()) {
                return reject(client, "The song contains an invalid note-to-block mapping. No blocks were placed.");
            }
            Placement source = request.plan.placements().get(event.cellIndex());
            PhysicalKey key = new PhysicalKey(source.instrumentId(), source.noteBlockPitch());
            List<Integer> groupCells = cellsByPhysicalKey.get(key);
            if (groupCells == null || groupCells.isEmpty()) {
                return reject(client, "The reachable dome could not map every note event. "
                        + "No blocks were placed; try another arrangement area or a smaller song.");
            }
            mappedTimeline.add(new TimedNote(event.tick(), groupCells.get(0), event.volume(),
                    event.panning(), event.finePitchCents(), source.nbsKey()));
        }

        int originalSelected = player.getInventory().getSelectedSlot();
        List<Cell> baseCells = cells.stream().filter(cell -> !cell.raised).toList();
        List<Cell> raisedCells = cells.stream().filter(cell -> cell.raised).toList();
        int tuningSteps = cells.stream().mapToInt(cell -> cell.pitch).sum();
        int totalOperations = 2 * cells.size() + tuningSteps;
        List<Offset> relocationOffsets = offsetCursor < offsets.size()
                ? new ArrayList<>(offsets.subList(offsetCursor, offsets.size()))
                : new ArrayList<>();
        Job job = new Job(client.level, cells, baseCells, raisedCells, scaffolds, relocationOffsets,
                center, right, forward, mappedTimeline, request.tempoHundredths,
                request.songLengthTicks, totalOperations, 0, originalSelected,
                buildInCreative, player.getYRot());
        activeJob = job;

        if (client.gameMode.getPlayerMode() == GameType.CREATIVE) {
            int reservedSlot = stageRequiredMaterials(client, job);
            if (reservedSlot < 0) {
                activeJob = null;
                BuildClientState.reset("Could not prepare the materials. Free inventory space and at least one hotbar slot, then try again.");
                sendMessage(client, BuildClientState.message());
                return false;
            }
            job.workHotbarSlot = reservedSlot;
            player.getInventory().setSelectedSlot(job.workHotbarSlot);
            job.phase = Phase.BASE_SUPPORTS;
            job.nextActionGameTime = client.level.getGameTime() + 2;
            publish(client, job, "Dome layout ready: " + cells.size() + " physical note blocks across "
                    + domeHeightBands + " reachable height bands (maximum lift " + domeMaxLift + "), "
                    + baseCells.size() + " ground-level + " + raisedCells.size() + " elevated, covering "
                    + mappedTimeline.size() + " of " + request.plan.timeline().size()
                    + " source note events. Compact " + domeRadiusBlocks + "-block radius; starting beside your feet "
                    + "at the bottom ring and building upward in three-block tiers. No glass scaffold towers; "
                    + "then switching to Survival for playback.");
            return true;
        }

        job.workHotbarSlot = reserveWorkingHotbarSlot(client);
        if (job.workHotbarSlot < 0) {
            activeJob = null;
            return reject(client, "Survival construction needs one free inventory slot so NoteClient can reserve an empty hand for tuning.");
        }
        String missing = missingMaterials(player, job);
        if (!missing.isEmpty()) {
            activeJob = null;
            return reject(client, "You're already in Survival, but you're missing materials: " + missing
                    + ". Switch to Creative to let NoteClient stage the required blocks, or gather them manually.");
        }
        player.getInventory().setSelectedSlot(job.workHotbarSlot);
        job.phase = Phase.BASE_SUPPORTS;
        job.nextActionGameTime = client.level.getGameTime() + 2;
        publish(client, job, "Dome layout ready: " + cells.size() + " physical note blocks across "
                + domeHeightBands + " reachable height bands (maximum lift " + domeMaxLift + "), "
                + baseCells.size() + " ground-level and " + raisedCells.size()
                + " elevated positions. Compact " + domeRadiusBlocks + "-block radius; starting beside your feet "
                + "at the bottom ring and building upward. Building with ordinary block interactions in Survival.");
        return true;
    }

    private static void tickScaffolds(Minecraft client, Job job, long now) {
        if (job.scaffoldIndex >= job.scaffolds.size()) {
            if (hasPendingKind(job, PendingKind.SCAFFOLD)) {
                job.nextActionGameTime = now + 1;
                return;
            }
            job.phase = Phase.RAISED_SUPPORTS;
            job.index = 0;
            job.nextActionGameTime = now + 1;
            publish(client, job, "Temporary dome supports confirmed. Placing elevated instrument supports...");
            return;
        }

        int sent = 0;
        while (job.scaffoldIndex < job.scaffolds.size() && sent < effectiveBuildActionsPerTick(job)) {
            Scaffold scaffold = job.scaffolds.get(job.scaffoldIndex);
            if (isPendingPosition(job, scaffold.position)) {
                job.scaffoldIndex++;
                continue;
            }

            BlockState scaffoldState = client.level.getBlockState(scaffold.position);
            if (isCreatedPosition(job, scaffold.position)) {
                if (scaffoldState.is(Blocks.GLASS)) {
                    job.scaffoldIndex++;
                    continue;
                }
                if (scaffoldState.isAir()) {
                    // A delayed server correction removed a previously confirmed
                    // temporary block. Forget the stale ownership record and
                    // place it again instead of stopping the whole arrangement.
                    forgetOwnedBlock(job, scaffold.position);
                } else {
                    forgetOwnedBlock(job, scaffold.position);
                    if (scaffoldState.isFaceSturdy(client.level, scaffold.position, Direction.UP)) {
                        job.scaffoldIndex++;
                        continue;
                    }
                    pauseAndRetain(client, job, "A temporary support position was replaced by a non-solid block. NoteClient left it untouched.");
                    return;
                }
            }

            // Build temporary supports bottom-up. A solid block already in the
            // target position is reused, never claimed or destroyed.
            BlockState belowState = client.level.getBlockState(scaffold.below);
            if (scaffold.chainDependent) {
                if (isPendingPosition(job, scaffold.below)) {
                    job.nextActionGameTime = now + 1;
                    return;
                }
                if (!belowState.isFaceSturdy(client.level, scaffold.below, Direction.UP)) {
                    if (retryMissingScaffold(client, job, scaffold.below, now)) return;
                    waitForSupportSync(client, job, scaffold.below, now);
                    return;
                }
            } else if (!belowState.isFaceSturdy(client.level, scaffold.below, Direction.UP)) {
                waitForSupportSync(client, job, scaffold.below, now);
                return;
            }

            if (scaffoldState.is(Blocks.GLASS)) {
                if (job.placementAttempts.containsKey(scaffold.position)) {
                    recordConfirmedPlacement(job, scaffold.position, Blocks.GLASS);
                }
                job.scaffoldIndex++;
                continue;
            }
            if (!scaffoldState.isAir()) {
                if (scaffoldState.isFaceSturdy(client.level, scaffold.position, Direction.UP)) {
                    job.scaffoldIndex++;
                    continue;
                }
                pauseAndRetain(client, job, "A temporary support position is occupied by a non-solid block. NoteClient will not replace it.");
                return;
            }

            Vec3 scaffoldHit = topFacePointToward(client.player.getEyePosition(), scaffold.below);
            if (!withinBuildReach(client.player, scaffoldHit, job)) {
                waitForReach(client, job, now);
                return;
            }
            if (!equipPlacementItem(client, job, Blocks.GLASS.asItem())) {
                waitForMissingItem(client, job, Blocks.GLASS.asItem(), now);
                return;
            }
            BlockHitResult hit = new BlockHitResult(scaffoldHit, Direction.UP, scaffold.below, false);
            job.placementAttempts.merge(scaffold.position, 1, (oldValue, one) -> Math.min(100000, oldValue + one));
            client.gameMode.useItemOn(client.player, InteractionHand.MAIN_HAND, hit);
            job.pendingPlacements.add(new PendingPlacement(scaffold.position, Blocks.GLASS,
                    PendingKind.SCAFFOLD, job.scaffoldIndex, now, now + placementAckTimeout(job)));
            job.scaffoldIndex++;
            sent++;
        }

        job.nextActionGameTime = now + BUILD_ACTION_INTERVAL_TICKS;
        publishQuietly(client, job, "Raising temporary dome supports: "
                + job.scaffoldIndex + "/" + job.scaffolds.size() + " glass scaffold blocks...");
    }

    private static void tickBaseSupports(Minecraft client, Job job, long now) {
        tickSupportList(client, job, now, job.baseCells, true);
    }

    private static void tickRaisedSupports(Minecraft client, Job job, long now) {
        tickSupportList(client, job, now, job.raisedCells, false);
    }

    private static void tickSupportList(Minecraft client, Job job, long now,
                                        List<Cell> supportCells, boolean baseTier) {
        if (job.index >= supportCells.size()) {
            if (hasPendingKind(job, PendingKind.SUPPORT)) {
                job.nextActionGameTime = now + 1;
                return;
            }
            job.index = 0;
            if (baseTier) {
                job.phase = job.raisedCells.isEmpty() ? Phase.NOTES : Phase.RAISED_SUPPORTS;
                publish(client, job, job.raisedCells.isEmpty()
                        ? "Base supports confirmed. Building note blocks..."
                        : "Base supports confirmed. Placing elevated instrument supports directly...");
            } else {
                // Elevated support blocks have now been placed directly through
                // normal air-cell interactions; no temporary glass dome is left.
                job.phase = Phase.NOTES;
                job.index = 0;
                publish(client, job, "All instrument supports confirmed. Placing note blocks...");
            }
            job.nextActionGameTime = now + 1;
            return;
        }

        int sent = 0;
        while (job.index < supportCells.size() && sent < effectiveBuildActionsPerTick(job)) {
            Cell cell = supportCells.get(job.index);
            if (isPendingPosition(job, cell.supportPos)) {
                job.index++;
                continue;
            }
            BlockPos below = cell.supportPos.below();
            BlockState supportState = client.level.getBlockState(cell.supportPos);
            if (isCreatedPosition(job, cell.supportPos)) {
                if (isCompatibleSupportBlock(cell.support, supportState.getBlock())) {
                    job.supportSyncAttempts.remove(cell.supportPos);
                    job.index++;
                    continue;
                }
                if (supportState.isAir()) {
                    forgetOwnedBlock(job, cell.supportPos);
                } else {
                    waitForChangedSupportSync(client, job, cell, now);
                    return;
                }
            }
            if (isCompatibleSupportBlock(cell.support, supportState.getBlock())) {
                // The exact instrument block appeared while the build was
                // running. It can be used, but is not claimed for later cleanup.
                job.supportSyncAttempts.remove(cell.supportPos);
                job.index++;
                continue;
            }
            if (!supportState.isAir()) {
                waitForChangedSupportSync(client, job, cell, now);
                return;
            }
            // Ordinary full-block instrument supports are attempted directly
            // against the air cell below the target. Only falling supports such
            // as sand need a real sturdy floor or they would fall immediately.
            if (cell.support instanceof FallingBlock
                    && !client.level.getBlockState(below).isFaceSturdy(client.level, below, Direction.UP)) {
                waitForFallingSupportSync(client, job, cell, now);
                return;
            }
            job.supportSyncAttempts.remove(below);

            BlockHitResult hit = supportPlacementHit(client.player, cell.supportPos);
            if (!withinBuildReach(client.player, hit.getLocation(), job)) {
                waitForReach(client, job, now);
                return;
            }
            if (!equipPlacementItem(client, job, cell.support.asItem())) {
                waitForMissingItem(client, job, cell.support.asItem(), now);
                return;
            }
            job.placementAttempts.merge(cell.supportPos, 1, (oldValue, one) -> Math.min(100000, oldValue + one));
            client.gameMode.useItemOn(client.player, InteractionHand.MAIN_HAND, hit);
            job.pendingPlacements.add(new PendingPlacement(cell.supportPos, cell.support,
                    PendingKind.SUPPORT, job.index, now, now + placementAckTimeout(job)));
            job.index++;
            sent++;
        }

        job.nextActionGameTime = now + BUILD_ACTION_INTERVAL_TICKS;
        publishQuietly(client, job, (baseTier ? "Placing lower instrument supports: " : "Placing elevated instrument supports: ")
                + job.index + "/" + supportCells.size() + "...");
    }

    private static int findScaffoldIndex(Job job, BlockPos position) {
        for (int i = 0; i < job.scaffolds.size(); i++) {
            if (job.scaffolds.get(i).position.equals(position)) return i;
        }
        return -1;
    }

    private static boolean retryMissingScaffold(Minecraft client, Job job, BlockPos position, long now) {
        int scaffoldIndex = findScaffoldIndex(job, position);
        if (scaffoldIndex < 0 || !client.level.getBlockState(position).isAir()) return false;
        forgetOwnedBlock(job, position);
        job.phase = Phase.SCAFFOLDS;
        job.scaffoldIndex = Math.min(job.scaffoldIndex, scaffoldIndex);
        job.index = 0;
        job.nextActionGameTime = now + 1;
        publish(client, job, "A temporary support update was missing. Rebuilding that support automatically; confirmed note blocks are preserved.");
        return true;
    }

    private static void waitForChangedSupportSync(Minecraft client, Job job, Cell cell, long now) {
        BlockPos position = cell.supportPos;
        // Re-read immediately before relocating: a late authoritative block
        // update can arrive between polling ticks. Do not move a cell whose
        // original support has already corrected itself.
        BlockState synchronizedState = client.level.getBlockState(position);
        if (isCompatibleSupportBlock(cell.support, synchronizedState.getBlock())) {
            job.supportSyncAttempts.remove(position);
            job.nextActionGameTime = now + 1;
            return;
        }
        int attempts = job.supportSyncAttempts.merge(position, 1, (oldValue, one) -> oldValue + 1);
        if (attempts <= 3) {
            job.nextActionGameTime = now + 1;
            publishQuietly(client, job, "A support update is still synchronizing. Rechecking automatically ("
                    + attempts + "/3)...");
            return;
        }
        job.supportSyncAttempts.remove(position);
        if (relocateSupportCell(client, job, cell, now)) return;
        pauseAndRetain(client, job, "The support position remained occupied and no other safe position is available. NoteClient left the changed block untouched.");
    }

    /**
     * Moves a cell to the next unused, prevalidated dome slot when its planned
     * support target is permanently occupied. The musical cell index is retained,
     * so every timeline event continues to point at the same instrument/pitch.
     */
    private static boolean relocateSupportCell(Minecraft client, Job job, Cell oldCell, long now) {
        if (client == null || client.player == null || client.level == null || oldCell == null) return false;
        Vec3 eye = client.player.getEyePosition();
        while (!job.relocationOffsets.isEmpty()) {
            // Select the spare nearest the failed cell (especially its current
            // height band), never the farthest tail of a world-sized candidate list.
            int spareIndex = nearestRelocationOffsetIndex(job, oldCell);
            Offset offset = job.relocationOffsets.remove(spareIndex);
            BlockPos basePos = job.anchor.relative(job.right, offset.right)
                    .relative(job.forward, offset.forward);
            BlockPos supportPos = basePos.above(offset.up);
            BlockPos notePos = supportPos.above();
            BlockPos soundSpace = notePos.above();
            if (!client.level.getWorldBorder().isWithinBounds(supportPos.below())
                    || !client.level.getWorldBorder().isWithinBounds(soundSpace)
                    || client.level.isOutsideBuildHeight(supportPos.below())
                    || client.level.isOutsideBuildHeight(soundSpace)) continue;
            if (!client.level.getBlockState(supportPos).isAir()
                    || !client.level.getBlockState(notePos).isAir()
                    || !client.level.getBlockState(soundSpace).isAir()) continue;
            if (oldCell.support instanceof FallingBlock
                    && !client.level.getBlockState(supportPos.below())
                    .isFaceSturdy(client.level, supportPos.below(), Direction.UP)) continue;

            BlockHitResult supportHit = supportPlacementHit(client.player, supportPos);
            Vec3 noteHit = topFacePointToward(eye, supportPos);
            if (!withinBuildReach(client.player, supportHit.getLocation(), job)
                    || !withinBuildReach(client.player, noteHit, job)
                    || eye.distanceTo(Vec3.atCenterOf(notePos))
                    > Math.max(0.5, blockInteractionReach(client.player) - REACH_SAFETY_MARGIN)) continue;

            Cell replacement = new Cell(oldCell.index, oldCell.support, oldCell.soundName,
                    supportPos, notePos, oldCell.pitch, oldCell.nbsKey, offset.up > 0);
            job.cells.set(oldCell.index, replacement);
            job.baseCells.removeIf(existing -> existing.index == replacement.index);
            job.raisedCells.removeIf(existing -> existing.index == replacement.index);
            List<Cell> destination = replacement.raised ? job.raisedCells : job.baseCells;
            destination.add(replacement);
            destination.sort(Comparator.comparingInt((Cell cell) -> cell.supportPos.getY())
                    .thenComparingDouble(cell -> horizontalDistanceSquared(job.anchor, cell.supportPos)));
            Block oldSupportNow = client.level.getBlockState(oldCell.supportPos).getBlock();
            if (!isCompatibleSupportBlock(oldCell.support, oldSupportNow)) {
                forgetOwnedBlock(job, oldCell.supportPos);
            }
            // The old note location may now contain somebody else's block. Forget
            // the old ownership claim, but never break or replace that block.
            if (!client.level.getBlockState(oldCell.notePos).is(Blocks.NOTE_BLOCK)) {
                forgetOwnedBlock(job, oldCell.notePos);
            }
            job.placementAttempts.remove(oldCell.notePos);
            job.supportSyncAttempts.remove(oldCell.supportPos);
            job.phase = replacement.raised ? Phase.RAISED_SUPPORTS : Phase.BASE_SUPPORTS;
            if (!job.repairOnlyPass) clearPendingTune(job);
            List<Cell> source = replacement.raised ? job.raisedCells : job.baseCells;
            job.index = firstUnconfirmedSupportIndex(client, job, source);
            job.nextActionGameTime = now + 1;
            publish(client, job, "A support position changed. NoteClient moved that instrument to another safe dome slot and is continuing without replacing the changed block.");
            return true;
        }
        return false;
    }

    private static double horizontalDistanceSquared(BlockPos anchor, BlockPos position) {
        double dx = position.getX() - anchor.getX();
        double dz = position.getZ() - anchor.getZ();
        return dx * dx + dz * dz;
    }

    private static int nearestRelocationOffsetIndex(Job job, Cell oldCell) {
        int bestIndex = 0;
        double bestScore = Double.POSITIVE_INFINITY;
        for (int i = 0; i < job.relocationOffsets.size(); i++) {
            Offset candidate = job.relocationOffsets.get(i);
            int dx = candidate.right - (oldCell.supportPos.getX() - job.anchor.getX()) * job.right.getStepX()
                    - (oldCell.supportPos.getZ() - job.anchor.getZ()) * job.right.getStepZ();
            int dz = candidate.forward - (oldCell.supportPos.getX() - job.anchor.getX()) * job.forward.getStepX()
                    - (oldCell.supportPos.getZ() - job.anchor.getZ()) * job.forward.getStepZ();
            int dy = candidate.up - (oldCell.supportPos.getY() - job.anchor.getY());
            double score = dx * dx + dz * dz + dy * dy * 2.5;
            if (score < bestScore) {
                bestScore = score;
                bestIndex = i;
            }
        }
        return bestIndex;
    }

    private static int firstUnconfirmedSupportIndex(Minecraft client, Job job, List<Cell> cells) {
        for (int i = 0; i < cells.size(); i++) {
            Cell cell = cells.get(i);
            if (isPendingPosition(job, cell.supportPos)) continue;
            if (isCompatibleSupportBlock(cell.support,
                    client.level.getBlockState(cell.supportPos).getBlock())) continue;
            return i;
        }
        return cells.size();
    }

    private static int indexOfCell(List<Cell> cells, int cellIndex) {
        for (int i = 0; i < cells.size(); i++) {
            if (cells.get(i).index == cellIndex) return i;
        }
        return cells.size();
    }

    private static void beginSupportRecovery(Minecraft client, Job job, Cell cell, long now) {
        if (!isCreatedPosition(job, cell.notePos)) {
            pauseAndRetain(client, job, "The support changed under a note block that NoteClient cannot verify as its own. The block was left untouched.");
            return;
        }
        if (!job.repairOnlyPass) clearPendingTune(job);
        job.pendingSupportRecoveryCell = cell;
        job.pendingSupportRecoverySentAt = Long.MIN_VALUE;
        job.pendingSupportRecoveryAirObservedAt = Long.MIN_VALUE;
        job.pendingSupportRecoveryRetries = 0;
        job.pendingSupportRecoveryRelocate = true;
        job.pendingSupportRecoveryRebuildSupport = false;
        job.nextActionGameTime = now + 1;
        publish(client, job, "An instrument support or note sound-space changed. Safely removing only this NoteClient-owned note, then rebuilding the cell in a free dome position; the rest of the arrangement is preserved.");
    }

    /**
     * Recovers a NoteClient-owned note block when its support or sound-space was
     * changed. The owned note is removed with an ordinary block-break interaction,
     * then the complete cell is moved to the nearest spare inside the same compact
     * dome. Other players' replacement blocks are never broken.
     */
    private static void tickSupportRecovery(Minecraft client, Job job, long now) {
        Cell cell = job.pendingSupportRecoveryCell;
        if (cell == null) return;

        BlockState noteState = client.level.getBlockState(cell.notePos);
        if (noteState.isAir()) {
            if (job.pendingSupportRecoveryAirObservedAt == Long.MIN_VALUE) {
                job.pendingSupportRecoveryAirObservedAt = now;
                job.nextActionGameTime = now + 1;
                return;
            }
            if (now - job.pendingSupportRecoveryAirObservedAt < CLEANUP_BREAK_CONFIRM_GRACE_TICKS) {
                job.nextActionGameTime = now + 1;
                return;
            }
            boolean relocate = job.pendingSupportRecoveryRelocate;
            boolean rebuildSupport = job.pendingSupportRecoveryRebuildSupport;
            forgetOwnedBlock(job, cell.notePos);
            job.pendingSupportRecoveryCell = null;
            job.pendingSupportRecoverySentAt = Long.MIN_VALUE;
            job.pendingSupportRecoveryAirObservedAt = Long.MIN_VALUE;
            job.pendingSupportRecoveryRetries = 0;
            job.pendingSupportRecoveryRelocate = true;
            job.pendingSupportRecoveryRebuildSupport = false;
            if (rebuildSupport && retryMissingSupportCell(client, job, cell, now)) {
                publish(client, job, "The note was removed and its missing support is being restored in the original position. The note will be placed again and retuned.");
                return;
            }
            if (!relocate
                    && isCompatibleSupportBlock(cell.support,
                    client.level.getBlockState(cell.supportPos).getBlock())
                    && client.level.getBlockState(cell.notePos.above()).isAir()) {
                // Only the instrument property was wrong. Recreate the note at the
                // same empty position over the still-correct support.
                job.phase = Phase.NOTES;
                job.index = cell.index;
                job.nextActionGameTime = now + 1;
                publish(client, job, "The changed note block was removed. Replacing it in the same position and retuning it...");
                return;
            }
            if (relocateSupportCell(client, job, cell, now)) return;
            pauseAndRetain(client, job, "The changed support or note was safely cleared, but the compact dome has no free replacement slot. Existing confirmed blocks were preserved.");
            return;
        }

        if (!noteState.is(Blocks.NOTE_BLOCK)) {
            // Someone replaced the old note block. Do not destroy the replacement.
            job.pendingSupportRecoveryAirObservedAt = Long.MIN_VALUE;
            forgetOwnedBlock(job, cell.notePos);
            job.pendingSupportRecoveryCell = null;
            job.pendingSupportRecoverySentAt = Long.MIN_VALUE;
            job.pendingSupportRecoveryAirObservedAt = Long.MIN_VALUE;
            job.pendingSupportRecoveryRetries = 0;
            job.pendingSupportRecoveryRelocate = true;
            job.pendingSupportRecoveryRebuildSupport = false;
            if (relocateSupportCell(client, job, cell, now)) return;
            pauseAndRetain(client, job, "The old note position was replaced by another block. It was left untouched and no compact replacement slot was available.");
            return;
        }

        if (!isCreatedPosition(job, cell.notePos)) {
            job.pendingSupportRecoveryAirObservedAt = Long.MIN_VALUE;
            job.pendingSupportRecoveryCell = null;
            job.pendingSupportRecoveryRelocate = true;
            job.pendingSupportRecoveryRebuildSupport = false;
            pauseAndRetain(client, job, "The note block at the changed support position is no longer verified as NoteClient-owned, so it was left untouched.");
            return;
        }

        if (!withinReach(client.player, Vec3.atCenterOf(cell.notePos))) {
            waitForReach(client, job, now);
            return;
        }

        if (client.gameMode.getPlayerMode() == GameType.CREATIVE) {
            if (job.pendingSupportRecoverySentAt == Long.MIN_VALUE
                    || now - job.pendingSupportRecoverySentAt >= 2) {
                if (job.pendingSupportRecoveryRetries >= 5) {
                    job.pendingSupportRecoveryCell = null;
                    job.pendingSupportRecoveryRelocate = true;
                    job.pendingSupportRecoveryRebuildSupport = false;
                    pauseAndRetain(client, job, "The server did not accept the safe removal needed to repair one changed support. The remaining arrangement was retained.");
                    return;
                }
                client.gameMode.startDestroyBlock(cell.notePos, Direction.UP);
                job.pendingSupportRecoveryRetries++;
                job.pendingSupportRecoverySentAt = now;
            }
        } else {
            // In Survival, START begins one continuous vanilla break. Repeatedly
            // calling START would abort/restart progress; CONTINUE advances it.
            if (job.pendingSupportRecoverySentAt == Long.MIN_VALUE) {
                client.gameMode.startDestroyBlock(cell.notePos, Direction.UP);
                job.pendingSupportRecoverySentAt = now;
            } else {
                client.gameMode.continueDestroyBlock(cell.notePos, Direction.UP);
            }
            if (now - job.pendingSupportRecoverySentAt >= SURVIVAL_CLEANUP_TIMEOUT_TICKS) {
                client.gameMode.stopDestroyBlock();
                job.pendingSupportRecoveryCell = null;
                job.pendingSupportRecoveryRelocate = true;
                job.pendingSupportRecoveryRebuildSupport = false;
                pauseAndRetain(client, job, "Survival could not break the owned note block quickly enough to repair its changed support. Use a suitable tool or Creative mode; the rest of the arrangement was preserved.");
                return;
            }
        }
        job.nextActionGameTime = now + 1;
        publishQuietly(client, job, "Recovering changed support • removing only the NoteClient-owned note block...");
    }

    private static void waitForFallingSupportSync(Minecraft client, Job job, Cell cell, long now) {
        BlockPos floor = cell.supportPos.below();
        int attempts = job.supportSyncAttempts.merge(floor, 1, (oldValue, one) -> oldValue + 1);
        if (attempts <= 3) {
            job.nextActionGameTime = now + 1;
            publishQuietly(client, job, "Checking the falling-block support position (" + attempts + "/3)...");
            return;
        }
        job.supportSyncAttempts.remove(floor);
        if (relocateSupportCell(client, job, cell, now)) return;
        pauseAndRetain(client, job, "This instrument uses a gravity-affected support block and no safe grounded fallback position is available. NoteClient preserved the arrangement rather than letting the support fall.");
    }

    private static void waitForSupportSync(Minecraft client, Job job, BlockPos position, long now) {
        int attempts = job.supportSyncAttempts.merge(position, 1, (oldValue, one) -> oldValue + 1);
        if (attempts <= 3) {
            job.nextActionGameTime = now + 1;
            publishQuietly(client, job, "Waiting for support block updates to synchronize (check " + attempts + "/3)...");
            return;
        }
        pauseAndRetain(client, job, "The block below an instrument support is still not solid. NoteClient preserved the arrangement instead of placing a gravity-affected block into unsupported space.");
    }

    private static boolean retryMissingSupportCell(Minecraft client, Job job, Cell cell, long now) {
        if (cell == null || !client.level.getBlockState(cell.supportPos).isAir()) return false;
        if (cell.support instanceof FallingBlock
                && !client.level.getBlockState(cell.supportPos.below())
                .isFaceSturdy(client.level, cell.supportPos.below(), Direction.UP)) return false;
        List<Cell> source = cell.raised ? job.raisedCells : job.baseCells;
        int sourceIndex = source.indexOf(cell);
        if (sourceIndex < 0) return false;
        forgetOwnedBlock(job, cell.supportPos);
        if (!job.repairOnlyPass) clearPendingTune(job);
        job.phase = cell.raised ? Phase.RAISED_SUPPORTS : Phase.BASE_SUPPORTS;
        job.index = sourceIndex;
        job.nextActionGameTime = now + 1;
        publish(client, job, "An instrument support was missing after a server correction. Rebuilding that one support automatically.");
        return true;
    }

    private static void tickNotes(Minecraft client, Job job, long now) {
        if (job.index >= job.cells.size()) {
            if (hasPendingKind(job, PendingKind.NOTE)) {
                job.nextActionGameTime = now + 1;
                return;
            }
            if (job.repairOnlyPass) {
                beginFinalVerification(client, job, now);
                return;
            }
            if (!job.scaffolds.isEmpty() && job.buildInCreative) {
                job.phase = Phase.SCAFFOLD_CLEANUP;
                job.scaffoldCleanupIndex = job.scaffolds.size() - 1;
                job.pendingScaffoldRemoval = null;
                job.nextActionGameTime = now + 1;
                publish(client, job, "Note blocks confirmed. Tuning the completed scaffold-free dome...");
                return;
            }
            beginFinalVerification(client, job, now);
            return;
        }

        int sent = 0;
        while (job.index < job.cells.size() && sent < effectiveBuildActionsPerTick(job)) {
            Cell cell = job.cells.get(job.index);
            if (isCreatedPosition(job, cell.notePos) || isPendingPosition(job, cell.notePos)) {
                job.index++;
                continue;
            }
            BlockState noteState = client.level.getBlockState(cell.notePos);
            if (noteState.is(Blocks.NOTE_BLOCK)) {
                if (!job.placementAttempts.containsKey(cell.notePos)) {
                    pauseAndRetain(client, job, "The note-block target became occupied after planning. NoteClient will not claim or remove a block it did not place.");
                    return;
                }
                BlockState placedSupport = client.level.getBlockState(cell.supportPos);
                if (!isCompatibleSupportBlock(cell.support, placedSupport.getBlock())) {
                    beginSupportRecovery(client, job, cell, now);
                    return;
                }
                recordConfirmedPlacement(job, cell.notePos, Blocks.NOTE_BLOCK);
                job.index++;
                continue;
            }
            BlockState currentSupport = client.level.getBlockState(cell.supportPos);
            if (!isCompatibleSupportBlock(cell.support, currentSupport.getBlock())) {
                if (currentSupport.isAir()) {
                    if (retryMissingSupportCell(client, job, cell, now)) return;
                    if (retryMissingScaffold(client, job, cell.supportPos.below(), now)) return;
                    waitForFallingSupportSync(client, job, cell, now);
                    return;
                }
                waitForChangedSupportSync(client, job, cell, now);
                return;
            }
            if (!noteState.isAir() || !client.level.getBlockState(cell.notePos.above()).isAir()) {
                pauseAndRetain(client, job, "A note-block or sound-space position is occupied. NoteClient will not overwrite it.");
                return;
            }

            if (!withinBuildReach(client.player, topFacePointToward(client.player.getEyePosition(), cell.supportPos), job)) {
                waitForReach(client, job, now);
                return;
            }
            if (!equipNoteBlockForCell(client, job, cell)) {
                waitForMissingItem(client, job, Blocks.NOTE_BLOCK.asItem(), now);
                return;
            }
            BlockHitResult hit = new BlockHitResult(topFacePointToward(client.player.getEyePosition(), cell.supportPos), Direction.UP, cell.supportPos, false);
            job.placementAttempts.merge(cell.notePos, 1, (oldValue, one) -> Math.min(100000, oldValue + one));
            client.gameMode.useItemOn(client.player, InteractionHand.MAIN_HAND, hit);
            job.pendingPlacements.add(new PendingPlacement(cell.notePos, Blocks.NOTE_BLOCK,
                    PendingKind.NOTE, job.index, now, now + placementAckTimeout(job)));
            job.index++;
            sent++;
        }

        job.nextActionGameTime = now + BUILD_ACTION_INTERVAL_TICKS;
        publishQuietly(client, job, "Placing note blocks: "
                + job.index + "/" + job.cells.size() + "...");
    }

    private static void beginFinalVerification(Minecraft client, Job job, long now) {
        // This is a hard phase boundary: tuning cannot begin while even one
        // support/note placement is awaiting a server acknowledgement.
        job.phase = Phase.VERIFYING_NOTES;
        job.verificationStartedAt = now;
        job.verificationStableTicks = 0;
        job.nextActionGameTime = now + 1;
        publish(client, job, "Construction complete. Verifying every support and note block before tuning...");
    }

    private static void tickFinalVerification(Minecraft client, Job job, long now) {
        if (!job.pendingPlacements.isEmpty()) {
            job.verificationStableTicks = 0;
            job.nextActionGameTime = now + 1;
            publishQuietly(client, job, "Waiting for the last server-confirmed placements before tuning...");
            return;
        }

        BlockPos missingPosition = null;
        String missingKind = null;
        for (Cell cell : job.cells) {
            BlockState support = client.level.getBlockState(cell.supportPos);
            if (!isCompatibleSupportBlock(cell.support, support.getBlock())) {
                missingPosition = cell.supportPos;
                missingKind = "instrument support";
                break;
            }
            BlockState note = client.level.getBlockState(cell.notePos);
            if (!note.is(Blocks.NOTE_BLOCK)) {
                missingPosition = cell.notePos;
                missingKind = "note block";
                break;
            }
            if (!hasExpectedNoteInstrument(note, cell)) {
                missingPosition = cell.notePos;
                missingKind = "note instrument";
                break;
            }
            if (!client.level.getBlockState(cell.notePos.above()).isAir()) {
                missingPosition = cell.notePos.above();
                missingKind = "note sound space";
                break;
            }
        }

        if (missingPosition != null) {
            job.verificationStableTicks = 0;
            if ("note block".equals(missingKind)) {
                Cell missingCell = findCellAtNotePosition(job, missingPosition);
                if (missingCell != null && now - job.verificationStartedAt >= 2
                        && beginMissingNoteRepair(client, job, missingCell, job.repairOnlyPass
                        ? job.repairReturnPhase : Phase.TUNING, now)) return;
            } else if ("instrument support".equals(missingKind)) {
                Cell affected = findCellAtSupportPosition(job, missingPosition);
                if (affected != null && now - job.verificationStartedAt >= 2
                        && beginRuntimeSupportRepair(client, job, affected,
                        job.repairOnlyPass ? job.repairReturnPhase : Phase.TUNING, now)) return;
            } else if ("note sound space".equals(missingKind)) {
                Cell affected = findCellAtNotePosition(job, missingPosition.below());
                if (affected != null && now - job.verificationStartedAt >= 2
                        && beginSoundSpaceRecovery(client, job, affected,
                        job.repairOnlyPass ? job.repairReturnPhase : Phase.TUNING, now)) return;
            } else if ("note instrument".equals(missingKind)) {
                Cell affected = findCellAtNotePosition(job, missingPosition);
                if (affected != null && now - job.verificationStartedAt >= 2
                        && beginNoteInstrumentRepair(client, job, affected,
                        job.repairOnlyPass ? job.repairReturnPhase : Phase.TUNING, now)) return;
            }
            if (now - job.verificationStartedAt < 8) {
                job.nextActionGameTime = now + 1;
                publishQuietly(client, job, "Waiting for server state to settle at " + missingKind + " "
                        + missingPosition.toShortString() + " before tuning...");
                return;
            }
            pauseAndRetain(client, job, "The complete arrangement could not be verified: " + missingKind
                    + " is occupied by a block NoteClient cannot safely replace at " + missingPosition.toShortString()
                    + ". Unrelated blocks were left untouched.");
            return;
        }

        job.verificationStableTicks++;
        if (job.verificationStableTicks < 3) {
            job.nextActionGameTime = now + 1;
            publishQuietly(client, job, "All " + job.cells.size() + " note blocks are present. Confirming stable server state ("
                    + job.verificationStableTicks + "/3)...");
            return;
        }

        finishPlacementAndBeginTuning(client, job, now);
    }


    private static Cell findCellAtNotePosition(Job job, BlockPos position) {
        for (Cell cell : job.cells) if (cell.notePos.equals(position)) return cell;
        return null;
    }

    private static Cell findCellAtSupportPosition(Job job, BlockPos position) {
        for (Cell cell : job.cells) if (cell.supportPos.equals(position)) return cell;
        return null;
    }

    private static void markCellForRetuning(Job job, int cellIndex) {
        job.pendingTunes.removeIf(pending -> pending.cellIndex == cellIndex);
        job.tuneRetryAt.remove(cellIndex);
        job.tuneRetryCounts.remove(cellIndex);
        if (cellIndex >= 0 && cellIndex < job.tunedCells.length && job.tunedCells[cellIndex]) {
            job.tunedCells[cellIndex] = false;
            job.tunedCount = Math.max(0, job.tunedCount - 1);
        }
    }

    private static void prepareRepairContext(Job job, int cellIndex, Phase resumePhase, long now) {
        if (!job.repairOnlyPass) {
            job.repairOnlyPass = true;
            job.repairReturnPhase = job.resumeAfterRepairTuning != null
                    ? job.resumeAfterRepairTuning : resumePhase;
            if (job.resumeAfterRepairTuning == null) job.repairStartedAt = now;
        }
        job.repairCellIndex = cellIndex;
        job.repairTuneIndices.add(cellIndex);
        markCellForRetuning(job, cellIndex);
    }

    /**
     * Rebuilds a missing NoteClient-owned note block at its original empty cell.
     * If another block now occupies that cell, it is preserved and the musical
     * cell is relocated to a free dome slot instead of overwriting someone else's block.
     */
    private static boolean beginMissingNoteRepair(Minecraft client, Job job, Cell cell,
                                                  Phase resumePhase, long now) {
        if (client == null || job == null || cell == null) return false;
        BlockState noteState = client.level.getBlockState(cell.notePos);
        if (noteState.is(Blocks.NOTE_BLOCK)) {
            // The block exists; a pitch change is repaired by tuning its observed
            // value back to the target, never by deleting/replacing it.
            beginTargetedRetune(client, job, cell, resumePhase, now);
            return true;
        }

        prepareRepairContext(job, cell.index, resumePhase, now);
        if (!noteState.isAir()) {
            // Do not break an unknown replacement block. Move this instrument to
            // the nearest spare position; the old position remains untouched.
            forgetOwnedBlock(job, cell.notePos);
            if (relocateSupportCell(client, job, cell, now)) {
                publish(client, job, "A note position was replaced by another block. That block was preserved; its note was moved to a nearby free dome position.");
                return true;
            }
            pauseAndRetain(client, job, "A different block occupies a missing note's position and no safe replacement slot is available. The other block was left untouched.");
            return false;
        }

        BlockState supportState = client.level.getBlockState(cell.supportPos);
        if (!isCompatibleSupportBlock(cell.support, supportState.getBlock())) {
            beginRuntimeSupportRepair(client, job, cell, resumePhase, now);
            return true;
        }
        if (!client.level.getBlockState(cell.notePos.above()).isAir()) {
            // The note itself is owned, so use the established safe recovery path
            // to remove that note, then relocate it. The sound-space obstruction
            // is never broken or overwritten.
            beginSupportRecovery(client, job, cell, now);
            return true;
        }

        forgetOwnedBlock(job, cell.notePos);
        job.phase = Phase.NOTES;
        job.index = cell.index;
        job.nextActionGameTime = now + 1;
        publish(client, job, "A missing note block was detected. Rebuilding that block in its original position, then retuning it automatically...");
        return true;
    }

    private static boolean beginRuntimeSupportRepair(Minecraft client, Job job, Cell cell,
                                                     Phase resumePhase, long now) {
        if (client == null || job == null || cell == null) return false;
        prepareRepairContext(job, cell.index, resumePhase, now);
        BlockState supportState = client.level.getBlockState(cell.supportPos);
        BlockState noteState = client.level.getBlockState(cell.notePos);
        if (!noteState.isAir() && !noteState.is(Blocks.NOTE_BLOCK)) {
            forgetOwnedBlock(job, cell.notePos);
            if (relocateSupportCell(client, job, cell, now)) {
                publish(client, job, "A different block replaced this note. It was preserved while the instrument moved to a free dome position.");
                return true;
            }
            pauseAndRetain(client, job, "A different block occupies the note position and no safe replacement slot is available. It was left untouched.");
            return false;
        }
        if (supportState.isAir()) {
            if (noteState.is(Blocks.NOTE_BLOCK) && isCreatedPosition(job, cell.notePos)) {
                // Remove our note first, restore the missing support in the same
                // cell when its floor is valid, then place a fresh note so its
                // instrument property is derived from the restored support.
                prepareRepairContext(job, cell.index, resumePhase, now);
                job.pendingSupportRecoveryCell = cell;
                job.pendingSupportRecoverySentAt = Long.MIN_VALUE;
                job.pendingSupportRecoveryAirObservedAt = Long.MIN_VALUE;
                job.pendingSupportRecoveryRetries = 0;
                job.pendingSupportRecoveryRelocate = false;
                job.pendingSupportRecoveryRebuildSupport = true;
                job.nextActionGameTime = now + 1;
                publish(client, job, "An instrument support disappeared. Removing only its owned note, restoring the support, and replacing the note...");
                return true;
            }
            if (retryMissingSupportCell(client, job, cell, now)) {
                publish(client, job, "An instrument support disappeared. Rebuilding that support in its original position, then rebuilding and retuning its note...");
                return true;
            }
            pauseAndRetain(client, job, "The missing instrument support could not be rebuilt safely. Existing blocks were preserved.");
            return false;
        }
        if (noteState.is(Blocks.NOTE_BLOCK) && isCreatedPosition(job, cell.notePos)) {
            beginSupportRecovery(client, job, cell, now);
            return true;
        }
        // The note block is already missing, so there is nothing owned to break.
        // Move the cell away from the changed support and leave that support alone.
        if (relocateSupportCell(client, job, cell, now)) {
            publish(client, job, "The instrument support changed while its note was missing. The changed block was preserved and the note moved to a safe dome position.");
            return true;
        }
        pauseAndRetain(client, job, "The instrument support changed and no free replacement position is available. The changed block was left untouched.");
        return false;
    }

    private static boolean beginNoteInstrumentRepair(Minecraft client, Job job, Cell cell,
                                                     Phase resumePhase, long now) {
        if (client == null || job == null || cell == null) return false;
        BlockState noteState = client.level.getBlockState(cell.notePos);
        if (!noteState.is(Blocks.NOTE_BLOCK) || !isCreatedPosition(job, cell.notePos)) return false;
        prepareRepairContext(job, cell.index, resumePhase, now);
        job.pendingSupportRecoveryCell = cell;
        job.pendingSupportRecoverySentAt = Long.MIN_VALUE;
        job.pendingSupportRecoveryAirObservedAt = Long.MIN_VALUE;
        job.pendingSupportRecoveryRetries = 0;
        job.pendingSupportRecoveryRelocate = false;
        job.pendingSupportRecoveryRebuildSupport = false;
        job.nextActionGameTime = now + 1;
        publish(client, job, "A Note Block's instrument changed. Replacing only that NoteClient-owned note over its existing support, then retuning it...");
        return true;
    }

    private static boolean beginSoundSpaceRecovery(Minecraft client, Job job, Cell cell,
                                                    Phase resumePhase, long now) {
        if (client == null || job == null || cell == null) return false;
        if (!client.level.getBlockState(cell.notePos).is(Blocks.NOTE_BLOCK)
                || !isCreatedPosition(job, cell.notePos)) return false;
        prepareRepairContext(job, cell.index, resumePhase, now);
        beginSupportRecovery(client, job, cell, now);
        return job.pendingSupportRecoveryCell == cell;
    }

    private static void beginTargetedRetune(Minecraft client, Job job, Cell cell,
                                            Phase resumePhase, long now) {
        // The block is still a Note Block. Keep it in place and correct the
        // server-observed pitch instead of deleting/replacing it.
        markCellForRetuning(job, cell.index);
        job.tuneRetryAt.put(cell.index, now + 1);
        if (resumePhase != Phase.TUNING) {
            if (job.resumeAfterRepairTuning == null) job.repairStartedAt = now;
            job.resumeAfterRepairTuning = resumePhase;
            job.tuneCursor = job.cells.size();
        }
        job.phase = Phase.TUNING;
        job.nextActionGameTime = now + 1;
        publish(client, job, "A note's pitch changed. Retuning it from the server-observed pitch before continuing...");
    }

    private static void finishPlacementAndBeginTuning(Minecraft client, Job job, long now) {
        boolean completedRepairPass = job.repairOnlyPass;
        if (completedRepairPass) {
            Phase resumePhase = job.repairReturnPhase == null ? Phase.TUNING : job.repairReturnPhase;
            List<Integer> repairedIndices = new ArrayList<>(job.repairTuneIndices);
            job.repairOnlyPass = false;
            job.repairReturnPhase = null;
            job.phase = Phase.TUNING;

            // When returning from playback/Survival handoff, all prior notes were
            // already tuned. Discard stale acknowledgements and queue only repaired
            // cells. During the initial tuning pass, keep all other in-flight work.
            if (resumePhase == Phase.PLAYING || resumePhase == Phase.WAITING_FOR_SURVIVAL) {
                job.pendingTunes.clear();
                job.tuneRetryAt.clear();
                job.tuneRetryCounts.clear();
                job.tuneCursor = job.cells.size();
                job.resumeAfterRepairTuning = resumePhase;
            }
            for (int cellIndex : repairedIndices) {
                if (cellIndex >= 0 && cellIndex < job.cells.size()) {
                    job.tuneRetryAt.put(cellIndex, now + 1);
                }
            }
            job.repairTuneIndices.clear();
            job.repairCellIndex = -1;
        } else {
            job.phase = Phase.TUNING;
            job.index = 0;
            job.tuneIntegrityScanCursor = 0;
            clearPendingTune(job);
        }
        if (!equipEmptyHandForTuning(client, job)) {
            publish(client, job, "Tuning needs an empty hand. The arrangement is built; NoteClient will wait for the working slot.");
            job.nextActionGameTime = now + 2;
            return;
        }
        job.nextActionGameTime = now + 1;
        publish(client, job, completedRepairPass
                ? "Repair confirmed. Retuning only the repaired note blocks..."
                : "All note blocks are built and verified. Starting parallel pitch tuning...");
    }

    /**
     * Remove the temporary glass columns after the permanent instrument blocks
     * and note blocks are confirmed. Stable instrument blocks remain floating;
     * gravity-affected instrument blocks (currently sand for Snare) retain only
     * the single glass block directly beneath them.
     */
    private static void tickScaffoldCleanup(Minecraft client, Job job, long now) {
        if (!job.buildInCreative) {
            job.scaffoldCleanupIndex = -1;
            beginFinalVerification(client, job, now);
            return;
        }

        if (job.pendingScaffoldRemoval != null) {
            BlockPos pending = job.pendingScaffoldRemoval;
            BlockState state = client.level.getBlockState(pending);
            if (state.isAir() || !state.is(Blocks.GLASS)) {
                forgetOwnedBlock(job, pending);
                job.pendingScaffoldRemoval = null;
                job.pendingScaffoldRemovalRetries = 0;
                job.scaffoldCleanupIndex--;
            } else if (now - job.pendingScaffoldRemovalSentAt < 2) {
                job.nextActionGameTime = now + 1;
                return;
            } else if (job.pendingScaffoldRemovalRetries < 2) {
                job.pendingScaffoldRemovalRetries++;
                job.pendingScaffoldRemovalSentAt = now;
                client.gameMode.startDestroyBlock(pending, Direction.UP);
                job.nextActionGameTime = now + 1;
                return;
            } else {
                // Do not stall the whole arrangement if the server refuses a
                // cleanup hit. Leave that one block intact and keep the music.
                job.pendingScaffoldRemoval = null;
                job.pendingScaffoldRemovalRetries = 0;
                job.scaffoldCleanupIndex--;
                publishQuietly(client, job, "One temporary glass block was not accepted for cleanup; continuing safely.");
            }
        }

        while (job.scaffoldCleanupIndex >= 0) {
            Scaffold scaffold = job.scaffolds.get(job.scaffoldCleanupIndex);
            BlockPos position = scaffold.position;
            if (job.protectedScaffolds.contains(position)) {
                job.scaffoldCleanupIndex--;
                continue;
            }

            BlockState state = client.level.getBlockState(position);
            if (state.isAir() || !state.is(Blocks.GLASS)) {
                forgetOwnedBlock(job, position);
                job.scaffoldCleanupIndex--;
                continue;
            }
            if (!isCreatedPosition(job, position)) {
                // Never break a glass block that was not placed by this job.
                job.scaffoldCleanupIndex--;
                continue;
            }
            if (!withinReach(client.player, Vec3.atCenterOf(position))) {
                // It was reachable when placed; if the player moved, do not
                // delay tuning indefinitely or attempt an out-of-range break.
                job.scaffoldCleanupIndex--;
                publishQuietly(client, job, "Some temporary glass was left in place because it is now outside normal reach.");
                continue;
            }

            job.pendingScaffoldRemoval = position;
            job.pendingScaffoldRemovalSentAt = now;
            job.pendingScaffoldRemovalRetries = 0;
            client.gameMode.startDestroyBlock(position, Direction.UP);
            job.nextActionGameTime = now + 1;
            publishQuietly(client, job, "Clearing temporary glass supports: "
                    + (job.scaffolds.size() - job.scaffoldCleanupIndex) + "/" + job.scaffolds.size());
            return;
        }

        beginFinalVerification(client, job, now);
    }

    private static void forgetOwnedBlock(Job job, BlockPos position) {
        int before = job.createdBlocks.size();
        job.createdBlocks.removeIf(owned -> owned.position.equals(position));
        int removed = before - job.createdBlocks.size();
        if (removed > 0) job.placed = Math.max(0, job.placed - removed);
        job.placementAttempts.remove(position);
        job.survivalCleanupRetries.remove(position);
        job.survivalCleanupRetryAt.remove(position);
        job.cleanupQueue.removeIf(owned -> owned.position.equals(position));
        job.cleanupDeferred.removeIf(owned -> owned.position.equals(position));
    }

    private static int placementAckTimeout(Job job) {
        // Creative actions are free to retry sooner. Survival must wait longer
        // because a late acknowledgement can affect real inventory counts.
        return job.buildInCreative
                ? CREATIVE_PLACEMENT_ACK_TIMEOUT_TICKS
                : SURVIVAL_PLACEMENT_ACK_TIMEOUT_TICKS;
    }

    private static boolean tickPendingPlacements(Minecraft client, Job job, long now) {
        var iterator = job.pendingPlacements.iterator();
        while (iterator.hasNext()) {
            PendingPlacement pending = iterator.next();
            BlockState actual = client.level.getBlockState(pending.position);

            // A client prediction is not treated as accepted immediately. A short
            // grace window gives the server update time to arrive before the
            // bounded pipeline counts the placement as complete.
            if (now >= pending.sentAt + PLACEMENT_CONFIRM_GRACE_TICKS
                    && matchesPendingPlacement(pending, actual)) {
                long acknowledgementTicks = now - pending.sentAt;
                recordConfirmedPlacement(job, pending.position, actual.getBlock());
                if (acknowledgementTicks <= 4) {
                    job.quickPlacementAcks++;
                    if (job.quickPlacementAcks >= 8) {
                        job.adaptiveBuildActionsPerTick = Math.min(NoteClientConfig.buildActionsPerTick(),
                                job.adaptiveBuildActionsPerTick + 1);
                        job.quickPlacementAcks = 0;
                    }
                } else {
                    job.quickPlacementAcks = 0;
                }
                iterator.remove();
                continue;
            }

            long timeoutWithCleanupGrace = pending.timeoutAt
                    + (job.phase == Phase.CLEANUP ? CLEANUP_LATE_PLACEMENT_GRACE_TICKS : 0);
            if (now >= timeoutWithCleanupGrace) {
                iterator.remove();
                rewindPlacementCursor(job, pending.kind, pending.operationIndex);
                int attempts = job.placementAttempts.getOrDefault(pending.position, 1);
                job.adaptiveBuildActionsPerTick = Math.max(1, job.adaptiveBuildActionsPerTick - 1);
                job.quickPlacementAcks = 0;
                boolean rejectedAirSupport = pending.kind == PendingKind.SUPPORT
                        && client.level.getBlockState(pending.position.below()).isAir();
                if (rejectedAirSupport && attempts >= 3 && job.phase != Phase.CLEANUP) {
                    pauseAndRetain(client, job, "This server did not accept the normal mid-air support placement after three attempts. No glass scaffold was added and no server rules were bypassed. Use an AirPlace setup that this server permits, or an owner-authorized NoteClient companion; the client cannot force the server to accept a block placement.");
                    return true;
                }
                // During explicit cleanup, a rejected pending placement simply
                // never became an owned block. Do not pause Destroy for a block
                // the server did not place.
                if (job.phase == Phase.CLEANUP) {
                    // The late-acknowledgement window has expired and this
                    // position never became an owned block. Continue deleting
                    // the confirmed ledger; do not re-enter construction.
                    job.nextActionGameTime = now + 1;
                    publishQuietly(client, job, "An unconfirmed placement never arrived. Continuing cleanup of confirmed blocks...");
                    return true;
                }
                long retryDelay = Math.min(4L,
                        (long) PLACEMENT_RETRY_DELAY_TICKS * Math.max(1, Math.min(attempts, 4)));
                job.nextActionGameTime = now + retryDelay;
                String targetName = Component.translatable(pending.expectedBlock.getDescriptionId()).getString();
                publish(client, job, "The server has not confirmed " + targetName + " yet (attempt "
                        + (attempts + 1) + "). Confirmed blocks are preserved. Retrying with a short capped backoff.");
                // Do not send a new block in the same tick as a timeout/retry.
                return true;
            }
        }

        job.nextActionGameTime = now + 1;
        if (!job.pendingPlacements.isEmpty()) {
            publishQuietly(client, job, "Server-confirmed placements: " + job.placed + "/" + job.total
                    + " • awaiting " + job.pendingPlacements.size() + " server update(s)...");
        }
        return false;
    }

    private static boolean matchesPendingPlacement(PendingPlacement pending, BlockState actual) {
        if (pending.kind == PendingKind.SUPPORT) {
            return isCompatibleSupportBlock(pending.expectedBlock, actual.getBlock());
        }
        return actual.is(pending.expectedBlock);
    }

    private static boolean isCompatibleSupportBlock(Block expected, Block actual) {
        if (expected == actual) return true;
        // Harp is the default note-block instrument. Grass spreading over a dirt
        // support does not change that instrument, so it must not invalidate the
        // whole build or prevent playback.
        boolean expectedHarpGround = expected == Blocks.DIRT || expected == Blocks.COARSE_DIRT
                || expected == Blocks.GRASS_BLOCK || expected == Blocks.PODZOL
                || expected == Blocks.MYCELIUM || expected == Blocks.ROOTED_DIRT;
        boolean actualHarpGround = actual == Blocks.DIRT || actual == Blocks.COARSE_DIRT
                || actual == Blocks.GRASS_BLOCK || actual == Blocks.PODZOL
                || actual == Blocks.MYCELIUM || actual == Blocks.ROOTED_DIRT;
        return expectedHarpGround && actualHarpGround;
    }

    private static boolean isCreatedPosition(Job job, BlockPos position) {
        for (OwnedBlock owned : job.createdBlocks) {
            if (owned.position.equals(position)) return true;
        }
        return false;
    }

    private static boolean isPendingPosition(Job job, BlockPos position) {
        for (PendingPlacement pending : job.pendingPlacements) {
            if (pending.position.equals(position)) return true;
        }
        return false;
    }

    private static boolean hasPendingKind(Job job, PendingKind kind) {
        for (PendingPlacement pending : job.pendingPlacements) {
            if (pending.kind == kind) return true;
        }
        return false;
    }

    private static void recordConfirmedPlacement(Job job, BlockPos position, Block block) {
        boolean alreadyRecorded = job.createdBlocks.stream()
                .anyMatch(owned -> owned.position.equals(position));
        if (!alreadyRecorded) {
            OwnedBlock owned = new OwnedBlock(position, block);
            job.createdBlocks.add(owned);
            job.placed++;
            if (job.phase == Phase.CLEANUP && !job.pendingCleanupPositions.contains(position)) {
                job.cleanupQueue.addFirst(owned);
            }
        }
        job.placementAttempts.remove(position);
    }

    private static void rewindPlacementCursor(Job job, PendingKind kind, int operationIndex) {
        // Multiple positions may be in flight. Rewind to the exact timed-out
        // operation; each scan skips positions that are already owned or pending.
        switch (kind) {
            case SCAFFOLD -> job.scaffoldIndex = Math.min(job.scaffoldIndex, operationIndex);
            case SUPPORT, NOTE -> job.index = Math.min(job.index, operationIndex);
        }
    }

    private static void tickTuning(Minecraft client, Job job, long now) {
        final long deadlineNanos = System.nanoTime() + MAX_TUNING_WORK_NANOS;
        if (!equipEmptyHandForTuning(client, job)) {
            publish(client, job, "Tuning needs an empty hand. NoteClient will retry as soon as the working slot is clear.");
            job.nextActionGameTime = now + 1;
            return;
        }

        if (scanTuningIntegrity(client, job, now, deadlineNanos)) return;
        if (System.nanoTime() >= deadlineNanos) {
            job.nextActionGameTime = now + 1;
            return;
        }

        int configuredBudget = NoteClientConfig.tuningActionsPerTick();
        int actionBudget = Math.max(1, Math.min(configuredBudget, job.adaptiveTuneBudget));
        job.adaptiveTuneBudget = Math.max(1, job.adaptiveTuneBudget);

        // Observe all in-flight note blocks first. Each block is tracked by its
        // server-observed pitch, so a partial burst never causes an overshoot.
        for (int i = 0; i < job.pendingTunes.size() && System.nanoTime() < deadlineNanos;) {
            PendingTune pending = job.pendingTunes.get(i);
            if (pending.cellIndex < 0 || pending.cellIndex >= job.cells.size()) {
                job.pendingTunes.remove(i);
                continue;
            }
            Cell cell = job.cells.get(pending.cellIndex);
            BlockState noteState = client.level.getBlockState(cell.notePos);
            if (!noteState.is(Blocks.NOTE_BLOCK)) {
                if (beginMissingNoteRepair(client, job, cell, Phase.TUNING, now)) return;
                return;
            }
            if (!isCompatibleSupportBlock(cell.support,
                    client.level.getBlockState(cell.supportPos).getBlock())) {
                beginRuntimeSupportRepair(client, job, cell, Phase.TUNING, now);
                return;
            }
            if (!hasExpectedNoteInstrument(noteState, cell)) {
                beginNoteInstrumentRepair(client, job, cell, Phase.TUNING, now);
                return;
            }
            if (!client.level.getBlockState(cell.notePos.above()).isAir()) {
                beginSoundSpaceRecovery(client, job, cell, Phase.TUNING, now);
                return;
            }

            int actualPitch = readNoteBlockPitch(noteState);
            if (actualPitch < 0) {
                pauseAndRetain(client, job, "Could not read a server-confirmed note-block pitch. The arrangement was retained.");
                return;
            }
            long elapsed = now - pending.sentAt;
            int progressed = (actualPitch - pending.startPitch + 25) % 25;
            if (progressed > 0 && elapsed >= NoteClientConfig.tuningConfirmationTicks()) {
                job.placed = Math.min(job.total, job.placed + progressed);
                job.pendingTunes.remove(i);
                job.tuneRetryCounts.remove(pending.cellIndex);

                if (progressed < pending.clicksSent) {
                    // Learn the number of clicks the server actually accepted
                    // per note block, but keep the global budget high so one slow
                    // note does not throttle every other note in the arrangement.
                    job.adaptiveTuneBatchSize = Math.max(1,
                            Math.min(job.adaptiveTuneBatchSize, progressed));
                    job.quickTuneAcks = 0;
                } else {
                    job.quickTuneAcks++;
                    if (job.quickTuneAcks >= 5) {
                        job.adaptiveTuneBatchSize = Math.min(NoteClientConfig.tuningBatchSize(),
                                job.adaptiveTuneBatchSize + 2);
                        job.adaptiveTuneBudget = Math.min(NoteClientConfig.tuningActionsPerTick(),
                                job.adaptiveTuneBudget + 8);
                        job.quickTuneAcks = 0;
                    }
                }

                if (actualPitch == cell.pitch) {
                    job.tunedCells[pending.cellIndex] = true;
                    job.tuneRetryAt.remove(pending.cellIndex);
                    job.tunedCount++;
                } else {
                    // Immediately queue the remainder using the pitch the server
                    // actually applied. This is the main speed-up for partial bursts.
                    job.tuneRetryAt.put(pending.cellIndex, now);
                }
                continue;
            }

            if (elapsed >= TUNING_ACK_TIMEOUT_TICKS) {
                int retries = job.tuneRetryCounts.merge(pending.cellIndex, 1,
                        (oldValue, one) -> Math.min(100000, oldValue + one));
                job.pendingTunes.remove(i);
                job.adaptiveTuneBatchSize = Math.max(1, job.adaptiveTuneBatchSize - 1);
                job.adaptiveTuneBudget = Math.max(64, job.adaptiveTuneBudget * 3 / 4);
                job.quickTuneAcks = 0;
                long backoff = Math.min(4L, 1L << Math.min(2, retries - 1));
                job.tuneRetryAt.put(pending.cellIndex, now + backoff);
                continue;
            }
            i++;
        }

        // Retry partially accepted notes before scanning fresh cells.
        List<Integer> retryIndices = new ArrayList<>(job.tuneRetryAt.keySet());
        retryIndices.sort(Integer::compareTo);
        for (int cellIndex : retryIndices) {
            if (System.nanoTime() >= deadlineNanos
                    || actionBudget <= 0 || job.pendingTunes.size() >= MAX_TUNE_IN_FLIGHT) break;
            Long retryAt = job.tuneRetryAt.get(cellIndex);
            if (retryAt == null || retryAt > now) continue;
            job.tuneRetryAt.remove(cellIndex);
            if (cellIndex < 0 || cellIndex >= job.cells.size() || job.tunedCells[cellIndex]) continue;
            int sent = sendTuneBatch(client, job, cellIndex, now, actionBudget, deadlineNanos);
            if (sent < 0) return;
            if (sent == 0 && !job.tunedCells[cellIndex]) {
                job.tuneRetryAt.put(cellIndex, now + 1);
                break;
            }
            actionBudget -= sent;
        }

        // Fill the rest of the pipeline with new cells. A bounded set of up to
        // 128 note blocks may be awaiting server confirmation at once; clicks
        // are additionally limited by the user's manual budget and the time slice.
        while (System.nanoTime() < deadlineNanos && actionBudget > 0
                && job.pendingTunes.size() < MAX_TUNE_IN_FLIGHT
                && job.tuneCursor < job.cells.size()) {
            int cellIndex = job.tuneCursor++;
            if (job.tunedCells[cellIndex] || job.tuneRetryAt.containsKey(cellIndex)
                    || hasPendingTune(job, cellIndex)) continue;
            int sent = sendTuneBatch(client, job, cellIndex, now, actionBudget, deadlineNanos);
            if (sent < 0) return;
            if (sent == 0 && !job.tunedCells[cellIndex]) {
                job.tuneRetryAt.put(cellIndex, now + 1);
                break;
            }
            actionBudget -= sent;
        }

        job.index = job.tunedCount;
        if (job.tuneCursor >= job.cells.size() && job.pendingTunes.isEmpty()
                && job.tuneRetryAt.isEmpty()) {
            if (job.resumeAfterRepairTuning != null) {
                Phase resume = job.resumeAfterRepairTuning;
                job.resumeAfterRepairTuning = null;
                if (resume == Phase.PLAYING) {
                    if (job.playbackStart >= 0) job.playbackStart += Math.max(0L, now - job.repairStartedAt);
                    job.phase = Phase.PLAYING;
                    job.nextActionGameTime = now + 1;
                    publish(client, job, "Repaired note confirmed and retuned. Resuming the song at the exact paused position.");
                    return;
                }
                if (resume == Phase.WAITING_FOR_SURVIVAL) {
                    job.phase = Phase.WAITING_FOR_SURVIVAL;
                    job.nextActionGameTime = now + 1;
                    publish(client, job, "Repaired note confirmed and retuned. Waiting for Survival before playback.");
                    return;
                }
            }
            if (job.buildInCreative) {
                boolean switchedLocally = trySwitchIntegratedServerToSurvival(client);
                job.phase = Phase.WAITING_FOR_SURVIVAL;
                job.lastMessageTime = Long.MIN_VALUE;
                job.nextActionGameTime = now + 1;
                publish(client, job, switchedLocally
                        ? "Dome built and tuned. The singleplayer world has been switched to Survival automatically."
                        : "Dome built and tuned. This server controls game mode; automatic switching is only available in singleplayer or an owner-authorized NoteClient server. No command or permission bypass is used.");
            } else {
                beginPlayback(job, now);
                publish(client, job, "Dome built and every note pitch confirmed. Starting real note-block playback shortly.");
            }
            return;
        }

        job.nextActionGameTime = now + 1;
        publishQuietly(client, job, "Fast tuning: " + job.tunedCount + "/" + job.cells.size()
                + " note blocks • " + job.pendingTunes.size() + " awaiting server confirmation • "
                + Math.min(NoteClientConfig.tuningActionsPerTick(), job.adaptiveTuneBudget)
                + " interactions/tick • time-sliced");
    }

    private static boolean scanTuningIntegrity(Minecraft client, Job job, long now, long deadlineNanos) {
        int size = job.cells.size();
        if (size == 0) return false;
        int checks = Math.min(TUNING_INTEGRITY_CHECKS_PER_TICK, size);
        for (int checked = 0; checked < checks && System.nanoTime() < deadlineNanos; checked++) {
            if (job.tuneIntegrityScanCursor >= size) job.tuneIntegrityScanCursor = 0;
            int cellIndex = job.tuneIntegrityScanCursor++;
            if (!job.tunedCells[cellIndex] || hasPendingTune(job, cellIndex)
                    || job.tuneRetryAt.containsKey(cellIndex)) continue;
            Cell cell = job.cells.get(cellIndex);
            BlockState noteState = client.level.getBlockState(cell.notePos);
            if (!noteState.is(Blocks.NOTE_BLOCK)) {
                beginMissingNoteRepair(client, job, cell, Phase.TUNING, now);
                return true;
            }
            if (!isCompatibleSupportBlock(cell.support,
                    client.level.getBlockState(cell.supportPos).getBlock())) {
                beginRuntimeSupportRepair(client, job, cell, Phase.TUNING, now);
                return true;
            }
            if (!hasExpectedNoteInstrument(noteState, cell)) {
                beginNoteInstrumentRepair(client, job, cell, Phase.TUNING, now);
                return true;
            }
            if (!client.level.getBlockState(cell.notePos.above()).isAir()) {
                beginSoundSpaceRecovery(client, job, cell, Phase.TUNING, now);
                return true;
            }
            if (readNoteBlockPitch(noteState) != cell.pitch) {
                beginTargetedRetune(client, job, cell, Phase.TUNING, now);
                return true;
            }
        }
        return false;
    }

    private static boolean hasPendingTune(Job job, int cellIndex) {
        for (PendingTune pending : job.pendingTunes) if (pending.cellIndex == cellIndex) return true;
        return false;
    }

    /** Sends one bounded pitch burst using ordinary right-click interactions. */
    private static int sendTuneBatch(Minecraft client, Job job, int cellIndex, long now,
                                     int budget, long deadlineNanos) {
        Cell cell = job.cells.get(cellIndex);
        BlockState noteState = client.level.getBlockState(cell.notePos);
        if (!noteState.is(Blocks.NOTE_BLOCK)) {
            beginMissingNoteRepair(client, job, cell, Phase.TUNING, now);
            return -1;
        }
        if (!isCompatibleSupportBlock(cell.support,
                client.level.getBlockState(cell.supportPos).getBlock())) {
            beginRuntimeSupportRepair(client, job, cell, Phase.TUNING, now);
            return -1;
        }
        if (!hasExpectedNoteInstrument(noteState, cell)) {
            beginNoteInstrumentRepair(client, job, cell, Phase.TUNING, now);
            return -1;
        }
        if (!client.level.getBlockState(cell.notePos.above()).isAir()) {
            beginSoundSpaceRecovery(client, job, cell, Phase.TUNING, now);
            return -1;
        }

        int actualPitch = readNoteBlockPitch(noteState);
        if (actualPitch < 0) {
            pauseAndRetain(client, job, "Could not read a server-confirmed note-block pitch. The arrangement was retained.");
            return -1;
        }
        if (actualPitch == cell.pitch) {
            if (!job.tunedCells[cellIndex]) {
                job.tunedCells[cellIndex] = true;
                job.tunedCount++;
                // Count the pitch work as complete even when the Creative item
                // arrived pre-tuned and required no click packets.
                job.placed = Math.min(job.total, job.placed + cell.pitch);
            }
            return 0;
        }

        Vec3 tuningPoint = Vec3.atCenterOf(cell.notePos);
        if (!withinReach(client.player, tuningPoint)) {
            waitForReach(client, job, now);
            return -1;
        }

        int clicksNeeded = (cell.pitch - actualPitch + 25) % 25;
        int burst = Math.max(1, Math.min(Math.min(job.adaptiveTuneBatchSize, clicksNeeded), budget));
        BlockHitResult hit = new BlockHitResult(tuningPoint, Direction.UP, cell.notePos, false);
        int sent = 0;
        for (int click = 0; click < burst && System.nanoTime() < deadlineNanos; click++) {
            client.gameMode.useItemOn(client.player, InteractionHand.MAIN_HAND, hit);
            sent++;
        }
        if (sent <= 0) return 0;
        job.pendingTunes.add(new PendingTune(cellIndex, actualPitch, sent, now));
        return sent;
    }

    private static void clearPendingTune(Job job) {
        job.pendingTunes.clear();
        job.tuneRetryAt.clear();
        job.tuneRetryCounts.clear();
        job.tuneCursor = 0;
        job.tunedCount = 0;
        Arrays.fill(job.tunedCells, false);
        job.adaptiveTuneBatchSize = NoteClientConfig.tuningBatchSize();
        job.adaptiveTuneBudget = NoteClientConfig.tuningActionsPerTick();
        job.quickTuneAcks = 0;
    }

    private static int readNoteBlockPitch(BlockState state) {
        if (!state.is(Blocks.NOTE_BLOCK)) return -1;
        Matcher matcher = NOTE_VALUE_PATTERN.matcher(state.toString());
        if (!matcher.find()) return -1;
        try {
            int value = Integer.parseInt(matcher.group(1));
            return value >= 0 && value <= 24 ? value : -1;
        } catch (NumberFormatException ignored) {
            return -1;
        }
    }

    private static String readNoteBlockInstrument(BlockState state) {
        if (!state.is(Blocks.NOTE_BLOCK)) return null;
        Matcher matcher = NOTE_INSTRUMENT_PATTERN.matcher(state.toString());
        return matcher.find() ? matcher.group(1) : null;
    }

    private static boolean hasExpectedNoteInstrument(BlockState state, Cell cell) {
        String actual = readNoteBlockInstrument(state);
        // If a future mapping changes BlockState.toString(), don't destroy a
        // working note based on an unreadable property. Pitch and support checks
        // still remain active in that case.
        return actual == null || actual.equals(cell.soundName);
    }

    /**
     * A client cannot change an ordinary multiplayer server's authoritative
     * game mode. In singleplayer, however, the integrated server belongs to the
     * local world and can safely perform the user-requested Survival handoff.
     */
    private static boolean trySwitchIntegratedServerToSurvival(Minecraft client) {
        if (client == null || client.player == null) return false;
        var integratedServer = client.getSingleplayerServer();
        if (integratedServer == null) return false;
        var serverPlayer = integratedServer.getPlayerList().getPlayer(client.player.getUUID());
        if (serverPlayer == null) return false;
        serverPlayer.setGameMode(GameType.SURVIVAL);
        return true;
    }

    private static boolean trySwitchIntegratedServerToCreative(Minecraft client) {
        if (client == null || client.player == null) return false;
        var integratedServer = client.getSingleplayerServer();
        if (integratedServer == null) return false;
        var serverPlayer = integratedServer.getPlayerList().getPlayer(client.player.getUUID());
        if (serverPlayer == null) return false;
        serverPlayer.setGameMode(GameType.CREATIVE);
        return true;
    }

    private static void tickWaitForSurvival(Minecraft client, Job job, long now) {
        if (client.gameMode.getPlayerMode() != GameType.SURVIVAL) {
            if (job.lastMessageTime == Long.MIN_VALUE || now - job.lastMessageTime >= 100) {
                job.lastMessageTime = now;
                publish(client, job, "The arrangement is complete and tuned. Switch to Survival manually when ready. No slash commands are sent; playback has not started yet.");
            }
            job.nextActionGameTime = now + 2;
            return;
        }

        // The complete physical arrangement must still exist before playback.
        for (Cell cell : job.cells) {
            BlockState noteState = client.level.getBlockState(cell.notePos);
            if (!noteState.is(Blocks.NOTE_BLOCK)) {
                beginMissingNoteRepair(client, job, cell, Phase.WAITING_FOR_SURVIVAL, now);
                return;
            }
            if (!isCompatibleSupportBlock(cell.support, client.level.getBlockState(cell.supportPos).getBlock())) {
                beginRuntimeSupportRepair(client, job, cell, Phase.WAITING_FOR_SURVIVAL, now);
                return;
            }
            if (!hasExpectedNoteInstrument(noteState, cell)) {
                beginNoteInstrumentRepair(client, job, cell, Phase.WAITING_FOR_SURVIVAL, now);
                return;
            }
            if (!client.level.getBlockState(cell.notePos.above()).isAir()) {
                beginSoundSpaceRecovery(client, job, cell, Phase.WAITING_FOR_SURVIVAL, now);
                return;
            }
            if (readNoteBlockPitch(noteState) != cell.pitch) {
                beginTargetedRetune(client, job, cell, Phase.WAITING_FOR_SURVIVAL, now);
                return;
            }
            if (!withinReach(client.player, Vec3.atCenterOf(cell.notePos))) {
                publish(client, job, "Survival is active, but you moved away from the arrangement. Return to the center so every note block is within normal reach; playback has not started.");
                job.nextActionGameTime = now + 2;
                return;
            }
        }

        if (job.workHotbarSlot < 0 || job.workHotbarSlot >= 9) {
            job.workHotbarSlot = reserveWorkingHotbarSlot(client);
        }
        if (job.workHotbarSlot < 0) {
            publish(client, job, "Survival is active. Free one hotbar slot so NoteClient can reserve an empty hand for note playback.");
            job.nextActionGameTime = now + 4;
            return;
        }
        if (!client.player.getInventory().getItem(job.workHotbarSlot).isEmpty()
                && !equipEmptyHandForTuning(client, job)) {
            publish(client, job, "Survival is active. NoteClient is moving the remaining stack out of its working hand; free an inventory slot if it cannot continue.");
            job.nextActionGameTime = now + 4;
            return;
        }
        client.player.getInventory().setSelectedSlot(job.workHotbarSlot);
        beginPlayback(job, now);
        publish(client, job, "Survival confirmed. The Creative-built arrangement is complete; starting physical note-block playback shortly.");
        sendChat(client, "Survival confirmed. NoteClient is starting playback of the completed Creative-built arrangement.");
    }

    private static void tickWaitForMaterials(Minecraft client, Job job, long now) {
        if (client.gameMode.getPlayerMode() != GameType.SURVIVAL) {
            job.phase = Phase.WAITING_FOR_SURVIVAL;
            job.nextActionGameTime = now + 2;
            return;
        }
        String missing = missingMaterials(client.player, job);
        if (job.workHotbarSlot < 0 || !client.player.getInventory().getItem(job.workHotbarSlot).isEmpty()) {
            job.workHotbarSlot = reserveWorkingHotbarSlot(client);
        }
        if (!missing.isEmpty() || job.workHotbarSlot < 0) {
            if (job.lastMessageTime == Long.MIN_VALUE || now - job.lastMessageTime >= 100) {
                job.lastMessageTime = now;
                String extra = missing.isEmpty() ? "one free inventory slot for an empty hand" : missing;
                publish(client, job, "Waiting for required inventory space/materials: " + extra + ". Add them or free a slot; construction has not started yet.");
            }
            job.nextActionGameTime = now + 4;
            return;
        }
        client.player.getInventory().setSelectedSlot(job.workHotbarSlot);
        job.phase = Phase.BASE_SUPPORTS;
        job.nextActionGameTime = now + 2;
        publish(client, job, "Required materials are now present. Starting Survival construction.");
    }

    private static int stageRequiredMaterials(Minecraft client, Job job) {
        LocalPlayer player = client.player;
        int reserved = reserveWorkingHotbarSlot(client);
        if (reserved < 0) return -1;

        Map<Item, Integer> required = requiredMaterials(job);
        Map<Item, Integer> remaining = new LinkedHashMap<>();
        List<Grant> grants = new ArrayList<>();
        List<Integer> emptySlots = new ArrayList<>();

        // Top up matching partial stacks first, preserving their existing items.
        for (Map.Entry<Item, Integer> entry : required.entrySet()) {
            Item item = entry.getKey();
            // Prepared Note Blocks count toward the required item total. If a
            // prepared stack does not match a later cell, Creative mode creates
            // a plain fallback in the working slot on demand; this avoids
            // wasting inventory slots by duplicating every prepared stack.
            int missing = Math.max(0, entry.getValue() - countItem(player, item));
            int maxStack = new ItemStack(item).getMaxStackSize();
            for (int slot = 0; slot < 36 && missing > 0; slot++) {
                if (slot == reserved) continue;
                ItemStack existing = player.getInventory().getItem(slot);
                if (!existing.is(item) || existing.getCount() >= maxStack) continue;
                if (item == Blocks.NOTE_BLOCK.asItem() && !isPlainNoteStack(existing)) continue;
                int add = Math.min(missing, maxStack - existing.getCount());
                ItemStack toppedUp = existing.copy();
                toppedUp.setCount(existing.getCount() + add);
                grants.add(new Grant(slot, toppedUp));
                missing -= add;
            }
            remaining.put(item, missing);
        }

        // Remaining shortages use empty slots only. The reserved working hand is
        // excluded so it remains available for empty-hand note tuning and playback.
        for (int slot = 9; slot < 36; slot++) {
            if (slot != reserved && player.getInventory().getItem(slot).isEmpty()) emptySlots.add(slot);
        }
        for (int slot = 0; slot < 9; slot++) {
            if (slot != reserved && player.getInventory().getItem(slot).isEmpty()) emptySlots.add(slot);
        }

        for (Map.Entry<Item, Integer> entry : remaining.entrySet()) {
            Item item = entry.getKey();
            int missing = entry.getValue();
            int maxStack = new ItemStack(item).getMaxStackSize();
            while (missing > 0) {
                if (emptySlots.isEmpty()) return -1;
                int slot = emptySlots.remove(0);
                int amount = Math.min(missing, maxStack);
                grants.add(new Grant(slot, new ItemStack(item, amount)));
                missing -= amount;
            }
        }

        // Apply the complete plan only after confirming every shortage fits.
        for (Grant grant : grants) {
            int menuSlot = grant.inventorySlot < 9 ? 36 + grant.inventorySlot : grant.inventorySlot;
            player.getInventory().setItem(grant.inventorySlot, grant.stack.copy());
            client.gameMode.handleCreativeModeItemAdd(grant.stack.copy(), menuSlot);
        }
        job.workHotbarSlot = reserved;
        return reserved;
    }

    private static Map<Item, Integer> requiredMaterials(Job job) {
        Map<Item, Integer> result = new LinkedHashMap<>();
        for (Scaffold scaffold : job.scaffolds) result.merge(Blocks.GLASS.asItem(), 1, Integer::sum);
        for (Cell cell : job.cells) result.merge(cell.support.asItem(), 1, Integer::sum);
        result.merge(Blocks.NOTE_BLOCK.asItem(), job.cells.size(), Integer::sum);
        return result;
    }

    private static int countItem(LocalPlayer player, Item item) {
        int count = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (stack.is(item)) count += stack.getCount();
        }
        return count;
    }

    private static String missingMaterials(LocalPlayer player, Job job) {
        List<String> missing = new ArrayList<>();
        for (Map.Entry<Item, Integer> entry : requiredMaterials(job).entrySet()) {
            int deficit = entry.getValue() - countItem(player, entry.getKey());
            if (deficit > 0) {
                String name = Component.translatable(entry.getKey().getDescriptionId()).getString();
                missing.add(name + " ×" + deficit);
            }
        }
        return String.join(", ", missing);
    }

    /**
     * Prefer a genuine Note Block stack whose minecraft:block_state component
     * already matches this cell's note and/or instrument. Plain Note Blocks
     * remain the fallback and are tuned normally after placement.
     */
    private static boolean equipNoteBlockForCell(Minecraft client, Job job, Cell cell) {
        LocalPlayer player = client.player;
        int workSlot = job.workHotbarSlot;
        if (player.getInventory().getSelectedSlot() != workSlot) {
            player.getInventory().setSelectedSlot(workSlot);
            return false;
        }

        ItemStack held = player.getInventory().getItem(workSlot);

        // Always look for a complete pre-tuned match before accepting a plain
        // Note Block already in the working hand. This was important: otherwise
        // a plain stack in the reserved slot could prevent the prepared stack in
        // another inventory slot from ever being used.
        if (preparedNoteMatchScore(held, cell) == 2) return true;
        int matchingSlot = findPreparedNoteSlot(player, workSlot, cell, 2);
        if (matchingSlot >= 0) {
            swapIntoWorkingSlot(client, player, matchingSlot, workSlot);
            held = player.getInventory().getItem(workSlot);
            if (preparedNoteMatchScore(held, cell) == 2) return true;
        }

        // A stack that specifies only note or instrument is still useful: the
        // support block below supplies the vanilla instrument, and the builder
        // can tune any missing pitch property after the server confirms placement.
        held = player.getInventory().getItem(workSlot);
        if (isPreparedNoteStack(held, cell)) return true;
        matchingSlot = findPreparedNoteSlot(player, workSlot, cell, 1);
        if (matchingSlot >= 0) {
            swapIntoWorkingSlot(client, player, matchingSlot, workSlot);
            held = player.getInventory().getItem(workSlot);
            if (isPreparedNoteStack(held, cell)) return true;
        }

        // In Creative, prepare the exact note+instrument on the Note Block item
        // itself. Vanilla's block-state item component applies these properties
        // when the server places the block, removing the 1–24 right-click tuning
        // loop for every cell on servers that accept normal Creative slot updates.
        // The later world-state verification remains authoritative; if a server
        // strips or rejects the component, tickTuning() tunes the placed block
        // through ordinary interactions instead.
        if (client.gameMode.getPlayerMode() == GameType.CREATIVE) {
            ItemStack prepared = createPreparedNoteStack(cell);
            player.getInventory().setItem(workSlot, prepared.copy());
            client.gameMode.handleCreativeModeItemAdd(prepared.copy(), 36 + workSlot);
            return preparedNoteMatchScore(player.getInventory().getItem(workSlot), cell) == 2;
        }

        // Survival cannot synthesize item components or grant itself items. Use
        // a real prepared stack when available, otherwise tune the real Note Block.
        held = player.getInventory().getItem(workSlot);
        if (isPlainNoteStack(held)) return true;
        for (int slot = 0; slot < 36; slot++) {
            if (slot == workSlot || !isPlainNoteStack(player.getInventory().getItem(slot))) continue;
            swapIntoWorkingSlot(client, player, slot, workSlot);
            return isPlainNoteStack(player.getInventory().getItem(workSlot));
        }
        return false;
    }

    private static boolean isUsableNoteStack(ItemStack stack, Cell cell) {
        return isPlainNoteStack(stack) || isPreparedNoteStack(stack, cell);
    }

    private static ItemStack createPreparedNoteStack(Cell cell) {
        ItemStack stack = new ItemStack(Blocks.NOTE_BLOCK.asItem(), 64);
        Map<String, String> stateProperties = new LinkedHashMap<>();
        stateProperties.put("note", Integer.toString(cell.pitch));
        stateProperties.put("instrument", cell.soundName);
        stack.set(DataComponents.BLOCK_STATE, new BlockItemStateProperties(stateProperties));
        return stack;
    }

    private static boolean isPlainNoteStack(ItemStack stack) {
        if (stack == null || !stack.is(Blocks.NOTE_BLOCK.asItem())) return false;
        BlockItemStateProperties component = stack.get(DataComponents.BLOCK_STATE);
        if (component == null) return true;
        Map<String, String> properties = component.properties();
        return !properties.containsKey("note") && !properties.containsKey("instrument");
    }

    private static int findPreparedNoteSlot(LocalPlayer player, int workSlot, Cell cell, int wantedScore) {
        for (int slot = 0; slot < 36; slot++) {
            if (slot == workSlot) continue;
            if (preparedNoteMatchScore(player.getInventory().getItem(slot), cell) == wantedScore) return slot;
        }
        return -1;
    }

    private static void swapIntoWorkingSlot(Minecraft client, LocalPlayer player, int sourceSlot, int workSlot) {
        int menuSlot = sourceSlot < 9 ? 36 + sourceSlot : sourceSlot;
        client.gameMode.handleContainerInput(player.inventoryMenu.containerId,
                menuSlot, workSlot, ContainerInput.SWAP, player);
    }

    /**
     * Returns 2 for an exact note+instrument match, 1 for a matching partial
     * block_state component, and 0 for a nonmatching or ordinary Note Block.
     */
    private static int preparedNoteMatchScore(ItemStack stack, Cell cell) {
        if (stack == null || !stack.is(Blocks.NOTE_BLOCK.asItem())) return 0;
        BlockItemStateProperties component = stack.get(DataComponents.BLOCK_STATE);
        if (component == null) return 0;
        Map<String, String> properties = component.properties();
        String noteText = properties.get("note");
        String instrumentText = properties.get("instrument");
        if (noteText == null && instrumentText == null) return 0;
        if (noteText != null) {
            try {
                if (Integer.parseInt(noteText) != cell.pitch) return 0;
            } catch (NumberFormatException invalidNote) {
                return 0;
            }
        }
        if (instrumentText != null && !instrumentText.equalsIgnoreCase(cell.soundName)) return 0;
        return noteText != null && instrumentText != null ? 2 : 1;
    }

    private static boolean isPreparedNoteStack(ItemStack stack, Cell cell) {
        return preparedNoteMatchScore(stack, cell) > 0;
    }

    private static boolean equipPlacementItem(Minecraft client, Job job, Item item) {
        LocalPlayer player = client.player;
        int workSlot = job.workHotbarSlot;
        if (player.getInventory().getSelectedSlot() != workSlot) {
            player.getInventory().setSelectedSlot(workSlot);
            return false;
        }
        if (player.getInventory().getItem(workSlot).is(item)) return true;

        // Keep the selected hotbar index fixed for the entire build. Swap each
        // required stack into that slot via a normal inventory click, so the
        // subsequent placement packets always use the correct server-side hand.
        for (int slot = 0; slot < 36; slot++) {
            if (slot == workSlot || !player.getInventory().getItem(slot).is(item)) continue;
            int menuSlot = slot < 9 ? 36 + slot : slot;
            client.gameMode.handleContainerInput(player.inventoryMenu.containerId,
                    menuSlot, workSlot, ContainerInput.SWAP, player);
            return player.getInventory().getItem(workSlot).is(item);
        }
        return false;
    }

    private static boolean withinReach(LocalPlayer player, Vec3 hitPoint) {
        return player != null && player.getEyePosition().distanceTo(hitPoint)
                <= Math.max(0.5, blockInteractionReach(player) - REACH_SAFETY_MARGIN);
    }

    private static boolean withinBuildReach(LocalPlayer player, Vec3 hitPoint, Job job) {
        double limit = blockInteractionReach(player) - REACH_SAFETY_MARGIN;
        return player != null && player.getEyePosition().distanceTo(hitPoint) <= Math.max(0.5, limit);
    }

    private static void waitForReach(Minecraft client, Job job, long now) {
        publish(client, job, "Build paused: move back beside the arrangement center. NoteClient will resume when the next block is within normal reach.");
        job.nextActionGameTime = now + 3;
    }

    private static void waitForMissingItem(Minecraft client, Job job, Item item, long now) {
        String name = Component.translatable(item.getDescriptionId()).getString();
        if (countItem(client.player, item) > 0) {
            publish(client, job, "Waiting for the " + name + " inventory stack to synchronize. NoteClient will retry automatically.");
        } else {
            publish(client, job, "Build paused: " + name + " is missing from your inventory. Add it and NoteClient will continue.");
        }
        job.nextActionGameTime = now + 4;
    }

    private static boolean equipEmptyHandForTuning(Minecraft client, Job job) {
        LocalPlayer player = client.player;
        int workSlot = job.workHotbarSlot;
        if (player.getInventory().getSelectedSlot() != workSlot) {
            player.getInventory().setSelectedSlot(workSlot);
            return false;
        }
        if (player.getInventory().getItem(workSlot).isEmpty()) return true;

        // A source hotbar slot may have become empty when its material was swapped
        // into the working slot. Prefer using that free hotbar slot for the remainder.
        for (int slot = 0; slot < 9; slot++) {
            if (slot != workSlot && player.getInventory().getItem(slot).isEmpty()) {
                client.gameMode.handleContainerInput(player.inventoryMenu.containerId,
                        36 + slot, workSlot, ContainerInput.SWAP, player);
                return player.getInventory().getItem(workSlot).isEmpty();
            }
        }
        // Or move the remaining stack into an empty main-inventory slot.
        for (int slot = 9; slot < 36; slot++) {
            if (player.getInventory().getItem(slot).isEmpty()) {
                client.gameMode.handleContainerInput(player.inventoryMenu.containerId,
                        slot, workSlot, ContainerInput.SWAP, player);
                return player.getInventory().getItem(workSlot).isEmpty();
            }
        }
        return false;
    }

    private static void beginPlayback(Job job, long now) {
        job.phase = Phase.PLAYING;
        job.playbackStart = now + PLAYBACK_START_DELAY_TICKS;
        job.eventIndex = 0;
        job.integrityScanCursor = 0;
        job.tuneIntegrityScanCursor = 0;
        job.playbackQueue.clear();
        job.lastMessageTime = now;
        job.nextActionGameTime = now + 1;
    }

    private static boolean scanPlaybackIntegrity(Minecraft client, Job job, long now) {
        int size = job.cells.size();
        if (size == 0) return false;
        int checks = Math.min(PLAYBACK_INTEGRITY_CHECKS_PER_TICK, size);
        for (int checked = 0; checked < checks; checked++) {
            if (job.integrityScanCursor >= size) job.integrityScanCursor = 0;
            Cell cell = job.cells.get(job.integrityScanCursor++);
            BlockState noteState = client.level.getBlockState(cell.notePos);
            if (!noteState.is(Blocks.NOTE_BLOCK)) {
                beginMissingNoteRepair(client, job, cell, Phase.PLAYING, now);
                return true;
            }
            if (!isCompatibleSupportBlock(cell.support,
                    client.level.getBlockState(cell.supportPos).getBlock())) {
                beginRuntimeSupportRepair(client, job, cell, Phase.PLAYING, now);
                return true;
            }
            if (!hasExpectedNoteInstrument(noteState, cell)) {
                beginNoteInstrumentRepair(client, job, cell, Phase.PLAYING, now);
                return true;
            }
            if (!client.level.getBlockState(cell.notePos.above()).isAir()) {
                beginSoundSpaceRecovery(client, job, cell, Phase.PLAYING, now);
                return true;
            }
            if (readNoteBlockPitch(noteState) != cell.pitch) {
                beginTargetedRetune(client, job, cell, Phase.PLAYING, now);
                return true;
            }
        }
        return false;
    }

    private static void tickPlayback(Minecraft client, Job job, long now) {
        if (client.gameMode.getPlayerMode() != GameType.SURVIVAL) {
            if (job.playbackStart >= 0) job.playbackStart++;
            if (job.lastMessageTime == Long.MIN_VALUE || now - job.lastMessageTime >= 100) {
                job.lastMessageTime = now;
                publish(client, job, "Playback paused until Survival mode is active again. The song timeline is being preserved.");
            }
            job.nextActionGameTime = now + 1;
            return;
        }
        if (now < job.playbackStart) return;

        // A rotating integrity scan catches missing/changed blocks even when the
        // next song event using that cell is far in the future. Repairs happen
        // before an affected event can be played; the song clock is held meanwhile.
        if (scanPlaybackIntegrity(client, job, now)) return;

        long elapsedTicks = now - job.playbackStart;
        int songTick = (int) Math.min(Integer.MAX_VALUE,
                (elapsedTicks * (long) job.tempoHundredths) / 2000L);
        while (job.eventIndex < job.timeline.size()) {
            TimedNote event = job.timeline.get(job.eventIndex);
            if (event.tick() > songTick) break;
            job.playbackQueue.addLast(event);
            job.eventIndex++;
        }

        // Send a bounded four-block chord batch per client tick. This keeps
        // simultaneous notes close together without emitting an unbounded packet
        // burst; any remaining notes stay queued and the song clock waits for them.
        int attacks = 0;
        int attackLimit = Math.min(MAX_PLAYER_ATTACKS_PER_TICK, NoteClientConfig.playbackAttacksPerTick());
        while (!job.playbackQueue.isEmpty() && attacks < attackLimit) {
            TimedNote event = job.playbackQueue.peekFirst();
            if (event.volume() <= 0) {
                job.playbackQueue.removeFirst();
                continue;
            }
            if (event.cellIndex() < 0 || event.cellIndex() >= job.cells.size()) {
                pauseAndRetain(client, job, "Playback encountered an invalid note-to-block mapping. No remaining events were discarded.");
                return;
            }
            Cell cell = job.cells.get(event.cellIndex());
            BlockState noteState = client.level.getBlockState(cell.notePos);
            if (!noteState.is(Blocks.NOTE_BLOCK)) {
                beginMissingNoteRepair(client, job, cell, Phase.PLAYING, now);
                return;
            }
            if (!isCompatibleSupportBlock(cell.support,
                    client.level.getBlockState(cell.supportPos).getBlock())) {
                beginRuntimeSupportRepair(client, job, cell, Phase.PLAYING, now);
                return;
            }
            if (!hasExpectedNoteInstrument(noteState, cell)) {
                beginNoteInstrumentRepair(client, job, cell, Phase.PLAYING, now);
                return;
            }
            if (!client.level.getBlockState(cell.notePos.above()).isAir()) {
                beginSoundSpaceRecovery(client, job, cell, Phase.PLAYING, now);
                return;
            }
            if (readNoteBlockPitch(noteState) != cell.pitch) {
                beginTargetedRetune(client, job, cell, Phase.PLAYING, now);
                return;
            }
            if (!withinReach(client.player, Vec3.atCenterOf(cell.notePos))) {
                job.playbackStart++;
                if (job.lastMessageTime == Long.MIN_VALUE || now - job.lastMessageTime >= 100) {
                    job.lastMessageTime = now;
                    publish(client, job, "Playback paused at the next note because it is outside vanilla reach. Return to the arrangement; no notes were skipped.");
                }
                job.nextActionGameTime = now + 1;
                return;
            }

            job.playbackQueue.removeFirst();
            triggerNoteBlock(client, cell, job.workHotbarSlot, event, job.playerYaw);
            attacks++;
        }

        // If multiple events were due together, hold the song clock until all have
        // been played. The configured attack limit is bounded to four per tick; dense
        // chords may be slightly arpeggiated rather than silently dropping notes.
        if (!job.playbackQueue.isEmpty()) job.playbackStart++;

        int endTick = Math.max(job.songLengthTicks,
                job.timeline.isEmpty() ? 0 : job.timeline.get(job.timeline.size() - 1).tick() + 1);
        if (job.eventIndex >= job.timeline.size() && job.playbackQueue.isEmpty() && songTick >= endTick) {
            restoreTemporarySlot(client, job);
            job.phase = Phase.RETAINED;
            String message = "Song finished. Arrangement retained. Use Builder → Destroy when you want to remove it.";
            publish(client, job, message);
            sendChat(client, message);
        } else if (now - job.lastMessageTime >= 40) {
            job.lastMessageTime = now;
            publishQuietly(client, job, "Playing note blocks: " + (job.eventIndex - job.playbackQueue.size())
                    + "/" + job.timeline.size() + " note events.");
        }
    }

    private static void triggerNoteBlock(Minecraft client, Cell cell, int emptySlot,
                                         TimedNote event, float playerYaw) {
        if (client.player != null && client.gameMode != null
                && client.gameMode.getPlayerMode() == GameType.SURVIVAL
                && emptySlot >= 0 && client.player.getInventory().getItem(emptySlot).isEmpty()) {
            boolean started = client.gameMode.startDestroyBlock(cell.notePos, Direction.UP);
            if (started) {
                client.gameMode.stopDestroyBlock();
                return;
            }
        }
        // Local fallback keeps the event audible to the owner when an ordinary
        // server blocks the attack packet. Its pitch/velocity/pan still follow NBS.
        playLocalNote(client, cell, event, playerYaw);
    }

    private static void playLocalNote(Minecraft client, Cell cell, TimedNote event, float playerYaw) {
        SoundEvent sound = resolveNoteSound(cell.soundName);
        if (sound == null || event.volume() <= 0) return;
        int sourceKey = event.sourceKey() >= 0 ? event.sourceKey() : cell.nbsKey;
        double semitones = (sourceKey - 45) + event.finePitchCents() / 100.0;
        float pitch = (float) Math.pow(2.0, semitones / 12.0);
        float volume = event.volume() / 100.0F;
        Direction right = Direction.fromYRot(playerYaw).getClockWise();
        double pan = ((event.panning() - 100) / 100.0) * 2.0;
        BlockPos pos = cell.notePos;
        double x = pos.getX() + 0.5 + right.getStepX() * pan;
        double y = pos.getY() + 0.5;
        double z = pos.getZ() + 0.5 + right.getStepZ() * pan;
        client.level.playLocalSound(x, y, z, sound, SoundSource.RECORDS, volume, pitch, false);
    }

    private static int findEmptyHotbarSlot(LocalPlayer player) {
        for (int slot = 0; slot < 9; slot++) {
            if (player.getInventory().getItem(slot).isEmpty()) return slot;
        }
        return -1;
    }

    private static int reserveWorkingHotbarSlot(Minecraft client) {
        LocalPlayer player = client.player;
        int emptyHotbar = findEmptyHotbarSlot(player);
        if (emptyHotbar >= 0) return emptyHotbar;

        // If the hotbar is full, move one stack into an actually empty main slot.
        // SWAP is a normal inventory operation and preserves the player's items.
        for (int mainSlot = 9; mainSlot < 36; mainSlot++) {
            if (player.getInventory().getItem(mainSlot).isEmpty()) {
                int selected = player.getInventory().getSelectedSlot();
                int workSlot = selected == TEMP_HOTBAR_SLOT ? (TEMP_HOTBAR_SLOT + 1) % 9 : TEMP_HOTBAR_SLOT;
                client.gameMode.handleContainerInput(player.inventoryMenu.containerId,
                        mainSlot, workSlot, ContainerInput.SWAP, player);
                if (player.getInventory().getItem(workSlot).isEmpty()) return workSlot;
                return -1;
            }
        }
        return -1;
    }

    public static void playTestTone(Minecraft client) {
        if (client == null || client.player == null || client.level == null) {
            reject(client, "Join a world before testing audio.");
            return;
        }
        SoundEvent sound = resolveNoteSound("harp");
        if (sound == null) {
            sendMessage(client, "NoteClient could not find minecraft:block.note_block.harp in this game version.");
            return;
        }
        client.level.playLocalSound(client.player.getX(), client.player.getY() + 1.0, client.player.getZ(),
                sound, SoundSource.RECORDS, 1.5F, 1.0F, false);
        sendMessage(client, "Test note played. Check Options > Music & Sounds > Jukebox/Note Blocks volume.");
    }

    private static SoundEvent resolveNoteSound(String instrument) {
        SoundEvent cached = NOTE_SOUNDS.get(instrument);
        if (cached != null) return cached;
        Identifier id = Identifier.fromNamespaceAndPath("minecraft", "block.note_block." + instrument);
        SoundEvent resolved = BuiltInRegistries.SOUND_EVENT.getValue(id);
        if (resolved == null) {
            if (MISSING_SOUND_WARNINGS.add(id.toString())) {
                System.err.println("[NoteClient] Missing vanilla note sound event: " + id);
            }
            return null;
        }
        NOTE_SOUNDS.put(instrument, resolved);
        return resolved;
    }

    private static void tickCleanup(Minecraft client, Job job, long now) {
        // Resolve outstanding breaks first. In Creative, startDestroyBlock predicts
        // instant removal; one stable server update is enough to retire ownership.
        var pendingIterator = job.pendingCleanups.iterator();
        while (pendingIterator.hasNext()) {
            PendingCleanup pending = pendingIterator.next();
            BlockState current = client.level.getBlockState(pending.position);
            long age = now - pending.sentAt;
            if (age >= CLEANUP_BREAK_CONFIRM_GRACE_TICKS && current.isAir()) {
                forgetOwnedBlock(job, pending.position);
                job.pendingCleanupPositions.remove(pending.position);
                pendingIterator.remove();
                continue;
            }
            if (age >= CLEANUP_BREAK_CONFIRM_GRACE_TICKS
                    && current.getBlock() != pending.expectedBlock) {
                // Someone replaced the original block. Keep that replacement and
                // discard only the old NoteClient ownership record.
                forgetOwnedBlock(job, pending.position);
                job.pendingCleanupPositions.remove(pending.position);
                pendingIterator.remove();
                continue;
            }
            if (age >= CLEANUP_BREAK_RETRY_TICKS) {
                if (pending.attempts >= CLEANUP_BREAK_MAX_ATTEMPTS) {
                    pauseAndRetain(client, job, "The server has not confirmed removal of "
                            + pending.position.toShortString()
                            + ". That block remains tracked; check reach/permissions and press P to retry cleanup.");
                    return;
                }
                if (client.gameMode.getPlayerMode() != GameType.CREATIVE) {
                    // Hand an unconfirmed Creative break back to the one-at-a-time
                    // Survival path instead of waiting forever for Creative mode.
                    job.cleanupQueue.addFirst(new OwnedBlock(pending.position, pending.expectedBlock));
                    job.pendingCleanupPositions.remove(pending.position);
                    pendingIterator.remove();
                    continue;
                }
                if (!withinReach(client.player, Vec3.atCenterOf(pending.position))) {
                    job.cleanupDeferred.add(new OwnedBlock(pending.position, pending.expectedBlock));
                    job.pendingCleanupPositions.remove(pending.position);
                    pendingIterator.remove();
                    continue;
                }
                boolean started = client.gameMode.startDestroyBlock(pending.position, Direction.UP);
                if (started) client.gameMode.stopDestroyBlock();
                pending.attempts++;
                pending.sentAt = now;
            }
        }

        if (client.gameMode.getPlayerMode() != GameType.CREATIVE) {
            tickSurvivalCleanup(client, job, now);
            return;
        }
        if (job.survivalCleanupPosition != null) {
            // The player switched to Creative mid-break. Abort the ordinary break
            // and let the faster Creative batch path take over.
            client.gameMode.stopDestroyBlock();
            job.survivalCleanupPosition = null;
            job.survivalCleanupExpectedBlock = null;
            job.survivalCleanupAwaitingConfirmation = false;
            job.survivalCleanupStartedAt = Long.MIN_VALUE;
        }

        // Revisit previously out-of-reach blocks when the player moves closer.
        for (int i = job.cleanupDeferred.size() - 1; i >= 0; i--) {
            OwnedBlock deferred = job.cleanupDeferred.get(i);
            BlockState current = client.level.getBlockState(deferred.position);
            if (current.isAir() || current.getBlock() != deferred.block) {
                job.cleanupDeferred.remove(i);
                forgetOwnedBlock(job, deferred.position);
            } else if (withinReach(client.player, Vec3.atCenterOf(deferred.position))) {
                job.cleanupQueue.addLast(deferred);
                job.cleanupDeferred.remove(i);
                job.survivalCleanupRetryAt.remove(deferred.position);
            }
        }

        int sent = 0;
        while (sent < NoteClientConfig.buildActionsPerTick()
                && job.pendingCleanups.size() < MAX_PENDING_CLEANUPS
                && !job.cleanupQueue.isEmpty()) {
            OwnedBlock owned = job.cleanupQueue.removeFirst();
            if (!isCreatedPosition(job, owned.position)
                    || job.pendingCleanupPositions.contains(owned.position)) continue;

            BlockState current = client.level.getBlockState(owned.position);
            if (current.isAir() || current.getBlock() != owned.block) {
                forgetOwnedBlock(job, owned.position);
                job.survivalCleanupRetries.remove(owned.position);
                job.survivalCleanupRetryAt.remove(owned.position);
                continue;
            }
            if (!withinReach(client.player, Vec3.atCenterOf(owned.position))) {
                job.cleanupDeferred.add(owned);
                continue;
            }

            boolean started = client.gameMode.startDestroyBlock(owned.position, Direction.UP);
            if (started) client.gameMode.stopDestroyBlock();
            job.pendingCleanups.add(new PendingCleanup(owned.position.immutable(), owned.block, now, 1));
            job.pendingCleanupPositions.add(owned.position.immutable());
            sent++;
        }

        // Defensive reconciliation: every still-owned block must be represented by
        // exactly one queued, deferred, or in-flight cleanup entry.
        for (OwnedBlock owned : job.createdBlocks) {
            if (job.pendingCleanupPositions.contains(owned.position)
                    || containsOwnedPosition(job.cleanupQueue, owned.position)
                    || containsOwnedPosition(job.cleanupDeferred, owned.position)) continue;
            job.cleanupQueue.addLast(owned);
        }

        if (completeCleanupIfDone(client, job)) return;

        if (sent > 0 || !job.pendingCleanups.isEmpty() || !job.cleanupQueue.isEmpty()) {
            job.nextActionGameTime = now + 1;
            publishQuietly(client, job, "Fast cleanup: " + job.createdBlocks.size()
                    + " owned blocks remaining • " + job.pendingCleanups.size() + " awaiting confirmation...");
            return;
        }
        if (!job.cleanupDeferred.isEmpty()) {
            job.nextActionGameTime = now + 20;
            if (now - job.lastMessageTime >= 40) {
                job.lastMessageTime = now;
                publish(client, job, "Some arrangement blocks are outside current reach. Move closer and cleanup will continue automatically.");
            }
            return;
        }
        job.nextActionGameTime = now + 1;
    }

    /**
     * Survival cleanup uses the normal held-break lifecycle. It intentionally
     * processes one block at a time because vanilla destroy progress is tied to
     * the selected tool and the server's block-breaking rules.
     */
    private static void tickSurvivalCleanup(Minecraft client, Job job, long now) {
        for (int i = job.cleanupDeferred.size() - 1; i >= 0; i--) {
            OwnedBlock deferred = job.cleanupDeferred.get(i);
            BlockState state = client.level.getBlockState(deferred.position);
            if (state.isAir() || state.getBlock() != deferred.block) {
                job.cleanupDeferred.remove(i);
                forgetOwnedBlock(job, deferred.position);
                job.survivalCleanupRetries.remove(deferred.position);
                job.survivalCleanupRetryAt.remove(deferred.position);
            } else if (withinReach(client.player, Vec3.atCenterOf(deferred.position))
                    && now >= job.survivalCleanupRetryAt.getOrDefault(deferred.position, Long.MIN_VALUE)) {
                job.cleanupQueue.addLast(deferred);
                job.cleanupDeferred.remove(i);
                job.survivalCleanupRetryAt.remove(deferred.position);
            }
        }

        if (job.survivalCleanupPosition != null) {
            BlockPos position = job.survivalCleanupPosition;
            BlockState current = client.level.getBlockState(position);
            if (current.isAir()) {
                if (!job.survivalCleanupAwaitingConfirmation) {
                    job.survivalCleanupAwaitingConfirmation = true;
                    job.survivalCleanupConfirmedAt = now;
                } else if (now - job.survivalCleanupConfirmedAt >= CLEANUP_BREAK_CONFIRM_GRACE_TICKS) {
                    forgetOwnedBlock(job, position);
                    job.survivalCleanupRetries.remove(position);
                    job.survivalCleanupRetryAt.remove(position);
                    clearSurvivalCleanupTarget(job);
                }
                job.nextActionGameTime = now + 1;
                return;
            }
            if (current.getBlock() != job.survivalCleanupExpectedBlock) {
                // A replacement block is not ours to break.
                client.gameMode.stopDestroyBlock();
                forgetOwnedBlock(job, position);
                job.survivalCleanupRetries.remove(position);
                job.survivalCleanupRetryAt.remove(position);
                clearSurvivalCleanupTarget(job);
                job.nextActionGameTime = now + 1;
                return;
            }
            if (job.survivalCleanupAwaitingConfirmation) {
                if (now - job.survivalCleanupConfirmedAt >= 8) {
                    // The local prediction was rejected. Stop the held break before
                    // retrying so client-side destroy progress cannot leak to the next block.
                    client.gameMode.stopDestroyBlock();
                    clearSurvivalCleanupTarget(job);
                    int retries = job.survivalCleanupRetries.merge(position, 1,
                            (oldValue, one) -> Math.min(1000, oldValue + one));
                    if (retries >= 3) {
                        pauseAndRetain(client, job, "The server did not confirm Survival cleanup at "
                                + position.toShortString() + ". The block is still tracked; use Creative or check permissions/tool durability.");
                        return;
                    }
                    job.cleanupQueue.addFirst(new OwnedBlock(position, current.getBlock()));
                }
                job.nextActionGameTime = now + 1;
                return;
            }
            if (now - job.survivalCleanupStartedAt >= SURVIVAL_CLEANUP_TIMEOUT_TICKS) {
                client.gameMode.stopDestroyBlock();
                BlockPos failed = position;
                clearSurvivalCleanupTarget(job);
                job.cleanupDeferred.add(new OwnedBlock(failed, current.getBlock()));
                job.survivalCleanupRetryAt.put(failed, now + 40);
                publish(client, job, "Survival cleanup is taking too long at " + failed.toShortString()
                        + ". Use a suitable tool or switch to Creative to remove the remaining blocks faster.");
                job.nextActionGameTime = now + 20;
                return;
            }
            client.gameMode.continueDestroyBlock(position, Direction.UP);
            BlockState after = client.level.getBlockState(position);
            if (after.isAir()) {
                job.survivalCleanupAwaitingConfirmation = true;
                job.survivalCleanupConfirmedAt = now;
            } else if (after.getBlock() != job.survivalCleanupExpectedBlock) {
                client.gameMode.stopDestroyBlock();
                forgetOwnedBlock(job, position);
                job.survivalCleanupRetries.remove(position);
                job.survivalCleanupRetryAt.remove(position);
                clearSurvivalCleanupTarget(job);
            }
            job.nextActionGameTime = now + 1;
            publishQuietly(client, job, "Survival cleanup: " + job.createdBlocks.size()
                    + " owned blocks remaining • breaking one block with normal tool speed...");
            return;
        }

        while (!job.cleanupQueue.isEmpty()) {
            OwnedBlock owned = job.cleanupQueue.removeFirst();
            if (!isCreatedPosition(job, owned.position)
                    || job.pendingCleanupPositions.contains(owned.position)) continue;
            BlockState current = client.level.getBlockState(owned.position);
            if (current.isAir() || current.getBlock() != owned.block) {
                forgetOwnedBlock(job, owned.position);
                job.survivalCleanupRetries.remove(owned.position);
                continue;
            }
            if (!withinReach(client.player, Vec3.atCenterOf(owned.position))) {
                job.cleanupDeferred.add(owned);
                continue;
            }
            job.survivalCleanupPosition = owned.position.immutable();
            job.survivalCleanupExpectedBlock = owned.block;
            job.survivalCleanupStartedAt = now;
            job.survivalCleanupAwaitingConfirmation = false;
            boolean started = client.gameMode.startDestroyBlock(owned.position, Direction.UP);
            if (!started) {
                clearSurvivalCleanupTarget(job);
                int retries = job.survivalCleanupRetries.merge(owned.position, 1,
                        (oldValue, one) -> Math.min(1000, oldValue + one));
                if (retries >= 3) {
                    pauseAndRetain(client, job, "The server refused ordinary Survival breaking at "
                            + owned.position.toShortString() + ". The block remains tracked; switch to Creative or check permissions.");
                    return;
                }
                job.cleanupQueue.addFirst(owned);
                job.nextActionGameTime = now + 4;
                return;
            }
            if (client.level.getBlockState(owned.position).isAir()) {
                job.survivalCleanupAwaitingConfirmation = true;
                job.survivalCleanupConfirmedAt = now;
            }
            job.nextActionGameTime = now + 1;
            publishQuietly(client, job, "Survival cleanup: " + job.createdBlocks.size()
                    + " owned blocks remaining • normal server-authorized breaking...");
            return;
        }

        if (completeCleanupIfDone(client, job)) return;
        if (!job.cleanupDeferred.isEmpty()) {
            job.nextActionGameTime = now + 20;
            if (now - job.lastMessageTime >= 40) {
                job.lastMessageTime = now;
                publish(client, job, "Some arrangement blocks are outside current reach. Move closer and Survival cleanup will continue automatically.");
            }
            return;
        }
        // Reconcile blocks that remain in the ownership ledger but are not in
        // a queue after a delayed acknowledgement or a retry.
        for (OwnedBlock owned : job.createdBlocks) {
            if (!containsOwnedPosition(job.cleanupQueue, owned.position)
                    && !job.pendingCleanupPositions.contains(owned.position)) {
                job.cleanupQueue.addLast(owned);
            }
        }
        job.nextActionGameTime = now + 1;
    }

    private static void clearSurvivalCleanupTarget(Job job) {
        job.survivalCleanupPosition = null;
        job.survivalCleanupExpectedBlock = null;
        job.survivalCleanupStartedAt = Long.MIN_VALUE;
        job.survivalCleanupConfirmedAt = Long.MIN_VALUE;
        job.survivalCleanupAwaitingConfirmation = false;
    }

    private static boolean completeCleanupIfDone(Minecraft client, Job job) {
        if (!job.createdBlocks.isEmpty() || !job.pendingCleanups.isEmpty()
                || !job.cleanupQueue.isEmpty() || !job.cleanupDeferred.isEmpty()
                || !job.pendingPlacements.isEmpty() || job.survivalCleanupPosition != null) return false;
        restoreTemporarySlot(client, job);
        Request pending = job.pendingRequest;
        activeJob = null;
        if (pending != null) {
            if (!createJob(client, pending)) sendMessage(client, BuildClientState.message());
        } else {
            BuildClientState.updateLocal(0, 0, job.skipped, 0, true, false, "Arrangement destroyed. Cleanup complete.");
            sendMessage(client, "NoteClient arrangement destroyed.");
            sendChat(client, "Arrangement destroyed. Your selected hotbar slot has been restored.");
        }
        return true;
    }

    private static boolean containsOwnedPosition(Iterable<OwnedBlock> blocks, BlockPos position) {
        for (OwnedBlock owned : blocks) if (owned.position.equals(position)) return true;
        return false;
    }

    private static void pauseAndRetain(Minecraft client, Job job, String message) {
        // A failed or unconfirmed action must never erase blocks that the server
        // has already accepted. Keep the current phase/cursor so P can retry after
        // the player fixes reach, materials, or the obstructed position.
        job.paused = true;
        job.pausedAt = client.level == null ? 0 : client.level.getGameTime();
        job.lastMessageTime = job.pausedAt;
        publish(client, job, message + " No automatic cleanup will run. Confirmed blocks are retained. Press P to retry after fixing the issue, or O to intentionally destroy this arrangement.");
    }

    private static void restoreTemporarySlot(Minecraft client, Job job) {
        if (job.slotRestored || client.player == null) return;
        // Inventory stacks are genuine materials now: never overwrite them with a
        // saved Creative-only hotbar snapshot. Restore only the selected slot.
        client.player.getInventory().setSelectedSlot(job.originalSelectedSlot);
        job.slotRestored = true;
    }

    private static int effectiveBuildActionsPerTick(Job job) {
        return Math.max(1, Math.min(NoteClientConfig.buildActionsPerTick(), job.adaptiveBuildActionsPerTick));
    }

    private static void publish(Minecraft client, Job job, String message) {
        publishInternal(client, job, message, true);
    }

    private static void publishQuietly(Minecraft client, Job job, String message) {
        publishInternal(client, job, message, false);
    }

    private static void publishInternal(Minecraft client, Job job, String message, boolean showHud) {
        int layer = switch (job.phase) {
            case BASE_SUPPORTS, SCAFFOLDS, RAISED_SUPPORTS, SCAFFOLD_CLEANUP -> 2;
            case NOTES -> 3;
            case VERIFYING_NOTES -> 3;
            case TUNING -> 4;
            case WAITING_FOR_SURVIVAL, WAITING_FOR_MATERIALS, PLAYING -> 5;
            case CLEANUP -> 6;
            case RETAINED -> 7;
        };
        if (showHud) {
            BuildClientState.updateLocal(job.placed, job.total, job.skipped, layer, false, job.paused, message);
            sendMessage(client, message);
        } else {
            BuildClientState.updateLocalQuietly(job.placed, job.total, job.skipped, layer,
                    false, job.paused, message);
        }
    }

    private static boolean reject(Minecraft client, String message) {
        BuildClientState.reset(message);
        sendMessage(client, message);
        return false;
    }

    private static void sendMessage(Minecraft client, String message) {
        if (client != null && client.player != null) {
            NoteClientHud.show(message);
        }
    }

    /**
     * Creates a compact, player-centered dome volume. The lowest ring starts
     * beside the player's feet and is built first. Higher tiers are stacked
     * three blocks apart in progressively smaller horizontal rings, leaving
     * the note block's required sound-space air gap between stacked instruments.
     *
     * The radius is selected from the number of physical note blocks required,
     * not from the maximum /reach hint. This keeps a retry/build local instead
     * of filling every reachable chunk. Candidate order is bottom-up, then
     * inside-out, so supports are placed from the player's ground-level ring
     * toward the upper center of the dome.
     */
    private static List<Offset> accessibleDomeOffsets(LocalPlayer player, BlockPos center,
                                                       Direction right, Direction forward,
                                                       double playbackReach, double buildReach,
                                                       int requiredPositions) {
        if (requiredPositions <= 0) return List.of();

        Vec3 eye = player.getEyePosition();
        int maxDomeLift = Math.min(MAX_PLANNED_DOME_LIFT,
                (int) Math.floor(Math.sqrt(Math.max(1.0, playbackReach * playbackReach - 1.0))));
        maxDomeLift = (maxDomeLift / 3) * 3;

        // A 100-block server reach should increase vertical capacity, not make
        // the layout expand to a 200-block-wide field. A 6-block radius cap
        // keeps the footprint to 13x13 blocks (at most four chunks); all 20
        // vanilla instruments across 25 pitches fit in 518 candidate slots.
        int maxRadius = Math.min(MAX_COMPACT_DOME_RADIUS,
                Math.max(1, (int) Math.floor(Math.min(playbackReach, buildReach))));
        List<Offset> best = List.of();

        for (int radius = 1; radius <= maxRadius; radius++) {
            List<Offset> candidates = new ArrayList<>();
            int radiusDomeLift = Math.min(maxDomeLift, radius * 3);
            for (int rightOffset = -radius; rightOffset <= radius; rightOffset++) {
                for (int forwardOffset = -radius; forwardOffset <= radius; forwardOffset++) {
                    int distanceSquared = rightOffset * rightOffset + forwardOffset * forwardOffset;
                    if (distanceSquared > radius * radius) continue;

                    double radialDistance = Math.sqrt(distanceSquared);
                    double domeHeight = distanceSquared == 0 ? radiusDomeLift
                            : radiusDomeLift * Math.sqrt(Math.max(0.0,
                                    1.0 - distanceSquared / (double) (radius * radius)));
                    int highestTier = (int) Math.floor((domeHeight + 1.0e-6) / 3.0);

                    BlockPos basePos = center.relative(right, rightOffset)
                            .relative(forward, forwardOffset);
                    // Each tier is three blocks above the previous one: support,
                    // note block, one air block for sound, then the next support.
                    // Keep the player's feet column empty, but allow the dome's
                    // upper tiers to meet above the player at its central apex.
                    for (int tier = 0; tier <= highestTier; tier++) {
                        int up = tier * 3;
                        if (distanceSquared == 0 && up == 0) continue;
                        BlockPos supportPos = basePos.above(up);
                        BlockPos notePos = supportPos.above();
                        BlockPos soundSpace = notePos.above();

                        boolean outside = !player.level().getWorldBorder().isWithinBounds(supportPos.below())
                                || !player.level().getWorldBorder().isWithinBounds(supportPos)
                                || !player.level().getWorldBorder().isWithinBounds(notePos)
                                || !player.level().getWorldBorder().isWithinBounds(soundSpace)
                                || player.level().isOutsideBuildHeight(supportPos.below())
                                || player.level().isOutsideBuildHeight(soundSpace);
                        if (outside) continue;

                        if (!player.level().getBlockState(supportPos).isAir()
                                || !player.level().getBlockState(notePos).isAir()
                                || !player.level().getBlockState(soundSpace).isAir()) continue;

                        BlockHitResult supportHit = supportPlacementHit(player, supportPos);
                        Vec3 notePlacementHit = topFacePointToward(eye, supportPos);
                        double noteDistance = eye.distanceTo(Vec3.atCenterOf(notePos));
                        boolean reachable = eye.distanceTo(supportHit.getLocation()) <= buildReach
                                && eye.distanceTo(notePlacementHit) <= buildReach
                                && noteDistance <= playbackReach;
                        if (!reachable) continue;

                        double supportDistance = Math.max(eye.distanceTo(supportHit.getLocation()),
                                eye.distanceTo(notePlacementHit));
                        candidates.add(new Offset(rightOffset, up, forwardOffset,
                                noteDistance, supportDistance));
                    }
                }
            }

            // Build the base tier from the positions nearest the player's feet,
            // expand across the bottom ring, then repeat for each higher tier.
            candidates.sort(Comparator.comparingInt(Offset::up)
                    .thenComparingDouble(Offset::noteDistance)
                    .thenComparingDouble(Offset::supportDistance)
                    .thenComparingInt(Offset::right)
                    .thenComparingInt(Offset::forward));
            best = candidates;
            if (candidates.size() >= requiredPositions) return candidates;
        }
        return best;
    }

    private static double blockInteractionReach(LocalPlayer player) {
        double synchronizedReach = DEFAULT_SURVIVAL_REACH;
        if (player != null) {
            try {
                double reach = player.getAttributeValue(Attributes.BLOCK_INTERACTION_RANGE);
                if (Double.isFinite(reach) && reach > 0.0) synchronizedReach = reach;
            } catch (Throwable ignored) {
                // Fall back until the server-synchronized attributes are ready.
            }
        }

        // Some servers implement /reach independently of vanilla's
        // block_interaction_range attribute. The explicit setting is only a
        // planning hint; it does not modify client attributes or bypass server
        // validation. If the server rejects a target, the normal retry limit
        // stops the build safely.
        int requestedReach = NoteClientConfig.serverReachOverride();
        double effective = requestedReach > 0
                ? Math.max(synchronizedReach, requestedReach)
                : synchronizedReach;
        return Math.max(0.5, Math.min(128.0, effective));
    }

    private static void sendChat(Minecraft client, String message) {
        if (client == null || client.gui == null || message == null || message.isBlank()) return;
        client.gui.hud.getChat().addClientSystemMessage(
                Component.literal("[NoteClient] " + message));
    }

    /**
     * Makes a normal placement hit for an instrument support. If the block below
     * is solid, it clicks that block's top face. If it is air, the hit targets the
     * empty support cell itself, like a client-side AirPlace hit result. The game
     * still sends an ordinary use-item-on interaction and the server validates it.
     */
    private static BlockHitResult supportPlacementHit(LocalPlayer player, BlockPos supportPos) {
        Vec3 eye = player.getEyePosition();
        BlockPos below = supportPos.below();
        if (player.level().getBlockState(below)
                .isFaceSturdy(player.level(), below, Direction.UP)) {
            return new BlockHitResult(topFacePointToward(eye, below), Direction.UP, below, false);
        }

        Vec3 center = Vec3.atCenterOf(supportPos);
        Vec3 towardPlayer = eye.subtract(center);
        Direction face = Direction.getApproximateNearest(towardPlayer.x, towardPlayer.y, towardPlayer.z);
        Vec3 hitLocation = center.add(face.getStepX() * 0.499,
                face.getStepY() * 0.499, face.getStepZ() * 0.499);
        return new BlockHitResult(hitLocation, face, supportPos, false);
    }

    /**
     * Chooses the nearest point on a full block's top face to the player's eyes.
     * This is a precise, server-valid hit vector; the server still applies its own
     * block_interaction_range attribute.
     */
    private static Vec3 topFacePointToward(Vec3 eye, BlockPos pos) {
        double x = Math.max(pos.getX() + 0.001, Math.min(pos.getX() + 0.999, eye.x));
        double z = Math.max(pos.getZ() + 0.001, Math.min(pos.getZ() + 0.999, eye.z));
        return new Vec3(x, pos.getY() + 1.0, z);
    }

    private static Block lookupBlock(String namespacedId) {
        String[] parts = namespacedId.split(":", 2);
        if (parts.length != 2) return Blocks.AIR;
        return BuiltInRegistries.BLOCK.getValue(Identifier.fromNamespaceAndPath(parts[0], parts[1]));
    }

    private enum Phase {
        WAITING_FOR_SURVIVAL, WAITING_FOR_MATERIALS,
        BASE_SUPPORTS, SCAFFOLDS, RAISED_SUPPORTS,
        NOTES, SCAFFOLD_CLEANUP, VERIFYING_NOTES, TUNING, PLAYING, CLEANUP, RETAINED
    }

    private record Offset(int right, int up, int forward,
                          double noteDistance, double supportDistance) {}
    private record PhysicalKey(int instrumentId, int pitch) {}
    private static final class PhysicalNeed {
        private final PhysicalKey key;
        private final Placement representative;
        private int occurrences;
        private int copies = 1;

        private PhysicalNeed(PhysicalKey key, Placement representative) {
            this.key = key;
            this.representative = representative;
        }
    }
    private record Scaffold(BlockPos position, BlockPos below, boolean chainDependent) {}
    private record OwnedBlock(BlockPos position, Block block) {}
    private static final class PendingCleanup {
        private final BlockPos position;
        private final Block expectedBlock;
        private long sentAt;
        private int attempts;
        private PendingCleanup(BlockPos position, Block expectedBlock, long sentAt, int attempts) {
            this.position = position;
            this.expectedBlock = expectedBlock;
            this.sentAt = sentAt;
            this.attempts = attempts;
        }
    }
    private record Request(PlanResult plan, int tempoHundredths, int songLengthTicks) {}
    private record Cell(int index, Block support, String soundName,
                        BlockPos supportPos, BlockPos notePos, int pitch, int nbsKey, boolean raised) {}
    private enum PendingKind { SCAFFOLD, SUPPORT, NOTE }
    private record PendingPlacement(BlockPos position, Block expectedBlock, PendingKind kind,
                                    int operationIndex, long sentAt, long timeoutAt) {}
    private record Grant(int inventorySlot, ItemStack stack) {}

    private static final class PendingTune {
        private final int cellIndex;
        private final int startPitch;
        private final int clicksSent;
        private final long sentAt;

        private PendingTune(int cellIndex, int startPitch, int clicksSent, long sentAt) {
            this.cellIndex = cellIndex;
            this.startPitch = startPitch;
            this.clicksSent = clicksSent;
            this.sentAt = sentAt;
        }
    }

    private static final class Job {
        private final net.minecraft.client.multiplayer.ClientLevel level;
        private final List<Cell> cells;
        private final List<Cell> baseCells;
        private final List<Cell> raisedCells;
        private final List<Scaffold> scaffolds;
        private final List<Offset> relocationOffsets;
        private final BlockPos anchor;
        private final Direction right;
        private final Direction forward;
        private final List<TimedNote> timeline;
        private final int tempoHundredths;
        private final int songLengthTicks;
        private final int total;
        private final int skipped;
        private final int originalSelectedSlot;
        private int workHotbarSlot = TEMP_HOTBAR_SLOT;
        private final boolean buildInCreative;
        private final List<OwnedBlock> createdBlocks = new ArrayList<>();
        private Phase phase = Phase.BASE_SUPPORTS;
        private int scaffoldIndex;
        private int scaffoldCleanupIndex = -1;
        private BlockPos pendingScaffoldRemoval;
        private long pendingScaffoldRemovalSentAt;
        private int pendingScaffoldRemovalRetries;
        private final Set<BlockPos> protectedScaffolds = new HashSet<>();
        private final Map<BlockPos, Integer> supportSyncAttempts = new HashMap<>();
        private int index;
        private int tuneCursor;
        private int tunedCount;
        private final boolean[] tunedCells;
        private final List<PendingTune> pendingTunes = new ArrayList<>();
        private final Map<Integer, Long> tuneRetryAt = new HashMap<>();
        private final Map<Integer, Integer> tuneRetryCounts = new HashMap<>();
        private int adaptiveTuneBatchSize = NoteClientConfig.tuningBatchSize();
        private int adaptiveTuneBudget = NoteClientConfig.tuningActionsPerTick();
        private int quickTuneAcks;
        private int eventIndex;
        private final ArrayDeque<TimedNote> playbackQueue = new ArrayDeque<>();
        private final float playerYaw;
        private final ArrayDeque<OwnedBlock> cleanupQueue = new ArrayDeque<>();
        private final List<OwnedBlock> cleanupDeferred = new ArrayList<>();
        private final List<PendingCleanup> pendingCleanups = new ArrayList<>();
        private final Set<BlockPos> pendingCleanupPositions = new HashSet<>();
        private BlockPos survivalCleanupPosition;
        private Block survivalCleanupExpectedBlock;
        private long survivalCleanupStartedAt = Long.MIN_VALUE;
        private long survivalCleanupConfirmedAt = Long.MIN_VALUE;
        private boolean survivalCleanupAwaitingConfirmation;
        private final Map<BlockPos, Integer> survivalCleanupRetries = new HashMap<>();
        private final Map<BlockPos, Long> survivalCleanupRetryAt = new HashMap<>();
        private int integrityScanCursor;
        private int tuneIntegrityScanCursor;
        private boolean repairOnlyPass;
        private int repairCellIndex = -1;
        private final Set<Integer> repairTuneIndices = new HashSet<>();
        private Phase repairReturnPhase;
        private Phase resumeAfterRepairTuning;
        private long repairStartedAt;
        private long verificationStartedAt;
        private int verificationStableTicks;
        private int placed;
        private int adaptiveBuildActionsPerTick = NoteClientConfig.buildActionsPerTick();
        private int quickPlacementAcks;
        private boolean paused;
        private boolean slotRestored;
        private long pausedAt;
        private long nextActionGameTime;
        private long playbackStart = -1;
        private long lastMessageTime = Long.MIN_VALUE;
        private Request pendingRequest;
        private final List<PendingPlacement> pendingPlacements = new ArrayList<>();
        private final Map<BlockPos, Integer> placementAttempts = new HashMap<>();
        private Cell pendingSupportRecoveryCell;
        private long pendingSupportRecoverySentAt = Long.MIN_VALUE;
        private long pendingSupportRecoveryAirObservedAt = Long.MIN_VALUE;
        private int pendingSupportRecoveryRetries;
        private boolean pendingSupportRecoveryRelocate = true;
        private boolean pendingSupportRecoveryRebuildSupport;
        private String cleanupMessage = "";

        private Job(net.minecraft.client.multiplayer.ClientLevel level, List<Cell> cells,
                    List<Cell> baseCells, List<Cell> raisedCells, List<Scaffold> scaffolds,
                    List<Offset> relocationOffsets, BlockPos anchor, Direction right, Direction forward,
                    List<TimedNote> timeline, int tempoHundredths, int songLengthTicks,
                    int total, int skipped, int originalSelectedSlot,
                    boolean buildInCreative, float playerYaw) {
            this.level = level;
            this.cells = new ArrayList<>(cells);
            this.tunedCells = new boolean[this.cells.size()];
            this.baseCells = new ArrayList<>(baseCells);
            this.raisedCells = new ArrayList<>(raisedCells);
            this.scaffolds = List.copyOf(scaffolds);
            this.relocationOffsets = new ArrayList<>(relocationOffsets);
            this.anchor = anchor.immutable();
            this.right = right;
            this.forward = forward;
            for (Cell cell : cells) {
                if (cell.support instanceof FallingBlock) {
                    this.protectedScaffolds.add(cell.supportPos.below());
                }
            }
            this.timeline = List.copyOf(timeline);
            this.tempoHundredths = tempoHundredths;
            this.songLengthTicks = songLengthTicks;
            this.total = Math.max(1, total);
            this.skipped = Math.max(0, skipped);
            this.originalSelectedSlot = originalSelectedSlot;
            this.buildInCreative = buildInCreative;
            this.playerYaw = playerYaw;
            this.nextActionGameTime = level.getGameTime();
        }

        private void beginCleanup(String message) {
            this.cleanupMessage = message;
            this.phase = Phase.CLEANUP;
            this.cleanupQueue.clear();
            this.cleanupDeferred.clear();
            this.pendingCleanups.clear();
            this.pendingCleanupPositions.clear();
            this.survivalCleanupPosition = null;
            this.survivalCleanupExpectedBlock = null;
            this.survivalCleanupStartedAt = Long.MIN_VALUE;
            this.survivalCleanupConfirmedAt = Long.MIN_VALUE;
            this.survivalCleanupAwaitingConfirmation = false;
            this.survivalCleanupRetries.clear();
            this.survivalCleanupRetryAt.clear();
            for (int i = this.createdBlocks.size() - 1; i >= 0; i--) {
                this.cleanupQueue.addLast(this.createdBlocks.get(i));
            }
            this.pendingSupportRecoveryCell = null;
            this.pendingSupportRecoverySentAt = Long.MIN_VALUE;
            this.pendingSupportRecoveryAirObservedAt = Long.MIN_VALUE;
            this.pendingSupportRecoveryRetries = 0;
            this.pendingSupportRecoveryRelocate = true;
            this.pendingSupportRecoveryRebuildSupport = false;
            this.repairOnlyPass = false;
            this.repairCellIndex = -1;
            this.repairTuneIndices.clear();
            this.repairReturnPhase = null;
            this.resumeAfterRepairTuning = null;
            this.paused = false;
            this.lastMessageTime = Long.MIN_VALUE;
        }
    }
}
