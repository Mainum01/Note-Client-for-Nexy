package dev.noteclient.nbs;

import java.util.List;

/** Immutable representation of the parts of an NBS song needed by the planner/player. */
public record NbsSong(
        int formatVersion,
        int vanillaInstrumentCount,
        int songLengthTicks,
        int layerCount,
        String name,
        String author,
        String originalAuthor,
        String description,
        int tempoHundredths,
        boolean looping,
        int maxLoopCount,
        int loopStartTick,
        List<Layer> layers,
        List<Note> notes
) {
    public NbsSong {
        layers = List.copyOf(layers);
        notes = List.copyOf(notes);
    }

    public Layer layer(int index) {
        if (index >= 0 && index < layers.size()) return layers.get(index);
        return Layer.DEFAULT;
    }

    public double tempoTicksPerSecond() {
        return tempoHundredths / 100.0;
    }

    public double durationSeconds() {
        double tempo = tempoTicksPerSecond();
        if (tempo <= 0) return 0;
        int length = songLengthTicks;
        if (length <= 0 && !notes.isEmpty()) {
            length = notes.stream().mapToInt(Note::tick).max().orElse(0) + 1;
        }
        return length / tempo;
    }

    public record Layer(int volume, int panning) {
        public static final Layer DEFAULT = new Layer(100, 100);

        public Layer {
            volume = Math.max(0, Math.min(100, volume));
            panning = Math.max(0, Math.min(200, panning));
        }
    }

    public record Note(
            int tick,
            int layer,
            int instrumentId,
            int key,
            int velocity,
            int panning,
            int finePitchCents,
            boolean customInstrument
    ) {}
}
