package dev.noteclient.nbs;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Strict reader for classic NBS v0 and modern NBS versions 1 through 6. */
public final class NbsReader {
    private static final int MAX_FILE_BYTES = 128 * 1024 * 1024;
    private static final int MAX_STRING_BYTES = 4 * 1024 * 1024;
    private static final int MAX_NOTES = 2_000_000;
    private static final int MAX_LAYERS = 32_768;

    private NbsReader() {}

    public static NbsSong read(Path path) throws IOException {
        long size = Files.size(path);
        if (size <= 0 || size > MAX_FILE_BYTES) {
            throw new IOException("NBS file size is invalid or exceeds 128 MiB.");
        }
        return read(Files.readAllBytes(path));
    }

    public static NbsSong read(byte[] bytes) throws IOException {
        if (bytes == null || bytes.length < 2 || bytes.length > MAX_FILE_BYTES) {
            throw new IOException("File is empty, truncated, or exceeds 128 MiB.");
        }

        Cursor in = new Cursor(bytes);
        int firstShort = in.u16();
        if (firstShort != 0) {
            return readClassicV0(in, firstShort);
        }
        return readModern(in);
    }

    /**
     * Original Minecraft Note Block Studio format. In v0 the first short is the
     * song length, the second short is the layer count, and there is no version
     * or vanilla-instrument-count byte. The original format has ten built-in
     * instruments and no per-note velocity, panning, or fine-pitch values.
     */
    private static NbsSong readClassicV0(Cursor in, int songLength) throws IOException {
        int layerCount = in.u16();
        checkLayerCount(layerCount);

        String name = in.string();
        String author = in.string();
        String originalAuthor = in.string();
        String description = in.string();
        int tempo = in.u16();
        in.skip(1); // Auto-saving enabled
        in.skip(1); // Auto-saving duration
        in.skip(1); // Time signature
        in.skip(4); // Minutes spent
        in.skip(4); // Left clicks
        in.skip(4); // Right clicks
        in.skip(4); // Blocks added
        in.skip(4); // Blocks removed
        in.string(); // Imported MIDI/schematic filename

        List<NbsSong.Note> notes = readNoteBlocks(in, 10, 0, false);
        List<NbsSong.Layer> layers = parseClassicOptionalTail(in, layerCount);

        return new NbsSong(0, 10, songLength, layerCount, name, author,
                originalAuthor, description, tempo, false, 0, 0, layers, notes);
    }

    /** Reads OpenNBS v1-v6. The first two zero bytes were consumed by read(). */
    private static NbsSong readModern(Cursor in) throws IOException {
        int version = in.u8();
        if (version < 1 || version > 6) {
            throw new IOException("Unsupported NBS version: " + version + " (supported: classic v0 and modern v1-v6).");
        }

        int vanillaInstrumentCount = in.u8();
        if (vanillaInstrumentCount < 1 || vanillaInstrumentCount > 20) {
            throw new IOException("Invalid vanilla instrument count: " + vanillaInstrumentCount);
        }
        int songLength = version >= 3 ? in.u16() : 0;
        int layerCount = in.u16();
        checkLayerCount(layerCount);

        String name = in.string();
        String author = in.string();
        String originalAuthor = in.string();
        String description = in.string();
        int tempo = in.u16();
        in.skip(1); // Auto-saving enabled
        in.skip(1); // Auto-saving duration
        in.skip(1); // Time signature
        in.skip(4); // Minutes spent
        in.skip(4); // Left clicks
        in.skip(4); // Right clicks
        in.skip(4); // Notes added
        in.skip(4); // Notes removed
        in.string(); // Imported MIDI/schematic filename

        boolean looping = false;
        int maxLoopCount = 0;
        int loopStartTick = 0;
        if (version >= 4) {
            looping = in.u8() != 0;
            maxLoopCount = in.u8();
            loopStartTick = in.u16();
        }

        List<NbsSong.Note> notes = readNoteBlocks(in, vanillaInstrumentCount, version, true);
        List<NbsSong.Layer> layers = parseModernOptionalTail(in, layerCount, version);

        return new NbsSong(version, vanillaInstrumentCount, songLength, layerCount,
                name, author, originalAuthor, description, tempo,
                looping, maxLoopCount, loopStartTick, layers, notes);
    }

    private static void checkLayerCount(int layerCount) throws IOException {
        if (layerCount < 0 || layerCount > MAX_LAYERS) {
            throw new IOException("NBS layer count is unreasonably large: " + layerCount);
        }
    }

    private static List<NbsSong.Note> readNoteBlocks(Cursor in, int vanillaInstrumentCount,
                                                       int version, boolean modern) throws IOException {
        List<NbsSong.Note> notes = new ArrayList<>();
        int tick = -1;
        while (true) {
            int tickJump = in.u16();
            if (tickJump == 0) break;
            tick = safeAdd(tick, tickJump, "tick");
            int layer = -1;

            while (true) {
                int layerJump = in.u16();
                if (layerJump == 0) break;
                layer = safeAdd(layer, layerJump, "layer");

                int instrumentId = in.u8();
                int key = in.u8();
                int velocity = 100;
                int panning = 100;
                int finePitch = 0;
                if (modern && version >= 4) {
                    velocity = in.u8();
                    panning = in.u8();
                    finePitch = in.s16();
                }

                if (notes.size() >= MAX_NOTES) {
                    throw new IOException("NBS contains more than " + MAX_NOTES
                            + " notes; refusing to allocate an oversized song.");
                }
                boolean custom = instrumentId >= vanillaInstrumentCount;
                notes.add(new NbsSong.Note(tick, layer, instrumentId, key,
                        velocity, panning, finePitch, custom));
            }
        }
        return notes;
    }

    /**
     * In classic v0 the layer section and custom-instrument section are both
     * optional. Because there is no section marker, try both valid layouts on
     * independent cursors and prefer the documented layer-present layout when
     * both happen to parse completely.
     */
    private static List<NbsSong.Layer> parseClassicOptionalTail(Cursor in, int layerCount) throws IOException {
        Cursor withLayers = in.fork();
        IOException layerError;
        try {
            List<NbsSong.Layer> result = parseTail(withLayers, layerCount, 0, 9);
            in.copyPositionFrom(withLayers);
            return result;
        } catch (IOException exception) {
            layerError = exception;
        }

        Cursor withoutLayers = in.fork();
        try {
            List<NbsSong.Layer> result = parseTail(withoutLayers, 0, 0, 9);
            in.copyPositionFrom(withoutLayers);
            return result;
        } catch (IOException noLayerError) {
            IOException failure = new IOException("Invalid classic NBS v0 layer/custom-instrument section: "
                    + noLayerError.getMessage());
            failure.addSuppressed(layerError);
            throw failure;
        }
    }

    private static List<NbsSong.Layer> parseModernOptionalTail(Cursor in, int layerCount, int version) throws IOException {
        if (in.remaining() == 0) return List.of();
        int maxCustom = version >= 6 ? 236 : version == 5 ? 240 : 18;
        Cursor withLayers = in.fork();
        IOException layerError;
        try {
            List<NbsSong.Layer> result = parseTail(withLayers, layerCount, version, maxCustom);
            in.copyPositionFrom(withLayers);
            return result;
        } catch (IOException exception) {
            layerError = exception;
        }

        Cursor withoutLayers = in.fork();
        try {
            List<NbsSong.Layer> result = parseTail(withoutLayers, 0, version, maxCustom);
            in.copyPositionFrom(withoutLayers);
            return result;
        } catch (IOException noLayerError) {
            IOException failure = new IOException("Invalid modern NBS layer/custom-instrument section: "
                    + noLayerError.getMessage());
            failure.addSuppressed(layerError);
            throw failure;
        }
    }

    /** Parses optional layer records followed by optional custom instruments. */
    private static List<NbsSong.Layer> parseTail(Cursor in, int layerCount, int formatVersion,
                                                  int maxCustomInstruments) throws IOException {
        List<NbsSong.Layer> layers = new ArrayList<>(layerCount);
        for (int layer = 0; layer < layerCount; layer++) {
            in.string(); // Layer name
            if (formatVersion >= 4) in.skip(1); // Layer locked flag
            int volume = in.u8();
            int panning = formatVersion >= 2 ? in.u8() : 100;
            layers.add(new NbsSong.Layer(volume, panning));
        }

        if (in.remaining() > 0) {
            int customCount = in.u8();
            if (customCount > maxCustomInstruments) {
                throw new IOException("Invalid custom instrument count: " + customCount);
            }
            for (int i = 0; i < customCount; i++) {
                in.string(); // Instrument name
                in.string(); // Sound filename/path
                in.skip(1);  // Sound key
                in.skip(1);  // Press piano key
            }
        }

        if (in.remaining() != 0) {
            throw new IOException("Unexpected " + in.remaining() + " trailing byte(s) after NBS metadata.");
        }
        return List.copyOf(layers);
    }

    private static int safeAdd(int a, int b, String field) throws IOException {
        long value = (long) a + b;
        if (value > Integer.MAX_VALUE) throw new IOException("NBS " + field + " overflow.");
        return (int) value;
    }

    private static final class Cursor {
        private final byte[] bytes;
        private final ByteBuffer data;

        private Cursor(byte[] bytes) {
            this.bytes = bytes;
            data = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        }

        int remaining() { return data.remaining(); }

        Cursor fork() {
            Cursor copy = new Cursor(bytes);
            copy.data.position(data.position());
            return copy;
        }

        void copyPositionFrom(Cursor other) {
            data.position(other.data.position());
        }

        int u8() throws IOException {
            require(1);
            return data.get() & 0xFF;
        }

        int u16() throws IOException {
            require(2);
            return data.getShort() & 0xFFFF;
        }

        int s16() throws IOException {
            require(2);
            return data.getShort();
        }

        int s32() throws IOException {
            require(4);
            return data.getInt();
        }

        String string() throws IOException {
            int length = s32();
            if (length < 0 || length > MAX_STRING_BYTES) {
                throw new IOException("Invalid NBS string length: " + length);
            }
            require(length);
            byte[] value = new byte[length];
            data.get(value);
            return new String(value, StandardCharsets.UTF_8);
        }

        void skip(int amount) throws IOException {
            if (amount < 0) throw new IOException("Invalid NBS skip length.");
            require(amount);
            data.position(data.position() + amount);
        }

        private void require(int amount) throws IOException {
            if (data.remaining() < amount) {
                throw new IOException("NBS file ended unexpectedly at byte " + data.position() + ".");
            }
        }
    }
}
