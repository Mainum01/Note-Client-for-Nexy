package dev.noteclient.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Owner-only control request for a running NoteClient build or song job. */
public record BuildControlPayload(int action) implements CustomPacketPayload {
    public static final int TOGGLE_PAUSE = 0;
    public static final int CANCEL = 1;
    public static final int DESTROY = 2;

    public static final Identifier ID = Identifier.fromNamespaceAndPath("noteclient", "build_control_v2");
    public static final Type<BuildControlPayload> TYPE = new Type<>(ID);
    public static final StreamCodec<RegistryFriendlyByteBuf, BuildControlPayload> CODEC = StreamCodec.of(
            BuildControlPayload::encode, BuildControlPayload::decode
    );

    public BuildControlPayload {
        if (action != TOGGLE_PAUSE && action != CANCEL && action != DESTROY) {
            throw new IllegalArgumentException("Unknown NoteClient build control action: " + action);
        }
    }

    private static void encode(RegistryFriendlyByteBuf buffer, BuildControlPayload payload) {
        buffer.writeVarInt(payload.action);
    }

    private static BuildControlPayload decode(RegistryFriendlyByteBuf buffer) {
        return new BuildControlPayload(buffer.readVarInt());
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
