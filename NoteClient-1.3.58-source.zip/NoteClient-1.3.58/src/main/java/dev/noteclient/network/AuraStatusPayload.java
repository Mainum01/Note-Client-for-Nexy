package dev.noteclient.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Server acknowledgement for the server-visible Aura request. */
public record AuraStatusPayload(boolean active, String message) implements CustomPacketPayload {
    public static final Identifier ID = Identifier.fromNamespaceAndPath("noteclient", "aura_status_v1");
    public static final Type<AuraStatusPayload> TYPE = new Type<>(ID);
    public static final StreamCodec<RegistryFriendlyByteBuf, AuraStatusPayload> CODEC =
            StreamCodec.of(AuraStatusPayload::encode, AuraStatusPayload::decode);

    public AuraStatusPayload {
        message = message == null ? "" : message;
        if (message.length() > 240) message = message.substring(0, 240);
    }

    private static void encode(RegistryFriendlyByteBuf buffer, AuraStatusPayload payload) {
        buffer.writeBoolean(payload.active);
        buffer.writeUtf(payload.message, 240);
    }

    private static AuraStatusPayload decode(RegistryFriendlyByteBuf buffer) {
        return new AuraStatusPayload(buffer.readBoolean(), buffer.readUtf(240));
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
