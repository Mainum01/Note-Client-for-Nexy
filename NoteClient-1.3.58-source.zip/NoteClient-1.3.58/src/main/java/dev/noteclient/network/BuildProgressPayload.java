package dev.noteclient.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Server-to-client status for the builder, playback, pause, and cleanup job. */
public record BuildProgressPayload(
        int placed,
        int total,
        int skippedSlots,
        int layer,
        boolean finished,
        boolean paused,
        String message
) implements CustomPacketPayload {
    public static final Identifier ID = Identifier.fromNamespaceAndPath("noteclient", "build_progress");
    public static final Type<BuildProgressPayload> TYPE = new Type<>(ID);
    public static final StreamCodec<RegistryFriendlyByteBuf, BuildProgressPayload> CODEC = StreamCodec.of(
            BuildProgressPayload::encode, BuildProgressPayload::decode
    );

    public BuildProgressPayload {
        message = message == null ? "" : message;
        if (message.length() > 240) message = message.substring(0, 240);
    }

    private static void encode(RegistryFriendlyByteBuf buffer, BuildProgressPayload payload) {
        buffer.writeVarInt(payload.placed);
        buffer.writeVarInt(payload.total);
        buffer.writeVarInt(payload.skippedSlots);
        buffer.writeVarInt(payload.layer);
        buffer.writeBoolean(payload.finished);
        buffer.writeBoolean(payload.paused);
        buffer.writeUtf(payload.message, 240);
    }

    private static BuildProgressPayload decode(RegistryFriendlyByteBuf buffer) {
        return new BuildProgressPayload(
                buffer.readVarInt(),
                buffer.readVarInt(),
                buffer.readVarInt(),
                buffer.readVarInt(),
                buffer.readBoolean(),
                buffer.readBoolean(),
                buffer.readUtf(240)
        );
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
