package dev.noteclient.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** A request to start or stop the server-authoritative world-block Aura. */
public record AuraControlPayload(boolean enabled) implements CustomPacketPayload {
    public static final Identifier ID = Identifier.fromNamespaceAndPath("noteclient", "aura_control_v1");
    public static final Type<AuraControlPayload> TYPE = new Type<>(ID);
    public static final StreamCodec<RegistryFriendlyByteBuf, AuraControlPayload> CODEC =
            StreamCodec.of(AuraControlPayload::encode, AuraControlPayload::decode);

    private static void encode(RegistryFriendlyByteBuf buffer, AuraControlPayload payload) {
        buffer.writeBoolean(payload.enabled);
    }

    private static AuraControlPayload decode(RegistryFriendlyByteBuf buffer) {
        return new AuraControlPayload(buffer.readBoolean());
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
