package dev.noteclient.plan;

import dev.noteclient.nbs.NbsSong;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Exports a deterministic CSV placement list and a per-note event timeline. */
public final class PlanExporter {
    private PlanExporter() {}

    public static Path writeLayout(Path songPath, NoteBlockPlanner.PlanResult plan) throws IOException {
        Path output = outputPath(songPath, plan.fallback() ? "-universal-grid.csv" : "-notebot-layout.csv");
        try (BufferedWriter writer = Files.newBufferedWriter(output, StandardCharsets.UTF_8)) {
            writer.write("kind,instrument_id,instrument,nbs_key,note_block_pitch,copy_index,copies_required,total_song_occurrences,x,y,z,block_state\n");
            for (NoteBlockPlanner.Placement p : plan.placements()) {
                String instrumentState = NoteBlockPlanner.instruments().get(p.instrumentId()).noteBlockInstrument();
                String noteState = "minecraft:note_block[instrument=" + instrumentState
                        + ",note=" + p.noteBlockPitch() + ",powered=false]";
                // Owner Mode writes the complete note-block blockstate directly. It
                // does not require physical support blocks or pitch-click interactions.
                writer.write(row("floating_note_block", p, p.noteX(), p.noteY(), p.noteZ(), noteState));
            }
        }
        return output;
    }

    public static Path writeTimeline(Path songPath, NbsSong song) throws IOException {
        Path output = outputPath(songPath, "-notebot-timeline.csv");
        try (BufferedWriter writer = Files.newBufferedWriter(output, StandardCharsets.UTF_8)) {
            writer.write("tick,layer,instrument_id,custom_instrument,nbs_key,native_pitch_level,octave_folded,velocity,panning,fine_pitch_cents,layer_volume,layer_panning,effective_volume,effective_panning\n");
            for (NbsSong.Note note : song.notes()) {
                int pitch = NoteBlockPlanner.nativePitchLevelForKey(note.key());
                writer.write(note.tick() + "," + note.layer() + "," + note.instrumentId() + ","
                        + note.customInstrument() + "," + note.key() + "," + pitch + ","
                        + NoteBlockPlanner.requiresOctaveFolding(note.key()) + ","
                        + note.velocity() + "," + note.panning() + "," + note.finePitchCents() + ","
                        + song.layer(note.layer()).volume() + "," + song.layer(note.layer()).panning() + ","
                        + ((note.velocity() * song.layer(note.layer()).volume()) / 100) + ","
                        + (song.layer(note.layer()).panning() == 100 ? note.panning()
                        : (song.layer(note.layer()).panning() + note.panning()) / 2) + "\n");
            }
        }
        return output;
    }

    private static String row(String kind, NoteBlockPlanner.Placement p,
                              int x, int y, int z, String state) {
        return kind + "," + p.instrumentId() + ",\"" + csv(p.instrumentName()) + "\","
                + p.nbsKey() + "," + p.noteBlockPitch() + "," + p.copyIndex() + ","
                + p.copiesRequired() + "," + p.totalSongOccurrences() + ","
                + x + "," + y + "," + z + "," + state + "\n";
    }

    private static String csv(String value) {
        return value.replace("\"", "\"\"");
    }

    private static Path outputPath(Path songPath, String suffix) {
        String name = songPath.getFileName().toString();
        int dot = name.lastIndexOf('.');
        if (dot > 0) name = name.substring(0, dot);
        return songPath.resolveSibling(name + suffix);
    }
}
