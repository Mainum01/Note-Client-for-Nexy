package dev.noteclient.plan;

import dev.noteclient.nbs.NbsSong;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Builds a circular instrument/pitch array and maps every playable NBS event to a slot. */
public final class NoteBlockPlanner {
    public static final int BUILT_IN_INSTRUMENTS = 20;
    public static final int NOTE_LEVELS = 25;
    public static final int FIRST_NATIVE_NBS_KEY = 33;
    public static final int LAST_NATIVE_NBS_KEY = 57;
    private static final int INNER_RING_RADIUS = 2;

    private static final List<Instrument> INSTRUMENTS = List.of(
            new Instrument(0, "Harp / Piano", "minecraft:coarse_dirt", "harp"),
            new Instrument(1, "Bass", "minecraft:oak_planks", "bass"),
            new Instrument(2, "Basedrum", "minecraft:stone", "basedrum"),
            new Instrument(3, "Snare", "minecraft:sand", "snare"),
            new Instrument(4, "Hat / Click", "minecraft:glass", "hat"),
            new Instrument(5, "Guitar", "minecraft:white_wool", "guitar"),
            new Instrument(6, "Flute", "minecraft:clay", "flute"),
            new Instrument(7, "Bell", "minecraft:gold_block", "bell"),
            new Instrument(8, "Chime", "minecraft:packed_ice", "chime"),
            new Instrument(9, "Xylophone", "minecraft:bone_block", "xylophone"),
            new Instrument(10, "Iron Xylophone", "minecraft:iron_block", "iron_xylophone"),
            new Instrument(11, "Cow Bell", "minecraft:soul_sand", "cow_bell"),
            new Instrument(12, "Didgeridoo", "minecraft:pumpkin", "didgeridoo"),
            new Instrument(13, "Bit", "minecraft:emerald_block", "bit"),
            new Instrument(14, "Banjo", "minecraft:hay_block", "banjo"),
            new Instrument(15, "Pling", "minecraft:glowstone", "pling"),
            new Instrument(16, "Trumpet", "minecraft:copper_block", "trumpet"),
            new Instrument(17, "Exposed Trumpet", "minecraft:exposed_copper", "trumpet_exposed"),
            new Instrument(18, "Weathered Trumpet", "minecraft:weathered_copper", "trumpet_weathered"),
            new Instrument(19, "Oxidized Trumpet", "minecraft:oxidized_copper", "trumpet_oxidized")
    );

    private NoteBlockPlanner() {}

    public static List<Instrument> instruments() {
        return INSTRUMENTS;
    }

    /**
     * Returns the physical 0..24 note-block pitch for an NBS key. NBS supports
     * keys 0..87, while vanilla note blocks expose only keys 33..57. For an
     * out-of-range but valid NBS key, fold by octaves while preserving pitch
     * class. Local playback retains the original key for the exact octave.
     */
    public static int nativePitchLevelForKey(int nbsKey) {
        if (nbsKey < 0 || nbsKey > 87) return -1;
        int folded = nbsKey;
        while (folded < FIRST_NATIVE_NBS_KEY) folded += 12;
        while (folded > LAST_NATIVE_NBS_KEY) folded -= 12;
        return folded - FIRST_NATIVE_NBS_KEY;
    }

    public static boolean requiresOctaveFolding(int nbsKey) {
        return nbsKey >= 0 && nbsKey <= 87
                && (nbsKey < FIRST_NATIVE_NBS_KEY || nbsKey > LAST_NATIVE_NBS_KEY);
    }

    public static PlanResult planSong(NbsSong song) {
        Map<Pair, Map<Integer, Integer>> simultaneousCounts = new HashMap<>();
        Map<Pair, Integer> occurrences = new HashMap<>();
        Map<Pair, Map<Integer, Integer>> assignedCopies = new HashMap<>();
        List<PendingNote> pendingNotes = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        int skipped = 0;
        int octaveFoldedNotes = 0;
        int finePitchNotes = 0;
        int expressiveNotes = 0;
        int approximatedInstruments = 0;

        for (NbsSong.Note note : song.notes()) {
            if (nativePitchLevelForKey(note.key()) < 0) {
                skipped++;
                continue;
            }

            // NBS custom instruments are sample files, not note-block instruments.
            // Keep their events instead of dropping them: ordinary vanilla mode
            // approximates an unsupported sample with the harp while preserving
            // its original key, timing, velocity, and pan in the event timeline.
            int instrumentId = note.instrumentId();
            boolean unsupportedInstrument = note.customInstrument() || instrumentId < 0
                    || instrumentId >= BUILT_IN_INSTRUMENTS
                    || instrumentId >= song.vanillaInstrumentCount();
            if (unsupportedInstrument) {
                instrumentId = 0;
                approximatedInstruments++;
            }

            if (requiresOctaveFolding(note.key())) octaveFoldedNotes++;
            Pair pair = new Pair(instrumentId, note.key());
            simultaneousCounts.computeIfAbsent(pair, ignored -> new HashMap<>())
                    .merge(note.tick(), 1, Integer::sum);
            occurrences.merge(pair, 1, Integer::sum);

            Map<Integer, Integer> byTick = assignedCopies.computeIfAbsent(pair, ignored -> new HashMap<>());
            int copyIndex = byTick.getOrDefault(note.tick(), 0);
            byTick.put(note.tick(), copyIndex + 1);
            NbsSong.Layer layer = song.layer(note.layer());
            int effectiveVolume = Math.max(0, Math.min(100,
                    (note.velocity() * layer.volume()) / 100));
            int effectivePanning = layer.panning() == 100
                    ? note.panning()
                    : (layer.panning() + note.panning()) / 2;
            effectivePanning = Math.max(0, Math.min(200, effectivePanning));
            int finePitchCents = Math.max(-1200, Math.min(1200, note.finePitchCents()));
            pendingNotes.add(new PendingNote(note.tick(), pair, copyIndex,
                    effectiveVolume, effectivePanning, finePitchCents));

            if (finePitchCents != 0) finePitchNotes++;
            if (effectiveVolume != 100 || effectivePanning != 100) expressiveNotes++;
        }

        if (skipped > 0) {
            warnings.add(skipped + " note event(s) could not be mapped because their NBS keys were outside the supported 0..87 range.");
        }
        if (approximatedInstruments > 0) {
            warnings.add(approximatedInstruments + " custom/unsupported instrument event(s) are mapped to the vanilla harp so the notes remain playable instead of being discarded. The original NBS instrument sound cannot be reproduced by a physical vanilla note block.");
        }
        if (octaveFoldedNotes > 0) {
            warnings.add(0, octaveFoldedNotes + " note event(s) are outside vanilla's 25-pitch range. The physical note blocks use the nearest matching pitch class (octave-folded); local playback uses the original NBS octave. On a NoteClient-enabled server, other players hear the physical octave-folded note.");
        }
        if (finePitchNotes > 0) {
            warnings.add(finePitchNotes + " event(s) use fine detuning. The optional server companion preserves cents; ordinary vanilla note blocks can only play semitone steps.");
        }
        if (expressiveNotes > 0) {
            warnings.add(expressiveNotes + " event(s) use layer/note volume or stereo panning. The optional server companion preserves these mix settings; ordinary vanilla block attacks cannot.");
        }

        List<PairNeed> needs = new ArrayList<>();
        for (Map.Entry<Pair, Map<Integer, Integer>> entry : simultaneousCounts.entrySet()) {
            int copies = entry.getValue().values().stream().mapToInt(Integer::intValue).max().orElse(1);
            Pair pair = entry.getKey();
            needs.add(new PairNeed(pair, copies, occurrences.getOrDefault(pair, 0)));
        }
        // Put frequently-used instrument/pitch pairs first. The vanilla client
        // builder later packs these unique physical pitches into the full reachable
        // lower + elevated layout around the player.
        needs.sort(Comparator.comparingInt(PairNeed::occurrences).reversed()
                .thenComparingInt(need -> need.pair.instrumentId)
                .thenComparingInt(need -> need.pair.key));

        int slotCount = needs.stream().mapToInt(PairNeed::copies).sum();
        List<Offset> offsets = sphericalOffsets(slotCount);
        List<Placement> placements = new ArrayList<>(slotCount);
        Map<Pair, int[]> slotIndexes = new HashMap<>();

        for (PairNeed need : needs) {
            Instrument instrument = INSTRUMENTS.get(need.pair.instrumentId);
            int pitchLevel = nativePitchLevelForKey(need.pair.key);
            int[] slots = new int[need.copies];
            for (int copy = 0; copy < need.copies; copy++) {
                Offset offset = offsets.get(placements.size());
                slots[copy] = placements.size();
                placements.add(new Placement(
                        need.pair.instrumentId, instrument.name, need.pair.key, pitchLevel,
                        need.copies, copy, need.occurrences, instrument.supportBlock,
                        offset.x, offset.y, offset.z,
                        offset.x, offset.y + 1, offset.z
                ));
            }
            slotIndexes.put(need.pair, slots);
        }

        List<TimedNote> timeline = new ArrayList<>(pendingNotes.size());
        for (PendingNote pending : pendingNotes) {
            int[] slots = slotIndexes.get(pending.pair);
            if (slots != null && pending.copyIndex < slots.length) {
                timeline.add(new TimedNote(pending.tick, slots[pending.copyIndex],
                        pending.volume, pending.panning, pending.finePitchCents, pending.pair.key));
            }
        }
        timeline.sort(Comparator.comparingInt(TimedNote::tick));

        int outerRadius = 0;
        if (!offsets.isEmpty()) {
            int farthestSquared = offsets.stream()
                    .mapToInt(offset -> offset.x * offset.x + offset.z * offset.z)
                    .max().orElse(0);
            outerRadius = (int) Math.ceil(Math.sqrt(farthestSquared));
        }
        warnings.add("Owner Mode uses the floating 3D reference dome. Ordinary-server mode uses a compact player-centered vertical dome built from the ground ring upward.");
        return new PlanResult(false, song.notes().size(), skipped, placements, timeline, warnings,
                needs.size(), outerRadius, NOTE_LEVELS);
    }

    /** Full 20 × 25 reference array. It has no timeline because the source song was not parseable. */
    public static PlanResult universalGrid(String reason) {
        int count = BUILT_IN_INSTRUMENTS * NOTE_LEVELS;
        List<Offset> offsets = sphericalOffsets(count);
        List<Placement> placements = new ArrayList<>(count);
        for (Instrument instrument : INSTRUMENTS) {
            for (int pitch = 0; pitch < NOTE_LEVELS; pitch++) {
                Offset offset = offsets.get(placements.size());
                placements.add(new Placement(
                        instrument.id, instrument.name, FIRST_NATIVE_NBS_KEY + pitch, pitch,
                        1, 0, 0, instrument.supportBlock,
                        offset.x, offset.y, offset.z, offset.x, offset.y + 1, offset.z
                ));
            }
        }
        List<String> warnings = new ArrayList<>();
        warnings.add("UNIVERSAL FALLBACK GRID: " + reason);
        warnings.add("Covers all 20 built-in instruments × all 25 vanilla note-block pitch levels. Playback is unavailable because this source file could not be parsed.");
        warnings.add("Owner Mode uses the floating 3D reference dome. Ordinary-server mode uses a compact player-centered vertical dome built from the ground ring upward.");
        int farthestSquared = offsets.stream()
                .mapToInt(offset -> offset.x * offset.x + offset.z * offset.z)
                .max().orElse(0);
        int outerRadius = (int) Math.ceil(Math.sqrt(farthestSquared));
        return new PlanResult(true, 0, 0, placements, List.of(), warnings,
                count, outerRadius, NOTE_LEVELS);
    }

    /**
     * Builds a rising spherical-dome layout. It first uses a compact inner shell,
     * then increases the horizontal radius as more unique columns are required.
     * Each x/z column is unique; y rises toward the inner portion of the dome.
     */
    private static List<Offset> sphericalOffsets(int count) {
        if (count <= 0) return List.of();

        int maxDistanceSquared = 17; // Initial shell: 52 flat columns; expand for larger songs.
        List<FlatOffset> flat = new ArrayList<>();
        while (maxDistanceSquared <= MAX_LAYOUT_RADIUS_SQUARED) {
            flat.clear();
            int bound = (int) Math.ceil(Math.sqrt(maxDistanceSquared));
            for (int x = -bound; x <= bound; x++) {
                for (int z = -bound; z <= bound; z++) {
                    int distanceSquared = x * x + z * z;
                    if (distanceSquared < 2 || distanceSquared > maxDistanceSquared) continue;
                    flat.add(new FlatOffset(x, z, distanceSquared));
                }
            }
            if (flat.size() >= count) break;
            maxDistanceSquared++;
        }
        if (flat.size() < count) {
            throw new IllegalArgumentException("Could not generate enough spherical layout positions.");
        }

        flat.sort(Comparator.comparingInt(FlatOffset::distanceSquared)
                .thenComparingDouble(offset -> Math.atan2(offset.x, offset.z)));
        int maxHeight = Math.max(3, Math.min(64,
                (int) Math.round(Math.sqrt(maxDistanceSquared) * 0.73)));
        List<Offset> result = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            FlatOffset offset = flat.get(i);
            double normalized = (maxDistanceSquared - offset.distanceSquared)
                    / (double) Math.max(1, maxDistanceSquared - 2);
            int y = (int) Math.round(maxHeight * Math.sqrt(Math.max(0.0, normalized)));
            result.add(new Offset(offset.x, y, offset.z));
        }
        return result;
    }

    private static final int MAX_LAYOUT_RADIUS_SQUARED = 128 * 128;

    public record Instrument(int id, String name, String supportBlock, String noteBlockInstrument) {}
    /** Complete NBS playback event, including note+layer mix settings. */
    public record TimedNote(int tick, int cellIndex, int volume, int panning,
                            int finePitchCents, int sourceKey) {
        public TimedNote {
            volume = Math.max(0, Math.min(100, volume));
            panning = Math.max(0, Math.min(200, panning));
            finePitchCents = Math.max(-1200, Math.min(1200, finePitchCents));
            sourceKey = Math.max(-1, Math.min(87, sourceKey));
        }

        /** Compatibility constructor for code that creates a note without source-key metadata. */
        public TimedNote(int tick, int cellIndex, int volume, int panning, int finePitchCents) {
            this(tick, cellIndex, volume, panning, finePitchCents, -1);
        }
    }
    public record Placement(
            int instrumentId, String instrumentName, int nbsKey, int noteBlockPitch,
            int copiesRequired, int copyIndex, int totalSongOccurrences, String supportBlock,
            int supportX, int supportY, int supportZ,
            int noteX, int noteY, int noteZ
    ) {}
    public record PlanResult(
            boolean fallback, int totalNoteEvents, int skippedNoteEvents,
            List<Placement> placements, List<TimedNote> timeline, List<String> warnings,
            int distinctInstrumentPitchPairs, int depth, int width
    ) {
        public PlanResult {
            placements = List.copyOf(placements);
            timeline = List.copyOf(timeline);
            warnings = List.copyOf(warnings);
        }
        public int totalBlockCount() { return placements.size(); }
    }

    private record Pair(int instrumentId, int key) {}
    private record PairNeed(Pair pair, int copies, int occurrences) {}
    private record PendingNote(int tick, Pair pair, int copyIndex,
                               int volume, int panning, int finePitchCents) {}
    private record FlatOffset(int x, int z, int distanceSquared) {}
    private record Offset(int x, int y, int z) {}
}
