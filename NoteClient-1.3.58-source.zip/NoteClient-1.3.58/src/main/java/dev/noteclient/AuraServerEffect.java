package dev.noteclient;

import dev.noteclient.network.AuraStatusPayload;
import dev.noteclient.server.NoteClientServerConfig;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Owner-authorized server-side Aura. It animates real temporary world blocks,
 * so normal server block updates make the effect visible to nearby players.
 * Only air is replaced; cleanup removes only exact states placed by this Aura.
 */
public final class AuraServerEffect {
    private static final int POINTS_PER_RING = 40;
    private static final double RADIUS = 4.35;
    private static final double CENTER_HEIGHT = 2.3;
    private static final Map<UUID, AuraJob> ACTIVE = new LinkedHashMap<>();

    private static final List<Ring> RINGS = List.of(
            new Ring(new Vector3(0, 1, 0), new Vector3(1, 0, 0), 0.145, 0.2),
            new Ring(new Vector3(1, 0, 0), new Vector3(0, 0, 1), -0.121, 1.1),
            new Ring(new Vector3(0, 0, 1), new Vector3(0, 1, 0), 0.167, 2.0),
            new Ring(new Vector3(1, 1, 0), new Vector3(0, 0, 1), -0.103, 2.8),
            new Ring(new Vector3(0, 1, 1), new Vector3(1, 0, 0), 0.132, 3.7),
            new Ring(new Vector3(1, 0, 1), new Vector3(0, 1, 0), -0.154, 4.6)
    );

    private static final List<BlockState> PALETTE = List.of(
            Blocks.STAINED_GLASS.pick(DyeColor.WHITE).defaultBlockState(),
            Blocks.STAINED_GLASS.pick(DyeColor.LIGHT_BLUE).defaultBlockState(),
            Blocks.STAINED_GLASS.pick(DyeColor.CYAN).defaultBlockState(),
            Blocks.STAINED_GLASS.pick(DyeColor.BLUE).defaultBlockState(),
            Blocks.PACKED_ICE.defaultBlockState(),
            Blocks.BLUE_ICE.defaultBlockState(),
            Blocks.CALCITE.defaultBlockState(),
            Blocks.PRISMARINE.defaultBlockState(),
            Blocks.AMETHYST_BLOCK.defaultBlockState(),
            Blocks.SEA_LANTERN.defaultBlockState()
    );

    private AuraServerEffect() {}

    public static void handleRequest(ServerPlayer player, boolean enabled, NoteClientServerConfig config) {
        if (player == null) return;
        if (!enabled) {
            stop(player.getUUID());
            send(player, false, "Server Aura disabled. Its temporary blocks were cleaned up.");
            return;
        }

        MinecraftServer server = player.level().getServer();
        if (!config.allowServerAura) {
            send(player, false, "Server Aura is disabled by the server owner. Set allowServerAura=true in noteclient-server.properties.");
            return;
        }
        if (server == null || (config.serverAuraRequiresOp && !server.isSingleplayer()
                && !server.getPlayerList().isOp(player.nameAndId()))) {
            send(player, false, "Server Aura denied. Operator permission is required by server configuration.");
            return;
        }
        if (ACTIVE.containsKey(player.getUUID())) {
            send(player, true, "Server Aura is already active. Nearby players can see its moving block rings.");
            return;
        }
        if (ACTIVE.size() >= config.maxActiveAuras) {
            send(player, false, "Server Aura limit reached. The server currently allows " + config.maxActiveAuras + " active Aura(s).");
            return;
        }

        ServerLevel level = (ServerLevel) player.level();
        AuraJob job = new AuraJob(level, level.getGameTime());
        ACTIVE.put(player.getUUID(), job);
        updateFrame(player, job, config.maxAuraBlocks);
        send(player, true, "Server Aura enabled. Its real temporary block rings are visible to nearby players.");
    }

    public static void tick(MinecraftServer server, NoteClientServerConfig config) {
        if (ACTIVE.isEmpty()) return;
        List<UUID> remove = new ArrayList<>();
        for (Map.Entry<UUID, AuraJob> entry : new ArrayList<>(ACTIVE.entrySet())) {
            ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
            AuraJob job = entry.getValue();
            if (player == null || player.isRemoved() || !player.isAlive()) {
                clearFrame(job);
                remove.add(entry.getKey());
                continue;
            }
            ServerLevel currentLevel = player.level();
            if (currentLevel != job.level) {
                clearFrame(job);
                job.level = currentLevel;
                job.frame = 0;
                job.lastUpdate = currentLevel.getGameTime();
            }

            long now = currentLevel.getGameTime();
            if (now - job.lastUpdate < config.auraUpdateIntervalTicks) continue;
            job.lastUpdate = now;
            job.frame++;
            updateFrame(player, job, config.maxAuraBlocks);
        }
        for (UUID id : remove) ACTIVE.remove(id);
    }

    public static void stopAll() {
        for (AuraJob job : new ArrayList<>(ACTIVE.values())) clearFrame(job);
        ACTIVE.clear();
    }

    private static void stop(UUID id) {
        AuraJob job = ACTIVE.remove(id);
        if (job != null) clearFrame(job);
    }

    private static void updateFrame(ServerPlayer player, AuraJob job, int maxBlocks) {
        clearFrame(job);
        ServerLevel level = job.level;
        double centerX = player.getX();
        double centerY = player.getY() + CENTER_HEIGHT;
        double centerZ = player.getZ();
        Map<BlockPos, BlockState> next = new LinkedHashMap<>();

        for (int ringIndex = 0; ringIndex < RINGS.size(); ringIndex++) {
            Ring ring = RINGS.get(ringIndex);
            double phase = job.frame * ring.speed;
            Vector3 normal = rotate(ring.normal.normalized(), ring.axis.normalized(), phase).normalized();
            Vector3 reference = Math.abs(normal.y) > 0.92
                    ? new Vector3(0, 0, 1) : new Vector3(0, 1, 0);
            Vector3 u = normal.cross(reference).normalized();
            Vector3 v = normal.cross(u).normalized();

            for (int sample = 0; sample < POINTS_PER_RING; sample++) {
                double angle = Math.PI * 2.0 * sample / POINTS_PER_RING;
                double radialWave = Math.sin(angle * 2.0 + phase + ring.offset) * 0.58
                        + Math.cos(angle * 3.0 - phase * 1.55 + ring.offset) * 0.30;
                double normalWave = Math.sin(angle * 2.0 - phase * 1.25 + ring.offset) * 0.72;
                double radius = RADIUS + radialWave;
                Vector3 offset = u.scale(Math.cos(angle) * radius)
                        .add(v.scale(Math.sin(angle) * radius))
                        .add(normal.scale(normalWave));
                BlockPos pos = new BlockPos((int) Math.round(centerX + offset.x),
                        (int) Math.round(centerY + offset.y),
                        (int) Math.round(centerZ + offset.z));
                next.putIfAbsent(pos, blockFor(ringIndex, sample, phase));
                if (next.size() >= maxBlocks) break;
            }
            if (next.size() >= maxBlocks) break;
        }

        for (Map.Entry<BlockPos, BlockState> entry : next.entrySet()) {
            BlockPos pos = entry.getKey();
            if (!level.hasChunkAt(pos) || level.isOutsideBuildHeight(pos)
                    || !level.getWorldBorder().isWithinBounds(pos)
                    || !level.getBlockState(pos).isAir()) continue;
            if (level.setBlock(pos, entry.getValue(), 3)) {
                job.placed.put(pos.immutable(), entry.getValue());
            }
        }
    }

    private static BlockState blockFor(int ring, int sample, double phase) {
        int streak = Math.floorMod(sample + ring * 7 + (int) Math.floor(phase * 5.0), 17);
        if (streak == 0 || streak == 1) return Blocks.SEA_LANTERN.defaultBlockState();
        int index = Math.floorMod(sample / 3 + ring * 2 + (int) Math.floor(phase * 2.0), PALETTE.size());
        return PALETTE.get(index);
    }

    private static void clearFrame(AuraJob job) {
        for (Map.Entry<BlockPos, BlockState> entry : new ArrayList<>(job.placed.entrySet())) {
            try {
                BlockPos pos = entry.getKey();
                if (job.level.hasChunkAt(pos) && job.level.getBlockState(pos).equals(entry.getValue())) {
                    job.level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                }
            } catch (Throwable ignored) {
                // Chunk unload or shutdown: never replace a changed block.
            }
        }
        job.placed.clear();
    }

    /** Rodrigues axis-angle rotation used to tilt each ring independently. */
    private static Vector3 rotate(Vector3 vector, Vector3 axis, double radians) {
        Vector3 unitAxis = axis.normalized();
        double cosine = Math.cos(radians);
        double sine = Math.sin(radians);
        return vector.scale(cosine)
                .add(unitAxis.cross(vector).scale(sine))
                .add(unitAxis.scale(unitAxis.dot(vector) * (1.0 - cosine)));
    }

    private static void send(ServerPlayer player, boolean active, String message) {
        ServerPlayNetworking.send(player, new AuraStatusPayload(active, message));
    }

    private record Ring(Vector3 normal, Vector3 axis, double speed, double offset) {}

    private static final class AuraJob {
        private ServerLevel level;
        private final Map<BlockPos, BlockState> placed = new LinkedHashMap<>();
        private long lastUpdate;
        private int frame;

        private AuraJob(ServerLevel level, long now) {
            this.level = level;
            this.lastUpdate = now;
        }
    }

    private record Vector3(double x, double y, double z) {
        private Vector3 add(Vector3 other) { return new Vector3(x + other.x, y + other.y, z + other.z); }
        private Vector3 scale(double factor) { return new Vector3(x * factor, y * factor, z * factor); }
        private double dot(Vector3 other) { return x * other.x + y * other.y + z * other.z; }
        private Vector3 cross(Vector3 other) {
            return new Vector3(y * other.z - z * other.y,
                    z * other.x - x * other.z, x * other.y - y * other.x);
        }
        private Vector3 normalized() {
            double length = Math.sqrt(dot(this));
            return length < 1.0E-9 ? new Vector3(0, 1, 0) : scale(1.0 / length);
        }
    }
}
