package dev.noteclient.voxel.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Compact editable voxel model. paletteIndex==0 means empty; non-zero values
 * are 1-based indexes into the palette. Each occupied cell also stores a layer
 * index so base skin, hat, jacket, sleeves, pants and custom accessories can
 * be isolated independently.
 */
public final class VoxelModel {
    public record PaletteEntry(String blockId, int argb) {
        public PaletteEntry {
            Objects.requireNonNull(blockId, "blockId");
            if (blockId.isBlank() || blockId.length() > VoxelStudioConfig.MAX_BLOCK_ID_LENGTH) {
                throw new IllegalArgumentException("Invalid palette block id");
            }
            argb |= 0xFF000000;
        }
    }

    public record Layer(int id, String name, float offsetX, float offsetY, float offsetZ,
                        boolean visible, boolean buildToWorld) {
        public Layer {
            if (id < 0 || id >= VoxelStudioConfig.MAX_LAYERS) throw new IllegalArgumentException("Layer id out of range");
            Objects.requireNonNull(name, "name");
            if (name.isBlank() || name.length() > VoxelStudioConfig.MAX_NAME_LENGTH) {
                throw new IllegalArgumentException("Invalid layer name");
            }
            if (!Float.isFinite(offsetX) || !Float.isFinite(offsetY) || !Float.isFinite(offsetZ)) {
                throw new IllegalArgumentException("Layer offsets must be finite");
            }
        }
    }

    public record Cell(int x, int y, int z, int paletteIndex, int layerId) {}

    private final int width;
    private final int height;
    private final int depth;
    private final byte[] paletteIndexes;
    private final byte[] layerIndexes;
    private final ArrayList<PaletteEntry> palette;
    private final List<Layer> layers;
    private String name;
    private boolean slimArms;

    public VoxelModel(int width, int height, int depth, String name,
                      List<PaletteEntry> palette, List<Layer> layers, boolean slimArms) {
        if (width < 1 || height < 1 || depth < 1
                || width > VoxelStudioConfig.MAX_DIMENSION
                || height > VoxelStudioConfig.MAX_DIMENSION
                || depth > VoxelStudioConfig.MAX_DIMENSION
                || (long) width * height * depth > VoxelStudioConfig.MAX_CELLS) {
            throw new IllegalArgumentException("Voxel dimensions exceed configured limits");
        }
        if (palette == null || palette.isEmpty() || palette.size() > VoxelStudioConfig.MAX_PALETTE) {
            throw new IllegalArgumentException("Palette must contain 1.." + VoxelStudioConfig.MAX_PALETTE + " entries");
        }
        if (layers == null || layers.isEmpty() || layers.size() > VoxelStudioConfig.MAX_LAYERS) {
            throw new IllegalArgumentException("Layer list must contain 1.." + VoxelStudioConfig.MAX_LAYERS + " entries");
        }
        this.width = width;
        this.height = height;
        this.depth = depth;
        this.name = sanitizeName(name);
        this.palette = new ArrayList<>(palette);
        this.layers = new ArrayList<>(layers);
        this.slimArms = slimArms;
        int volume = width * height * depth;
        this.paletteIndexes = new byte[volume];
        this.layerIndexes = new byte[volume];
        validateLayers();
    }

    private VoxelModel(VoxelModel source) {
        this.width = source.width;
        this.height = source.height;
        this.depth = source.depth;
        this.name = source.name;
        this.slimArms = source.slimArms;
        this.palette = new ArrayList<>(source.palette);
        this.layers = new ArrayList<>(source.layers);
        this.paletteIndexes = source.paletteIndexes.clone();
        this.layerIndexes = source.layerIndexes.clone();
    }

    public int width() { return width; }
    public int height() { return height; }
    public int depth() { return depth; }
    public String name() { return name; }
    public void setName(String name) { this.name = sanitizeName(name); }
    public boolean slimArms() { return slimArms; }
    public void setSlimArms(boolean slimArms) { this.slimArms = slimArms; }
    public List<PaletteEntry> palette() { return Collections.unmodifiableList(palette); }

    /** Add a newly selected material and return its 1-based index. */
    public int ensurePaletteEntry(PaletteEntry entry) {
        Objects.requireNonNull(entry, "entry");
        for (int i = 0; i < palette.size(); i++) {
            if (palette.get(i).blockId().equals(entry.blockId())) return i + 1;
        }
        if (palette.size() < VoxelStudioConfig.MAX_PALETTE) {
            palette.add(entry);
            return palette.size();
        }

        // Keep the model valid when a painter deliberately selects more than 255
        // different blocks: fall back to the perceptually closest existing entry.
        int best = 0;
        double bestDistance = Double.POSITIVE_INFINITY;
        for (int i = 0; i < palette.size(); i++) {
            double distance = VoxelColorMath.distanceSquared(entry.argb(), palette.get(i).argb());
            if (distance < bestDistance) { bestDistance = distance; best = i; }
        }
        return best + 1;
    }
    public List<Layer> layers() { return List.copyOf(layers); }
    public int volume() { return paletteIndexes.length; }

    public int paletteIndexAt(int x, int y, int z) {
        return Byte.toUnsignedInt(paletteIndexes[index(x, y, z)]);
    }

    public int layerAt(int x, int y, int z) {
        return Byte.toUnsignedInt(layerIndexes[index(x, y, z)]);
    }

    public boolean isOccupied(int x, int y, int z) {
        return paletteIndexAt(x, y, z) != 0;
    }

    public int argbAt(int x, int y, int z) {
        int index = paletteIndexAt(x, y, z);
        return index == 0 ? 0 : palette.get(index - 1).argb();
    }

    public String blockIdAt(int x, int y, int z) {
        int index = paletteIndexAt(x, y, z);
        return index == 0 ? null : palette.get(index - 1).blockId();
    }

    public void setVoxel(int x, int y, int z, int paletteIndex, int layerId) {
        if (paletteIndex < 0 || paletteIndex > palette.size()) throw new IllegalArgumentException("Invalid palette index");
        if (paletteIndex == 0) {
            clearVoxel(x, y, z);
            return;
        }
        layerListIndex(layerId); // Layer IDs are stable identifiers, not list offsets.
        int i = index(x, y, z);
        paletteIndexes[i] = (byte) paletteIndex;
        layerIndexes[i] = (byte) layerId;
    }

    public void clearVoxel(int x, int y, int z) {
        int i = index(x, y, z);
        paletteIndexes[i] = 0;
        layerIndexes[i] = 0;
    }

    public int occupiedCount() {
        int count = 0;
        for (byte b : paletteIndexes) if (b != 0) count++;
        return count;
    }

    public List<Cell> cells() {
        List<Cell> result = new ArrayList<>(occupiedCount());
        for (int y = 0; y < height; y++) {
            for (int z = 0; z < depth; z++) {
                for (int x = 0; x < width; x++) {
                    int index = indexUnchecked(x, y, z);
                    int paletteIndex = Byte.toUnsignedInt(paletteIndexes[index]);
                    if (paletteIndex != 0) {
                        result.add(new Cell(x, y, z, paletteIndex, Byte.toUnsignedInt(layerIndexes[index])));
                    }
                }
            }
        }
        return List.copyOf(result);
    }

    public boolean layerVisible(int layerId) {
        return layer(layerId).visible();
    }

    public void setLayerVisible(int layerId, boolean visible) {
        int index = layerListIndex(layerId);
        Layer old = layers.get(index);
        layers.set(index, new Layer(old.id(), old.name(), old.offsetX(), old.offsetY(), old.offsetZ(), visible, old.buildToWorld()));
    }

    public void setLayerBuildEnabled(int layerId, boolean enabled) {
        int index = layerListIndex(layerId);
        Layer old = layers.get(index);
        layers.set(index, new Layer(old.id(), old.name(), old.offsetX(), old.offsetY(), old.offsetZ(), old.visible(), enabled));
    }

    public Layer layer(int layerId) {
        return layers.get(layerListIndex(layerId));
    }

    public VoxelModel copy() { return new VoxelModel(this); }

    public void replaceWith(VoxelModel other) {
        if (other.width != width || other.height != height || other.depth != depth
                || !other.layers.equals(layers)) {
            throw new IllegalArgumentException("Cannot replace model with incompatible dimensions/layers");
        }
        palette.clear();
        palette.addAll(other.palette);
        System.arraycopy(other.paletteIndexes, 0, paletteIndexes, 0, paletteIndexes.length);
        System.arraycopy(other.layerIndexes, 0, layerIndexes, 0, layerIndexes.length);
        name = other.name;
        slimArms = other.slimArms;
    }

    public byte[] copyPaletteIndexes() { return paletteIndexes.clone(); }
    public byte[] copyLayerIndexes() { return layerIndexes.clone(); }

    public static VoxelModel fromRaw(int width, int height, int depth, String name,
                                     List<PaletteEntry> palette, List<Layer> layers,
                                     boolean slimArms, byte[] paletteIndexes, byte[] layerIndexes) {
        VoxelModel model = new VoxelModel(width, height, depth, name, palette, layers, slimArms);
        if (paletteIndexes.length != model.paletteIndexes.length || layerIndexes.length != model.layerIndexes.length) {
            throw new IllegalArgumentException("Raw voxel arrays do not match dimensions");
        }
        System.arraycopy(paletteIndexes, 0, model.paletteIndexes, 0, paletteIndexes.length);
        System.arraycopy(layerIndexes, 0, model.layerIndexes, 0, layerIndexes.length);
        for (int i = 0; i < model.paletteIndexes.length; i++) {
            int color = Byte.toUnsignedInt(model.paletteIndexes[i]);
            int layer = Byte.toUnsignedInt(model.layerIndexes[i]);
            if (color > palette.size()) {
                throw new IllegalArgumentException("Raw voxel data contains invalid palette/layer indexes");
            }
            if (color != 0) model.layerListIndex(layer);
            if (color == 0) model.layerIndexes[i] = 0;
        }
        if (model.occupiedCount() > VoxelStudioConfig.MAX_OCCUPIED_VOXELS) {
            throw new IllegalArgumentException("Model has too many occupied voxels");
        }
        return model;
    }

    private int index(int x, int y, int z) {
        if (x < 0 || x >= width || y < 0 || y >= height || z < 0 || z >= depth) {
            throw new IndexOutOfBoundsException("Voxel outside model bounds: " + x + "," + y + "," + z);
        }
        return indexUnchecked(x, y, z);
    }

    private int indexUnchecked(int x, int y, int z) {
        return x + width * (z + depth * y);
    }

    private int layerListIndex(int layerId) {
        for (int i = 0; i < layers.size(); i++) if (layers.get(i).id() == layerId) return i;
        throw new IllegalArgumentException("Unknown layer id " + layerId);
    }

    private void validateLayers() {
        boolean[] used = new boolean[VoxelStudioConfig.MAX_LAYERS];
        for (Layer layer : layers) {
            if (used[layer.id()]) throw new IllegalArgumentException("Duplicate layer id " + layer.id());
            used[layer.id()] = true;
        }
    }

    private static String sanitizeName(String value) {
        String name = value == null ? "Untitled" : value.trim();
        name = name.replaceAll("[^A-Za-z0-9 _.-]", "_");
        if (name.isBlank()) name = "Untitled";
        return name.substring(0, Math.min(name.length(), VoxelStudioConfig.MAX_NAME_LENGTH));
    }
}
