package dev.noteclient.voxel.network;

import dev.noteclient.voxel.core.VoxelStudioConfig;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Client -> server request containing only a bounded, compressed voxel model. */
public record VoxelBuildPayload(byte[] compressedModel, int anchorX, int anchorY, int anchorZ,
                                boolean replaceExisting) implements CustomPacketPayload {
    public static final Identifier ID = Identifier.fromNamespaceAndPath("noteclient", "voxel_build_v1");
    public static final Type<VoxelBuildPayload> TYPE = new Type<>(ID);
    public static final StreamCodec<RegistryFriendlyByteBuf, VoxelBuildPayload> CODEC = StreamCodec.of(
            VoxelBuildPayload::encode, VoxelBuildPayload::decode);

    public VoxelBuildPayload {
        if (compressedModel == null || compressedModel.length < 1
                || compressedModel.length > VoxelStudioConfig.MAX_COMPRESSED_MODEL_BYTES) {
            throw new IllegalArgumentException("Voxel model payload exceeds size limit");
        }
        compressedModel = compressedModel.clone();
    }

    @Override public byte[] compressedModel() { return compressedModel.clone(); }
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }

    private static void encode(RegistryFriendlyByteBuf buffer, VoxelBuildPayload payload) {
        buffer.writeByteArray(payload.compressedModel);
        buffer.writeInt(payload.anchorX);
        buffer.writeInt(payload.anchorY);
        buffer.writeInt(payload.anchorZ);
        buffer.writeBoolean(payload.replaceExisting);
    }

    private static VoxelBuildPayload decode(RegistryFriendlyByteBuf buffer) {
        return new VoxelBuildPayload(buffer.readByteArray(VoxelStudioConfig.MAX_COMPRESSED_MODEL_BYTES),
                buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readBoolean());
    }
}
