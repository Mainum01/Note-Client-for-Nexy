package dev.noteclient.voxel.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Control request for the active server-side voxel build journal. */
public record VoxelControlPayload(int action) implements CustomPacketPayload {
    public static final int REMOVE = 0;
    public static final int CANCEL_BUILD = 1;
    public static final Identifier ID = Identifier.fromNamespaceAndPath("noteclient", "voxel_control_v1");
    public static final Type<VoxelControlPayload> TYPE = new Type<>(ID);
    public static final StreamCodec<RegistryFriendlyByteBuf, VoxelControlPayload> CODEC = StreamCodec.of(
            (buffer, payload) -> buffer.writeVarInt(payload.action),
            buffer -> new VoxelControlPayload(buffer.readVarInt()));

    public VoxelControlPayload {
        if (action != REMOVE && action != CANCEL_BUILD) throw new IllegalArgumentException("Unknown voxel control action");
    }
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
