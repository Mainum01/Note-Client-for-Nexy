package dev.noteclient.voxel.core;

/**
 * Perceptual sRGB colour comparison using OKLab.
 * This is substantially more reliable than raw weighted RGB distance for
 * dark browns, muted greens, skin tones, and smooth light/dark gradients.
 */
public final class VoxelColorMath {
    private VoxelColorMath() {}

    public static double distanceSquared(int argbA, int argbB) {
        double[] a = toOklab(argbA);
        double[] b = toOklab(argbB);
        double dl = (a[0] - b[0]) * 1.12;
        double da = a[1] - b[1];
        double db = a[2] - b[2];
        return dl * dl + da * da + db * db;
    }

    public static double[] toOklab(int argb) {
        double r = linear(((argb >>> 16) & 255) / 255.0);
        double g = linear(((argb >>> 8) & 255) / 255.0);
        double b = linear((argb & 255) / 255.0);

        double l = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b;
        double m = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b;
        double s = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b;
        double lRoot = Math.cbrt(l);
        double mRoot = Math.cbrt(m);
        double sRoot = Math.cbrt(s);
        return new double[] {
                0.2104542553 * lRoot + 0.7936177850 * mRoot - 0.0040720468 * sRoot,
                1.9779984951 * lRoot - 2.4285922050 * mRoot + 0.4505937099 * sRoot,
                0.0259040371 * lRoot + 0.7827717662 * mRoot - 0.8086757660 * sRoot
        };
    }

    private static double linear(double value) {
        return value <= 0.04045 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4);
    }
}
