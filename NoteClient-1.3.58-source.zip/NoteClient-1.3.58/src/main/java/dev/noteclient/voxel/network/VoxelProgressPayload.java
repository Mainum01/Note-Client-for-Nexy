package dev.noteclient.voxel.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Server -> owner status updates; does not replicate individual voxels. */
public record VoxelProgressPayload(int completed, int total, int skipped, int phase,
                                   boolean finished, String message) implements CustomPacketPayload {
    public static final Identifier ID = Identifier.fromNamespaceAndPath("noteclient", "voxel_progress_v1");
    public static final Type<VoxelProgressPayload> TYPE = new Type<>(ID);
    public static final StreamCodec<RegistryFriendlyByteBuf, VoxelProgressPayload> CODEC = StreamCodec.of(
            VoxelProgressPayload::encode, VoxelProgressPayload::decode);

    public VoxelProgressPayload {
        if (message == null) message = "";
        if (message.length() > 180) message = message.substring(0,180);
        completed = Math.max(0, completed); total = Math.max(0,total); skipped = Math.max(0,skipped);
    }
    private static void encode(RegistryFriendlyByteBuf b, VoxelProgressPayload p) {
        b.writeVarInt(p.completed); b.writeVarInt(p.total); b.writeVarInt(p.skipped);
        b.writeVarInt(p.phase); b.writeBoolean(p.finished); b.writeUtf(p.message,180);
    }
    private static VoxelProgressPayload decode(RegistryFriendlyByteBuf b) {
        return new VoxelProgressPayload(b.readVarInt(),b.readVarInt(),b.readVarInt(),
                b.readVarInt(),b.readBoolean(),b.readUtf(180));
    }
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
