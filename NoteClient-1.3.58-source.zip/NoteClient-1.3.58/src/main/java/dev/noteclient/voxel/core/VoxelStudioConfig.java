package dev.noteclient.voxel.core;

/**
 * Hard safety and performance limits shared by the client and server.
 * These values are deliberately conservative: no software can guarantee
 * literally zero lag, so work is bounded per tick and expensive work is
 * prepared off-thread before it reaches Minecraft's world thread.
 */
public final class VoxelStudioConfig {
    private VoxelStudioConfig() {}

    public static final int FORMAT_VERSION = 2;
    public static final int MAX_DIMENSION = 64;
    public static final int MAX_CELLS = 65_536;
    public static final int MAX_OCCUPIED_VOXELS = 32_768;
    public static final int MAX_PALETTE = 255;
    public static final int MAX_LAYERS = 16;
    public static final int MAX_NAME_LENGTH = 48;
    public static final int MAX_BLOCK_ID_LENGTH = 96;
    public static final int MAX_COMPRESSED_MODEL_BYTES = 1_048_576;
    public static final int MAX_DECOMPRESSED_MODEL_BYTES = 4_194_304;
    public static final int MAX_SKIN_FILE_BYTES = 8 * 1024 * 1024;
    public static final int MAX_SKIN_SCAN_DEPTH = 8;

    /** Server-side edits per tick. Increase only after measuring server tick time. */
    public static final int SERVER_BUILD_BUDGET_PER_TICK = 160;
    public static final int SERVER_REMOVE_BUDGET_PER_TICK = 512;
    public static final int SERVER_PROGRESS_INTERVAL_TICKS = 5;
    public static final int SERVER_MAX_ACTIVE_JOBS_PER_PLAYER = 1;
    public static final int SERVER_MAX_DISTANCE = 128;

    /** Client preview limits. */
    public static final int PREVIEW_WIDTH = 256;
    public static final int PREVIEW_HEIGHT = 320;
    public static final int PREVIEW_MAX_FACES = 120_000;
    public static final int UNDO_HISTORY_LIMIT = 64;

    /** Studio tool defaults. */
    public static final int DEFAULT_BRUSH_ARGB = 0xFFCC6633;
    public static final double CAMERA_FOV_DEGREES = 42.0;
    public static final double CAMERA_MIN_DISTANCE = 12.0;
    public static final double CAMERA_MAX_DISTANCE = 96.0;
    public static final double CAMERA_MIN_PITCH = -1.48;
    public static final double CAMERA_MAX_PITCH = 1.48;

    /** Hotkey defaults. */
    public static final int KEY_OPEN_STUDIO = 67;      // C
    public static final int KEY_REBUILD = 82;          // R (inside the studio only)
    public static final int KEY_DESTROY = 340;         // GLFW_KEY_LEFT_SHIFT (inside the studio only)
}
