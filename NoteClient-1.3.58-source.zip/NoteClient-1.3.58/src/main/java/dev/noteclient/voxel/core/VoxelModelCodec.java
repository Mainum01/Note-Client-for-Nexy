package dev.noteclient.voxel.core;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;

/** Versioned, bounded serializer used for local .voxel.json files and network upload. */
public final class VoxelModelCodec {
    private static final int MAGIC = 0x4E435653; // NCVS
    private static final int MAX_STRING_BYTES = 256;

    private VoxelModelCodec() {}

    public static byte[] encodeCompressed(VoxelModel model) throws IOException {
        if (model.occupiedCount() > VoxelStudioConfig.MAX_OCCUPIED_VOXELS) {
            throw new IOException("Model exceeds occupied-voxel limit");
        }
        ByteArrayOutputStream rawBytes = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(rawBytes)) {
            out.writeInt(MAGIC);
            out.writeShort(VoxelStudioConfig.FORMAT_VERSION);
            out.writeByte(model.width());
            out.writeByte(model.height());
            out.writeByte(model.depth());
            out.writeBoolean(model.slimArms());
            writeString(out, model.name(), VoxelStudioConfig.MAX_NAME_LENGTH);

            out.writeByte(model.palette().size());
            for (VoxelModel.PaletteEntry entry : model.palette()) {
                writeString(out, entry.blockId(), VoxelStudioConfig.MAX_BLOCK_ID_LENGTH);
                out.writeInt(entry.argb());
            }

            out.writeByte(model.layers().size());
            for (VoxelModel.Layer layer : model.layers()) {
                out.writeByte(layer.id());
                writeString(out, layer.name(), VoxelStudioConfig.MAX_NAME_LENGTH);
                out.writeFloat(layer.offsetX());
                out.writeFloat(layer.offsetY());
                out.writeFloat(layer.offsetZ());
                out.writeBoolean(layer.visible());
                out.writeBoolean(layer.buildToWorld());
            }

            List<VoxelModel.Cell> cells = model.cells();
            out.writeInt(cells.size());
            for (VoxelModel.Cell cell : cells) {
                int packed = (cell.x() & 0x3F)
                        | ((cell.y() & 0x3F) << 6)
                        | ((cell.z() & 0x3F) << 12)
                        | ((cell.paletteIndex() & 0xFF) << 18)
                        | ((cell.layerId() & 0x0F) << 26);
                out.writeInt(packed);
            }
        }

        ByteArrayOutputStream compressed = new ByteArrayOutputStream();
        try (DeflaterOutputStream deflater = new DeflaterOutputStream(compressed)) {
            rawBytes.writeTo(deflater);
        }
        byte[] result = compressed.toByteArray();
        if (result.length > VoxelStudioConfig.MAX_COMPRESSED_MODEL_BYTES) {
            throw new IOException("Compressed model exceeds network/file limit");
        }
        return result;
    }

    public static VoxelModel decodeCompressed(byte[] compressed) throws IOException {
        if (compressed == null || compressed.length == 0
                || compressed.length > VoxelStudioConfig.MAX_COMPRESSED_MODEL_BYTES) {
            throw new IOException("Invalid compressed model size");
        }
        byte[] raw = inflateBounded(compressed, VoxelStudioConfig.MAX_DECOMPRESSED_MODEL_BYTES);
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(raw))) {
            if (in.readInt() != MAGIC) throw new IOException("Not a NoteClient voxel model");
            int version = in.readUnsignedShort();
            if (version < 1 || version > VoxelStudioConfig.FORMAT_VERSION) {
                throw new IOException("Unsupported voxel model version " + version);
            }
            int width = in.readUnsignedByte();
            int height = in.readUnsignedByte();
            int depth = in.readUnsignedByte();
            boolean slim = in.readBoolean();
            String name = readString(in, VoxelStudioConfig.MAX_NAME_LENGTH);

            int paletteCount = in.readUnsignedByte();
            int versionPaletteLimit = version == 1 ? 64 : VoxelStudioConfig.MAX_PALETTE;
            if (paletteCount < 1 || paletteCount > versionPaletteLimit) throw new IOException("Invalid palette count");
            List<VoxelModel.PaletteEntry> palette = new ArrayList<>(paletteCount);
            for (int i = 0; i < paletteCount; i++) {
                palette.add(new VoxelModel.PaletteEntry(
                        readString(in, VoxelStudioConfig.MAX_BLOCK_ID_LENGTH), in.readInt()));
            }

            int layerCount = in.readUnsignedByte();
            if (layerCount < 1 || layerCount > VoxelStudioConfig.MAX_LAYERS) throw new IOException("Invalid layer count");
            List<VoxelModel.Layer> layers = new ArrayList<>(layerCount);
            for (int i = 0; i < layerCount; i++) {
                layers.add(new VoxelModel.Layer(in.readUnsignedByte(),
                        readString(in, VoxelStudioConfig.MAX_NAME_LENGTH),
                        in.readFloat(), in.readFloat(), in.readFloat(),
                        in.readBoolean(), in.readBoolean()));
            }

            VoxelModel model = new VoxelModel(width, height, depth, name, palette, layers, slim);
            int count = in.readInt();
            if (count < 0 || count > VoxelStudioConfig.MAX_OCCUPIED_VOXELS) throw new IOException("Invalid voxel count");
            for (int i = 0; i < count; i++) {
                int packed = in.readInt();
                int x = packed & 0x3F;
                int y = (packed >>> 6) & 0x3F;
                int z = (packed >>> 12) & 0x3F;
                // v1 used a 7-bit palette index and placed layer bits at bit 25.
                // v2 uses all 8 palette-index bits, shifting layer bits to bit 26.
                int paletteIndex = version == 1 ? ((packed >>> 18) & 0x7F) : ((packed >>> 18) & 0xFF);
                int layerId = version == 1 ? ((packed >>> 25) & 0x0F) : ((packed >>> 26) & 0x0F);
                if (paletteIndex == 0 || paletteIndex > paletteCount
                        || x >= width || y >= height || z >= depth) {
                    throw new IOException("Voxel record is outside model bounds");
                }
                try {
                    model.setVoxel(x, y, z, paletteIndex, layerId);
                } catch (IllegalArgumentException invalidLayer) {
                    throw new IOException("Voxel references an unknown layer", invalidLayer);
                }
            }
            if (in.available() != 0) throw new IOException("Trailing data in voxel model");
            return model;
        } catch (IllegalArgumentException | IndexOutOfBoundsException exception) {
            throw new IOException("Invalid voxel model data", exception);
        }
    }

    public static String toJson(VoxelModel model) throws IOException {
        JsonObject root = new JsonObject();
        root.addProperty("format", "noteclient-voxel-model");
        root.addProperty("version", VoxelStudioConfig.FORMAT_VERSION);
        root.addProperty("encoding", "deflate-base64");
        root.addProperty("model", Base64.getEncoder().encodeToString(encodeCompressed(model)));
        return root.toString();
    }

    public static VoxelModel fromJson(String json) throws IOException {
        try {
            JsonObject root = JsonParser.parseString(json).getAsJsonObject();
            if (!"noteclient-voxel-model".equals(root.get("format").getAsString())) {
                throw new IOException("Unknown voxel template format");
            }
            int jsonVersion = root.get("version").getAsInt();
            if (jsonVersion < 1 || jsonVersion > VoxelStudioConfig.FORMAT_VERSION) {
                throw new IOException("Unsupported voxel template version");
            }
            String base64 = root.get("model").getAsString();
            if (base64.length() > VoxelStudioConfig.MAX_COMPRESSED_MODEL_BYTES * 2L) {
                throw new IOException("Voxel template is too large");
            }
            return decodeCompressed(Base64.getDecoder().decode(base64));
        } catch (RuntimeException exception) {
            throw new IOException("Malformed voxel template JSON", exception);
        }
    }

    private static byte[] inflateBounded(byte[] compressed, int maxBytes) throws IOException {
        try (InflaterInputStream in = new InflaterInputStream(new ByteArrayInputStream(compressed));
             ByteArrayOutputStream out = new ByteArrayOutputStream(Math.min(maxBytes, compressed.length * 4))) {
            byte[] buffer = new byte[8192];
            int read;
            int total = 0;
            while ((read = in.read(buffer)) != -1) {
                total += read;
                if (total > maxBytes) throw new IOException("Voxel model expands beyond allowed size");
                out.write(buffer, 0, read);
            }
            return out.toByteArray();
        }
    }

    private static void writeString(DataOutputStream out, String value, int maxChars) throws IOException {
        if (value == null || value.length() > maxChars) throw new IOException("String exceeds limit");
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        if (bytes.length > MAX_STRING_BYTES) throw new IOException("Encoded string exceeds limit");
        out.writeShort(bytes.length);
        out.write(bytes);
    }

    private static String readString(DataInputStream in, int maxChars) throws IOException {
        int length = in.readUnsignedShort();
        if (length > MAX_STRING_BYTES) throw new IOException("Encoded string exceeds limit");
        byte[] bytes = in.readNBytes(length);
        if (bytes.length != length) throw new IOException("Truncated string");
        String value = new String(bytes, StandardCharsets.UTF_8);
        if (value.length() > maxChars) throw new IOException("Decoded string exceeds limit");
        return value;
    }
}
