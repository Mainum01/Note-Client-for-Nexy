package dev.noteclient.voxel.server;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Server-owner policy. Construction is disabled for non-operators by design. */
public final class VoxelStudioServerConfig {
    public boolean allowOperatorBuilds = true;
    public boolean allowReplaceExisting = false;
    public int maxVoxelsPerJob = 16_384;
    public int maxChangesPerTick = 128;
    public int maxRemovalsPerTick = 384;
    public int maxDistanceFromPlayer = 64;
    public int progressEveryTicks = 5;

    private VoxelStudioServerConfig() {}

    public static VoxelStudioServerConfig load() {
        VoxelStudioServerConfig config = new VoxelStudioServerConfig();
        Path file = FabricLoader.getInstance().getConfigDir().resolve("noteclient-voxel-server.properties");
        Properties p = new Properties();
        try {
            if (Files.exists(file)) try (InputStream in = Files.newInputStream(file)) { p.load(in); }
            config.allowOperatorBuilds = p.getProperty("allowOperatorBuilds", "true").equalsIgnoreCase("true");
            config.allowReplaceExisting = p.getProperty("allowReplaceExisting", "false").equalsIgnoreCase("true");
            config.maxVoxelsPerJob = clamp(p.getProperty("maxVoxelsPerJob"), 16_384, 1, 32_768);
            config.maxChangesPerTick = clamp(p.getProperty("maxChangesPerTick"), 128, 1, 1024);
            config.maxRemovalsPerTick = clamp(p.getProperty("maxRemovalsPerTick"), 384, 1, 2048);
            config.maxDistanceFromPlayer = clamp(p.getProperty("maxDistanceFromPlayer"), 64, 8, 256);
            config.progressEveryTicks = clamp(p.getProperty("progressEveryTicks"), 5, 1, 40);
            p.setProperty("allowOperatorBuilds", Boolean.toString(config.allowOperatorBuilds));
            p.setProperty("allowReplaceExisting", Boolean.toString(config.allowReplaceExisting));
            p.setProperty("maxVoxelsPerJob", Integer.toString(config.maxVoxelsPerJob));
            p.setProperty("maxChangesPerTick", Integer.toString(config.maxChangesPerTick));
            p.setProperty("maxRemovalsPerTick", Integer.toString(config.maxRemovalsPerTick));
            p.setProperty("maxDistanceFromPlayer", Integer.toString(config.maxDistanceFromPlayer));
            p.setProperty("progressEveryTicks", Integer.toString(config.progressEveryTicks));
            Files.createDirectories(file.getParent());
            try (OutputStream out = Files.newOutputStream(file)) {
                p.store(out, "NoteClient Voxel Studio server safety limits");
            }
        } catch (IOException exception) {
            System.err.println("[NoteClient Voxel] Could not read/write server config: " + exception.getMessage());
        }
        return config;
    }

    private static int clamp(String value, int fallback, int min, int max) {
        try { return Math.max(min, Math.min(max, Integer.parseInt(value.trim()))); }
        catch (Exception ignored) { return fallback; }
    }
}
