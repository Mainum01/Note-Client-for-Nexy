package dev.noteclient.voxel.server;

import dev.noteclient.voxel.core.VoxelModel;
import dev.noteclient.voxel.core.VoxelModelCodec;
import dev.noteclient.voxel.core.VoxelStudioConfig;
import dev.noteclient.voxel.network.VoxelBuildPayload;
import dev.noteclient.voxel.network.VoxelControlPayload;
import dev.noteclient.voxel.network.VoxelProgressPayload;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.EmptyBlockGetter;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Authoritative world editor for the optional server companion.
 * Model decompression happens on a bounded worker pool; all registry/world reads
 * and all setBlock calls are performed back on the logical server thread.
 */
public final class VoxelStudioServerManager {
    private enum Phase { BUILDING, REMOVING, FINISHED }
    private record Operation(BlockPos pos, BlockState placed, BlockState original) {}
    private record Journal(BlockPos pos, BlockState placed, BlockState original) {}

    private static final int MAX_PACKET = VoxelStudioConfig.MAX_COMPRESSED_MODEL_BYTES + 64;
    // The palette accepts all vanilla full-cube materials, but these special or
    // destructive blocks are never valid character voxels even if they are solid.
    private static final Set<String> NEVER_USE_BLOCKS = Set.of(
            "tnt", "respawn_anchor", "command_block", "chain_command_block",
            "repeating_command_block", "structure_block", "jigsaw", "barrier",
            "light", "moving_piston", "piston_head", "end_gateway", "end_portal",
            "nether_portal", "spawner", "trial_spawner", "vault", "magma_block",
            "sand", "red_sand", "gravel", "suspicious_sand", "suspicious_gravel",
            "anvil", "chipped_anvil", "damaged_anvil", "dragon_egg", "bedrock"
    );
    // Completed jobs are retained as a per-player undo stack. Only the newest
    // job may still be changing the world; older entries are finished journals
    // that can be restored one at a time by REMOVE.
    private static final Map<UUID, Deque<Job>> JOBS = new HashMap<>();
    private static final int MAX_STATUES_PER_PLAYER = 16;
    private static final Set<UUID> DECODING = java.util.concurrent.ConcurrentHashMap.newKeySet();
    // Both worker count and pending tasks are bounded. A malicious or buggy client
    // cannot enqueue an unbounded number of expensive model-decompression jobs.
    private static final int MAX_ACTIVE_JOBS = 4;
    private static final ThreadPoolExecutor DECODER = new ThreadPoolExecutor(
            2, 2, 0L, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(8), runnable -> {
                Thread t = new Thread(runnable, "NoteClient-VoxelDecode");
                t.setDaemon(true);
                return t;
            }, new ThreadPoolExecutor.AbortPolicy());
    private static VoxelStudioServerConfig config;
    private static boolean initialized;

    private VoxelStudioServerManager() {}

    /** Call from the server companion's ModInitializer exactly once. */
    public static void initialize() {
        if (initialized) return;
        initialized = true;
        config = VoxelStudioServerConfig.load();

        PayloadTypeRegistry.serverboundPlay().registerLarge(VoxelBuildPayload.TYPE, VoxelBuildPayload.CODEC, MAX_PACKET);
        PayloadTypeRegistry.serverboundPlay().register(VoxelControlPayload.TYPE, VoxelControlPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(VoxelProgressPayload.TYPE, VoxelProgressPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(VoxelBuildPayload.TYPE,
                (payload, context) -> decodeAndStart(context.player(), payload));
        ServerPlayNetworking.registerGlobalReceiver(VoxelControlPayload.TYPE,
                (payload, context) -> control(context.player(), payload.action()));
        ServerTickEvents.END_SERVER_TICK.register(VoxelStudioServerManager::tick);
        ServerLifecycleEvents.SERVER_STOPPING.register(VoxelStudioServerManager::restoreAndStop);

        System.out.println("[NoteClient Voxel] Server manager ready. Operator-only=" + config.allowOperatorBuilds
                + ", maxVoxels=" + config.maxVoxelsPerJob + ", build/tick=" + config.maxChangesPerTick
                + ", removal/tick=" + config.maxRemovalsPerTick);
    }

    private static void decodeAndStart(ServerPlayer player, VoxelBuildPayload payload) {
        if (!authorized(player)) {
            send(player,0,0,0,0,true,"Voxel build denied: this server requires operator permission.");
            return;
        }
        UUID playerId = player.getUUID();
        Deque<Job> history = JOBS.get(playerId);
        Job latest = history == null ? null : history.peekLast();
        if ((latest != null && latest.phase != Phase.FINISHED) || !DECODING.add(playerId)) {
            send(player,0,0,0,0,false,
                    "A voxel build/removal is still active. Let it finish before starting another statue.");
            return;
        }
        if (history != null && history.size() >= MAX_STATUES_PER_PLAYER) {
            DECODING.remove(playerId);
            send(player,0,0,0,0,true,
                    "Voxel build denied: undo history is full. Undo a previous statue before building another.");
            return;
        }
        if (activeJobCount() + DECODING.size() > MAX_ACTIVE_JOBS) {
            DECODING.remove(playerId);
            send(player,0,0,0,0,true,"Voxel build denied: server is at its active-job limit.");
            return;
        }
        byte[] compressed = payload.compressedModel();
        MinecraftServer server = serverOf(player);
        if (server == null) {
            DECODING.remove(playerId);
            send(player,0,0,0,0,true,"Voxel build denied: server context unavailable.");
            return;
        }
        try {
            CompletableFuture.supplyAsync(() -> {
                try { return VoxelModelCodec.decodeCompressed(compressed); }
                catch (Exception e) { throw new java.util.concurrent.CompletionException(e); }
            }, DECODER).whenComplete((model,error) -> {
                try {
                    server.execute(() -> {
                        DECODING.remove(playerId);
                        if (player.isRemoved()) return;
                        if (error != null || model == null) {
                            send(player,0,0,0,0,true,"Voxel build denied: the model packet was invalid, too large, or decoder capacity was exceeded.");
                            return;
                        }
                        prepareJob(player, payload, model);
                    });
                } catch (RuntimeException stoppingServer) {
                    DECODING.remove(playerId);
                }
            });
        } catch (java.util.concurrent.RejectedExecutionException overloaded) {
            DECODING.remove(playerId);
            send(player,0,0,0,0,true,"Voxel build denied: server model decoder is busy. Try again in a moment.");
        }
    }

    private static void prepareJob(ServerPlayer player, VoxelBuildPayload request, VoxelModel model) {
        if (!authorized(player)) {
            send(player,0,0,0,0,true,"Voxel build denied: permission changed before validation completed.");
            return;
        }
        if (model.occupiedCount() > config.maxVoxelsPerJob) {
            send(player,0,model.occupiedCount(),0,0,true,"Voxel build denied: model exceeds maxVoxelsPerJob.");
            return;
        }
        if (request.replaceExisting() && !config.allowReplaceExisting) {
            send(player,0,model.occupiedCount(),0,0,true,"Voxel build denied: replacing existing blocks is disabled by the server owner.");
            return;
        }
        ServerLevel level = (ServerLevel) player.level();
        BlockPos anchor = new BlockPos(request.anchorX(),request.anchorY(),request.anchorZ());
        double maxDistanceSq = (double)config.maxDistanceFromPlayer * config.maxDistanceFromPlayer;
        if (player.distanceToSqr(anchor.getX()+0.5,anchor.getY()+0.5,anchor.getZ()+0.5) > maxDistanceSq) {
            send(player,0,model.occupiedCount(),0,0,true,"Voxel build denied: the anchor is too far away.");
            return;
        }

        Deque<Operation> queue = new ArrayDeque<>();
        int skipped=0;
        for (VoxelModel.Cell cell : model.cells()) {
            VoxelModel.Layer layer = model.layer(cell.layerId());
            if (!layer.buildToWorld()) continue;
            BlockPos pos = anchor.offset(cell.x(),cell.y(),cell.z());
            if (!level.isInWorldBounds(pos) || !level.getWorldBorder().isWithinBounds(pos) || !level.hasChunkAt(pos)) {
                skipped++;
                continue;
            }
            String blockId = model.palette().get(cell.paletteIndex()-1).blockId();
            BlockState placed = resolveSafeBlock(blockId);
            if (placed == null || placed.hasBlockEntity() || !placed.getFluidState().isEmpty() || placed.isAir()) {
                skipped++;
                continue;
            }
            BlockState original = level.getBlockState(pos);
            if (!original.isAir() && !request.replaceExisting()) {
                skipped++;
                continue;
            }
            queue.addLast(new Operation(pos.immutable(),placed,original));
        }
        if (queue.isEmpty()) {
            send(player,0,model.occupiedCount(),skipped,Phase.FINISHED.ordinal(),true,
                    "No buildable voxels. Check that target chunks are loaded and cells are air.");
            return;
        }
        Deque<Job> history = JOBS.computeIfAbsent(player.getUUID(), ignored -> new ArrayDeque<>());
        Job latest = history.peekLast();
        if (latest != null && latest.phase != Phase.FINISHED) {
            send(player,0,model.occupiedCount(),skipped,Phase.FINISHED.ordinal(),true,
                    "A previous statue is still changing the world. Wait for it to finish first.");
            return;
        }
        if (history.size() >= MAX_STATUES_PER_PLAYER) {
            send(player,0,model.occupiedCount(),skipped,Phase.FINISHED.ordinal(),true,
                    "Undo history is full. Undo a previous statue before building another.");
            return;
        }
        Job job = new Job(player,level,queue,skipped);
        history.addLast(job);
        send(player,0,job.total,skipped,Phase.BUILDING.ordinal(),false,
                history.size() == 1
                        ? "Server accepted voxel statue; building in bounded batches."
                        : "Server accepted another voxel statue; the previous statue was kept in undo history.");
    }

    private static BlockState resolveSafeBlock(String text) {
        try {
            Identifier id = Identifier.parse(text);
            if (!"minecraft".equals(id.getNamespace()) || NEVER_USE_BLOCKS.contains(id.getPath())
                    || id.getPath().endsWith("_concrete_powder")) return null;
            Block block = BuiltInRegistries.BLOCK.getOptional(id).orElse(null);
            if (block == null) return null;
            BlockState state = block.defaultBlockState();
            if (state.isAir() || state.hasBlockEntity() || !state.getFluidState().isEmpty()) return null;
            // Only full, solid cubes are accepted for the voxel statue. This keeps
            // every cell one block, avoids block-entity/NBT data, and ensures the
            // server palette accepts the same broad material family as the client.
            if (!state.isCollisionShapeFullBlock(EmptyBlockGetter.INSTANCE, BlockPos.ZERO)) return null;
            return state;
        } catch (RuntimeException exception) {
            return null;
        }
    }

    private static void control(ServerPlayer player, int action) {
        Deque<Job> history = JOBS.get(player.getUUID());
        Job job = history == null ? null : history.peekLast();
        if (job == null) {
            send(player,0,0,0,Phase.FINISHED.ordinal(),true,"No statue is available in the undo history.");
            return;
        }
        if (!authorized(player)) {
            send(player,job.completed,job.total,job.skipped,job.phase.ordinal(),false,"Voxel control denied: operator permission required.");
            return;
        }
        if (action == VoxelControlPayload.REMOVE) {
            if (job.phase == Phase.REMOVING) {
                send(player,job.removalCompleted,job.journal.size(),job.skipped,Phase.REMOVING.ordinal(),false,
                        "The newest statue is already being undone.");
                return;
            }
            job.beginRemoval();
            send(player,job.removalCompleted,job.journal.size(),job.skipped,Phase.REMOVING.ordinal(),false,
                    "Undoing the newest statue in bounded batches. Older statues are being kept.");
        } else if (action == VoxelControlPayload.CANCEL_BUILD) {
            job.queue.clear();
            job.beginRemoval();
        }
    }

    private static void tick(MinecraftServer server) {
        if (JOBS.isEmpty()) return;
        var iterator = JOBS.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Deque<Job>> entry = iterator.next();
            Deque<Job> history = entry.getValue();
            Job job = history.peekLast();
            if (job == null) {
                iterator.remove();
                continue;
            }
            if (job.player.isRemoved() || serverOf(job.player) != server) {
                // Restore newest-first so overlapping undo journals unwind in
                // the reverse order in which they changed the world.
                var reverse = history.descendingIterator();
                while (reverse.hasNext()) restoreJournal(reverse.next());
                iterator.remove();
                continue;
            }

            // A completed statue remains in the stack, but does not need to be
            // visited again until a newer build or an undo request arrives.
            if (job.phase == Phase.FINISHED && !job.wasRemoval) continue;

            int budget = job.phase == Phase.REMOVING ? config.maxRemovalsPerTick : config.maxChangesPerTick;
            int changed = 0;
            if (job.phase == Phase.BUILDING) {
                while (changed < budget && !job.queue.isEmpty()) {
                    Operation op = job.queue.removeFirst();
                    BlockState current = job.level.getBlockState(op.pos);
                    if (!current.equals(op.original)) { job.skipped++; continue; }
                    if (job.level.setBlock(op.pos,op.placed,3)) {
                        job.journal.add(new Journal(op.pos,op.placed,op.original));
                        job.completed++;
                        changed++;
                    } else job.skipped++;
                }
                if (job.queue.isEmpty()) job.phase=Phase.FINISHED;
            } else if (job.phase == Phase.REMOVING) {
                while (changed < budget && !job.removeQueue.isEmpty()) {
                    Journal journalEntry = job.removeQueue.removeLast();
                    BlockState current = job.level.getBlockState(journalEntry.pos);
                    if (current.equals(journalEntry.placed)) {
                        if (job.level.setBlock(journalEntry.pos,journalEntry.original,3)) job.removalCompleted++;
                    } else job.skipped++;
                    changed++;
                }
                if (job.removeQueue.isEmpty()) job.phase=Phase.FINISHED;
            }

            // A removal's final status is sent only after its stack entry is
            // popped below. Sending an intermediate FINISHED packet here could
            // make a client rebuild start before the next undo target is exposed.
            if (!(job.phase == Phase.FINISHED && job.wasRemoval)
                    && (server.getTickCount() % config.progressEveryTicks == 0 || job.phase == Phase.FINISHED)) {
                String message = job.phase == Phase.REMOVING ? "Undoing newest statue" :
                        job.phase == Phase.FINISHED ? "Statue build finished" : "Building voxel statue";
                send(job.player,job.phase == Phase.REMOVING ? job.removalCompleted : job.completed,
                        job.phase == Phase.REMOVING ? job.journal.size() : job.total,job.skipped,job.phase.ordinal(),
                        job.phase == Phase.FINISHED,message);
            }

            if (job.phase == Phase.FINISHED && job.wasRemoval) {
                // Remove exactly the newest statue from the journal stack. The
                // older statue becomes the next target for a subsequent undo.
                history.removeLast();
                Job previous = history.peekLast();
                if (previous == null) {
                    send(job.player,job.removalCompleted,job.journal.size(),job.skipped,
                            Phase.FINISHED.ordinal(),true,"Undid the newest statue. Undo history is now empty.");
                    iterator.remove();
                } else {
                    send(job.player,previous.completed,previous.total,previous.skipped,
                            previous.phase.ordinal(),true,
                            "Undid the newest statue. The previous statue is still built; undo again to remove that build.");
                }
            }
        }
    }

    /** Counts only jobs still changing blocks; completed statues live in undo history. */
    private static int activeJobCount() {
        int count = 0;
        for (Deque<Job> history : JOBS.values()) {
            Job latest = history.peekLast();
            if (latest != null && latest.phase != Phase.FINISHED) count++;
        }
        return count;
    }

    /** Minecraft 26.2 exposes the server through the player's ServerLevel, not ServerPlayer. */
    private static MinecraftServer serverOf(ServerPlayer player) {
        return player.level().getServer();
    }

    private static boolean authorized(ServerPlayer player) {
        MinecraftServer server = serverOf(player);
        if (server == null) return false;
        // In an integrated server, only the actual singleplayer host is implicitly
        // trusted. LAN guests must still be operators; server.isSingleplayer() alone
        // would accidentally grant every LAN guest world-edit permission.
        if (server.isSingleplayer() && server.isSingleplayerOwner(player.nameAndId())) return true;
        return config.allowOperatorBuilds && server.getPlayerList().isOp(player.nameAndId());
    }

    private static void send(ServerPlayer player,int completed,int total,int skipped,int phase,boolean finished,String message) {
        if (ServerPlayNetworking.canSend(player,VoxelProgressPayload.TYPE)) {
            ServerPlayNetworking.send(player,new VoxelProgressPayload(completed,total,skipped,phase,finished,message));
        }
    }

    private static void restoreAndStop(MinecraftServer server) {
        for (Deque<Job> history : JOBS.values()) {
            var reverse = history.descendingIterator();
            while (reverse.hasNext()) restoreJournal(reverse.next());
        }
        JOBS.clear();
        // Integrated servers may stop/start repeatedly in one client process.
        // Keep the small daemon decoder alive instead of permanently shutting it down.
    }

    private static void restoreJournal(Job job) {
        for (int i=job.journal.size()-1;i>=0;i--) {
            Journal entry=job.journal.get(i);
            // Restore only blocks that still contain this job's exact placed state.
            // This avoids overwriting edits made by the player or another system.
            BlockState current = job.level.getBlockState(entry.pos);
            if (current.equals(entry.placed)) {
                job.level.setBlock(entry.pos,entry.original,3);
            }
        }
    }

    private static final class Job {
        final ServerPlayer player;
        final ServerLevel level;
        final Deque<Operation> queue;
        final List<Journal> journal = new ArrayList<>();
        final Deque<Journal> removeQueue = new ArrayDeque<>();
        final int total;
        int completed, skipped, removalCompleted;
        Phase phase=Phase.BUILDING;
        boolean wasRemoval;
        Job(ServerPlayer player,ServerLevel level,Deque<Operation> queue,int skipped) {
            this.player=player; this.level=level; this.queue=queue; this.total=queue.size(); this.skipped=skipped;
        }
        void beginRemoval() {
            if (wasRemoval) return;
            wasRemoval=true; phase=Phase.REMOVING;
            removeQueue.addAll(journal);
        }
    }
}
