package dev.noteclient;

import dev.noteclient.schematic.SchematicBuilder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/** Searchable Minecraft schematic library with an in-world block-model preview. */
public final class SchematicBrowserScreen extends Screen {
    private final Screen parent;
    private final Path folder = SchematicBuilder.NoteClientSchematics.folder();
    private List<Path> files = List.of();
    private String searchText = "";
    private String status = "Select a Minecraft schematic to anchor its preview at your current position.";
    private Path selected;
    private EditBox searchBox;
    private int panelX, panelY, panelWidth, panelHeight;
    private int listTop, listBottom, rowHeight, visibleRows, scrollOffset;

    public SchematicBrowserScreen(Screen parent) {
        super(Component.literal("NoteClient Schematics"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        panelWidth = Math.max(1, Math.min(760, width - 18));
        panelHeight = Math.max(1, Math.min(540, height - 18));
        panelX = (width - panelWidth) / 2;
        panelY = (height - panelHeight) / 2;
        reloadFiles();

        searchBox = new EditBox(font, panelX + 12, panelY + 48,
                Math.max(1, panelWidth - 24), 19, Component.literal("Search schematics"));
        searchBox.setMaxLength(180);
        searchBox.setValue(searchText);
        searchBox.setHint(Component.literal("Search schematic files and subfolders…"));
        searchBox.setResponder(value -> {
            searchText = value;
            scrollOffset = 0;
        });
        addRenderableWidget(searchBox);

        listTop = panelY + 75;
        listBottom = panelY + panelHeight - 76;
        int available = Math.max(1, listBottom - listTop);
        rowHeight = Math.max(20, Math.min(30, available / 10));
        visibleRows = Math.max(1, available / rowHeight);

        int buttonY = panelY + panelHeight - 65;
        if (panelWidth < 570) {
            // Keep every hitbox separate on compact game windows. The old fixed
            // coordinates overlapped Build with Clear Preview at lower widths.
            int x = panelX + 12;
            int gap = 3;
            int[] widths = {48, 54, 48, 52, 62, 42};
            String[] labels = {"Refresh", "Folder", "Rotate", "Unload", "Build", "Back"};
            Runnable[] actions = {
                    this::reloadFiles,
                    () -> {
                        Minecraft client = this.minecraft;
                        if (client != null) {
                            client.keyboardHandler.setClipboard(folder.toAbsolutePath().toString());
                            status = "Copied the schematics folder path.";
                        }
                    },
                    () -> { SchematicBuilder.rotatePreview(); status = SchematicBuilder.status(); },
                    () -> { SchematicBuilder.unloadPreview(); selected = null; status = SchematicBuilder.status(); },
                    this::startBuild,
                    this::goBack
            };
            for (int i = 0; i < widths.length; i++) {
                addButton(labels[i], x, buttonY, widths[i], actions[i]);
                x += widths[i] + gap;
            }
        } else {
            addButton("Refresh", panelX + 12, buttonY, 72, this::reloadFiles);
            addButton("Copy Folder", panelX + 90, buttonY, 92, () -> {
                Minecraft client = this.minecraft;
                if (client != null) {
                    client.keyboardHandler.setClipboard(folder.toAbsolutePath().toString());
                    status = "Copied the schematics folder path.";
                }
            });
            addButton("Rotate", panelX + 188, buttonY, 72, () -> {
                SchematicBuilder.rotatePreview();
                status = SchematicBuilder.status();
            });
            addButton("Unload", panelX + 266, buttonY, 76, () -> {
                SchematicBuilder.unloadPreview();
                selected = null;
                status = SchematicBuilder.status();
            });
            addButton("Build (←)", panelX + panelWidth - 184, buttonY, 88, this::startBuild);
            addButton("Back", panelX + panelWidth - 88, buttonY, 76, this::goBack);
        }
    }

    private void addButton(String label, int x, int y, int width, Runnable action) {
        addRenderableWidget(Button.builder(Component.literal(label), button -> action.run())
                .bounds(x, y, Math.max(1, width), 20).build());
    }

    private void reloadFiles() {
        try {
            Files.createDirectories(folder);
            try (Stream<Path> stream = Files.walk(folder, 8)) {
                files = stream.filter(Files::isRegularFile)
                        .filter(path -> isSupported(path))
                        .sorted(Comparator.comparing(path -> folder.relativize(path).toString()
                                .replace('\\', '/').toLowerCase(Locale.ROOT)))
                        .toList();
            }
            status = files.size() + " supported schematic file(s) found (.litematic, .schem, .schematic, .nbt).";
        } catch (IOException exception) {
            files = List.of();
            status = "Could not scan schematics folder: " + exception.getMessage();
        }
    }

    private List<Path> filteredFiles() {
        String query = searchText == null ? "" : searchText.trim().toLowerCase(Locale.ROOT);
        if (query.isEmpty()) return files;
        return files.stream().filter(path -> folder.relativize(path).toString()
                .replace('\\', '/').toLowerCase(Locale.ROOT).contains(query)).toList();
    }

    private void select(Path file) {
        selected = file;
        status = "Loading and anchoring " + folder.relativize(file).toString().replace('\\', '/') + "…";
        SchematicBuilder.load(file, this.minecraft, message -> status = message);
    }

    private void startBuild() {
        if (SchematicBuilder.startBuild(this.minecraft)) {
            if (this.minecraft != null) this.minecraft.gui.setScreen(parent);
        } else {
            status = SchematicBuilder.status();
        }
    }

    private void goBack() {
        if (this.minecraft != null) this.minecraft.gui.setScreen(parent);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == GLFW.GLFW_KEY_LEFT && SchematicBuilder.hasPreview()
                && (searchBox == null || !searchBox.isFocused())) {
            startBuild();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mouseX = event.x();
        double mouseY = event.y();
        if (event.button() == 0 && mouseX >= panelX + 8 && mouseX <= panelX + panelWidth - 8
                && mouseY >= listTop && mouseY < listBottom) {
            int row = (int) ((mouseY - listTop) / rowHeight);
            int index = scrollOffset + row;
            List<Path> filtered = filteredFiles();
            if (row >= 0 && row < visibleRows && index >= 0 && index < filtered.size()) {
                select(filtered.get(index));
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (mouseX >= panelX + 8 && mouseX <= panelX + panelWidth - 8
                && mouseY >= listTop && mouseY < listBottom) {
            int max = Math.max(0, filteredFiles().size() - visibleRows);
            scrollOffset = Math.max(0, Math.min(max, scrollOffset + (verticalAmount > 0 ? -3 : 3)));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void onClose() { goBack(); }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        graphics.fill(0, 0, width, height, 0xB0000000);
        graphics.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xFF17130F);
        graphics.fill(panelX + 2, panelY + 2, panelX + panelWidth - 2, panelY + panelHeight - 2, 0xFF30261C);
        graphics.fill(panelX + 4, panelY + 4, panelX + panelWidth - 4, panelY + 31, 0xFF44301F);
        graphics.fill(panelX + 4, panelY + 4, panelX + panelWidth - 4, panelY + 5, 0xFFFFD36B);
        graphics.text(font, "NOTECLIENT  /  SCHEMATIC LIBRARY", panelX + 12, panelY + 13, 0xFFFFE08A, true);
        graphics.text(font, "LITEMATIC / SPONGE / LEGACY / VANILLA NBT  •  LEFT ARROW BUILDS",
                panelX + 12, panelY + 34, 0xFFBDB09B, false);
        graphics.fill(panelX + 8, listTop - 2, panelX + panelWidth - 8, listBottom + 2, 0xFF171717);
        List<Path> filtered = filteredFiles();
        if (filtered.isEmpty()) {
            graphics.text(font, "No supported schematic files found.", panelX + 18, listTop + 12, 0xFFFFD36B, true);
            graphics.text(font, "Drop .litematic, .schem, .schematic or .nbt files into:", panelX + 18, listTop + 30, 0xFFBFB8AC, false);
            graphics.text(font, folder.toAbsolutePath().toString(), panelX + 18, listTop + 45, 0xFFE4D6BE, false);
        } else {
            int end = Math.min(filtered.size(), scrollOffset + visibleRows);
            for (int i = scrollOffset; i < end; i++) {
                Path file = filtered.get(i);
                int row = i - scrollOffset;
                int y = listTop + row * rowHeight;
                boolean hovered = mouseX >= panelX + 8 && mouseX <= panelX + panelWidth - 8
                        && mouseY >= y && mouseY < y + rowHeight;
                boolean isSelected = file.equals(selected);
                int color = isSelected ? 0xFF5A482B : hovered ? 0xFF59432B
                        : row % 2 == 0 ? 0xFF292929 : 0xFF222222;
                graphics.fill(panelX + 10, y, panelX + panelWidth - 10, y + rowHeight - 1, color);
                String name = folder.relativize(file).toString().replace('\\', '/');
                graphics.text(font, clip(name, panelWidth - 42), panelX + 18, y + 4,
                        isSelected ? 0xFFFFE08A : 0xFFF0F0F0, true);
                graphics.text(font, extension(file) + "  •  " + fileSize(file), panelX + 18, y + 15, 0xFFB9B9B9, false);
            }
        }
        int countY = panelY + panelHeight - 40;
        graphics.text(font, "Preview: " + (SchematicBuilder.hasPreview() ? SchematicBuilder.previewName() : "none"),
                panelX + 14, countY, 0xFFE6D6B9, true);
        graphics.text(font, clip(status, panelWidth - 28), panelX + 14, countY + 13, 0xFFBDB09B, false);
        super.extractRenderState(graphics, mouseX, mouseY, delta);
    }

    private boolean isSupported(Path path) {
        String name = path.getFileName().toString().toLowerCase(Locale.ROOT);
        return name.endsWith(".litematic") || name.endsWith(".schem")
                || name.endsWith(".schematic") || name.endsWith(".nbt");
    }

    private String extension(Path path) {
        String name = path.getFileName().toString();
        int dot = name.lastIndexOf('.');
        return dot < 0 ? "unknown" : name.substring(dot);
    }

    private String fileSize(Path path) {
        try {
            long bytes = Files.size(path);
            return bytes >= 1_048_576 ? String.format(Locale.ROOT, "%.1f MiB", bytes / 1_048_576.0)
                    : String.format(Locale.ROOT, "%.0f KiB", bytes / 1024.0);
        } catch (IOException ignored) {
            return "size unavailable";
        }
    }

    private String clip(String value, int maxWidth) {
        if (value == null || font.width(value) <= maxWidth) return value == null ? "" : value;
        String candidate = value;
        while (!candidate.isEmpty() && font.width(candidate + "…") > maxWidth) {
            candidate = candidate.substring(0, candidate.length() - 1);
        }
        return candidate + "…";
    }
}
