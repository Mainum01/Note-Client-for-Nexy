package dev.noteclient;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

/** Client-side build preferences shared by the Builder page and scan screen. */
public final class BuilderPreferences {
    private static volatile boolean customAnchor;
    private static volatile int anchorX;
    private static volatile int anchorY;
    private static volatile int anchorZ;
    private static volatile boolean replaceExisting;

    private BuilderPreferences() {}

    public static void usePlayerAnchor(Minecraft client) {
        if (client == null || client.player == null) return;
        BlockPos pos = client.player.blockPosition();
        anchorX = pos.getX();
        anchorY = pos.getY();
        anchorZ = pos.getZ();
        customAnchor = false;
    }

    public static boolean setCustomAnchor(String x, String y, String z) {
        try {
            int parsedX = Integer.parseInt(x.trim());
            int parsedY = Integer.parseInt(y.trim());
            int parsedZ = Integer.parseInt(z.trim());
            if (Math.abs((long) parsedX) > 30_000_000L || parsedY < -2048 || parsedY > 4096
                    || Math.abs((long) parsedZ) > 30_000_000L) return false;
            anchorX = parsedX;
            anchorY = parsedY;
            anchorZ = parsedZ;
            customAnchor = true;
            return true;
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    public static BlockPos resolveAnchor(Minecraft client) {
        if (customAnchor) return new BlockPos(anchorX, anchorY, anchorZ);
        if (client != null && client.player != null) return client.player.blockPosition();
        return BlockPos.ZERO;
    }

    public static boolean isCustomAnchor() { return customAnchor; }
    public static int anchorX(Minecraft client) { return resolveAnchor(client).getX(); }
    public static int anchorY(Minecraft client) { return resolveAnchor(client).getY(); }
    public static int anchorZ(Minecraft client) { return resolveAnchor(client).getZ(); }

    public static boolean replaceExisting() { return replaceExisting; }
    public static void setReplaceExisting(boolean value) { replaceExisting = value; }


}
