package dev.noteclient;

import dev.noteclient.network.BuildProgressPayload;

/** Client-visible status for the server-side builder and playback job. */
public final class BuildClientState {
    private static volatile int placed;
    private static volatile int total;
    private static volatile int skippedSlots;
    private static volatile int layer;
    private static volatile boolean finished;
    private static volatile boolean paused;
    private static volatile String message = "";

    private BuildClientState() {}

    public static void reset(String initialMessage) {
        placed = 0;
        total = 0;
        skippedSlots = 0;
        layer = 0;
        finished = false;
        paused = false;
        message = initialMessage == null ? "" : initialMessage;
    }

    public static void accept(BuildProgressPayload payload) {
        placed = payload.placed();
        total = payload.total();
        skippedSlots = payload.skippedSlots();
        layer = payload.layer();
        finished = payload.finished();
        paused = payload.paused();
        message = payload.message();
        NoteClientHud.show(payload.message());
    }


    /** Updates the HUD state for the client-only vanilla-server builder. */
    public static void updateLocal(int nextPlaced, int nextTotal, int nextSkipped, int nextLayer,
                                   boolean nextFinished, boolean nextPaused, String nextMessage) {
        updateLocalInternal(nextPlaced, nextTotal, nextSkipped, nextLayer,
                nextFinished, nextPaused, nextMessage, true);
    }

    /** Updates the visible progress text without creating another HUD toast. */
    public static void updateLocalQuietly(int nextPlaced, int nextTotal, int nextSkipped, int nextLayer,
                                          boolean nextFinished, boolean nextPaused, String nextMessage) {
        updateLocalInternal(nextPlaced, nextTotal, nextSkipped, nextLayer,
                nextFinished, nextPaused, nextMessage, false);
    }

    private static void updateLocalInternal(int nextPlaced, int nextTotal, int nextSkipped, int nextLayer,
                                            boolean nextFinished, boolean nextPaused, String nextMessage,
                                            boolean showHud) {
        placed = Math.max(0, nextPlaced);
        total = Math.max(0, nextTotal);
        skippedSlots = Math.max(0, nextSkipped);
        layer = Math.max(0, nextLayer);
        finished = nextFinished;
        paused = nextPaused;
        message = nextMessage == null ? "" : nextMessage;
        if (showHud && nextMessage != null && !nextMessage.isBlank()) NoteClientHud.show(nextMessage);
    }

    public static int placed() { return placed; }
    public static int total() { return total; }
    public static int skippedSlots() { return skippedSlots; }
    public static int layer() { return layer; }
    public static boolean finished() { return finished; }
    public static boolean paused() { return paused; }
    public static String message() { return message; }

    /** True while a build/song is active, or while a persistent fallback grid is retained. */
    public static boolean hasArrangement() {
        return total > 0 && layer > 0 && (!finished || layer == 4 || layer == 5);
    }

    public static int percent() {
        if (finished) return 100;
        if (total <= 0) return 0;
        return Math.max(0, Math.min(100, (int) ((placed * 100L) / total)));
    }
}
