package dev.noteclient;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Persistent client preferences plus a temporary, server-specific reach planning hint. */
public final class NoteClientConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("noteclient.properties");
    private static final int MIN_BUILD_ACTIONS = 1;
    private static final int MAX_BUILD_ACTIONS = 128;
    private static final int MIN_TUNE_ACTIONS = 1;
    private static final int MAX_TUNE_ACTIONS = 4096;
    private static final int[] PLAYBACK_PRESETS = {1, 2, 3, 4};

    private static volatile boolean hudEnabled = true;
    private static volatile int buildActionsPerTick = 16;
    private static volatile int tuningActionsPerTick = 2048;
    private static volatile int playbackAttacksPerTick = 4;
    // 0 = use server-synchronized reach; 100 = the user requested /reach 100.
    private static volatile int serverReachOverride = 0;

    private NoteClientConfig() {}

    public static void load() {
        Properties properties = new Properties();
        if (Files.isRegularFile(FILE)) {
            try (InputStream input = Files.newInputStream(FILE)) {
                properties.load(input);
            } catch (IOException exception) {
                System.err.println("[NoteClient] Could not read preferences: " + exception.getMessage());
            }
        }
        hudEnabled = Boolean.parseBoolean(properties.getProperty("hud.enabled", "true"));
        int configVersion = parseInt(properties, "config.version", 0);
        int storedBuildRate = parseInt(properties, "performance.buildActionsPerTick", 16);
        if (configVersion < 3 && storedBuildRate == 3) storedBuildRate = 4;
        int storedTuneRate = parseInt(properties, "performance.tuneActionsPerTick", 2048);
        if (storedTuneRate < 0) storedTuneRate = 2048;

        // v5 and earlier only offered low build/tune presets. Upgrade those old
        // defaults to the new publication defaults once, while preserving users'
        // deliberately customized values above the old preset range.
        if (configVersion < 7) {
            if (storedBuildRate <= 8) storedBuildRate = 16;
            if (storedTuneRate <= 144) storedTuneRate = 2048;
        }
        buildActionsPerTick = clamp(storedBuildRate, MIN_BUILD_ACTIONS, MAX_BUILD_ACTIONS);
        tuningActionsPerTick = clamp(storedTuneRate, MIN_TUNE_ACTIONS, MAX_TUNE_ACTIONS);
        playbackAttacksPerTick = clampPreset(
                parseInt(properties, "performance.playbackAttacksPerTick", 4), PLAYBACK_PRESETS);

        // Custom reach is session/server-specific and is intentionally never
        // restored from disk. It resets on disconnect to avoid carrying a 100
        // block assumption onto an unrelated server.
        serverReachOverride = 0;
        save();
    }

    public static void save() {
        Properties properties = new Properties();
        properties.setProperty("config.version", "7");
        properties.setProperty("hud.enabled", Boolean.toString(hudEnabled));
        properties.setProperty("performance.buildActionsPerTick", Integer.toString(buildActionsPerTick));
        properties.setProperty("performance.tuneActionsPerTick", Integer.toString(tuningActionsPerTick));
        properties.setProperty("performance.playbackAttacksPerTick", Integer.toString(playbackAttacksPerTick));
        properties.setProperty("safety.userInitiatedReachCommandOnly", "true");
        properties.setProperty("safety.serverValidatesEveryInteraction", "true");
        try {
            Files.createDirectories(FILE.getParent());
            try (OutputStream output = Files.newOutputStream(FILE)) {
                properties.store(output,
                        "NoteClient client preferences. Safety settings are enforced and cannot be disabled.");
            }
        } catch (IOException exception) {
            System.err.println("[NoteClient] Could not save preferences: " + exception.getMessage());
        }
    }

    public static boolean hudEnabled() { return hudEnabled; }
    public static void setHudEnabled(boolean enabled) {
        hudEnabled = enabled;
        save();
    }

    /** Global maximum number of placement/removal actions a builder may issue per tick. */
    public static int buildActionsPerTick() { return buildActionsPerTick; }
    public static void setBuildActionsPerTick(int value) {
        buildActionsPerTick = clamp(value, MIN_BUILD_ACTIONS, MAX_BUILD_ACTIONS);
        save();
    }

    /** Global maximum number of ordinary note-block interactions the tuner may issue per tick. */
    public static int tuningActionsPerTick() { return tuningActionsPerTick; }
    public static void setTuningActionsPerTick(int value) {
        tuningActionsPerTick = clamp(value, MIN_TUNE_ACTIONS, MAX_TUNE_ACTIONS);
        save();
    }

    /** A one-tick confirmation grace keeps tuning responsive without assuming acceptance. */
    public static int tuningConfirmationTicks() { return 1; }
    /** A complete 25-pitch cycle needs at most 24 clicks from any starting pitch. */
    public static int tuningBatchSize() { return 24; }

    public static int playbackAttacksPerTick() { return playbackAttacksPerTick; }
    public static int serverReachOverride() { return serverReachOverride; }

    public static void setServerReachOverride(int reach) {
        serverReachOverride = reach == 100 ? 100 : 0;
    }

    public static int nextPlaybackAttacksPerTick() {
        playbackAttacksPerTick = nextPreset(playbackAttacksPerTick, PLAYBACK_PRESETS);
        save();
        return playbackAttacksPerTick;
    }

    public static void resetDefaults() {
        hudEnabled = true;
        buildActionsPerTick = 16;
        tuningActionsPerTick = 2048;
        playbackAttacksPerTick = 4;
        serverReachOverride = 0;
        save();
    }

    private static int parseInt(Properties properties, String key, int fallback) {
        try {
            return Integer.parseInt(properties.getProperty(key, Integer.toString(fallback)).trim());
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }

    private static int clamp(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private static int clampPreset(int value, int[] presets) {
        int best = presets[0];
        for (int preset : presets) {
            if (Math.abs(preset - value) < Math.abs(best - value)) best = preset;
        }
        return best;
    }

    private static int nextPreset(int current, int[] presets) {
        for (int i = 0; i < presets.length; i++) {
            if (presets[i] == current) return presets[(i + 1) % presets.length];
        }
        return presets[0];
    }
}
