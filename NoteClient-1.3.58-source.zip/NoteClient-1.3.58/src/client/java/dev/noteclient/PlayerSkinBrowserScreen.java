package dev.noteclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** Searchable picker for PNG skins in the profile's NoteClient folder and vanilla presets. */
public final class PlayerSkinBrowserScreen extends Screen {
    public enum Mode { PNG_FILES, PRESETS, ONLINE_PLAYERS }

    private final Screen parent;
    private Mode mode;
    private String searchText;
    private List<SkinEntry> allEntries = List.of();
    private int scrollOffset;

    private int panelX;
    private int panelY;
    private int panelWidth;
    private int panelHeight;
    private int listTop;
    private int listBottom;
    private int rowHeight;
    private int visibleRows;
    private EditBox searchBox;

    public PlayerSkinBrowserScreen(Screen parent, Mode mode) {
        this(parent, mode, "");
    }

    private PlayerSkinBrowserScreen(Screen parent, Mode mode, String searchText) {
        super(Component.literal("NoteClient Skin Library"));
        this.parent = parent;
        this.mode = mode == null ? Mode.PNG_FILES : mode;
        this.searchText = searchText == null ? "" : searchText;
    }

    @Override
    protected void init() {
        panelWidth = Math.max(1, Math.min(720, width - 18));
        panelHeight = Math.max(1, Math.min(520, height - 18));
        panelX = (width - panelWidth) / 2;
        panelY = (height - panelHeight) / 2;

        reloadEntries();

        int tabsY = panelY + 36;
        int gap = 4;
        int tabWidth = Math.max(1, Math.min(132, (panelWidth - 150 - 28 - gap * 2) / 3));
        addButton("PNG FILES", panelX + 12, tabsY, tabWidth, () -> switchMode(Mode.PNG_FILES));
        addButton("PRESETS", panelX + 12 + tabWidth + gap,
                tabsY, tabWidth, () -> switchMode(Mode.PRESETS));
        addButton("SERVER PLAYERS", panelX + 12 + (tabWidth + gap) * 2,
                tabsY, tabWidth, () -> switchMode(Mode.ONLINE_PLAYERS));
        addButton("Refresh", panelX + panelWidth - 88, tabsY, 76, this::reloadEntries);

        searchBox = new EditBox(font, panelX + 12, panelY + 61,
                Math.max(1, panelWidth - 24), 19, Component.literal("Search skins"));
        searchBox.setMaxLength(160);
        searchBox.setValue(searchText);
        searchBox.setHint(Component.literal(switch (mode) {
            case PNG_FILES -> "Search PNG file names and folders…";
            case PRESETS -> "Search the nine vanilla character skins…";
            case ONLINE_PLAYERS -> "Search player names…";
        }));
        searchBox.setResponder(value -> {
            searchText = value;
            scrollOffset = 0;
        });
        addRenderableWidget(searchBox);

        listTop = panelY + 89;
        listBottom = panelY + panelHeight - 35;
        int availableHeight = Math.max(1, listBottom - listTop);
        rowHeight = Math.max(22, Math.min(28, availableHeight / 12));
        visibleRows = Math.max(1, availableHeight / rowHeight);

        addButton("Copy Skins Folder", panelX + 12, panelY + panelHeight - 25, 132, () -> {
            Minecraft client = this.minecraft;
            if (client != null) {
                client.keyboardHandler.setClipboard(PlayerStatueBuilder.skinsFolder().toAbsolutePath().toString());
                NoteClientHud.show("Copied the profile's NoteClient/skins folder path.");
            }
        });
        addButton("Back", panelX + panelWidth - 78, panelY + panelHeight - 25, 66, this::goBack);
    }

    private void addButton(String label, int x, int y, int buttonWidth, Runnable action) {
        addRenderableWidget(Button.builder(Component.literal(label), button -> action.run())
                .bounds(x, y, Math.max(1, buttonWidth), 18).build());
    }

    private void switchMode(Mode next) {
        if (next == mode || this.minecraft == null) return;
        this.minecraft.gui.setScreen(new PlayerSkinBrowserScreen(parent, next, searchText));
    }

    private void reloadEntries() {
        if (mode == Mode.PNG_FILES) {
            Path root = PlayerStatueBuilder.skinsFolder().toAbsolutePath().normalize();
            List<SkinEntry> entries = new ArrayList<>();
            for (Path file : PlayerStatueBuilder.listSkinFiles()) {
                String relative = root.relativize(file.toAbsolutePath().normalize())
                        .toString().replace('\\', '/');
                entries.add(new SkinEntry(relative, "PNG skin file", file, null, null, null));
            }
            allEntries = List.copyOf(entries);
        } else if (mode == Mode.PRESETS) {
            List<SkinEntry> entries = new ArrayList<>();
            for (String name : PlayerStatueBuilder.defaultSkinNames()) {
                String armType = PlayerStatueBuilder.defaultSkinUsesSlimArms(name)
                        ? "Slim arms" : "Classic arms";
                entries.add(new SkinEntry(name, "Vanilla preset • " + armType, null, name, null, null));
            }
            allEntries = List.copyOf(entries);
        } else {
            List<SkinEntry> entries = new ArrayList<>();
            for (PlayerStatueBuilder.OnlinePlayer player : PlayerStatueBuilder.onlinePlayers(this.minecraft)) {
                entries.add(new SkinEntry(player.username(),
                        "Online player • " + player.latencyMs() + " ms ping • server skin profile",
                        null, null, player.id(), player.username(), player.textureProperty()));
            }
            allEntries = List.copyOf(entries);
        }
        scrollOffset = 0;
    }

    private List<SkinEntry> filteredEntries() {
        String query = searchText == null ? "" : searchText.trim().toLowerCase(Locale.ROOT);
        if (query.isEmpty()) return allEntries;
        return allEntries.stream().filter(entry ->
                entry.label.toLowerCase(Locale.ROOT).contains(query)
                        || entry.detail.toLowerCase(Locale.ROOT).contains(query)).toList();
    }

    private void select(SkinEntry entry) {
        Minecraft client = this.minecraft;
        if (client == null) return;
        if (entry.file != null) {
            PlayerStatueBuilder.loadSkinFile(client, entry.file);
        } else if (entry.preset != null) {
            PlayerStatueBuilder.loadDefaultSkin(client, entry.preset);
        } else if (entry.onlinePlayerId != null && entry.onlinePlayerName != null) {
            PlayerStatueBuilder.lookupOnlinePlayer(client, entry.onlinePlayerId,
                    entry.onlinePlayerName, entry.textureProperty);
        }
        client.gui.setScreen(parent);
    }

    private void goBack() {
        if (this.minecraft != null) this.minecraft.gui.setScreen(parent);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mouseX = event.x();
        double mouseY = event.y();
        if (event.button() == 0 && mouseX >= panelX + 8 && mouseX <= panelX + panelWidth - 8
                && mouseY >= listTop && mouseY < listBottom) {
            int row = (int) ((mouseY - listTop) / rowHeight);
            int index = scrollOffset + row;
            List<SkinEntry> filtered = filteredEntries();
            if (row >= 0 && row < visibleRows && index >= 0 && index < filtered.size()) {
                select(filtered.get(index));
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (mouseX >= panelX + 8 && mouseX <= panelX + panelWidth - 8
                && mouseY >= listTop && mouseY < listBottom) {
            int max = Math.max(0, filteredEntries().size() - visibleRows);
            scrollOffset = Math.max(0, Math.min(max, scrollOffset + (verticalAmount > 0 ? -3 : 3)));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void onClose() {
        goBack();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        graphics.fill(0, 0, width, height, 0xA8000000);
        graphics.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xFF17130F);
        graphics.fill(panelX + 2, panelY + 2, panelX + panelWidth - 2, panelY + panelHeight - 2, 0xFF30261C);
        graphics.fill(panelX + 4, panelY + 4, panelX + panelWidth - 4, panelY + 29, 0xFF44301F);
        graphics.fill(panelX + 4, panelY + 4, panelX + panelWidth - 4, panelY + 5, 0xFFFFD36B);
        graphics.text(font, "NOTECLIENT  /  PLAYER SKINS", panelX + 12, panelY + 12, 0xFFFFE08A, true);
        String sectionTitle = switch (mode) {
            case PNG_FILES -> "PROFILE PNG LIBRARY";
            case PRESETS -> "VANILLA CHARACTER PRESETS";
            case ONLINE_PLAYERS -> "PLAYERS CURRENTLY LISTED BY THE SERVER";
        };
        graphics.text(font, sectionTitle, panelX + 12, panelY + 82, 0xFFFFD36B, true);

        graphics.fill(panelX + 8, listTop - 2, panelX + panelWidth - 8, listBottom + 2, 0xFF171717);
        List<SkinEntry> filtered = filteredEntries();
        if (filtered.isEmpty()) {
            String message = switch (mode) {
                case PNG_FILES -> "No PNG skins found. Put skin PNG files in " + PlayerStatueBuilder.skinsFolder();
                case PRESETS -> "No presets matched that search.";
                case ONLINE_PLAYERS -> this.minecraft == null || this.minecraft.getConnection() == null
                        ? "Join a multiplayer server to see its player list."
                        : "No online players matched that search. Press Refresh to rescan the server list.";
            };
            drawWrapped(graphics, message, panelX + 18, listTop + 12, panelWidth - 36, 12, 4, 0xFFBDBDBD);
        } else {
            int end = Math.min(filtered.size(), scrollOffset + visibleRows);
            for (int index = scrollOffset; index < end; index++) {
                SkinEntry entry = filtered.get(index);
                int row = index - scrollOffset;
                int y = listTop + row * rowHeight;
                boolean hovered = mouseX >= panelX + 8 && mouseX <= panelX + panelWidth - 8
                        && mouseY >= y && mouseY < y + rowHeight;
                graphics.fill(panelX + 10, y, panelX + panelWidth - 10, y + rowHeight - 1,
                        hovered ? 0xFF59432B : (row % 2 == 0 ? 0xFF292929 : 0xFF222222));
                graphics.text(font, clip(entry.label, panelWidth - 54), panelX + 18, y + 4,
                        hovered ? 0xFFFFE08A : 0xFFF0F0F0, true);
                graphics.text(font, clip(entry.detail, panelWidth - 54), panelX + 18, y + 15,
                        0xFFB9B9B9, false);
            }
        }

        int countY = panelY + panelHeight - 43;
        int shownStart = filtered.isEmpty() ? 0 : scrollOffset + 1;
        int shownEnd = Math.min(filtered.size(), scrollOffset + visibleRows);
        graphics.text(font, shownStart + "–" + shownEnd + " of " + filtered.size(),
                panelX + panelWidth - 112, countY, 0xFFBDB09B, false);
        super.extractRenderState(graphics, mouseX, mouseY, delta);
    }

    private String clip(String value, int maxWidth) {
        if (value == null || font.width(value) <= maxWidth) return value == null ? "" : value;
        String candidate = value;
        while (!candidate.isEmpty() && font.width(candidate + "…") > maxWidth) {
            candidate = candidate.substring(0, candidate.length() - 1);
        }
        return candidate + "…";
    }

    private void drawWrapped(GuiGraphicsExtractor graphics, String text, int x, int y,
                             int maxWidth, int lineHeight, int maxLines, int color) {
        if (text == null || text.isBlank() || maxWidth <= 0 || maxLines <= 0) return;
        StringBuilder line = new StringBuilder();
        int lines = 0;
        for (String word : text.split("\\s+")) {
            String next = line.isEmpty() ? word : line + " " + word;
            if (font.width(next) > maxWidth && !line.isEmpty()) {
                graphics.text(font, line.toString(), x, y + lines * lineHeight, color, false);
                lines++;
                line.setLength(0);
                line.append(word);
                if (lines >= maxLines) return;
            } else {
                line.setLength(0);
                line.append(next);
            }
        }
        if (!line.isEmpty() && lines < maxLines) {
            graphics.text(font, line.toString(), x, y + lines * lineHeight, color, false);
        }
    }

    private record SkinEntry(String label, String detail, Path file, String preset,
                             UUID onlinePlayerId, String onlinePlayerName, String textureProperty) {
        private SkinEntry(String label, String detail, Path file, String preset,
                          UUID onlinePlayerId, String onlinePlayerName) {
            this(label, detail, file, preset, onlinePlayerId, onlinePlayerName, null);
        }
    }
}
