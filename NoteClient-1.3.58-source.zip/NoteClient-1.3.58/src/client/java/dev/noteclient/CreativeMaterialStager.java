package dev.noteclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.level.GameType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Stocks the player's real Creative inventory with the materials used by a
 * client-side build. Existing stacks are topped up; empty slots are used for
 * new materials; unrelated inventory contents are never overwritten.
 *
 * This intentionally uses vanilla Creative inventory updates. A remote server
 * remains authoritative and may reject them, just as it can reject any other
 * Creative inventory update.
 */
public final class CreativeMaterialStager {
    private CreativeMaterialStager() {}

    public static Result stage(Minecraft client, Map<Item, Integer> requestedMaterials) {
        if (client == null || client.player == null || client.gameMode == null
                || client.gameMode.getPlayerMode() != GameType.CREATIVE) {
            return new Result(0, 0, 0, 0);
        }
        if (requestedMaterials == null || requestedMaterials.isEmpty()) {
            return new Result(0, 0, 0, 0);
        }

        LocalPlayer player = client.player;
        List<Map.Entry<Item, Integer>> materials = new ArrayList<>(requestedMaterials.entrySet());
        // Allocate inventory capacity to the most-used materials first.
        materials.sort(Comparator
                .<Map.Entry<Item, Integer>>comparingInt(entry -> entry.getValue() == null ? 0 : entry.getValue())
                .reversed());

        List<Integer> emptySlots = new ArrayList<>();
        for (int slot = 0; slot < 36; slot++) {
            if (player.getInventory().getItem(slot).isEmpty()) emptySlots.add(slot);
        }

        List<Grant> grants = new ArrayList<>();
        int addedTypes = 0;
        int alreadyStockedTypes = 0;
        int unableToFitTypes = 0;

        for (Map.Entry<Item, Integer> material : materials) {
            Item item = material.getKey();
            if (item == null || item == Items.AIR) continue;

            int requiredCount = Math.max(1, material.getValue() == null ? 1 : material.getValue());
            int missing = Math.max(0, requiredCount - countItem(player, item));
            if (missing == 0) {
                alreadyStockedTypes++;
                continue;
            }

            boolean addedThisType = false;
            int maxStack = Math.max(1, new ItemStack(item).getMaxStackSize());

            // Fill every existing partial stack before using a new slot.
            for (int slot = 0; slot < 36 && missing > 0; slot++) {
                ItemStack existing = player.getInventory().getItem(slot);
                if (!existing.is(item) || existing.getCount() >= maxStack) continue;
                int add = Math.min(missing, maxStack - existing.getCount());
                ItemStack toppedUp = existing.copy();
                toppedUp.setCount(existing.getCount() + add);
                grants.add(new Grant(slot, toppedUp));
                missing -= add;
                addedThisType = true;
            }

            // Large builds can need several full stacks of the same block.
            while (missing > 0 && !emptySlots.isEmpty()) {
                int slot = emptySlots.remove(0);
                int amount = Math.min(missing, maxStack);
                grants.add(new Grant(slot, new ItemStack(item, amount)));
                missing -= amount;
                addedThisType = true;
            }

            if (addedThisType) addedTypes++;
            if (missing > 0) unableToFitTypes++;
        }

        // Apply only after the plan is complete; unrelated inventory contents
        // are never overwritten, and each requested type receives its full
        // required count whenever the player has enough free inventory space.
        for (Grant grant : grants) {
            player.getInventory().setItem(grant.inventorySlot, grant.stack.copy());
            int menuSlot = grant.inventorySlot < 9 ? 36 + grant.inventorySlot : grant.inventorySlot;
            client.gameMode.handleCreativeModeItemAdd(grant.stack.copy(), menuSlot);
        }

        return new Result(requestedMaterials.size(), addedTypes, alreadyStockedTypes, unableToFitTypes);
    }

    private static int countItem(LocalPlayer player, Item item) {
        int count = 0;
        for (int slot = 0; slot < 36; slot++) {
            ItemStack stack = player.getInventory().getItem(slot);
            if (stack.is(item)) count += stack.getCount();
        }
        return count;
    }

    public record Result(int requestedTypes, int addedTypes, int alreadyStockedTypes, int unableToFitTypes) {
        public String summary() {
            if (requestedTypes <= 0) return "no extra materials needed";
            StringBuilder text = new StringBuilder("inventory: ")
                    .append(addedTypes).append(" material type(s) added")
                    .append(", ").append(alreadyStockedTypes).append(" already stocked");
            if (unableToFitTypes > 0) {
                text.append(", ").append(unableToFitTypes)
                        .append(" could not fit (free inventory slots to collect the rest)");
            }
            return text.toString();
        }
    }

    private record Grant(int inventorySlot, ItemStack stack) {}
}
