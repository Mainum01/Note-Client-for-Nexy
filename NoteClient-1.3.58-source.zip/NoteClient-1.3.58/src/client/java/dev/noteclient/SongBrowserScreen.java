package dev.noteclient;

import dev.noteclient.network.BuildControlPayload;
import dev.noteclient.network.BuildRequestPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/** Minecraft-styled, size-aware NoteClient control center. */
public final class SongBrowserScreen extends Screen {
    private static final int MAX_VISIBLE_SONGS = 10;

    private final Screen parent;
    private final Tab tab;
    private final Path songsFolder;

    private List<Path> songs = List.of();
    private String folderError;
    private String searchText = "";
    private int scrollOffset;

    private int panelX;
    private int panelY;
    private int panelWidth;
    private int panelHeight;
    private boolean wideLayout;
    private int sidebarX;
    private int sidebarY;
    private int sidebarWidth;
    private int contentX;
    private int contentWidth;
    private int navY;
    private int pageTop;
    private int pageBottom;
    private int footerY;
    private int searchY;
    private int listTop;
    private int listBottom;
    private int countY;
    private int rowHeight;
    private int visibleRows;
    private int anchorCardY;

    private EditBox searchBox;
    private EditBox anchorXBox;
    private EditBox anchorYBox;
    private EditBox anchorZBox;
    private EditBox playerNameBox;
    private EditBox buildSpeedBox;
    private EditBox tuneSpeedBox;
    private boolean showAnchorControls;
    private boolean closingToGameplay;

    public SongBrowserScreen(Screen parent) {
        this(parent, Tab.LIBRARY, "");
    }

    private SongBrowserScreen(Screen parent, Tab tab, String searchText) {
        super(Component.literal("NoteClient"));
        this.parent = parent;
        this.tab = tab;
        this.searchText = searchText == null ? "" : searchText;
        this.songsFolder = NoteClient.getSongsFolder();
    }

    @Override
    protected void init() {
        panelWidth = Math.max(1, Math.min(900, width - 16));
        panelHeight = Math.max(1, Math.min(620, height - 16));
        panelX = (width - panelWidth) / 2;
        panelY = (height - panelHeight) / 2;

        // Large screens use a dedicated left navigation rail. Narrow or short
        // windows retain compact top tabs so content never gets squeezed below
        // the width needed by the controls.
        wideLayout = panelWidth >= 700 && panelHeight >= 360;
        sidebarX = panelX + 10;
        sidebarY = panelY + 47;
        sidebarWidth = wideLayout ? 118 : 0;
        contentX = panelX + (wideLayout ? 140 : 12);
        contentWidth = panelWidth - (wideLayout ? 152 : 24);

        navY = panelY + 39;
        pageTop = wideLayout ? panelY + 47 : navY + 25;
        footerY = panelY + panelHeight - 24;
        pageBottom = footerY - 8;

        loadSongs();

        // Aura is a global quick action in the oak title bar, available from
        // every page without adding another crowded navigation tab.
        addActionButton(AuraEffect.isActive() ? "Aura: ON" : "Aura: OFF",
                panelX + panelWidth - 86, panelY + 9, 76, () -> {
                    AuraEffect.toggle(this.minecraft);
                    refreshTab();
                });

        Tab[] destinations = Tab.values();
        if (wideLayout) {
            String[] labels = {"01  LIBRARY", "02  BUILDER", "03  PLAYER", "04  SETTINGS"};
            for (int i = 0; i < destinations.length; i++) {
                Tab destination = destinations[i];
                String label = (tab == destination ? "★ " : "   ") + labels[i];
                addRenderableWidget(Button.builder(Component.literal(label), button -> switchTab(destination))
                        .bounds(sidebarX + 6, sidebarY + 35 + i * 34, sidebarWidth - 12, 24).build());
            }
        } else {
            String[] labels = contentWidth < 300
                    ? new String[]{"Songs", "Build", "Player", "Opts"}
                    : new String[]{"Library", "Builder", "Player", "Settings"};
            int gap = 3;
            int navWidth = Math.max(1, (contentWidth - gap * 3) / 4);
            for (int i = 0; i < destinations.length; i++) {
                Tab destination = destinations[i];
                int x = contentX + i * (navWidth + gap);
                int w = i == destinations.length - 1
                        ? contentX + contentWidth - x : navWidth;
                String label = tab == destination ? "▶ " + labels[i] : labels[i];
                addRenderableWidget(Button.builder(Component.literal(label), button -> switchTab(destination))
                        .bounds(x, navY, Math.max(1, w), 20).build());
            }
        }

        if (tab == Tab.LIBRARY) {
            searchY = pageTop + 18;
            listTop = searchY + 22;
            countY = pageBottom - 14;
            listBottom = countY - 6;
            int availableListHeight = Math.max(1, listBottom - listTop);
            rowHeight = Math.max(12, Math.min(27, availableListHeight / MAX_VISIBLE_SONGS));
            visibleRows = Math.max(1, Math.min(MAX_VISIBLE_SONGS, availableListHeight / rowHeight));

            searchBox = new EditBox(font, contentX + 8, searchY, Math.max(1, contentWidth - 16), 18,
                    Component.literal("Search songs"));
            searchBox.setMaxLength(160);
            searchBox.setValue(searchText);
            searchBox.setHint(Component.literal("Search by song title or folder…"));
            searchBox.setResponder(value -> {
                searchText = value;
                scrollOffset = 0;
            });
            addRenderableWidget(searchBox);

            addFooterGroup(
                    new String[]{"Refresh", "Copy Path", "Schematics"},
                    new Runnable[]{() -> { loadSongs(); scrollOffset = 0; }, this::copySongsFolder,
                            () -> this.minecraft.gui.setScreen(new SchematicBrowserScreen(this))},
                    "Close", this::onClose);
        } else if (tab == Tab.BUILDER) {
            addFooterGroup(
                    new String[]{BuildClientState.paused() ? "Resume" : "Pause", "Cancel", "Destroy"},
                    new Runnable[]{() -> NoteClient.sendBuildControl(this.minecraft, BuildControlPayload.TOGGLE_PAUSE),
                            () -> NoteClient.sendBuildControl(this.minecraft, BuildControlPayload.CANCEL),
                            () -> NoteClient.sendBuildControl(this.minecraft, BuildControlPayload.DESTROY)},
                    "Library", () -> switchTab(Tab.LIBRARY));

            anchorCardY = pageBottom - 70;
            showAnchorControls = ClientPlayNetworking.canSend(BuildRequestPayload.TYPE)
                    && pageBottom - pageTop >= 265 && anchorCardY > pageTop + 185;
            if (showAnchorControls) {
                int left = contentX + 16;
                int fieldWidth = Math.max(42, Math.min(92, (contentWidth - 78) / 3));
                net.minecraft.core.BlockPos anchor = BuilderPreferences.resolveAnchor(this.minecraft);
                int fieldY = anchorCardY + 19;
                anchorXBox = new EditBox(font, left, fieldY, fieldWidth, 18, Component.literal("X"));
                anchorYBox = new EditBox(font, left + fieldWidth + 6, fieldY, fieldWidth, 18,
                        Component.literal("Y"));
                anchorZBox = new EditBox(font, left + (fieldWidth + 6) * 2, fieldY, fieldWidth, 18,
                        Component.literal("Z"));
                anchorXBox.setMaxLength(10);
                anchorYBox.setMaxLength(6);
                anchorZBox.setMaxLength(10);
                anchorXBox.setValue(Integer.toString(anchor.getX()));
                anchorYBox.setValue(Integer.toString(anchor.getY()));
                anchorZBox.setValue(Integer.toString(anchor.getZ()));
                addRenderableWidget(anchorXBox);
                addRenderableWidget(anchorYBox);
                addRenderableWidget(anchorZBox);

                int buttonY = anchorCardY + 43;
                int buttonW = Math.max(48, Math.min(82, (contentWidth - 34) / 3));
                addActionButton("Apply", left, buttonY, buttonW, () -> {
                    boolean valid = BuilderPreferences.setCustomAnchor(
                            anchorXBox.getValue(), anchorYBox.getValue(), anchorZBox.getValue());
                    if (valid) NoteClientHud.show("Server-companion anchor saved.");
                    else NoteClientHud.warn("Invalid anchor. X/Z must be within ±30,000,000 and Y between -2048 and 4096.");
                });
                addActionButton("Player Anchor", left + buttonW + 5, buttonY, buttonW, () -> {
                    BuilderPreferences.usePlayerAnchor(this.minecraft);
                    refreshTab();
                });
                addActionButton(BuilderPreferences.replaceExisting() ? "Replace ON" : "Replace OFF",
                        left + (buttonW + 5) * 2, buttonY, buttonW + 4, () -> {
                            BuilderPreferences.setReplaceExisting(!BuilderPreferences.replaceExisting());
                            refreshTab();
                        });
            }
        } else if (tab == Tab.PLAYER) {
            int inputY = pageTop + 20;
            int lookupButtonWidth = Math.max(52, Math.min(84, contentWidth / 4));
            int inputWidth = Math.max(48, contentWidth - lookupButtonWidth - 26);
            playerNameBox = new EditBox(font, contentX + 8, inputY, inputWidth, 18,
                    Component.literal("Java username"));
            playerNameBox.setMaxLength(16);
            playerNameBox.setValue(PlayerStatueBuilder.loadedUsername());
            playerNameBox.setHint(Component.literal("Enter Java username…"));
            addRenderableWidget(playerNameBox);
            addActionButton("Lookup Skin", contentX + 16 + inputWidth, inputY,
                    lookupButtonWidth, () -> PlayerStatueBuilder.lookup(this.minecraft, playerNameBox.getValue()));

            int skinButtonY = pageTop + 42;
            int skinGap = 4;
            int skinButtonW = Math.max(42, (contentWidth - 16 - skinGap * 4) / 5);
            int skinX = contentX + 8;
            addActionButton("My Skin", skinX, skinButtonY, skinButtonW,
                    () -> PlayerStatueBuilder.lookupSelf(this.minecraft));
            addActionButton("Browse PNGs", skinX + skinButtonW + skinGap, skinButtonY, skinButtonW,
                    () -> this.minecraft.gui.setScreen(new PlayerSkinBrowserScreen(this,
                            PlayerSkinBrowserScreen.Mode.PNG_FILES)));
            addActionButton("Presets", skinX + (skinButtonW + skinGap) * 2, skinButtonY, skinButtonW,
                    () -> this.minecraft.gui.setScreen(new PlayerSkinBrowserScreen(this,
                            PlayerSkinBrowserScreen.Mode.PRESETS)));
            addActionButton(PlayerStatueBuilder.slimArms() ? "Arms: Slim" : "Arms: Wide",
                    skinX + (skinButtonW + skinGap) * 3, skinButtonY, skinButtonW, () -> {
                        PlayerStatueBuilder.toggleArmModel(this.minecraft);
                        refreshTab();
                    });
            addActionButton("Skins Folder", skinX + (skinButtonW + skinGap) * 4, skinButtonY, skinButtonW,
                    () -> {
                        if (this.minecraft != null) {
                            PlayerStatueBuilder.initialize();
                            this.minecraft.keyboardHandler.setClipboard(PlayerStatueBuilder.skinsFolder().toAbsolutePath().toString());
                            NoteClientHud.show("Skins folder path copied. Add PNG files there, then use Browse PNGs.");
                        }
                    });
            if (PlayerStatueBuilder.isBuilding()) {
                addFooterGroup(new String[]{"BUILD", "RETRY", "UNDO", "STOP"},
                        new Runnable[]{() -> {
                                    if (PlayerStatueBuilder.startBuild(this.minecraft)) this.closeToGameplay();
                                },
                                () -> { PlayerStatueBuilder.retry(this.minecraft); this.closeToGameplay(); },
                                () -> { PlayerStatueBuilder.remove(this.minecraft); this.closeToGameplay(); },
                                () -> { PlayerStatueBuilder.cancel(this.minecraft); this.closeToGameplay(); }},
                        "CLOSE", this::onClose);
            } else {
                addFooterGroup(new String[]{"Build Statue", "Retry (R)", "Undo Last (O)"},
                        new Runnable[]{() -> {
                                    if (PlayerStatueBuilder.startBuild(this.minecraft)) this.closeToGameplay();
                                },
                                () -> { PlayerStatueBuilder.retry(this.minecraft); this.closeToGameplay(); },
                                () -> { PlayerStatueBuilder.remove(this.minecraft); this.closeToGameplay(); }},
                        "Close", this::onClose);
            }
        } else {
            int controlY = pageBottom - 65;
            int gapBetween = 5;
            int halfWidth = Math.max(1, (contentWidth - 18 - gapBetween) / 2);
            int secondX = contentX + 8 + halfWidth + gapBetween;

            buildSpeedBox = new EditBox(font, contentX + 8, controlY, halfWidth, 18,
                    Component.literal("Build actions per tick"));
            buildSpeedBox.setMaxLength(3);
            buildSpeedBox.setValue(Integer.toString(NoteClientConfig.buildActionsPerTick()));
            buildSpeedBox.setHint(Component.literal("Build actions/tick (1–128)"));
            addRenderableWidget(buildSpeedBox);

            tuneSpeedBox = new EditBox(font, secondX, controlY, halfWidth, 18,
                    Component.literal("Tune interactions per tick"));
            tuneSpeedBox.setMaxLength(4);
            tuneSpeedBox.setValue(Integer.toString(NoteClientConfig.tuningActionsPerTick()));
            tuneSpeedBox.setHint(Component.literal("Tune interactions/tick (1–4096)"));
            addRenderableWidget(tuneSpeedBox);

            addActionButton("Apply Speeds", contentX + 8, controlY + 22, halfWidth,
                    this::applyPerformanceSettings);
            addActionButton("Playback: " + NoteClientConfig.playbackAttacksPerTick(), secondX, controlY + 22,
                    halfWidth, () -> {
                        NoteClientConfig.nextPlaybackAttacksPerTick();
                        refreshTab();
                    });
            addActionButton("Request /reach 100", contentX + 8, controlY + 44,
                    halfWidth, this::requestServerReach100);
            addActionButton("Use Synced Reach", secondX, controlY + 44, halfWidth, () -> {
                NoteClientConfig.setServerReachOverride(0);
                NoteClientHud.show("Reach planning now uses the server-synchronized interaction range.");
                refreshTab();
            });

            addFooterGroup(new String[]{"Reset Defaults", "HUD: " + (NoteClientConfig.hudEnabled() ? "ON" : "OFF")},
                    new Runnable[]{() -> {
                        NoteClientConfig.resetDefaults();
                        NoteClientHud.setEnabled(NoteClientConfig.hudEnabled());
                        refreshTab();
                    }, () -> {
                        NoteClientConfig.setHudEnabled(!NoteClientConfig.hudEnabled());
                        NoteClientHud.setEnabled(NoteClientConfig.hudEnabled());
                        refreshTab();
                    }}, "Close", this::onClose);
        }
    }

    private void applyPerformanceSettings() {
        try {
            int buildRate = Integer.parseInt(buildSpeedBox == null ? "" : buildSpeedBox.getValue().trim());
            int tuneRate = Integer.parseInt(tuneSpeedBox == null ? "" : tuneSpeedBox.getValue().trim());
            if (buildRate < 1 || buildRate > 128) throw new NumberFormatException("Build speed must be 1–128.");
            if (tuneRate < 1 || tuneRate > 4096) throw new NumberFormatException("Tune speed must be 1–4096.");
            NoteClientConfig.setBuildActionsPerTick(buildRate);
            NoteClientConfig.setTuningActionsPerTick(tuneRate);
            NoteClientHud.show("Performance saved • build " + buildRate + "/tick • tune " + tuneRate + "/tick");
            refreshTab();
        } catch (NumberFormatException exception) {
            NoteClientHud.warn("Enter whole numbers: build 1–128 and tune 1–4096 interactions per tick.");
        }
    }

    private void requestServerReach100() {
        if (minecraft == null || minecraft.player == null || minecraft.player.connection == null) {
            NoteClientHud.warn("Join the server before requesting /reach 100.");
            return;
        }
        try {
            // This only runs from the user's explicit Settings button click.
            // The server must expose and accept the command; the client does not
            // grant itself permissions or alter the server's reach validation.
            minecraft.player.connection.sendCommand("reach 100");
            NoteClientConfig.setServerReachOverride(100);
            NoteClientHud.show("Requested /reach 100. NoteClient will plan up to 100 blocks; the server still decides which interactions are accepted.");
            refreshTab();
        } catch (RuntimeException exception) {
            NoteClientHud.warn("Could not send /reach 100: " + exception.getClass().getSimpleName());
        }
    }

    private void addFooterGroup(String[] labels, Runnable[] actions, String rightLabel, Runnable rightAction) {
        int left = contentX + 5;
        int rightWidth = Math.max(48, Math.min(76, contentWidth / 4));
        int gap = 4;
        int leftSpace = Math.max(1, contentWidth - rightWidth - 17);
        int eachWidth = Math.max(30, (leftSpace - gap * Math.max(0, labels.length - 1)) / labels.length);
        for (int i = 0; i < labels.length; i++) {
            int x = left + i * (eachWidth + gap);
            addActionButton(labels[i], x, footerY, eachWidth, actions[i]);
        }
        addActionButton(rightLabel, contentX + contentWidth - rightWidth - 5,
                footerY, rightWidth, rightAction);
    }

    private void addActionButton(String label, int x, int y, int buttonWidth, Runnable action) {
        int safeX = Math.max(panelX + 3, x);
        int safeWidth = Math.max(1, Math.min(buttonWidth, panelX + panelWidth - 5 - safeX));
        String fittedLabel = clip(label, Math.max(6, safeWidth - 12));
        addRenderableWidget(Button.builder(Component.literal(fittedLabel), button -> action.run())
                .bounds(safeX, y, safeWidth, 18).build());
    }

    private void loadSongs() {
        folderError = null;
        try {
            Files.createDirectories(songsFolder);
            try (Stream<Path> walk = Files.walk(songsFolder)) {
                songs = walk.filter(Files::isRegularFile)
                        .filter(path -> path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".nbs"))
                        .sorted(Comparator.comparing(path -> songsFolder.relativize(path).toString()
                                .toLowerCase(Locale.ROOT)))
                        .toList();
            }
        } catch (IOException exception) {
            songs = List.of();
            folderError = exception.getMessage() == null
                    ? exception.getClass().getSimpleName() : exception.getMessage();
        }
    }

    private void copySongsFolder() {
        if (this.minecraft == null) return;
        this.minecraft.keyboardHandler.setClipboard(songsFolder.toAbsolutePath().toString());
        NoteClientHud.show("Songs folder path copied to clipboard.");
    }

    private List<Path> filteredSongs() {
        String query = searchText.toLowerCase(Locale.ROOT).trim();
        if (query.isEmpty()) return songs;
        return songs.stream().filter(path -> songsFolder.relativize(path).toString()
                .replace('\\', '/').toLowerCase(Locale.ROOT).contains(query)).toList();
    }

    private void openSong(Path song) {
        boolean swapActiveArrangement = BuildClientState.hasArrangement();
        SongScanScreen scanScreen = new SongScanScreen(this, song, swapActiveArrangement);
        this.minecraft.gui.setScreen(scanScreen);
        scanScreen.beginScan();
    }

    private void switchTab(Tab next) {
        this.minecraft.gui.setScreen(new SongBrowserScreen(parent, next, searchText));
    }

    private void refreshTab() {
        this.minecraft.gui.setScreen(new SongBrowserScreen(parent, tab, searchText));
    }

    public static void refreshIfOpen(Minecraft client) {
        if (client != null && client.gui.screen() instanceof SongBrowserScreen screen) {
            screen.refreshTab();
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mouseX = event.x();
        double mouseY = event.y();
        if (tab == Tab.LIBRARY && event.button() == 0
                && mouseX >= contentX + 6 && mouseX <= contentX + contentWidth - 8
                && mouseY >= listTop && mouseY < listBottom) {
            int row = (int) ((mouseY - listTop) / rowHeight);
            int index = scrollOffset + row;
            List<Path> filtered = filteredSongs();
            if (row >= 0 && row < visibleRows && index >= 0 && index < filtered.size()) {
                openSong(filtered.get(index));
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (tab == Tab.LIBRARY && mouseX >= contentX + 4 && mouseX <= contentX + contentWidth - 4
                && mouseY >= listTop && mouseY < listBottom) {
            int max = Math.max(0, filteredSongs().size() - visibleRows);
            scrollOffset = Math.max(0, Math.min(max, scrollOffset + (verticalAmount > 0 ? -3 : 3)));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    /** Closes this screen and its parent menu instead of reopening the parent in onClose(). */
    private void closeToGameplay() {
        closingToGameplay = true;
        if (this.minecraft != null) this.minecraft.gui.setScreen(null);
    }

    @Override
    public void onClose() {
        if (closingToGameplay) {
            closingToGameplay = false;
            return;
        }
        this.minecraft.gui.setScreen(parent);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        graphics.fill(0, 0, width, height, 0xA8000000);
        drawMinecraftWindow(graphics, panelX, panelY, panelWidth, panelHeight);
        drawHeader(graphics);
        if (wideLayout) {
            drawMinecraftPanel(graphics, sidebarX, sidebarY, sidebarWidth, Math.max(1, pageBottom - sidebarY));
            graphics.text(font, "NAVIGATION", sidebarX + 10, sidebarY + 12, 0xFFFFD36B, true);
            graphics.fill(sidebarX + 9, sidebarY + 25, sidebarX + sidebarWidth - 9,
                    sidebarY + 26, 0xFF927349);
            graphics.text(font, "1.3.57  •  CLIENT", sidebarX + 10,
                    Math.max(sidebarY + 166, pageBottom - 18), 0xFFBDB09B, false);
        }
        drawMinecraftPanel(graphics, contentX, pageTop, contentWidth, Math.max(1, pageBottom - pageTop));

        if (tab == Tab.LIBRARY) renderLibrary(graphics, mouseX, mouseY);
        else if (tab == Tab.BUILDER) renderBuilder(graphics);
        else if (tab == Tab.PLAYER) renderPlayer(graphics);
        else renderSettings(graphics);

        // Widgets are deliberately extracted last so fields and buttons stay
        // above all panel fills and text, even on compact window sizes.
        super.extractRenderState(graphics, mouseX, mouseY, delta);
    }

    private void drawHeader(GuiGraphicsExtractor graphics) {
        // A warm dark-oak title strip with the thin gold line used by the
        // NoteClient identity. The rest of the screen uses recessed stone slots.
        graphics.fill(panelX + 4, panelY + 4, panelX + panelWidth - 4, panelY + 35, 0xFF39291D);
        graphics.fill(panelX + 4, panelY + 4, panelX + panelWidth - 4, panelY + 5, 0xFFFFD36B);
        graphics.fill(panelX + 4, panelY + 34, panelX + panelWidth - 4, panelY + 35, 0xFF17120E);
        graphics.fill(panelX + 9, panelY + 9, panelX + 11, panelY + 29, 0xFFFFC65D);
        graphics.text(font, "NOTECLIENT", panelX + 17, panelY + 10, 0xFFFFE08A, true);
        if (panelWidth > 520) {
            graphics.text(font, "NOTE BLOCK WORKBENCH", panelX + 112, panelY + 11,
                    0xFFD8C7AA, false);
        }
        String pageTitle = tab.title.toUpperCase(Locale.ROOT);
        int titleX = panelX + panelWidth - font.width(pageTitle) - 98;
        graphics.text(font, pageTitle, Math.max(panelX + 130, titleX), panelY + 11,
                0xFFFFD36B, true);
    }

    private void renderLibrary(GuiGraphicsExtractor graphics, int mouseX, int mouseY) {
        int left = contentX + 8;
        int right = contentX + contentWidth - 8;
        List<Path> filtered = filteredSongs();
        int max = Math.max(0, filtered.size() - visibleRows);
        scrollOffset = Math.max(0, Math.min(scrollOffset, max));

        graphics.text(font, "SEARCH SONGS", left + 1, pageTop + 1, 0xFFFFE08A, true);
        drawMinecraftPanel(graphics, left, listTop - 4, Math.max(1, right - left),
                Math.max(1, listBottom - listTop + 3));

        if (folderError != null) {
            drawWrapped(graphics, "Could not read the songs folder: " + folderError,
                    left + 10, listTop + 10, contentWidth - 40, 12, 3, 0xFFFF8585);
        } else if (filtered.isEmpty()) {
            String message = searchText.isBlank()
                    ? "No NBS songs found. Put .nbs files in .minecraft/noteclient/songs or a subfolder."
                    : "No songs match this search. Clear the search field to show every song.";
            drawWrapped(graphics, message, left + 10, listTop + 10,
                    contentWidth - 40, 12, 3, 0xFFE7E7E7);
        } else {
            int end = Math.min(filtered.size(), scrollOffset + visibleRows);
            for (int index = scrollOffset; index < end; index++) {
                int row = index - scrollOffset;
                int y = listTop + row * rowHeight;
                boolean hovered = mouseX >= left + 4 && mouseX <= right - 4
                        && mouseY >= y && mouseY < y + rowHeight;
                int fill = hovered ? 0xFF657D54 : (row % 2 == 0 ? 0xFF454545 : 0xFF3D3D3D);
                graphics.fill(left + 4, y + 1, right - 4, y + rowHeight - 1, fill);
                graphics.fill(left + 4, y + 1, right - 4, y + 2, hovered ? 0xFFB7D88F : 0xFF777777);

                Path file = filtered.get(index);
                String name = file.getFileName().toString();
                String folder = songsFolder.relativize(file.getParent()).toString().replace('\\', '/');
                if (folder.isBlank() || folder.equals(".")) folder = "Songs";
                int textY = y + Math.max(1, (rowHeight - 9) / 2);
                int openWidth = Math.min(45, Math.max(30, contentWidth / 10));
                int folderWidth = Math.min(180, Math.max(50, contentWidth / 4));
                int nameWidth = Math.max(25, right - left - openWidth - folderWidth - 38);
                graphics.text(font, clip(name, nameWidth), left + 11, textY, 0xFFFFFFFF, true);
                if (rowHeight >= 24) {
                    graphics.text(font, clip(folder, folderWidth), right - openWidth - folderWidth - 14,
                            textY + 10, 0xFFC2C2C2, false);
                }
                graphics.text(font, "OPEN ›", right - openWidth - 9, textY,
                        0xFFFFE08A, true);
            }
        }

        String summary = filtered.isEmpty() ? "0 songs" : "Showing " + (scrollOffset + 1) + "–"
                + Math.min(filtered.size(), scrollOffset + visibleRows) + " of " + filtered.size()
                + " songs  •  Scroll to browse";
        graphics.text(font, clip(summary, contentWidth - 18), left + 3, countY + 3,
                0xFFD0D0D0, true);

        int trackX = right - 3;
        int trackY = listTop + 3;
        int trackHeight = Math.max(8, listBottom - listTop - 6);
        graphics.fill(trackX, trackY, trackX + 3, trackY + trackHeight, 0xFF202020);
        if (max > 0) {
            int thumbHeight = Math.max(14, trackHeight * visibleRows / filtered.size());
            int thumbY = trackY + (trackHeight - thumbHeight) * scrollOffset / max;
            graphics.fill(trackX, thumbY, trackX + 3, thumbY + thumbHeight, 0xFFFFD66E);
        }
    }

    private void renderBuilder(GuiGraphicsExtractor graphics) {
        int x = contentX + 12;
        int y = pageTop + 10;
        int w = Math.max(1, contentWidth - 24);
        int lowerLimit = showAnchorControls ? anchorCardY - 8 : pageBottom - 8;
        int panelHeight = Math.max(52, lowerLimit - y);
        drawMinecraftPanel(graphics, x, y, w, panelHeight);
        graphics.text(font, "BUILDER", x + 11, y + 8, 0xFFFFE08A, true);
        String message = BuildClientState.message().isBlank()
                ? "Choose a song in the Library to begin."
                : BuildClientState.message();
        drawWrapped(graphics, message, x + 11, y + 25, w - 22, 12,
                Math.max(1, Math.min(3, (panelHeight - 58) / 12)), 0xFFEDEDED);
        int statsY = Math.max(y + 38, y + panelHeight - 34);
        String phase = BuildClientState.paused() ? "PAUSED"
                : BuildClientState.finished() ? "READY" : "BUILDING";
        graphics.text(font, phase + "  •  BAND " + BuildClientState.layer()
                + "  •  " + BuildClientState.placed() + "/" + BuildClientState.total()
                + "  •  " + BuildClientState.percent() + "%", x + 11, statsY,
                0xFFFFFFFF, true);
        drawProgressBar(graphics, x + 11, y + panelHeight - 16, w - 22, 7,
                BuildClientState.percent());

        if (showAnchorControls) {
            drawMinecraftPanel(graphics, x, anchorCardY, w, 66);
            graphics.text(font, "OPTIONAL SERVER-COMPANION ANCHOR", x + 11,
                    anchorCardY + 7, 0xFFFFE08A, true);
        }
    }

    private void renderPlayer(GuiGraphicsExtractor graphics) {
        int x = contentX + 12;
        int y = pageTop + 68;
        int w = Math.max(1, contentWidth - 24);
        int h = Math.max(1, pageBottom - y - 8);
        drawMinecraftPanel(graphics, x, y, w, h);
        graphics.text(font, "3D PLAYER STATUE", x + 11, y + 8, 0xFFFFE08A, true);
        int statusLines = h < 132 ? 1 : 3;
        drawWrapped(graphics, PlayerStatueBuilder.status(), x + 11, y + 25,
                w - 22, 12, statusLines, 0xFFEDEDED);

        if (PlayerStatueBuilder.hasSkin()) {
            int previewY = y + (h < 132 ? 44 : 68);
            int remainingHeight = Math.max(1, pageBottom - previewY - 10);
            int scale = Math.max(1, Math.min(5, remainingHeight / 32));
            int previewX = x + 16;
            int previewWidth = 16 * scale;
            int previewHeight = 32 * scale;
            graphics.fill(previewX - 5, previewY - 5,
                    previewX + previewWidth + 5, previewY + previewHeight + 5, 0xFF202020);
            graphics.fill(previewX - 4, previewY - 4,
                    previewX + previewWidth + 4, previewY + previewHeight + 4, 0xFF777777);
            for (int py = 0; py < 32; py++) {
                for (int px = 0; px < 16; px++) {
                    int color = PlayerStatueBuilder.previewBasePixel(px, py);
                    if ((color >>> 24) != 0) {
                        graphics.fill(previewX + px * scale, previewY + py * scale,
                                previewX + (px + 1) * scale, previewY + (py + 1) * scale,
                                0xFF000000 | (color & 0x00FFFFFF));
                    }
                    int outer = PlayerStatueBuilder.previewOuterPixel(px, py);
                    if ((outer >>> 24) > 24) {
                        int inset = Math.max(1, scale / 3);
                        graphics.fill(previewX + px * scale + inset, previewY + py * scale + inset,
                                previewX + (px + 1) * scale, previewY + (py + 1) * scale,
                                0xFF000000 | (outer & 0x00FFFFFF));
                    }
                }
            }
            int infoX = previewX + previewWidth + 18;
            int infoY = previewY + 4;
            graphics.text(font, PlayerStatueBuilder.loadedUsername(), infoX, infoY,
                    0xFFFFE08A, true);
            graphics.text(font, PlayerStatueBuilder.slimArms() ? "SLIM ARM MODEL" : "CLASSIC ARM MODEL",
                    infoX, infoY + 14, 0xFFD8D8D8, false);
            if (!PlayerStatueBuilder.skinSourceName().isBlank()) {
                graphics.text(font, PlayerStatueBuilder.skinSourceName(), infoX, infoY + 28,
                        0xFFB8C7D8, false);
            }
            if (h >= 180) {
                graphics.text(font, "Six-face 3D skin cuboids", infoX, infoY + 44, 0xFFD8D8D8, false);
                graphics.text(font, "Hat, jacket, sleeves, pants layers", infoX, infoY + 58, 0xFFD8D8D8, false);
                graphics.text(font, "P pause • R retry • O remove", infoX, infoY + 72, 0xFFD8D8D8, false);
                graphics.text(font, "Build requires Creative", infoX, infoY + 86, 0xFFFFC66D, false);
            } else if (h >= 132) {
                graphics.text(font, "3D • P pause • R retry • O remove", infoX, infoY + 44, 0xFFD8D8D8, false);
            } else {
                graphics.text(font, "3D • shaded", infoX, infoY + 16, 0xFFD8D8D8, false);
            }
        } else {
            int helpY = y + (h < 132 ? 44 : 68);
            int helpLines = Math.max(1, Math.min(6, (pageBottom - helpY - 6) / 12));
            drawWrapped(graphics,
                    "Look up a public Java username, browse every PNG in your profile's noteclient/skins folder, or choose one of the nine built-in Minecraft skins. Supports modern 64×64, legacy 64×32 and scaled PNG files, selectable slim/classic arms, and raised clothing layers.",
                    x + 11, helpY, w - 22, 12, helpLines, 0xFFBDBDBD);
        }
    }

    private void renderSettings(GuiGraphicsExtractor graphics) {
        int x = contentX + 12;
        int y = pageTop + 10;
        int w = Math.max(1, contentWidth - 24);
        int controlY = pageBottom - 65;
        int cardHeight = Math.max(0, controlY - y - 8);
        if (cardHeight >= 32) {
            drawMinecraftPanel(graphics, x, y, w, cardHeight);
            graphics.text(font, "PERFORMANCE", x + 11, y + 8, 0xFFFFD36B, true);
            graphics.text(font, "Build: " + NoteClientConfig.buildActionsPerTick()
                    + " actions/tick  •  Tune: " + NoteClientConfig.tuningActionsPerTick()
                    + " interactions/tick", x + 11, y + 27, 0xFFEDEDED, false);
            if (cardHeight >= 58) {
                graphics.text(font, "Build rate applies to songs, schematics, redstone, statues, and cleanup.",
                        x + 11, y + 43, 0xFFD5D5D5, false);
            }
            if (cardHeight >= 76) {
                String reach = NoteClientConfig.serverReachOverride() == 100
                        ? "Reach plan: 100 blocks (custom server command requested)"
                        : "Reach plan: automatic (server-synchronized range)";
                graphics.text(font, reach, x + 11, y + 59, 0xFFD5D5D5, false);
            }
            if (cardHeight >= 94) {
                graphics.text(font, "Creative builds try pre-tuned note items first; Tune rate is the fallback click budget.",
                        x + 11, y + 75, 0xFFB8B8B8, false);
            }
        }
    }

    private void drawMinecraftWindow(GuiGraphicsExtractor graphics, int x, int y, int w, int h) {
        if (w <= 0 || h <= 0) return;
        graphics.fill(x + 4, y + 5, x + w + 4, y + h + 5, 0x99000000);
        graphics.fill(x, y, x + w, y + h, 0xFF090909);
        graphics.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFFB7B7B7);
        graphics.fill(x + 2, y + 2, x + w - 2, y + h - 2, 0xFF555555);
        graphics.fill(x + 3, y + 3, x + w - 3, y + h - 3, 0xFF454545);
        // Subtle 8px stone speckle gives the frame a block-textured surface
        // without making text or interactive controls hard to read.
        for (int py = y + 5; py < y + h - 5; py += 8) {
            for (int px = x + 5; px < x + w - 5; px += 8) {
                int hash = (px * 31 + py * 17) & 7;
                if (hash == 0 || hash == 3) {
                    graphics.fill(px, py, Math.min(x + w - 4, px + 3),
                            Math.min(y + h - 4, py + 2), hash == 0 ? 0xFF4B4B4B : 0xFF3D3D3D);
                }
            }
        }
        graphics.fill(x + 3, y + 3, x + w - 3, y + 4, 0xFF9A9A9A);
        graphics.fill(x + 3, y + h - 4, x + w - 3, y + h - 3, 0xFF242424);
    }

    private void drawMinecraftPanel(GuiGraphicsExtractor graphics, int x, int y, int w, int h) {
        if (w <= 0 || h <= 0) return;
        graphics.fill(x, y, x + w, y + h, 0xFF171717);
        if (w > 2 && h > 2) graphics.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFF8A8A8A);
        if (w > 4 && h > 4) graphics.fill(x + 2, y + 2, x + w - 2, y + h - 2, 0xFF393939);
        if (w > 4 && h > 3) graphics.fill(x + 2, y + 2, x + w - 2, y + 3, 0xFF9B9B9B);
        if (w > 4 && h > 4) graphics.fill(x + 2, y + h - 3, x + w - 2, y + h - 2, 0xFF202020);
    }

    private void drawProgressBar(GuiGraphicsExtractor graphics, int x, int y, int w, int h, int percent) {
        if (w <= 0 || h <= 0) return;
        graphics.fill(x, y, x + w, y + h, 0xFF151515);
        graphics.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFF555555);
        int innerW = Math.max(0, w - 2);
        int filled = Math.max(0, Math.min(innerW, innerW * percent / 100));
        graphics.fill(x + 1, y + 1, x + 1 + filled, y + h - 1, 0xFF7BA653);
    }

    private int drawWrapped(GuiGraphicsExtractor graphics, String text, int x, int y, int maxWidth,
                           int lineHeight, int maxLines, int color) {
        if (text == null || text.isBlank() || maxWidth < 12 || maxLines <= 0) return y;
        StringBuilder line = new StringBuilder();
        int drawn = 0;
        for (String word : text.replace('\n', ' ').split("\\s+")) {
            if (line.isEmpty() && font.width(word) > maxWidth) word = clip(word, maxWidth);
            String candidate = line.isEmpty() ? word : line + " " + word;
            if (font.width(candidate) > maxWidth && !line.isEmpty()) {
                graphics.text(font, line.toString(), x, y, color, true);
                y += lineHeight;
                drawn++;
                line.setLength(0);
                if (drawn >= maxLines) return y;
                line.append(font.width(word) > maxWidth ? clip(word, maxWidth) : word);
            } else {
                line.setLength(0);
                line.append(candidate);
            }
        }
        if (!line.isEmpty() && drawn < maxLines) {
            graphics.text(font, line.toString(), x, y, color, true);
            y += lineHeight;
        }
        return y;
    }

    private String clip(String text, int maxWidth) {
        if (maxWidth <= 0) return "";
        if (font.width(text) <= maxWidth) return text;
        String result = text;
        while (!result.isEmpty() && font.width(result + "…") > maxWidth) {
            result = result.substring(0, result.length() - 1);
        }
        return result + "…";
    }

    private enum Tab {
        LIBRARY("Song Library"),
        BUILDER("Builder"),
        PLAYER("Player Builder"),
        SETTINGS("Settings");

        private final String title;
        Tab(String title) { this.title = title; }
    }
}
