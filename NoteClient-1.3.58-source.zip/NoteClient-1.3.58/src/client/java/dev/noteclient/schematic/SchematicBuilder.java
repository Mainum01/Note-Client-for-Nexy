package dev.noteclient.schematic;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.noteclient.NoteClientHud;
import dev.noteclient.NoteClientConfig;
import dev.noteclient.CreativeMaterialStager;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.LightCoordsUtil;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelPart;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.component.BlockItemStateProperties;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Sponge schematic preview and normal-interaction builder. */
public final class SchematicBuilder {
    private static final int WORKING_SLOT = 8;
    private static final int MAX_RENDERED_PREVIEW_BLOCKS = 12_000;
    private static final int MAX_RENDER_DISTANCE = 96;
    private static final int CONFIRM_TIMEOUT_TICKS = 12;
    private static final int MAX_ATTEMPTS_PER_BLOCK = 3;
    private static final int SUPPORT_RETRY_INTERVAL_TICKS = 20;

    private static volatile Preview preview;
    private static BuildJob activeJob;
    private static String status = "Place .litematic, .schem, .schematic, or .nbt files in NoteClient/schematics.";
    private static long loadGeneration;

    private SchematicBuilder() {}

    public static void initialize() {
        try {
            Files.createDirectories(NoteClientSchematics.folder());
        } catch (IOException exception) {
            status = "Could not create schematics folder: " + exception.getMessage();
        }
        LevelRenderEvents.COLLECT_SUBMITS.register(SchematicBuilder::renderPreview);
    }

    public static String status() { return status; }
    public static boolean hasPreview() { return preview != null; }
    public static boolean hasActiveJob() { return activeJob != null; }
    public static String previewName() { Preview current = preview; return current == null ? "" : current.name; }

    public static void load(Path file, Minecraft client, java.util.function.Consumer<String> completion) {
        if (file == null || client == null) return;
        long generation = ++loadGeneration;
        if (activeJob != null) { status = "Cannot switch schematics while a build is running."; if (completion != null) completion.accept(status); return; }
        if (client.player == null) { status = "Join a world before selecting a schematic."; if (completion != null) completion.accept(status); return; }
        // Snapshot the anchor at the exact moment the user selects this file. The preview never follows later movement.
        BlockPos selectedAnchor = client.player.blockPosition();
        Direction selectedForward = Direction.fromYRot(client.player.getYRot());
        preview = null;
        status = "Reading " + file.getFileName() + "…";
        java.util.concurrent.CompletableFuture.supplyAsync(() -> {
            try {
                SpongeSchematicReader.Schematic schematic = SpongeSchematicReader.read(file);
                List<PreparedBlock> prepared = prepareBlocks(schematic);
                return new PreparedSchematic(schematic, prepared, null);
            } catch (Exception exception) {
                String message = exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage();
                return new PreparedSchematic(null, List.of(), message);
            }
        }).whenComplete((result, error) -> client.execute(() -> {
            if (generation != loadGeneration) return;
            if (error != null || result == null || result.error != null || result.schematic == null) {
                String message = result != null && result.error != null ? result.error
                        : error == null ? "Could not read schematic." : rootMessage(error);
                status = "Schematic load failed: " + message;
                if (completion != null) completion.accept(status);
                NoteClientHud.warn(status);
                return;
            }
            if (client.player == null) {
                status = "Join a world to preview this schematic.";
                if (completion != null) completion.accept(status);
                return;
            }
            preview = new Preview(file.getFileName().toString(), result.schematic,
                    result.blocks, selectedForward, selectedAnchor);
            status = "Preview anchored at " + selectedAnchor.toShortString() + " • " + result.blocks.size() + " blocks • left arrow to build";
            if (completion != null) completion.accept(status);
            NoteClientHud.show(status);
        }));
    }

    private static List<PreparedBlock> prepareBlocks(SpongeSchematicReader.Schematic schematic) throws IOException {
        List<PreparedBlock> result = new ArrayList<>(schematic.blocks().size());
        for (SpongeSchematicReader.BlockEntry entry : schematic.blocks()) {
            Identifier id;
            try {
                id = Identifier.parse(entry.blockId());
            } catch (RuntimeException exception) {
                continue;
            }
            Block block = BuiltInRegistries.BLOCK.getOptional(id).orElse(null);
            if (block == null || block == Blocks.AIR) continue;
            BlockState state = block.defaultBlockState();
            for (Map.Entry<String, String> propertyEntry : entry.properties().entrySet()) {
                Property<?> property = block.getStateDefinition().getProperty(propertyEntry.getKey());
                if (property == null) continue;
                try {
                    state = withProperty(state, property, propertyEntry.getValue());
                } catch (RuntimeException ignored) {
                    // Unknown values from modded/newer schematic versions fall back to the block default.
                }
            }
            Item item = block.asItem();
            if (item == Items.AIR) continue;
            result.add(new PreparedBlock(entry.x(), entry.y(), entry.z(), state, item));
        }
        result.sort(Comparator.comparingInt(PreparedBlock::y)
                .thenComparingInt(PreparedBlock::z).thenComparingInt(PreparedBlock::x));
        if (result.isEmpty()) throw new IOException("The schematic contains no registered placeable blocks for this Minecraft version.");
        return List.copyOf(result);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static BlockState withProperty(BlockState state, Property property, String serializedValue) {
        java.util.Optional parsed = property.getValue(serializedValue);
        if (parsed.isEmpty()) throw new IllegalArgumentException("Invalid block property value: " + serializedValue);
        return state.setValue(property, (Comparable) parsed.get());
    }

    public static void rotatePreview() {
        Preview current = preview;
        if (current == null || activeJob != null) return;
        preview = new Preview(current.name, current.schematic, current.blocks,
                current.forward.getClockWise(), current.origin);
        status = "Preview rotated • facing " + preview.forward.getName().toUpperCase();
    }

    public static void unloadPreview() {
        if (activeJob != null) {
            status = "Cannot unload the schematic while a build is running. Stop the build first.";
            NoteClientHud.warn(status);
            return;
        }
        loadGeneration++;
        preview = null;
        status = "Schematic unloaded.";
        NoteClientHud.show(status);
    }

    /** Backwards-compatible alias for older UI actions. */
    public static void clearPreview() { unloadPreview(); }

    public static boolean startBuild(Minecraft client) {
        Preview current = preview;
        if (current == null || client == null || client.player == null || client.level == null || client.gameMode == null) {
            status = "Select a schematic and join a world first.";
            NoteClientHud.warn(status);
            return false;
        }
        if (activeJob != null) {
            status = "A schematic build is already running. Press P to pause or O to stop.";
            NoteClientHud.warn(status);
            return false;
        }
        if (client.gameMode.getPlayerMode() != GameType.CREATIVE) {
            status = "Schematic construction currently requires Creative mode so the client can supply the needed blocks.";
            NoteClientHud.warn(status);
            return false;
        }
        BlockPos origin = current.origin;
        // Start with the cells closest to the player's eyes, then work outward.
        // This lets a large schematic begin immediately without being blocked by
        // its far edge, even when the server grants a custom interaction range.
        Vec3 playerEye = client.player.getEyePosition();
        List<PreparedBlock> buildOrder = new ArrayList<>(current.blocks);
        buildOrder.sort(Comparator
                .comparingDouble((PreparedBlock block) -> playerEye.distanceToSqr(
                        Vec3.atCenterOf(previewWorldPosition(current, block))))
                .thenComparingInt(PreparedBlock::y)
                .thenComparingInt(PreparedBlock::z)
                .thenComparingInt(PreparedBlock::x));
        Map<Item, Integer> requiredMaterials = new HashMap<>();
        for (PreparedBlock block : buildOrder) requiredMaterials.merge(block.item, 1, Integer::sum);
        CreativeMaterialStager.Result inventory = CreativeMaterialStager.stage(client, requiredMaterials);

        // Snapshot the working slot after stocking materials. The builder may
        // temporarily use this slot for block-state-specific item stacks, then
        // restore the stocked stack when the job ends so the materials remain
        // in the player's inventory.
        activeJob = new BuildJob(current, List.copyOf(buildOrder), origin,
                client.player.getInventory().getSelectedSlot(),
                client.player.getInventory().getItem(WORKING_SLOT).copy());
        preview = new Preview(current.name, current.schematic, current.blocks, current.forward, current.origin);
        status = "Building " + current.name + " • nearest blocks first • planning reach "
                + Math.round(blockInteractionReach(client.player)) + " blocks • " + inventory.summary();
        NoteClientHud.show(status);
        return true;
    }

    public static void tick(Minecraft client) {
        BuildJob job = activeJob;
        if (job == null) return;
        if (client == null || client.player == null || client.level == null || client.gameMode == null) {
            finish(client, job, "Disconnected. Confirmed schematic blocks remain in the world.");
            return;
        }
        if (client.gameMode.getPlayerMode() != GameType.CREATIVE) {
            finish(client, job, "Build stopped because Creative mode is no longer active. Already confirmed blocks were left in place.");
            return;
        }
        if (job.paused) return;

        long now = client.level.getGameTime();

        // Resolve every in-flight interaction before scheduling more work. This
        // lets the builder keep a bounded pipeline moving instead of waiting a
        // full round trip for each individual schematic block.
        for (int i = 0; i < job.pending.size();) {
            PendingBlock pending = job.pending.get(i);
            BlockState observed = client.level.getBlockState(pending.position);
            if (matchesExpectedBlock(observed, pending.expected)) {
                job.placed++;
                job.pendingPositions.remove(pending.position);
                job.attemptsByPosition.remove(pending.position);
                job.pending.remove(i);
                if (job.placed % 20 == 0) {
                    status = "Schematic build • " + job.placed + " / " + job.blocks.size()
                            + " confirmed • " + job.pending.size() + " awaiting server • "
                            + job.deferred.size() + " deferred";
                    NoteClientHud.show(status);
                }
                continue;
            }
            if (!observed.isAir()) {
                // The cell was occupied by a different block. Do not overwrite it.
                job.skipped++;
                job.pendingPositions.remove(pending.position);
                job.attemptsByPosition.remove(pending.position);
                job.pending.remove(i);
                continue;
            }
            if (now - pending.sentAt >= CONFIRM_TIMEOUT_TICKS) {
                job.pending.remove(i);
                job.pendingPositions.remove(pending.position);
                int attempts = job.attemptsByPosition.merge(pending.position, 1,
                        (oldValue, one) -> Math.min(MAX_ATTEMPTS_PER_BLOCK, oldValue + one));
                job.deferred.add(pending.source);
                job.retryPassStartPlaced = job.placed;
                job.nextSupportRetryTick = Math.min(job.nextSupportRetryTick == 0
                        ? now + SUPPORT_RETRY_INTERVAL_TICKS : job.nextSupportRetryTick,
                        now + SUPPORT_RETRY_INTERVAL_TICKS);
                if (attempts >= MAX_ATTEMPTS_PER_BLOCK) {
                    status = "Server has not confirmed " + pending.position.toShortString()
                            + ". It is queued for another pass; confirmed blocks are retained.";
                    NoteClientHud.warn(status);
                }
                continue;
            }
            i++;
        }

        int buildBudget = NoteClientConfig.buildActionsPerTick();
        int maxInFlight = Math.max(3, Math.min(128, buildBudget * 3));
        int sent = 0;
        int examined = 0;
        int maxExamined = Math.max(32, buildBudget * 8);
        while (sent < buildBudget && examined < maxExamined && job.pending.size() < maxInFlight) {
            PreparedBlock source = currentBlock(job);
            if (source == null) {
                if (!job.retryingDeferred && !job.deferred.isEmpty()) {
                    beginDeferredPass(job, now);
                    source = currentBlock(job);
                } else if (job.retryingDeferred && !job.deferred.isEmpty()) {
                    if ((job.placed > job.retryPassStartPlaced || now >= job.nextSupportRetryTick)
                            && job.lastDeferredPassTick != now) {
                        beginDeferredPass(job, now);
                        source = currentBlock(job);
                    } else {
                        break;
                    }
                } else if (job.deferred.isEmpty()) {
                    if (job.pending.isEmpty()) {
                        finish(client, job, "Schematic complete • " + job.placed + " placed • " + job.skipped
                                + " occupied cells skipped. The placed blocks are retained.");
                    }
                    break;
                }
            }
            if (source == null) break;
            examined++;

            BlockPos target = worldPosition(job, source);
            if (job.pendingPositions.contains(target)) {
                advanceCurrent(job);
                continue;
            }
            if (!client.level.hasChunkAt(target)) {
                deferCurrent(job, source);
                continue;
            }

            BlockState existing = client.level.getBlockState(target);
            BlockState expected = source.state.rotate(rotationFor(job.preview.forward));
            if (!existing.isAir()) {
                if (matchesExpectedBlock(existing, expected)) job.placed++;
                else job.skipped++;
                advanceCurrent(job);
                job.attempts = 0;
                continue;
            }

            // Gravity blocks and attached blocks are deferred until their real
            // support is present. A deferred cell never blocks other reachable work.
            if (!hasRequiredSupport(client, target, expected)
                    || findAnySupportHit(client, target, expected) == null) {
                deferCurrent(job, source);
                continue;
            }

            BlockHitResult hit = findPlacementHit(client, target, expected);
            if (hit == null) {
                deferCurrent(job, source);
                status = reachDeferredStatus(client, target, job.deferred.size());
                NoteClientHud.warn(status);
                continue;
            }

            LocalPlayer player = client.player;
            player.getInventory().setSelectedSlot(WORKING_SLOT);
            ItemStack stack = new ItemStack(source.item, 1);
            Map<String, String> properties = serializedProperties(expected);
            if (!properties.isEmpty()) stack.set(DataComponents.BLOCK_STATE, new BlockItemStateProperties(properties));
            player.getInventory().setItem(WORKING_SLOT, stack.copy());
            client.gameMode.handleCreativeModeItemAdd(stack.copy(), 36 + WORKING_SLOT);
            net.minecraft.world.InteractionResult interaction = client.gameMode.useItemOn(
                    player, InteractionHand.MAIN_HAND, hit);
            if (interaction != null && interaction.consumesAction()) {
                job.pending.add(new PendingBlock(source, target, expected, now));
                job.pendingPositions.add(target.immutable());
                advanceCurrent(job);
                job.attempts = 0;
                sent++;
            } else {
                int attempts = job.attemptsByPosition.merge(target, 1,
                        (oldValue, one) -> Math.min(MAX_ATTEMPTS_PER_BLOCK, oldValue + one));
                deferCurrent(job, source);
                if (attempts >= MAX_ATTEMPTS_PER_BLOCK) {
                    status = "Minecraft declined placement at " + target.toShortString()
                            + ". It is queued for another pass; check the target and server placement permissions.";
                    NoteClientHud.warn(status);
                }
                // Do not hammer a rejected interaction repeatedly in the same tick.
                break;
            }
        }

        if (sent > 0 && (job.placed % 20 == 0 || job.pending.size() >= maxInFlight)) {
            status = "Schematic build • " + job.placed + " / " + job.blocks.size()
                    + " confirmed • " + job.pending.size() + " awaiting server • "
                    + job.deferred.size() + " deferred";
            NoteClientHud.show(status);
        }
    }

    private static PreparedBlock currentBlock(BuildJob job) {
        if (!job.retryingDeferred) {
            return job.index < job.blocks.size() ? job.blocks.get(job.index) : null;
        }
        return job.retryIndex < job.retryQueue.size() ? job.retryQueue.get(job.retryIndex) : null;
    }

    private static void advanceCurrent(BuildJob job) {
        if (job.retryingDeferred) job.retryIndex++;
        else job.index++;
    }

    private static void deferCurrent(BuildJob job, PreparedBlock block) {
        job.deferred.add(block);
        advanceCurrent(job);
    }

    private static void beginDeferredPass(BuildJob job, long now) {
        job.lastDeferredPassTick = now;
        job.retryQueue = List.copyOf(job.deferred);
        job.deferred.clear();
        job.retryIndex = 0;
        job.retryingDeferred = true;
        job.retryPassStartPlaced = job.placed;
        job.nextSupportRetryTick = now + SUPPORT_RETRY_INTERVAL_TICKS;
    }

    private static boolean matchesExpectedBlock(BlockState actual, BlockState expected) {
        // Neighbor updates can legitimately change properties such as connections,
        // powered, waterlogged, or shape. The registered block itself is the reliable
        // placement acknowledgement; property differences must not make every cell red.
        return actual.is(expected.getBlock());
    }

    private static boolean hasRequiredSupport(Minecraft client, BlockPos target, BlockState expected) {
        if (expected.getBlock() instanceof FallingBlock) {
            BlockPos below = target.below();
            BlockState support = client.level.getBlockState(below);
            return support.isFaceSturdy(client.level, below, Direction.UP);
        }
        return expected.canSurvive(client.level, target);
    }

    private static BlockHitResult findAnySupportHit(Minecraft client, BlockPos target, BlockState expected) {
        boolean falling = expected.getBlock() instanceof FallingBlock;
        for (Direction offset : Direction.values()) {
            if (falling && offset != Direction.DOWN) continue;
            BlockPos neighbor = target.relative(offset);
            BlockState anchor = client.level.getBlockState(neighbor);
            if (anchor.isAir()
                    || !anchor.isFaceSturdy(client.level, neighbor, offset.getOpposite())) continue;
            Vec3 location = Vec3.atCenterOf(neighbor).add(
                    offset.getOpposite().getStepX() * 0.5,
                    offset.getOpposite().getStepY() * 0.5,
                    offset.getOpposite().getStepZ() * 0.5);
            return new BlockHitResult(location, offset.getOpposite(), neighbor, false);
        }
        return null;
    }

    private static Map<String, String> serializedProperties(BlockState state) {
        Map<String, String> values = new HashMap<>();
        for (Property<?> property : state.getProperties()) {
            propertyValueUnchecked(property, state, values);
        }
        return values;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void propertyValueUnchecked(Property property, BlockState state, Map<String, String> target) {
        Comparable value = (Comparable) state.getValue(property);
        target.put(property.getName(), property.getName(value));
    }

    private static BlockPos worldPosition(BuildJob job, PreparedBlock block) {
        // The selected player's block position is the schematic's bottom-right footprint corner.
        int fromRight = block.x - (job.preview.schematic.width() - 1);
        int fromBack = block.z - (job.preview.schematic.length() - 1);
        return job.origin.relative(job.preview.forward.getClockWise(), fromRight)
                .relative(job.preview.forward, fromBack).above(block.y);
    }

    private static BlockPos previewWorldPosition(Preview preview, PreparedBlock block) {
        int fromRight = block.x - (preview.schematic.width() - 1);
        int fromBack = block.z - (preview.schematic.length() - 1);
        return preview.origin.relative(preview.forward.getClockWise(), fromRight)
                .relative(preview.forward, fromBack).above(block.y);
    }

    private static Rotation rotationFor(Direction forward) {
        return switch (forward) {
            case SOUTH -> Rotation.NONE;
            case WEST -> Rotation.CLOCKWISE_90;
            case NORTH -> Rotation.CLOCKWISE_180;
            case EAST -> Rotation.COUNTERCLOCKWISE_90;
            default -> Rotation.NONE;
        };
    }

    private static double blockInteractionReach(LocalPlayer player) {
        double synchronizedReach = 4.5;
        if (player != null) {
            try {
                double reach = player.getAttributeValue(Attributes.BLOCK_INTERACTION_RANGE);
                if (Double.isFinite(reach) && reach > 0.0) synchronizedReach = reach;
            } catch (Throwable ignored) {
                // Use the vanilla fallback until the server-synchronized value is ready.
            }
        }

        // /reach is server-specific and is only enabled by the user's explicit
        // Request /reach 100 action in Settings. This is a planning hint only:
        // useItemOn remains an ordinary interaction and the server validates it.
        double requestedReach = NoteClientConfig.serverReachOverride();
        double effectiveReach = requestedReach > 0.0
                ? Math.max(synchronizedReach, requestedReach)
                : synchronizedReach;
        return Math.max(0.5, Math.min(128.0, effectiveReach));
    }

    private static String reachDeferredStatus(Minecraft client, BlockPos target, int queued) {
        long reach = Math.round(blockInteractionReach(client == null ? null : client.player));
        String hint = NoteClientConfig.serverReachOverride() == 100
                ? "The 100-block server reach hint is active; the server still validates placement."
                : "For a server with /reach 100, click N → Settings → Request /reach 100 first.";
        return "Queued " + target.toShortString() + " outside the current " + reach
                + "-block planning reach. Continuing with nearer blocks; " + queued
                + " block(s) will be retried. " + hint;
    }

    private static BlockHitResult findPlacementHit(Minecraft client, BlockPos target, BlockState expected) {
        LocalPlayer player = client.player;
        double reach = blockInteractionReach(player);
        double maxDistance = Math.max(0.5, reach - 0.5);
        Vec3 eye = player.getEyePosition();
        BlockHitResult best = null;
        double bestDistance = Double.MAX_VALUE;
        boolean falling = expected.getBlock() instanceof FallingBlock;
        for (Direction offset : Direction.values()) {
            // Falling blocks must be clicked onto the top face of their actual stabilizer.
            if (falling && offset != Direction.DOWN) continue;
            BlockPos neighbor = target.relative(offset);
            BlockState anchor = client.level.getBlockState(neighbor);
            if (anchor.isAir()
                    || !anchor.isFaceSturdy(client.level, neighbor, offset.getOpposite())) continue;
            Vec3 location = Vec3.atCenterOf(neighbor).add(
                    offset.getOpposite().getStepX() * 0.5,
                    offset.getOpposite().getStepY() * 0.5,
                    offset.getOpposite().getStepZ() * 0.5);
            double distance = eye.distanceTo(location);
            if (distance > maxDistance || distance >= bestDistance) continue;
            best = new BlockHitResult(location, offset.getOpposite(), neighbor, false);
            bestDistance = distance;
        }
        return best;
    }

    public static void togglePause(Minecraft client) {
        BuildJob job = activeJob;
        if (job == null) return;
        job.paused = !job.paused;
        status = job.paused ? "Schematic build paused • P to resume • O to stop"
                : "Schematic build resumed • " + job.placed + " / " + job.blocks.size() + " confirmed";
        NoteClientHud.show(status);
    }

    public static void cancel(Minecraft client) {
        BuildJob job = activeJob;
        if (job == null) return;
        finish(client, job, "Schematic build stopped • " + job.placed
                + " confirmed blocks were left in the world. No automatic cleanup was performed.");
    }

    public static void onDisconnect(Minecraft client) {
        BuildJob job = activeJob;
        if (job != null) {
            // Restore only our temporary hotbar selection locally. Do not send
            // removal packets: confirmed world changes remain owned by the server.
            if (client != null && client.player != null) {
                client.player.getInventory().setItem(WORKING_SLOT, job.originalWorkingStack.copy());
                client.player.getInventory().setSelectedSlot(job.originalSlot);
            }
            activeJob = null;
        }
        loadGeneration++;
    }

    private static void finish(Minecraft client, BuildJob job, String message) {
        if (client != null && client.player != null) {
            client.player.getInventory().setItem(WORKING_SLOT, job.originalWorkingStack.copy());
            if (client.gameMode != null && client.gameMode.getPlayerMode() == GameType.CREATIVE) {
                client.gameMode.handleCreativeModeItemAdd(job.originalWorkingStack.copy(), 36 + WORKING_SLOT);
            }
            client.player.getInventory().setSelectedSlot(job.originalSlot);
        }
        activeJob = null;
        status = message;
        NoteClientHud.show(message);
    }

    private static void renderPreview(net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext context) {
        Preview current = preview;
        Minecraft client = Minecraft.getInstance();
        if (current == null || client.level == null || client.player == null) return;
        BuildJob job = activeJob;
        BlockPos origin = job == null ? current.origin : job.origin;
        if (origin == null) return;
        Vec3 camera = context.gameRenderer().mainCamera().position();
        PoseStack pose = context.poseStack();
        int rendered = 0;
        for (PreparedBlock block : current.blocks) {
            BlockPos pos;
            if (job == null) {
                pos = previewWorldPosition(current, block);
            } else {
                pos = worldPosition(job, block);
            }
            double dx = pos.getX() + 0.5 - camera.x;
            double dy = pos.getY() + 0.5 - camera.y;
            double dz = pos.getZ() + 0.5 - camera.z;
            if (dx * dx + dy * dy + dz * dz > (double) MAX_RENDER_DISTANCE * MAX_RENDER_DISTANCE) continue;
            BlockState state = block.state.rotate(rotationFor(current.forward));
            if (state.getRenderShape() == RenderShape.INVISIBLE) continue;
            try {
                BlockStateModel model = client.getModelManager().getBlockStateModelSet().get(state);
                List<BlockStateModelPart> parts = new ArrayList<>();
                model.collectParts(RandomSource.create(state.getSeed(pos)), parts);
                if (parts.isEmpty()) continue;
                pose.pushPose();
                try {
                    pose.translate(pos.getX() - camera.x, pos.getY() - camera.y, pos.getZ() - camera.z);
                    BlockState actual = client.level.getBlockState(pos);
                    int outline = actual.isAir() || matchesExpectedBlock(actual, state)
                            ? 0xFF42E879 : 0xFFFF4A4A;
                    context.submitNodeCollector().submitBlockModel(pose, RenderTypes.translucentMovingBlock(),
                            parts, new int[0], LightCoordsUtil.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, outline);
                } finally {
                    pose.popPose();
                }
            } catch (RuntimeException ignored) {
                // A broken resource-pack model should not prevent other schematic cells from rendering.
            }
            rendered++;
            if (rendered >= MAX_RENDERED_PREVIEW_BLOCKS) break;
        }
    }

    private static String rootMessage(Throwable error) {
        Throwable current = error;
        while (current.getCause() != null) current = current.getCause();
        return current.getMessage() == null ? current.getClass().getSimpleName() : current.getMessage();
    }

    private static final class Preview {
        final String name;
        final SpongeSchematicReader.Schematic schematic;
        final List<PreparedBlock> blocks;
        final Direction forward;
        final BlockPos origin;
        Preview(String name, SpongeSchematicReader.Schematic schematic, List<PreparedBlock> blocks,
                Direction forward, BlockPos origin) {
            this.name = name;
            this.schematic = schematic;
            this.blocks = blocks;
            this.forward = forward;
            this.origin = origin;
        }
    }

    private static final class BuildJob {
        final Preview preview;
        final List<PreparedBlock> blocks;
        final BlockPos origin;
        final int originalSlot;
        final ItemStack originalWorkingStack;
        int index;
        int placed;
        int skipped;
        int attempts;
        boolean paused;
        boolean waitingForPlayer;
        boolean retryingDeferred;
        int retryIndex;
        int retryPassStartPlaced;
        long nextSupportRetryTick;
        long lastDeferredPassTick = Long.MIN_VALUE;
        List<PreparedBlock> deferred = new ArrayList<>();
        List<PreparedBlock> retryQueue = List.of();
        final List<PendingBlock> pending = new ArrayList<>();
        final java.util.Set<BlockPos> pendingPositions = new java.util.HashSet<>();
        final Map<BlockPos, Integer> attemptsByPosition = new HashMap<>();
        BuildJob(Preview preview, List<PreparedBlock> blocks, BlockPos origin,
                 int originalSlot, ItemStack originalWorkingStack) {
            this.preview = preview;
            this.blocks = blocks;
            this.origin = origin;
            this.originalSlot = originalSlot;
            this.originalWorkingStack = originalWorkingStack;
        }
    }

    private record PreparedBlock(int x, int y, int z, BlockState state, Item item) {}
    private record PendingBlock(PreparedBlock source, BlockPos position, BlockState expected, long sentAt) {}
    private record PreparedSchematic(SpongeSchematicReader.Schematic schematic,
                                     List<PreparedBlock> blocks, String error) {}

    /** Separate holder to keep the file-system root public to the browser without exposing mutable state. */
    public static final class NoteClientSchematics {
        private NoteClientSchematics() {}
        public static Path folder() {
            return net.fabricmc.loader.api.FabricLoader.getInstance().getGameDir()
                    .resolve("noteclient").resolve("schematics");
        }
    }
}
