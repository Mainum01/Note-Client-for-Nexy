package dev.noteclient.schematic;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/** Reader for Sponge Schematic v2/v3 files (.schem). Block-entity NBT is intentionally not imported. */
public final class SpongeSchematicReader {
    public static final int MAX_DIMENSION = 512;
    public static final int MAX_VOLUME = 2_000_000;
    public static final int MAX_BLOCKS = 500_000;
    private static final int MAX_NBT_BYTES = 128 * 1024 * 1024;
    private static final int MAX_NBT_ENTRIES = 16_000_000;
    private static final int MAX_DEPTH = 64;

    private SpongeSchematicReader() {}

    public static Schematic read(Path file) throws IOException {
        if (file == null || !Files.isRegularFile(file)) throw new IOException("Schematic file does not exist.");
        long size = Files.size(file);
        if (size <= 0 || size > MAX_NBT_BYTES) throw new IOException("Schematic file size is outside the safe 1 byte–128 MiB range.");
        Map<?, ?> root;
        try (InputStream raw = new BufferedInputStream(Files.newInputStream(file));
             InputStream decoded = openMaybeGzip(raw); DataInputStream in = new DataInputStream(decoded)) {
            int rootType = in.readUnsignedByte();
            if (rootType != 10) throw new IOException("The file is not a valid NBT compound schematic.");
            readString(in);
            Object value = readPayload(in, rootType, 0, new Budget());
            if (!(value instanceof Map<?, ?> map)) throw new IOException("Missing schematic root compound.");
            root = map;
        } catch (EOFException exception) {
            throw new IOException("The schematic NBT data is truncated.", exception);
        } catch (IllegalArgumentException exception) {
            throw new IOException("Invalid schematic data: " + exception.getMessage(), exception);
        }
        if (root.containsKey("Regions")) return decodeLitematic(root);
        if (root.containsKey("blocks") && root.containsKey("palette") && root.containsKey("size")) return decodeVanillaStructure(root);
        if (root.containsKey("Blocks") && root.containsKey("Data") && root.containsKey("Width")) return decodeLegacy(root);
        return decodeSchematic(root);
    }

    private static Schematic decodeLitematic(Map<?, ?> root) throws IOException {
        Map<?, ?> regions = asMap(root.get("Regions"));
        if (regions == null || regions.isEmpty()) throw new IOException("Litematic has no regions.");
        record RegionData(int px, int py, int pz, int sx, int sy, int sz, Map<?, ?> tag) {}
        List<RegionData> parsed = new ArrayList<>();
        int minX=Integer.MAX_VALUE,minY=Integer.MAX_VALUE,minZ=Integer.MAX_VALUE;
        int maxX=Integer.MIN_VALUE,maxY=Integer.MIN_VALUE,maxZ=Integer.MIN_VALUE;
        for (Object value : regions.values()) {
            Map<?, ?> region = asMap(value); if (region == null) continue;
            int[] pos = vec3(region.get("Position")); int[] size = vec3(region.get("Size"));
            if (pos == null || size == null) throw new IOException("Litematic region is missing Position or Size.");
            int sx=Math.abs(size[0]), sy=Math.abs(size[1]), sz=Math.abs(size[2]);
            if (sx<1||sy<1||sz<1) continue;
            long vol=(long)sx*sy*sz; if (vol>MAX_VOLUME) throw new IOException("Litematic region exceeds safe volume limit.");
            int x0=pos[0]+(size[0]<0?size[0]+1:0), y0=pos[1]+(size[1]<0?size[1]+1:0), z0=pos[2]+(size[2]<0?size[2]+1:0);
            int x1=x0+sx-1,y1=y0+sy-1,z1=z0+sz-1;
            minX=Math.min(minX,x0); minY=Math.min(minY,y0); minZ=Math.min(minZ,z0);
            maxX=Math.max(maxX,x1); maxY=Math.max(maxY,y1); maxZ=Math.max(maxZ,z1);
            parsed.add(new RegionData(pos[0],pos[1],pos[2],size[0],size[1],size[2],region));
        }
        if (parsed.isEmpty()) throw new IOException("Litematic contains no valid regions.");
        int width=maxX-minX+1,height=maxY-minY+1,length=maxZ-minZ+1;
        if ((long)width*height*length>MAX_VOLUME) throw new IOException("Combined litematic regions exceed safe volume limit.");
        List<BlockEntry> out=new ArrayList<>();
        for (RegionData r:parsed) {
            List<?> palette=asList(r.tag.get("BlockStatePalette")); Object rawStates=r.tag.get("BlockStates");
            if (palette==null || !(rawStates instanceof long[] states)) throw new IOException("Litematic region is missing BlockStatePalette or BlockStates.");
            if (palette.isEmpty()) throw new IOException("Litematic region has an empty block palette.");
            int bits=Math.max(2, 32-Integer.numberOfLeadingZeros(palette.size()-1));
            long mask=(1L<<bits)-1L;
            int sx=Math.abs(r.sx),sy=Math.abs(r.sy),sz=Math.abs(r.sz); long volume=(long)sx*sy*sz;
            if (volume>MAX_VOLUME) throw new IOException("Litematic region exceeds safe volume limit.");
            int regionMinX=r.px+(r.sx<0?r.sx+1:0), regionMinY=r.py+(r.sy<0?r.sy+1:0), regionMinZ=r.pz+(r.sz<0?r.sz+1:0);
            for (int i=0;i<(int)volume;i++) {
                long bitIndex=(long)i*bits; int word=(int)(bitIndex>>>6), shift=(int)(bitIndex&63);
                if (word>=states.length) throw new IOException("Litematic packed block data is truncated.");
                long packed=states[word]>>>shift;
                if (shift+bits>64) {
                    if (word+1>=states.length) throw new IOException("Litematic packed block data is truncated at a long boundary.");
                    packed |= states[word+1] << (64-shift);
                }
                int paletteId=(int)(packed&mask);
                if (paletteId<0||paletteId>=palette.size()) throw new IOException("Litematic references an invalid palette index.");
                ParsedState state=parsePaletteState(palette.get(paletteId));
                if (isAir(state.blockId)) continue;
                int lx=i%sx, lz=(i/sx)%sz, ly=i/(sx*sz);
                int gx=regionMinX+lx-minX;
                int gy=regionMinY+ly-minY;
                int gz=regionMinZ+lz-minZ;
                out.add(new BlockEntry(gx,gy,gz,state.blockId,state.properties));
                if(out.size()>MAX_BLOCKS) throw new IOException("Litematic contains more than "+MAX_BLOCKS+" non-air blocks.");
            }
        }
        return new Schematic(width,height,length,number(root.get("Version"),0),out,0);
    }

    private static Schematic decodeVanillaStructure(Map<?, ?> root) throws IOException {
        int[] size=vec3(root.get("size")); if(size==null) throw new IOException("Vanilla structure is missing size.");
        int w=size[0],h=size[1],l=size[2]; checkDimensions(w,h,l);
        List<?> palette=asList(root.get("palette")); List<?> blocks=asList(root.get("blocks"));
        if(palette==null||blocks==null) throw new IOException("Vanilla structure is missing palette or blocks list.");
        List<ParsedState> states=new ArrayList<>(); for(Object entry:palette) states.add(parsePaletteState(entry));
        List<BlockEntry> out=new ArrayList<>();
        for(Object entry:blocks){ Map<?,?> b=asMap(entry); if(b==null) continue; int[] pos=vec3(b.get("pos")); int idx=number(b.get("state"),-1);
            if(pos==null||idx<0||idx>=states.size()) continue; ParsedState st=states.get(idx); if(isAir(st.blockId)) continue;
            out.add(new BlockEntry(pos[0],pos[1],pos[2],st.blockId,st.properties)); if(out.size()>MAX_BLOCKS) throw new IOException("Structure exceeds block limit."); }
        return new Schematic(w,h,l,0,out,states.size());
    }

    private static Schematic decodeLegacy(Map<?, ?> root) throws IOException {
        int w=number(root.get("Width"),0),h=number(root.get("Height"),0),l=number(root.get("Length"),0); checkDimensions(w,h,l);
        Object raw=root.get("Blocks"), data=root.get("Data"); if(!(raw instanceof byte[] ids)||!(data instanceof byte[] metadata)) throw new IOException("Legacy schematic is missing Blocks or Data arrays.");
        int volume=w*h*l; if(ids.length<volume||metadata.length<volume) throw new IOException("Legacy schematic block arrays are truncated.");
        List<BlockEntry> out=new ArrayList<>();
        for(int i=0;i<volume;i++){ int id=ids[i]&255, meta=metadata[i]&15; String name=legacyBlock(id); if(name==null) continue;
            Map<String,String> props=legacyProperties(id,meta); int x=i%w,z=(i/w)%l,y=i/(w*l);
            out.add(new BlockEntry(x,y,z,name,props)); if(out.size()>MAX_BLOCKS) throw new IOException("Legacy schematic exceeds block limit."); }
        return new Schematic(w,h,l,1,out,0);
    }

    private static String legacyBlock(int id) {
        return switch(id){case 1->"minecraft:stone";case 2->"minecraft:grass_block";case 3->"minecraft:dirt";case 4->"minecraft:cobblestone";case 5->"minecraft:oak_planks";case 12->"minecraft:sand";case 13->"minecraft:gravel";case 17->"minecraft:oak_log";case 20->"minecraft:glass";case 24->"minecraft:sandstone";case 35->"minecraft:white_wool";case 41->"minecraft:gold_block";case 42->"minecraft:iron_block";case 45->"minecraft:bricks";case 47->"minecraft:bookshelf";case 49->"minecraft:obsidian";case 57->"minecraft:diamond_block";case 79->"minecraft:ice";case 80->"minecraft:snow_block";case 82->"minecraft:clay";case 87->"minecraft:netherrack";case 89->"minecraft:glowstone";case 98->"minecraft:stone_bricks";case 103->"minecraft:melon";case 112->"minecraft:nether_bricks";case 121->"minecraft:end_stone";case 133->"minecraft:emerald_block";case 152->"minecraft:redstone_block";case 155->"minecraft:quartz_block";case 159->"minecraft:white_terracotta";case 172->"minecraft:terracotta";case 173->"minecraft:coal_block";default->null;};
    }
    private static Map<String,String> legacyProperties(int id,int meta){
        Map<String,String> p=new LinkedHashMap<>(); if(id==17)p.put("axis",switch(meta&12){case 4->"x";case 8->"z";default->"y";});
        if(id==5){String[] names={"oak","spruce","birch","jungle","acacia","dark_oak"}; if(meta<names.length) return Map.of();}
        return p;
    }
    private static boolean isAir(String id){return id.equals("minecraft:air")||id.equals("minecraft:cave_air")||id.equals("minecraft:void_air");}
    private static void checkDimensions(int w,int h,int l)throws IOException{if(w<1||h<1||l<1||w>MAX_DIMENSION||h>MAX_DIMENSION||l>MAX_DIMENSION||(long)w*h*l>MAX_VOLUME)throw new IOException("Schematic dimensions exceed safe limits.");}
    private static int[] vec3(Object value){if(value instanceof int[] a&&a.length>=3)return new int[]{a[0],a[1],a[2]}; if(value instanceof List<?> a&&a.size()>=3)return new int[]{number(a.get(0),0),number(a.get(1),0),number(a.get(2),0)}; Map<?,?> m=asMap(value); if(m!=null)return new int[]{number(m.get("x"),0),number(m.get("y"),0),number(m.get("z"),0)}; return null;}
    private static List<?> asList(Object value){return value instanceof List<?> l?l:null;}
    private static ParsedState parsePaletteState(Object value)throws IOException{Map<?,?> m=asMap(value); if(m==null)throw new IOException("Invalid block palette entry."); Object name=m.get("Name"); if(!(name instanceof String id))throw new IOException("Block palette entry has no Name."); Map<String,String> props=new LinkedHashMap<>(); Map<?,?> raw=asMap(m.get("Properties")); if(raw!=null)for(var e:raw.entrySet())if(e.getKey() instanceof String k&&e.getValue()!=null)props.put(k,String.valueOf(e.getValue())); return new ParsedState(id,Collections.unmodifiableMap(props));}

    private static InputStream openMaybeGzip(InputStream input) throws IOException {
        input.mark(2);
        int first = input.read();
        int second = input.read();
        input.reset();
        if (first == 0x1F && second == 0x8B) return new GZIPInputStream(input);
        return input;
    }

    private static Schematic decodeSchematic(Map<?, ?> root) throws IOException {
        int version = number(root.get("Version"), -1);
        if (version != 2 && version != 3) {
            throw new IOException("Only Sponge Schematic format versions 2 and 3 are supported (found " + version + ").");
        }
        int width = number(root.get("Width"), 0);
        int height = number(root.get("Height"), 0);
        int length = number(root.get("Length"), 0);
        if (width < 1 || height < 1 || length < 1
                || width > MAX_DIMENSION || height > MAX_DIMENSION || length > MAX_DIMENSION) {
            throw new IOException("Schematic dimensions must each be between 1 and " + MAX_DIMENSION + ".");
        }
        long volumeLong = (long) width * height * length;
        if (volumeLong > MAX_VOLUME) {
            throw new IOException("Schematic volume exceeds the safe limit of " + MAX_VOLUME + " cells.");
        }
        int volume = (int) volumeLong;

        Map<?, ?> blocks = asMap(root.get("Blocks"));
        Object paletteObject = blocks == null ? root.get("Palette") : blocks.get("Palette");
        Object dataObject = blocks == null ? root.get("BlockData") : blocks.get("Data");
        if (paletteObject == null && blocks != null) paletteObject = root.get("Palette");
        if (dataObject == null) dataObject = root.get("BlockData");
        Map<?, ?> rawPalette = asMap(paletteObject);
        if (rawPalette == null || !(dataObject instanceof byte[] blockData)) {
            throw new IOException("Missing Sponge Blocks.Palette or Blocks.Data data.");
        }
        if (rawPalette.isEmpty() || rawPalette.size() > MAX_VOLUME) {
            throw new IOException("Schematic block palette is empty or too large.");
        }

        Map<Integer, String> palette = new LinkedHashMap<>();
        int maximumPaletteId = -1;
        for (Map.Entry<?, ?> entry : rawPalette.entrySet()) {
            if (!(entry.getKey() instanceof String state) || !(entry.getValue() instanceof Number value)) continue;
            int id = value.intValue();
            if (id < 0 || id >= MAX_VOLUME) throw new IOException("Schematic palette contains an invalid state index.");
            palette.put(id, state);
            maximumPaletteId = Math.max(maximumPaletteId, id);
        }
        if (palette.isEmpty()) throw new IOException("Schematic block palette contains no valid block states.");

        List<BlockEntry> entries = new ArrayList<>(Math.min(volume, MAX_BLOCKS));
        int[] cursor = {0};
        for (int index = 0; index < volume; index++) {
            int paletteId = readVarInt(blockData, cursor);
            String stateText = palette.get(paletteId);
            if (stateText == null) {
                throw new IOException("Block data references missing palette id " + paletteId + ".");
            }
            ParsedState state = parseBlockState(stateText);
            if (state.blockId.equals("minecraft:air") || state.blockId.equals("minecraft:cave_air")
                    || state.blockId.equals("minecraft:void_air")) continue;
            if (entries.size() >= MAX_BLOCKS) {
                throw new IOException("Schematic contains more than " + MAX_BLOCKS + " non-air blocks.");
            }
            int x = index % width;
            int z = (index / width) % length;
            int y = index / (width * length);
            entries.add(new BlockEntry(x, y, z, state.blockId, state.properties));
        }

        if (cursor[0] < blockData.length) {
            // Sponge writes exactly one palette varint per cell. Extra bytes usually mean a malformed or
            // incompatible encoding; tolerate only zero padding so we don't silently shift block data.
            for (int i = cursor[0]; i < blockData.length; i++) {
                if (blockData[i] != 0) throw new IOException("Unexpected trailing bytes in Sponge block data.");
            }
        }
        return new Schematic(width, height, length, version, entries, maximumPaletteId + 1);
    }

    private static ParsedState parseBlockState(String text) throws IOException {
        String value = text.trim();
        int open = value.indexOf('[');
        String blockId = open < 0 ? value : value.substring(0, open);
        if (blockId.isBlank() || !blockId.contains(":")) throw new IOException("Invalid block state id: " + text);
        Map<String, String> properties = new LinkedHashMap<>();
        if (open >= 0) {
            int close = value.lastIndexOf(']');
            if (close < open) throw new IOException("Invalid block-state properties: " + text);
            String list = value.substring(open + 1, close).trim();
            if (!list.isEmpty()) {
                for (String part : list.split(",")) {
                    int equals = part.indexOf('=');
                    if (equals <= 0 || equals == part.length() - 1) continue;
                    properties.put(part.substring(0, equals).trim(), part.substring(equals + 1).trim());
                }
            }
        }
        return new ParsedState(blockId, Collections.unmodifiableMap(properties));
    }

    private static int readVarInt(byte[] bytes, int[] cursor) throws IOException {
        int result = 0;
        int shift = 0;
        while (shift < 35) {
            if (cursor[0] >= bytes.length) throw new IOException("Block data ended before all palette entries were read.");
            int value = bytes[cursor[0]++] & 0xFF;
            result |= (value & 0x7F) << shift;
            if ((value & 0x80) == 0) return result;
            shift += 7;
        }
        throw new IOException("Block data contains an overlong palette varint.");
    }

    private static Object readPayload(DataInputStream in, int type, int depth, Budget budget) throws IOException {
        if (depth > MAX_DEPTH) throw new IOException("NBT nesting is too deep.");
        return switch (type) {
            case 1 -> in.readByte();
            case 2 -> in.readShort();
            case 3 -> in.readInt();
            case 4 -> in.readLong();
            case 5 -> in.readFloat();
            case 6 -> in.readDouble();
            case 7 -> readByteArray(in, budget);
            case 8 -> readString(in);
            case 9 -> readList(in, depth, budget);
            case 10 -> readCompound(in, depth, budget);
            case 11 -> readIntArray(in, budget);
            case 12 -> readLongArray(in, budget);
            default -> throw new IOException("Unknown NBT tag id " + type + ".");
        };
    }

    private static byte[] readByteArray(DataInputStream in, Budget budget) throws IOException {
        int length = readLength(in, budget);
        byte[] data = new byte[length];
        in.readFully(data);
        return data;
    }

    private static int[] readIntArray(DataInputStream in, Budget budget) throws IOException {
        int length = readLength(in, budget);
        int[] values = new int[length];
        for (int i = 0; i < length; i++) values[i] = in.readInt();
        return values;
    }

    private static long[] readLongArray(DataInputStream in, Budget budget) throws IOException {
        int length = readLength(in, budget);
        long[] values = new long[length];
        for (int i = 0; i < length; i++) values[i] = in.readLong();
        return values;
    }

    private static List<Object> readList(DataInputStream in, int depth, Budget budget) throws IOException {
        int childType = in.readUnsignedByte();
        int length = readLength(in, budget);
        if (childType == 0 && length != 0) throw new IOException("Invalid non-empty NBT end-tag list.");
        List<Object> values = new ArrayList<>(length);
        for (int i = 0; i < length; i++) values.add(readPayload(in, childType, depth + 1, budget));
        return values;
    }

    private static Map<String, Object> readCompound(DataInputStream in, int depth, Budget budget) throws IOException {
        Map<String, Object> values = new LinkedHashMap<>();
        while (true) {
            int childType = in.readUnsignedByte();
            if (childType == 0) return values;
            budget.add(1);
            String name = readString(in);
            values.put(name, readPayload(in, childType, depth + 1, budget));
        }
    }

    private static int readLength(DataInputStream in, Budget budget) throws IOException {
        int length = in.readInt();
        if (length < 0 || length > MAX_NBT_ENTRIES) throw new IOException("NBT array/list length is invalid or exceeds the safe limit.");
        budget.add(length);
        return length;
    }

    private static String readString(DataInputStream in) throws IOException {
        int length = in.readUnsignedShort();
        byte[] bytes = new byte[length];
        in.readFully(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    private static Map<?, ?> asMap(Object value) {
        return value instanceof Map<?, ?> map ? map : null;
    }

    private static int number(Object value, int fallback) {
        return value instanceof Number number ? number.intValue() : fallback;
    }

    private static final class Budget {
        private long entries;
        private void add(long value) throws IOException {
            entries += value;
            if (entries > MAX_NBT_ENTRIES) throw new IOException("NBT payload has too many nested entries.");
        }
    }

    private record ParsedState(String blockId, Map<String, String> properties) {}

    public record BlockEntry(int x, int y, int z, String blockId, Map<String, String> properties) {}

    public record Schematic(int width, int height, int length, int version,
                            List<BlockEntry> blocks, int paletteSize) {
        public Schematic {
            blocks = List.copyOf(blocks);
        }
    }
}
