package dev.noteclient;

import dev.noteclient.schematic.SchematicBuilder;

import dev.noteclient.plan.NoteBlockPlanner;
import dev.noteclient.plan.NoteBlockPlanner.PlanResult;
import dev.noteclient.plan.NoteBlockPlanner.Placement;
import dev.noteclient.plan.NoteBlockPlanner.TimedNote;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.BlockItemStateProperties;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Builds a real, button-started redstone note-block sequencer using ordinary
 * Creative-mode block interactions. No NoteClient server companion is needed.
 * Every placement waits for the world state to confirm it before continuing.
 */
public final class RedstoneSequencerBuilder {
    private static final int WORKING_SLOT = 8;
    // Each timing stage occupies three blocks along the repeater rail. The build
    // is streamed within ordinary interaction reach; the player follows its edge.
    private static final int MAX_STAGES = 255;
    // Two isolated dust branches can fan out to fourteen note blocks each.
    private static final int NOTES_PER_BRANCH = 14;
    private static final int MAX_NOTES_PER_STAGE = NOTES_PER_BRANCH * 2;
    private static final int MAX_ATTEMPTS = 3;
    private static final int ACK_TIMEOUT_TICKS = 40;
    private static final int STATUS_INTERVAL_TICKS = 30;

    private static Job activeJob;

    private RedstoneSequencerBuilder() {}

    public static boolean hasActiveJob() {
        return activeJob != null;
    }

    public static boolean start(Minecraft client, PlanResult plan, int tempoHundredths) {
        if (client == null || client.player == null || client.level == null || client.gameMode == null) {
            fail("Join a world before building a redstone sequencer.");
            return false;
        }
        if (activeJob != null) {
            fail("A redstone sequencer build is already running. Press P to pause or O to stop.");
            return false;
        }
        if (VanillaServerBuilder.hasActiveJob() || SchematicBuilder.hasActiveJob()
                || PlayerStatueBuilder.isBuilding() || PlayerStatueBuilder.isRemoving()) {
            fail("Another NoteClient block build is already active. Let it finish or stop it before starting Redstone Setup.");
            return false;
        }
        if (client.gameMode.getPlayerMode() != GameType.CREATIVE) {
            fail("Redstone Setup uses ordinary Creative block interactions. Switch to Creative and try again.");
            return false;
        }
        if (plan == null || plan.placements().isEmpty() || plan.timeline().isEmpty() || tempoHundredths <= 0) {
            fail("This song does not contain a playable NBS timeline for a physical sequencer.");
            return false;
        }

        try {
            List<CircuitBlock> blocks = createCircuit(client, plan, tempoHundredths);
            if (blocks.isEmpty()) {
                fail("The song did not produce any physical redstone blocks.");
                return false;
            }
            LocalPlayer player = client.player;
            Map<Item, Integer> requiredMaterials = new LinkedHashMap<>();
            for (CircuitBlock block : blocks) {
                Item item = block.expected.getBlock().asItem();
                if (item != Items.AIR) requiredMaterials.merge(item, 1, Integer::sum);
            }
            CreativeMaterialStager.Result inventory = CreativeMaterialStager.stage(client, requiredMaterials);
            // Capture the working stack after material stocking so finish/stop
            // restores the stocked items instead of deleting them.
            activeJob = new Job(client.level, blocks, player.getInventory().getSelectedSlot(),
                    player.getInventory().getItem(WORKING_SLOT).copy());
            BuildClientState.reset("Building client-side redstone sequencer • 0 / " + blocks.size()
                    + " confirmed • " + inventory.summary()
                    + " • follow the circuit when prompted. Do not press its button until the build finishes.");
            BuildClientState.updateLocal(0, blocks.size(), 0, 1, false, false, BuildClientState.message());
            NoteClientHud.show(BuildClientState.message());
            return true;
        } catch (IllegalArgumentException exception) {
            fail(exception.getMessage());
            return false;
        } catch (RuntimeException exception) {
            String reason = exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage();
            fail("Could not plan the redstone circuit: " + reason);
            return false;
        }
    }

    public static void tick(Minecraft client) {
        Job job = activeJob;
        if (job == null) return;
        if (client == null || client.player == null || client.level == null || client.gameMode == null) {
            finish(client, job, "Redstone build stopped after disconnect. Confirmed circuit blocks remain in the world.");
            return;
        }
        if (client.level != job.level) {
            finish(client, job, "Redstone build stopped after the dimension changed. Confirmed circuit blocks remain in the previous dimension.");
            return;
        }
        if (client.gameMode.getPlayerMode() != GameType.CREATIVE) {
            finish(client, job, "Redstone build stopped because Creative mode is no longer active. Confirmed blocks were retained.");
            return;
        }
        if (job.paused) return;

        long now = client.level.getGameTime();
        for (int i = 0; i < job.pending.size();) {
            PendingBlock pending = job.pending.get(i);
            CircuitBlock block = pending.block;
            BlockState observed = client.level.getBlockState(block.position);
            boolean foundationReady = block.foundation && !observed.isAir() && !observed.hasBlockEntity()
                    && observed.isFaceSturdy(client.level, block.position, Direction.UP);
            if (foundationReady || matchesExpectedBlock(observed, block.expected)) {
                job.placed++;
                job.pending.remove(i);
                if (job.placed % 10 == 0 || job.placed == job.blocks.size()) {
                    setStatus(job, now, "Building physical redstone sequencer • " + job.placed + " / "
                            + job.blocks.size() + " confirmed • " + job.pending.size() + " awaiting server");
                }
                continue;
            }
            if (!observed.isAir()) {
                finish(client, job, "Redstone build stopped: another block appeared at "
                        + block.position.toShortString() + ". That block was left untouched; confirmed circuit blocks remain.");
                return;
            }
            if (now - pending.sentAt >= ACK_TIMEOUT_TICKS) {
                job.pending.remove(i);
                if (pending.attempts >= MAX_ATTEMPTS) {
                    finish(client, job, "Redstone build stopped: the server did not confirm "
                            + block.position.toShortString() + " after " + MAX_ATTEMPTS
                            + " attempts. Confirmed circuit blocks were retained. Check reach, claims, and Creative placement permissions.");
                    return;
                }
                job.retries.addLast(new RetryBlock(block, pending.attempts + 1,
                        now + 2L * pending.attempts));
                continue;
            }
            i++;
        }

        int buildBudget = NoteClientConfig.buildActionsPerTick();
        int maxInFlight = Math.max(3, Math.min(128, buildBudget * 3));
        int sent = 0;
        int examined = 0;
        int maxExamined = Math.max(32, buildBudget * 8);
        while (sent < buildBudget && examined < maxExamined && job.pending.size() < maxInFlight) {
            RetryBlock retry = job.retries.peekFirst();
            boolean isRetry = retry != null && retry.readyAt <= now;
            CircuitBlock block;
            int attempts;
            if (isRetry) {
                retry = job.retries.removeFirst();
                block = retry.block;
                attempts = retry.attempts;
            } else if (job.index < job.blocks.size()) {
                block = job.blocks.get(job.index);
                attempts = 1;
            } else {
                break;
            }

            examined++;
            BlockPos target = block.position;
            if (!client.level.getWorldBorder().isWithinBounds(target) || client.level.isOutsideBuildHeight(target)) {
                finish(client, job, "Redstone build stopped: " + target.toShortString()
                        + " is outside the world border or build height. Confirmed blocks were retained.");
                return;
            }
            if (!client.level.hasChunkAt(target)) {
                if (isRetry) job.retries.addFirst(retry);
                setStatus(job, now, "Waiting for the next circuit chunk at " + target.toShortString() + ". Move closer to load it.");
                return;
            }
            if (block.clearAbove != null) {
                if (!client.level.hasChunkAt(block.clearAbove)) {
                    if (isRetry) job.retries.addFirst(retry);
                    setStatus(job, now, "Waiting for the note-block sound space to load. Move closer to the next circuit section.");
                    return;
                }
                if (!client.level.getBlockState(block.clearAbove).isAir()) {
                    finish(client, job, "Redstone build stopped: the space above a note block is obstructed at "
                            + block.clearAbove.toShortString() + ". Existing blocks were not changed.");
                    return;
                }
            }

            BlockState existing = client.level.getBlockState(target);
            if (block.foundation) {
                if (!existing.isAir() && !existing.hasBlockEntity()
                        && existing.isFaceSturdy(client.level, target, Direction.UP)) {
                    if (!isRetry) job.index++;
                    continue;
                }
                if (!existing.isAir()) {
                    finish(client, job, "Redstone build stopped: the required foundation position is occupied by a non-solid block at "
                            + target.toShortString() + ". Nothing was replaced.");
                    return;
                }
            } else {
                if (matchesExpectedBlock(existing, block.expected)) {
                    job.placed++;
                    if (!isRetry) job.index++;
                    continue;
                }
                if (!existing.isAir()) {
                    finish(client, job, "Redstone build stopped: " + target.toShortString()
                            + " is occupied. Existing blocks were not replaced.");
                    return;
                }
            }

            BlockHitResult hit = findPlacementHit(client, target);
            if (hit == null) {
                if (isRetry) job.retries.addFirst(retry);
                job.waitingForPlayer = true;
                job.nextAction = now + 10;
                setStatus(job, now, "Move closer to the next circuit block at " + target.toShortString()
                        + ". Follow alongside the repeater line; the build will resume automatically.");
                return;
            }
            job.waitingForPlayer = false;

            Item item = block.expected.getBlock().asItem();
            if (item == Items.AIR) {
                finish(client, job, "Redstone build stopped: " + block.expected.getBlock().getDescriptionId()
                        + " has no placeable item. Confirmed blocks were retained.");
                return;
            }

            ItemStack stack = new ItemStack(item, 1);
            if (!block.expected.is(Blocks.REDSTONE_WIRE)) {
                Map<String, String> properties = serializedProperties(block.expected);
                if (!properties.isEmpty()) stack.set(DataComponents.BLOCK_STATE, new BlockItemStateProperties(properties));
            }
            LocalPlayer player = client.player;
            player.getInventory().setSelectedSlot(WORKING_SLOT);
            player.getInventory().setItem(WORKING_SLOT, stack.copy());
            client.gameMode.handleCreativeModeItemAdd(stack.copy(), 36 + WORKING_SLOT);
            InteractionResult result = client.gameMode.useItemOn(player, InteractionHand.MAIN_HAND, hit);
            if (result != null && result.consumesAction()) {
                job.pending.add(new PendingBlock(block, attempts, now));
                if (!isRetry) job.index++;
                sent++;
            } else {
                if (attempts >= MAX_ATTEMPTS) {
                    finish(client, job, "Redstone build stopped: the server rejected placement at "
                            + target.toShortString() + " after " + MAX_ATTEMPTS
                            + " attempts. Confirmed circuit blocks were retained. Check reach, claims, and Creative placement permissions.");
                    return;
                }
                job.retries.addLast(new RetryBlock(block, attempts + 1, now + 2L * attempts));
                if (!isRetry) job.index++;
                break;
            }
        }

        if (job.index >= job.blocks.size() && job.retries.isEmpty() && job.pending.isEmpty()) {
            finish(client, job, "Redstone sequencer complete • " + job.placed
                    + " blocks confirmed. Anyone who can reach the stone button can start it. The circuit is retained.");
            BuildClientState.updateLocal(job.placed, job.blocks.size(), 0, 4, true, false, BuildClientState.message());
            return;
        }
        if (sent > 0) {
            setStatus(job, now, "Building physical redstone sequencer • " + job.placed + " / "
                    + job.blocks.size() + " confirmed • " + job.pending.size() + " awaiting server • "
                    + job.retries.size() + " retrying");
        }
    }

    private static void setStatus(Job job, long now, String message) {
        if (job.lastStatus == Long.MIN_VALUE || now - job.lastStatus >= STATUS_INTERVAL_TICKS
                || job.index == job.blocks.size()) {
            job.lastStatus = now;
            BuildClientState.updateLocalQuietly(job.placed, job.blocks.size(), 0, 1, false, job.paused, message);
            NoteClientHud.show(message);
        }
    }

    /** Toggles the active redstone build without discarding its confirmed/pending work. */
    public static void togglePause(Minecraft client) {
        Job job = activeJob;
        if (job == null) return;
        job.paused = !job.paused;
        String message = job.paused
                ? "Redstone sequencer build paused • P to resume • O to stop"
                : "Redstone sequencer build resumed • " + job.placed + " / " + job.blocks.size() + " confirmed";
        BuildClientState.updateLocalQuietly(job.placed, job.blocks.size(), 0, 1,
                false, job.paused, message);
        NoteClientHud.show(message);
    }

    /** Stops sending placements. Already confirmed circuit blocks are deliberately retained. */
    public static void cancel(Minecraft client) {
        Job job = activeJob;
        if (job == null) return;
        int awaiting = job.pending.size();
        finish(client, job, "Redstone sequencer build stopped • " + job.placed
                + " confirmed blocks remain. " + awaiting
                + " already-sent placements may still be processed by the server. No automatic cleanup was performed.");
    }

    /** Releases local builder state when leaving a server; never sends cleanup packets. */
    public static void onDisconnect(Minecraft client) {
        Job job = activeJob;
        if (job == null) return;
        if (client != null && client.player != null) {
            // Restore the temporary working hotbar slot locally. The server owns
            // every placement already sent, so disconnect must not try to undo it.
            client.player.getInventory().setItem(WORKING_SLOT, job.originalWorkingStack.copy());
            client.player.getInventory().setSelectedSlot(job.originalSelectedSlot);
        }
        activeJob = null;
    }

    private static void finish(Minecraft client, Job job, String message) {
        restoreHand(client, job);
        activeJob = null;
        BuildClientState.updateLocal(job.placed, job.blocks.size(), 0, 4, true, false, message);
        NoteClientHud.show(message);
    }

    private static void restoreHand(Minecraft client, Job job) {
        if (client == null || client.player == null) return;
        client.player.getInventory().setItem(WORKING_SLOT, job.originalWorkingStack.copy());
        if (client.gameMode != null && client.gameMode.getPlayerMode() == GameType.CREATIVE) {
            client.gameMode.handleCreativeModeItemAdd(job.originalWorkingStack.copy(), 36 + WORKING_SLOT);
        }
        client.player.getInventory().setSelectedSlot(job.originalSelectedSlot);
    }

    private static List<CircuitBlock> createCircuit(Minecraft client, PlanResult plan, int tempoHundredths) {
        TreeMap<Integer, List<PhysicalNote>> grouped = new TreeMap<>();
        for (TimedNote event : plan.timeline()) {
            if (event.volume() <= 0) continue;
            if (event.cellIndex() < 0 || event.cellIndex() >= plan.placements().size()) {
                throw new IllegalArgumentException("The NBS timeline contains an invalid note-to-block reference.");
            }
            Placement placement = plan.placements().get(event.cellIndex());
            if (placement.instrumentId() < 0 || placement.instrumentId() >= NoteBlockPlanner.instruments().size()
                    || placement.noteBlockPitch() < 0 || placement.noteBlockPitch() > 24) {
                throw new IllegalArgumentException("A note uses an unsupported vanilla instrument or pitch.");
            }
            // NBS tempo is stored in hundredths. One redstone tick is 0.1 s,
            // so each event is quantized to the nearest physical repeater tick.
            long tickLong = Math.max(1L, Math.round(event.tick() * 1000.0 / tempoHundredths));
            // The physical circuit is deliberately capped at 255 repeaters.
            // Notes beyond that point are omitted instead of rejecting the song.
            if (tickLong > MAX_STAGES * 4L) continue;
            int redstoneTick = (int) tickLong;
            List<PhysicalNote> chord = grouped.computeIfAbsent(redstoneTick, ignored -> new ArrayList<>());
            chord.add(new PhysicalNote(placement.instrumentId(), placement.noteBlockPitch()));
            if (chord.size() > MAX_NOTES_PER_STAGE) {
                throw new IllegalArgumentException("A chord has " + chord.size()
                        + " simultaneous notes after 0.1-second redstone timing is applied. "
                        + "The physical circuit supports up to " + MAX_NOTES_PER_STAGE
                        + " notes per moment; use Direct Play for this song.");
            }
        }
        if (grouped.isEmpty()) throw new IllegalArgumentException("No audible notes remain after filtering silent events.");

        List<RedstoneStage> stages = new ArrayList<>();
        int elapsed = 0;
        for (Map.Entry<Integer, List<PhysicalNote>> entry : grouped.entrySet()) {
            int gap = entry.getKey() - elapsed;
            while (gap > 4 && stages.size() < MAX_STAGES) {
                stages.add(new RedstoneStage(4, List.of()));
                elapsed += 4;
                gap -= 4;
            }
            if (stages.size() >= MAX_STAGES) break;
            if (gap < 1) gap = 1;
            stages.add(new RedstoneStage(gap, List.copyOf(entry.getValue())));
            elapsed += gap;
            if (stages.size() >= MAX_STAGES) break;
        }

        LocalPlayer player = client.player;
        Direction forward = Direction.fromYRot(player.getYRot());
        Direction side = forward.getClockWise();
        Direction oppositeSide = side.getOpposite();
        BlockPos anchor = player.blockPosition();
        // The rail is one block above the ground. Repeaters and redstone dust
        // all occupy the same Y level, with a solid support directly underneath.
        // The start button sits on the input block behind the first repeater.
        BlockPos circuitBase = anchor.relative(forward, 2).above();
        LinkedHashMap<BlockPos, CircuitBlock> planned = new LinkedHashMap<>();

        addFoundation(client, planned, circuitBase.below());
        addRequired(client, planned, circuitBase, Blocks.STONE.defaultBlockState(), null);

        List<NoteBlockPlanner.Instrument> instruments = NoteBlockPlanner.instruments();
        for (int stageIndex = 0; stageIndex < stages.size(); stageIndex++) {
            RedstoneStage stage = stages.get(stageIndex);
            // Stage geometry (all at the same height):
            // repeater -> wire -> wire -> next repeater.
            // The first wire also feeds two side branches. Each branch wire is
            // directly adjacent to the note block it triggers.
            BlockPos repeaterPos = circuitBase.relative(forward, stageIndex * 3 + 1);
            BlockPos firstWirePos = repeaterPos.relative(forward);
            BlockPos secondWirePos = repeaterPos.relative(forward, 2);

            BlockState repeater = withProperty(Blocks.REPEATER.defaultBlockState(), "facing", forward.getName());
            repeater = withProperty(repeater, "delay", Integer.toString(stage.delay));
            addFoundation(client, planned, repeaterPos.below());
            addRequired(client, planned, repeaterPos, repeater, null);

            addFoundation(client, planned, firstWirePos.below());
            addRequired(client, planned, firstWirePos, Blocks.REDSTONE_WIRE.defaultBlockState(), null);
            addFoundation(client, planned, secondWirePos.below());
            addRequired(client, planned, secondWirePos, Blocks.REDSTONE_WIRE.defaultBlockState(), null);

            int firstBranchCount = Math.min(NOTES_PER_BRANCH, stage.notes.size());
            int secondBranchCount = Math.max(0, stage.notes.size() - firstBranchCount);
            addNoteBranch(client, planned, firstWirePos, secondWirePos, side, stage.notes, 0,
                    firstBranchCount, instruments);
            addNoteBranch(client, planned, firstWirePos, secondWirePos, oppositeSide,
                    stage.notes, firstBranchCount, secondBranchCount, instruments);
        }

        // Button is installed last so it cannot accidentally start a partially
        // built circuit. It powers the solid input block directly behind stage 0.
        BlockState button = withProperty(Blocks.STONE_BUTTON.defaultBlockState(), "face", "floor");
        button = withProperty(button, "facing", forward.getName());
        addRequired(client, planned, circuitBase.above(), button, null);

        List<CircuitBlock> result = new ArrayList<>(planned.values());
        for (CircuitBlock block : result) {
            if (block.expected.getBlock().asItem() == Items.AIR) {
                throw new IllegalArgumentException("The block " + block.expected.getBlock().getDescriptionId()
                        + " has no placeable item and cannot be used in the physical circuit.");
            }
        }
        validateCircuitSpace(client, result);
        return result;
    }

    private static void validateCircuitSpace(Minecraft client, List<CircuitBlock> blocks) {
        for (CircuitBlock block : blocks) {
            BlockPos position = block.position;
            if (!client.level.getWorldBorder().isWithinBounds(position)
                    || client.level.isOutsideBuildHeight(position)) {
                throw new IllegalArgumentException("The planned circuit reaches outside the world border/build height at "
                        + position.toShortString() + ". Move to a larger clear area.");
            }
            if (client.level.hasChunkAt(position)) {
                BlockState existing = client.level.getBlockState(position);
                if (block.foundation) {
                    if (!existing.isAir() && (existing.hasBlockEntity()
                            || !existing.isFaceSturdy(client.level, position, Direction.UP))) {
                        throw new IllegalArgumentException("The circuit foundation is obstructed at "
                                + position.toShortString() + ". Nothing was replaced.");
                    }
                } else if (!existing.isAir() && !matchesExpectedBlock(existing, block.expected)) {
                    throw new IllegalArgumentException("The circuit needs an empty cell at "
                            + position.toShortString() + ", but it is occupied by "
                            + existing.getBlock().getName().getString() + ". Nothing was replaced.");
                }
            }
            if (block.clearAbove != null && client.level.hasChunkAt(block.clearAbove)
                    && !client.level.getBlockState(block.clearAbove).isAir()) {
                throw new IllegalArgumentException("A note block's sound space is obstructed at "
                        + block.clearAbove.toShortString() + ". Clear the block above that note position and retry.");
            }
        }
    }

    private static void addNoteBranch(Minecraft client, LinkedHashMap<BlockPos, CircuitBlock> planned,
                                      BlockPos outputPos, BlockPos bridgePos, Direction branchDirection,
                                      List<PhysicalNote> notes, int noteStart, int noteCount,
                                      List<NoteBlockPlanner.Instrument> instruments) {
        if (noteCount <= 0) return;
        // Each dust cell directly powers one note block placed beside it.
        // Signal strength drops by one per cell, so offset 14 still has strength 1.
        for (int offset = 1; offset <= noteCount; offset++) {
            BlockPos dustPos = outputPos.relative(branchDirection, offset);
            addFoundation(client, planned, dustPos.below());
            addRequired(client, planned, dustPos, Blocks.REDSTONE_WIRE.defaultBlockState(), null);
        }

        for (int i = 0; i < noteCount; i++) {
            int wireOffset = 1 + i;
            PhysicalNote note = notes.get(noteStart + i);
            BlockPos notePos = bridgePos.relative(branchDirection, wireOffset);
            BlockPos noteSupportPos = notePos.below();
            addFoundation(client, planned, noteSupportPos.below());
            addRequired(client, planned, noteSupportPos,
                    supportState(note.instrumentId, instruments), null);

            BlockState noteState = withProperty(Blocks.NOTE_BLOCK.defaultBlockState(), "instrument",
                    instruments.get(note.instrumentId).noteBlockInstrument());
            noteState = withProperty(noteState, "note", Integer.toString(note.pitch));
            addRequired(client, planned, notePos, noteState, notePos.above());
        }
    }

    private static boolean matchesExpectedBlock(BlockState observed, BlockState expected) {
        if (expected.is(Blocks.REDSTONE_WIRE)) return observed.is(Blocks.REDSTONE_WIRE);
        return observed.equals(expected);
    }

    private static void addFoundation(Minecraft client, LinkedHashMap<BlockPos, CircuitBlock> planned,
                                      BlockPos position) {
        BlockPos pos = position.immutable();
        if (planned.containsKey(pos)) return;
        // A foundation is optional: an existing sturdy block is reused. If it is
        // air, a stone block is inserted here and acknowledged like every other
        // placement. Occupied non-sturdy blocks are never replaced.
        planned.put(pos, new CircuitBlock(pos, Blocks.STONE.defaultBlockState(), true, null));
    }

    private static void addRequired(Minecraft client, LinkedHashMap<BlockPos, CircuitBlock> planned,
                                    BlockPos position, BlockState expected, BlockPos clearAbove) {
        if (expected == null) throw new IllegalArgumentException("An instrument support block is unavailable.");
        BlockPos pos = position.immutable();
        CircuitBlock previous = planned.get(pos);
        if (previous != null) {
            if (!previous.expected.equals(expected)) {
                throw new IllegalArgumentException("The physical redstone layout overlaps two different blocks at "
                        + pos.toShortString() + ". Choose another clear building area.");
            }
            if (previous.foundation) {
                // If a required circuit block occupies a position previously
                // considered as an optional floor, it must be placed/verified as
                // the exact required state instead of reusing any sturdy block.
                planned.put(pos, new CircuitBlock(pos, expected, false, clearAbove));
            }
            return;
        }
        planned.put(pos, new CircuitBlock(pos, expected, false, clearAbove));
    }

    private static BlockState supportState(int instrumentId, List<NoteBlockPlanner.Instrument> instruments) {
        if (instrumentId < 0 || instrumentId >= instruments.size()) {
            throw new IllegalArgumentException("The song uses an unsupported note-block instrument.");
        }
        String id = instruments.get(instrumentId).supportBlock();
        try {
            return BuiltInRegistries.BLOCK.getOptional(Identifier.parse(id))
                    .map(Block::defaultBlockState)
                    .orElseThrow(() -> new IllegalArgumentException("Instrument support block is unavailable: " + id));
        } catch (RuntimeException exception) {
            if (exception instanceof IllegalArgumentException illegal) throw illegal;
            throw new IllegalArgumentException("Invalid instrument support block: " + id, exception);
        }
    }

    private static BlockHitResult findPlacementHit(Minecraft client, BlockPos target) {
        LocalPlayer player = client.player;
        double reach = player.getAttributeValue(Attributes.BLOCK_INTERACTION_RANGE);
        double maxDistance = Math.max(0.5, reach - 0.5);
        Vec3 eye = player.getEyePosition();
        BlockHitResult best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Direction offset : Direction.values()) {
            BlockPos neighbor = target.relative(offset);
            BlockState anchor = client.level.getBlockState(neighbor);
            if (anchor.isAir() || anchor.hasBlockEntity()
                    || !anchor.isFaceSturdy(client.level, neighbor, offset.getOpposite())) continue;
            Vec3 location = Vec3.atCenterOf(neighbor).add(
                    offset.getOpposite().getStepX() * 0.5,
                    offset.getOpposite().getStepY() * 0.5,
                    offset.getOpposite().getStepZ() * 0.5);
            double distance = eye.distanceTo(location);
            if (distance > maxDistance || distance >= bestDistance) continue;
            best = new BlockHitResult(location, offset.getOpposite(), neighbor, false);
            bestDistance = distance;
        }
        return best;
    }

    private static Map<String, String> serializedProperties(BlockState state) {
        Map<String, String> values = new java.util.HashMap<>();
        for (Property<?> property : state.getProperties()) propertyValueUnchecked(property, state, values);
        return values;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void propertyValueUnchecked(Property property, BlockState state, Map<String, String> target) {
        Comparable value = (Comparable) state.getValue(property);
        target.put(property.getName(), property.getName(value));
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static BlockState withProperty(BlockState state, String name, String value) {
        Property property = state.getBlock().getStateDefinition().getProperty(name);
        if (property == null) throw new IllegalArgumentException("Missing block state property: " + name);
        java.util.Optional parsed = property.getValue(value);
        if (parsed.isEmpty()) throw new IllegalArgumentException("Invalid block property " + name + "=" + value);
        return state.setValue(property, (Comparable) parsed.get());
    }

    private record PhysicalNote(int instrumentId, int pitch) {}
    private record RedstoneStage(int delay, List<PhysicalNote> notes) {}
    private record CircuitBlock(BlockPos position, BlockState expected, boolean foundation, BlockPos clearAbove) {}
    private record PendingBlock(CircuitBlock block, int attempts, long sentAt) {}
    private record RetryBlock(CircuitBlock block, int attempts, long readyAt) {}

    private static final class Job {
        private final net.minecraft.client.multiplayer.ClientLevel level;
        private final List<CircuitBlock> blocks;
        private final int originalSelectedSlot;
        private final ItemStack originalWorkingStack;
        private int index;
        private int placed;
        private int attempts;
        private boolean waitingForPlayer;
        private boolean paused;
        private long nextAction;
        private long lastStatus = Long.MIN_VALUE;
        private final List<PendingBlock> pending = new ArrayList<>();
        private final java.util.ArrayDeque<RetryBlock> retries = new java.util.ArrayDeque<>();

        private Job(net.minecraft.client.multiplayer.ClientLevel level, List<CircuitBlock> blocks,
                    int originalSelectedSlot, ItemStack originalWorkingStack) {
            this.level = level;
            this.blocks = List.copyOf(blocks);
            this.originalSelectedSlot = originalSelectedSlot;
            this.originalWorkingStack = originalWorkingStack;
            this.nextAction = level.getGameTime();
        }
    }

    private static void fail(String message) {
        String safe = message == null || message.isBlank() ? "Redstone setup could not start." : message;
        BuildClientState.reset(safe);
        NoteClientHud.warn(safe);
    }
}
