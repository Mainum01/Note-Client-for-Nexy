package dev.noteclient;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Wrapped, bounded status card. Unlike the vanilla action bar it does not truncate long messages. */
public final class NoteClientHud {
    private static volatile String message = "";
    private static volatile long expiresAt;
    private static volatile int accent = 0xFF67C7A5;
    private static volatile boolean enabled = true;

    private NoteClientHud() {}

    public static void register() {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("noteclient", "status_card"),
                NoteClientHud::extract
        );
    }

    public static void show(String text) {
        show(text, 0xFF67C7A5, 6500L);
    }

    public static void setEnabled(boolean value) {
        enabled = value;
        if (!value) message = "";
    }

    public static void warn(String text) {
        show(text, 0xFFFFC66D, 9000L);
    }

    private static void show(String text, int color, long durationMs) {
        if (!enabled || text == null || text.isBlank()) return;
        message = text.replace('\n', ' ').replace('\r', ' ').trim();
        accent = color;
        expiresAt = System.currentTimeMillis() + durationMs;
    }

    private static void extract(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
        if (!enabled) return;
        String current = message;
        boolean showNotice = !current.isBlank() && System.currentTimeMillis() <= expiresAt;
        // Tracked statues remain in the undo journal after completion. Read the
        // tracking state for the HUD/status binding, but only show progress while
        // construction or removal is actually active so completed builds never
        // leave a permanent progress panel on screen.
        boolean trackedStatue = PlayerStatueBuilder.hasTrackedStatue();
        boolean statueProgress = trackedStatue
                && (PlayerStatueBuilder.isBuilding() || PlayerStatueBuilder.isRemoving());
        boolean showProgress = statueProgress
                || (BuildClientState.total() > 0 && !BuildClientState.finished());
        if (!showNotice && !showProgress) return;

        Minecraft client = Minecraft.getInstance();
        if (client.font == null || client.getWindow() == null || client.gui == null
                || client.gui.screen() != null) return;
        int screenWidth = client.getWindow().getGuiScaledWidth();
        int screenHeight = client.getWindow().getGuiScaledHeight();
        if (screenWidth < 160 || screenHeight < 80) return;

        int noticeBottom = 0;
        if (showNotice) {
            int maxWidth = Math.min(520, screenWidth - 24);
            if (maxWidth >= 120) {
                int maxLines = Math.max(3, Math.min(8, (screenHeight - 100) / 12));
                List<String> lines = wrap(current, client.font, maxWidth - 32, maxLines);
                int textWidth = lines.stream().mapToInt(client.font::width).max().orElse(100);
                int panelWidth = Math.min(maxWidth, Math.max(120, textWidth + 32));
                int panelHeight = lines.size() * 12 + 30;
                int x = (screenWidth - panelWidth) / 2;
                int y = 12;
                noticeBottom = y + panelHeight;

                drawMinecraftCard(graphics, x, y, panelWidth, panelHeight);
                graphics.fill(x + 3, y + 3, x + 6, y + panelHeight - 3, accent);
                graphics.text(client.font, "NOTECLIENT", x + 13, y + 7, 0xFFFFE08A, true);
                int textY = y + 20;
                for (String line : lines) {
                    graphics.text(client.font, line, x + 13, textY, 0xFFF0F0F0, true);
                    textY += 12;
                }
            }
        }

        if (showProgress) {
            int cardWidth = Math.min(statueProgress ? 380 : 238, screenWidth - 24);
            int cardHeight = statueProgress ? 62 : 47;
            int x = screenWidth - cardWidth - 12;
            // Put the progress card away from the top notification so two status
            // surfaces can never draw over each other. On very short screens,
            // prefer the full notification instead of hiding its text.
            int y = showNotice ? screenHeight - cardHeight - 44 : 12;
            if (y >= noticeBottom + (showNotice ? 8 : 0)) {
                drawMinecraftCard(graphics, x, y, cardWidth, cardHeight);
                if (statueProgress) {
                    boolean paused = PlayerStatueBuilder.isPaused();
                    boolean removing = PlayerStatueBuilder.isRemoving();
                    String statuePhase = PlayerStatueBuilder.progressPhase();
                    boolean waiting = "PARTIAL".equals(statuePhase)
                            || "WAITING FOR CELLS".equals(statuePhase)
                            || "WAITING FOR REACH".equals(statuePhase);
                    int count = PlayerStatueBuilder.progressCount();
                    int total = PlayerStatueBuilder.progressTotal();
                    int percent = PlayerStatueBuilder.progressPercent();
                    int accentColor = paused || waiting ? 0xFFFFC66D
                            : removing ? 0xFFDE8272 : 0xFF7BA653;
                    graphics.fill(x + 3, y + 3, x + 6, y + cardHeight - 3, accentColor);
                    graphics.text(client.font, "NOTECLIENT  /  STATUE  •  "
                                    + PlayerStatueBuilder.progressPhase(),
                            x + 12, y + 6, 0xFFFFE08A, true);
                    graphics.text(client.font, count + " / " + total + "  •  " + percent + "%",
                            x + 12, y + 20, 0xFFEDEDED, false);
                    graphics.text(client.font, PlayerStatueBuilder.progressDetail(),
                            x + 12, y + 33, 0xFFBFC6CC, false);
                    int barWidth = cardWidth - 24;
                    graphics.fill(x + 12, y + 48, x + 12 + barWidth, y + 53, 0xFF171717);
                    graphics.fill(x + 13, y + 49,
                            x + 13 + Math.max(0, Math.min(barWidth - 2,
                                    (barWidth - 2) * percent / 100)),
                            y + 52, accentColor);
                } else {
                    graphics.fill(x + 3, y + 3, x + 6, y + cardHeight - 3,
                            BuildClientState.paused() ? 0xFFFFC66D : 0xFF7BA653);
                    String phase = BuildClientState.paused() ? "PAUSED" : "BUILDING";
                    String progress = BuildClientState.placed() + " / " + BuildClientState.total()
                            + "  •  " + BuildClientState.percent() + "%";
                    graphics.text(client.font, "NOTECLIENT  /  " + phase, x + 12, y + 7,
                            0xFFFFE08A, true);
                    graphics.text(client.font, progress, x + 12, y + 21, 0xFFEDEDED, false);
                    int barWidth = cardWidth - 24;
                    graphics.fill(x + 12, y + 36, x + 12 + barWidth, y + 41, 0xFF171717);
                    graphics.fill(x + 13, y + 37,
                            x + 13 + Math.max(0, Math.min(barWidth - 2,
                                    (barWidth - 2) * BuildClientState.percent() / 100)),
                            y + 40, 0xFF7BA653);
                }
            }
        }
    }

    private static void drawMinecraftCard(GuiGraphicsExtractor graphics, int x, int y, int w, int h) {
        graphics.fill(x + 2, y + 3, x + w + 2, y + h + 3, 0x88000000);
        graphics.fill(x, y, x + w, y + h, 0xFF101010);
        graphics.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFF777777);
        graphics.fill(x + 2, y + 2, x + w - 2, y + h - 2, 0xFF292929);
        graphics.fill(x + 2, y + 2, x + w - 2, y + 3, 0xFF9A9A9A);
    }

    private static List<String> wrap(String value, net.minecraft.client.gui.Font font,
                                     int maxWidth, int maxLines) {
        List<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : value.split("\\s+")) {
            if (font.width(word) > maxWidth) {
                if (!line.isEmpty()) {
                    lines.add(line.toString());
                    line.setLength(0);
                }
                StringBuilder part = new StringBuilder();
                for (int i = 0; i < word.length(); i++) {
                    String candidate = part.toString() + word.charAt(i);
                    if (font.width(candidate) > maxWidth && !part.isEmpty()) {
                        lines.add(part.toString());
                        part.setLength(0);
                        if (lines.size() >= maxLines) return withEllipsis(lines, font, maxWidth, maxLines);
                    }
                    part.append(word.charAt(i));
                }
                if (!part.isEmpty()) line.append(part);
            } else {
                String candidate = line.isEmpty() ? word : line + " " + word;
                if (font.width(candidate) > maxWidth && !line.isEmpty()) {
                    lines.add(line.toString());
                    line.setLength(0);
                    line.append(word);
                    if (lines.size() >= maxLines) return withEllipsis(lines, font, maxWidth, maxLines);
                } else {
                    line.setLength(0);
                    line.append(candidate);
                }
            }
        }
        if (!line.isEmpty() && lines.size() < maxLines) lines.add(line.toString());
        if (lines.isEmpty()) lines.add("NoteClient");
        if (lines.size() >= maxLines && (lines.size() < 1 || !lines.get(lines.size() - 1).endsWith("…"))) {
            return withEllipsis(lines, font, maxWidth, maxLines);
        }
        return lines;
    }

    private static List<String> withEllipsis(List<String> source, net.minecraft.client.gui.Font font,
                                              int maxWidth, int maxLines) {
        List<String> result = new ArrayList<>(source.subList(0, Math.min(source.size(), maxLines)));
        if (result.isEmpty()) result.add("NoteClient");
        int lastIndex = result.size() - 1;
        String last = result.get(lastIndex);
        while (!last.isEmpty() && font.width(last + "…") > maxWidth) {
            last = last.substring(0, last.length() - 1);
        }
        result.set(lastIndex, last + "…");
        return result;
    }
}
