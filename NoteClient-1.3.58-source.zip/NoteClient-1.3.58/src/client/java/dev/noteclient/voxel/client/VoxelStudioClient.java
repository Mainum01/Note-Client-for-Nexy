package dev.noteclient.voxel.client;

import com.mojang.blaze3d.platform.InputConstants;
import dev.noteclient.PlayerSkinBrowserScreen;
import dev.noteclient.PlayerStatueBuilder;
import dev.noteclient.voxel.core.VoxelModel;
import dev.noteclient.voxel.core.VoxelStudioConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

/** Client-only Voxel Studio actions. World edits use the ordinary player placement pipeline. */
public final class VoxelStudioClient {
    private static KeyMapping openStudioKey;
    private static KeyMapping destroyKey;
    private static String status = "Voxel Studio ready";

    private VoxelStudioClient() {}

    /** Called by NoteClient.onInitializeClient(). No server payloads are registered here. */
    public static void initialize() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("noteclient", "voxel_studio"));
        openStudioKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.noteclient.voxel_studio", InputConstants.Type.KEYSYM,
                VoxelStudioConfig.KEY_OPEN_STUDIO, category));
        destroyKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.noteclient.voxel_destroy", InputConstants.Type.KEYSYM,
                VoxelStudioConfig.KEY_DESTROY, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openStudioKey.consumeClick()) {
                if (client.gui.screen() instanceof VoxelStudioScreen screen) screen.closeToParent();
                else if (client.player != null) open(client);
            }
            if (client.gui.screen() instanceof VoxelStudioScreen) {
                while (destroyKey.consumeClick()) {
                    if (client.player != null && PlayerStatueBuilder.hasTrackedStatue()) remove();
                }
            }
        });
        VoxelSkinLibrary.ensureDirectory();
    }

    public static void open(Minecraft client) {
        client.gui.setScreen(new VoxelStudioScreen(client.gui.screen()));
    }

    public static String status() { return status; }

    /** Starts a client-driven build; no NoteClient Server Companion is required. */
    public static void build(VoxelModel model) {
        Minecraft client = Minecraft.getInstance();
        if (PlayerStatueBuilder.startVoxelBuild(client, model)) {
            status = PlayerStatueBuilder.status();
            closeEditorForWorldAction(client);
        } else {
            status = PlayerStatueBuilder.status();
        }
    }

    /** A rebuild is another tracked model build; older builds remain available to Undo Last. */
    public static void rebuild(VoxelModel model) {
        build(model);
    }

    /** Stops the active build without removing already placed blocks, then closes the editor. */
    public static void stop() {
        Minecraft client = Minecraft.getInstance();
        PlayerStatueBuilder.cancel(client);
        status = PlayerStatueBuilder.status();
        closeEditorForWorldAction(client);
    }

    /** Undoes only the newest NoteClient model/statue journal using normal block breaking. */
    public static void remove() {
        Minecraft client = Minecraft.getInstance();
        PlayerStatueBuilder.remove(client);
        status = PlayerStatueBuilder.status();
        closeEditorForWorldAction(client);
    }

    private static void closeEditorForWorldAction(Minecraft client) {
        if (client != null && client.gui != null) {
            // Calling setScreen(null) on a child screen normally invokes onClose(),
            // which reopens its parent. Use the editor's explicit gameplay-close
            // path so Stop/Build cannot leave a parent GUI stuck on screen.
            if (client.gui.screen() instanceof VoxelStudioScreen screen) {
                screen.closeToGameplay();
            } else {
                client.gui.setScreen(null);
            }
        }
    }

    public static void openOnlinePlayerBrowser(VoxelStudioScreen parent) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return;
        parent.beginExternalSkinImport();
        client.gui.setScreen(new PlayerSkinBrowserScreen(parent, PlayerSkinBrowserScreen.Mode.ONLINE_PLAYERS));
    }

    public static void openPresetBrowser(VoxelStudioScreen parent) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return;
        parent.beginExternalSkinImport();
        client.gui.setScreen(new PlayerSkinBrowserScreen(parent, PlayerSkinBrowserScreen.Mode.PRESETS));
    }
}
