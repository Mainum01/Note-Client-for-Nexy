package dev.noteclient.voxel.core;

import dev.noteclient.voxel.core.VoxelCamera.Ray;
import dev.noteclient.voxel.core.VoxelCamera.Vec3;

/** Amanatides-Woo 3D DDA ray traversal; work is bounded by the model dimensions. */
public final class VoxelRaycaster {
    /** paletteIndex==0 represents a valid empty cell used as a paint target. */
    public record Hit(int x, int y, int z, int layerId, int paletteIndex,
                      int normalX, int normalY, int normalZ, double distance) {}

    private VoxelRaycaster() {}

    /** Returns the first visible occupied voxel (used by erase and color-pick). */
    public static Hit pick(VoxelModel model, Ray ray) {
        return traverse(model, ray, false, 0);
    }

    /**
     * For the base layer, returns the actual first solid surface voxel so a
     * click recolors the character instead of adding a voxel in front of it.
     * For a different active layer, it can target the immediately adjacent
     * empty cell to paint a separate clothing/accessory layer. Empty documents
     * still return their first in-bounds cell as a valid paint target.
     */
    public static Hit pickPaintTarget(VoxelModel model, Ray ray, int activeLayerId) {
        return traverse(model, ray, true, activeLayerId);
    }

    private static Hit traverse(VoxelModel model, Ray ray, boolean paintTarget, int fallbackLayer) {
        double[] interval = intersectBounds(model, ray);
        if (interval == null) return null;
        double t = Math.max(0.0, interval[0]) + 1.0e-7;
        double end = interval[1];
        if (end < t) return null;

        Vec3 origin = ray.origin();
        Vec3 direction = ray.direction().normalized();
        double px = origin.x() + direction.x() * t;
        double py = origin.y() + direction.y() * t;
        double pz = origin.z() + direction.z() * t;
        int x = clamp((int)Math.floor(px), 0, model.width() - 1);
        int y = clamp((int)Math.floor(py), 0, model.height() - 1);
        int z = clamp((int)Math.floor(pz), 0, model.depth() - 1);

        int stepX = sign(direction.x());
        int stepY = sign(direction.y());
        int stepZ = sign(direction.z());
        double tDeltaX = stepX == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / direction.x());
        double tDeltaY = stepY == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / direction.y());
        double tDeltaZ = stepZ == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / direction.z());
        double tMaxX = firstBoundaryT(origin.x(), direction.x(), x, stepX, t);
        double tMaxY = firstBoundaryT(origin.y(), direction.y(), y, stepY, t);
        double tMaxZ = firstBoundaryT(origin.z(), direction.z(), z, stepZ, t);

        int normalX = 0, normalY = 0, normalZ = 0;
        Hit firstEmpty = null;
        Hit previousEmpty = null;
        int maxSteps = model.width() + model.height() + model.depth() + 8;
        for (int step = 0; step < maxSteps && t <= end; step++) {
            if (inside(model, x, y, z)) {
                int palette = model.paletteIndexAt(x, y, z);
                int layer = model.layerAt(x, y, z);
                boolean occupiedVisible = palette != 0 && model.layerVisible(layer);
                if (occupiedVisible) {
                    Hit solid = new Hit(x,y,z,layer,palette,normalX,normalY,normalZ,t);
                    if (!paintTarget) return solid;
                    // Base-body painting recolors the actual surface voxel.
                    // For a different active layer, use the adjacent empty cell
                    // as an overlay so hats/jackets remain independently editable.
                    if (layer == fallbackLayer || fallbackLayer == 0) return solid;
                    return previousEmpty != null ? previousEmpty : solid;
                }
                if (paintTarget) {
                    Hit empty = new Hit(x,y,z,fallbackLayer,0,normalX,normalY,normalZ,t);
                    if (firstEmpty == null) firstEmpty = empty;
                    previousEmpty = empty;
                }
            }

            if (tMaxX <= tMaxY && tMaxX <= tMaxZ) {
                t = tMaxX; tMaxX += tDeltaX; x += stepX;
                normalX = -stepX; normalY = 0; normalZ = 0;
            } else if (tMaxY <= tMaxZ) {
                t = tMaxY; tMaxY += tDeltaY; y += stepY;
                normalX = 0; normalY = -stepY; normalZ = 0;
            } else {
                t = tMaxZ; tMaxZ += tDeltaZ; z += stepZ;
                normalX = 0; normalY = 0; normalZ = -stepZ;
            }
        }
        return paintTarget ? firstEmpty : null;
    }

    private static double[] intersectBounds(VoxelModel model, Ray ray) {
        double tMin = Double.NEGATIVE_INFINITY;
        double tMax = Double.POSITIVE_INFINITY;
        double[] origins = {ray.origin().x(), ray.origin().y(), ray.origin().z()};
        double[] directions = {ray.direction().x(), ray.direction().y(), ray.direction().z()};
        double[] sizes = {model.width(), model.height(), model.depth()};
        for (int axis = 0; axis < 3; axis++) {
            double d = directions[axis], o = origins[axis];
            if (Math.abs(d) < 1.0e-12) {
                if (o < 0 || o > sizes[axis]) return null;
                continue;
            }
            double a = (0 - o) / d, b = (sizes[axis] - o) / d;
            if (a > b) { double tmp=a; a=b; b=tmp; }
            tMin=Math.max(tMin,a); tMax=Math.min(tMax,b);
            if (tMax < tMin) return null;
        }
        return new double[]{tMin,tMax};
    }

    private static double firstBoundaryT(double origin,double direction,int cell,int step,double currentT) {
        if (step == 0) return Double.POSITIVE_INFINITY;
        double boundary = step > 0 ? cell + 1.0 : cell;
        return Math.max(currentT,(boundary-origin)/direction);
    }
    private static int sign(double value) { return value > 1.0e-12 ? 1 : value < -1.0e-12 ? -1 : 0; }
    private static boolean inside(VoxelModel model,int x,int y,int z) {
        return x>=0 && x<model.width() && y>=0 && y<model.height() && z>=0 && z<model.depth();
    }
    private static int clamp(int value,int min,int max) { return Math.max(min,Math.min(max,value)); }
}
