package dev.noteclient.voxel.client;

import dev.noteclient.voxel.core.GiantBlockVoxelizer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Block;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Searchable picker for turning any registered Minecraft/mod block into a giant voxel shell. */
public final class GiantBlockPickerScreen extends Screen {
    private record Entry(String id, String name) {}

    private final Screen parent;
    private List<Entry> allEntries = List.of();
    private List<Entry> filtered = List.of();
    private EditBox searchBox;
    private String searchText = "";
    private String status = "Select any Minecraft block to build its giant pixel-textured version.";
    private Entry selected;
    private int size = GiantBlockVoxelizer.DEFAULT_SIZE;
    private boolean generating;

    private int panelX, panelY, panelWidth, panelHeight;
    private int listTop, listBottom, rowHeight, visibleRows, scrollOffset;

    public GiantBlockPickerScreen(Screen parent) {
        super(Component.literal("NoteClient Giant Block Builder"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        panelWidth = Math.max(1, Math.min(760, width - 18));
        panelHeight = Math.max(1, Math.min(560, height - 18));
        panelX = (width - panelWidth) / 2;
        panelY = (height - panelHeight) / 2;

        loadBlocks();
        searchBox = new EditBox(font, panelX + 12, panelY + 38,
                Math.max(1, panelWidth - 24), 20, Component.literal("Search Minecraft blocks"));
        searchBox.setMaxLength(100);
        searchBox.setValue(searchText);
        searchBox.setHint(Component.literal("Search block names or IDs…"));
        searchBox.setResponder(value -> {
            searchText = value;
            scrollOffset = 0;
            updateFiltered();
        });
        addRenderableWidget(searchBox);

        listTop = panelY + 68;
        listBottom = panelY + panelHeight - 56;
        int available = Math.max(1, listBottom - listTop);
        rowHeight = Math.max(24, Math.min(30, available / 12));
        visibleRows = Math.max(1, available / rowHeight);

        addButton("SIZE: " + size + "³", panelX + 12, panelY + panelHeight - 30, 94, this::toggleSize);
        addButton("CREATE GIANT BLOCK", panelX + panelWidth - 292, panelY + panelHeight - 30,
                168, this::createGiantBlock);
        addButton("BACK", panelX + panelWidth - 112, panelY + panelHeight - 30, 100,
                () -> minecraft.gui.setScreen(parent));
    }

    private void addButton(String label, int x, int y, int w, Runnable action) {
        addRenderableWidget(Button.builder(Component.literal(label), ignored -> action.run())
                .bounds(x, y, w, 19).build());
    }

    private void loadBlocks() {
        List<Entry> entries = new ArrayList<>();
        for (Block block : BuiltInRegistries.BLOCK) {
            Identifier id = BuiltInRegistries.BLOCK.getKey(block);
            if (id == null || block.defaultBlockState().isAir()) continue;
            entries.add(new Entry(id.toString(), block.getName().getString()));
        }
        entries.sort(Comparator.comparing((Entry entry) -> entry.name().toLowerCase(Locale.ROOT))
                .thenComparing(Entry::id));
        allEntries = List.copyOf(entries);
        updateFiltered();
        if (pendingSelectedId != null) {
            selected = filtered.stream().filter(entry -> entry.id().equals(pendingSelectedId)).findFirst().orElse(null);
        }
        if (selected == null && !filtered.isEmpty()) selected = filtered.get(0);
    }

    private void updateFiltered() {
        String query = searchText == null ? "" : searchText.trim().toLowerCase(Locale.ROOT);
        filtered = query.isEmpty() ? allEntries : allEntries.stream()
                .filter(entry -> entry.name().toLowerCase(Locale.ROOT).contains(query)
                        || entry.id().toLowerCase(Locale.ROOT).contains(query))
                .toList();
        scrollOffset = Math.max(0, Math.min(scrollOffset, Math.max(0, filtered.size() - visibleRows)));
        if (selected != null && !filtered.contains(selected)) selected = filtered.isEmpty() ? null : filtered.get(0);
    }

    private void toggleSize() {
        if (generating || minecraft == null) return;
        size = size == GiantBlockVoxelizer.DEFAULT_SIZE
                ? GiantBlockVoxelizer.HD_SIZE : GiantBlockVoxelizer.DEFAULT_SIZE;
        minecraft.gui.setScreen(new GiantBlockPickerScreen(parent, searchText, size, selected == null ? null : selected.id()));
    }

    private GiantBlockPickerScreen(Screen parent, String search, int size, String selectedId) {
        this(parent);
        this.searchText = search == null ? "" : search;
        this.size = size;
        this.pendingSelectedId = selectedId;
    }

    private String pendingSelectedId;

    private void createGiantBlock() {
        if (generating || selected == null || minecraft == null) return;
        generating = true;
        status = "Reading baked face textures for " + selected.name() + "…";
        String selectedId = selected.id();
        int requestedSize = size;
        GiantBlockVoxelizer.createAsync(selectedId, requestedSize).whenComplete((model, error) ->
                Minecraft.getInstance().execute(() -> {
                    if (minecraft == null || minecraft.gui.screen() != this) return;
                    if (error != null) {
                        generating = false;
                        status = "Could not create giant block: " + rootMessage(error);
                        return;
                    }
                    minecraft.gui.setScreen(new VoxelStudioScreen(this, model, true));
                }));
    }

    private String rootMessage(Throwable error) {
        Throwable current = error;
        while (current.getCause() != null) current = current.getCause();
        return current.getMessage() == null ? current.getClass().getSimpleName() : current.getMessage();
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0 && event.x() >= panelX + 8 && event.x() <= panelX + panelWidth - 8
                && event.y() >= listTop && event.y() < listBottom) {
            int row = (int)((event.y() - listTop) / rowHeight);
            int index = scrollOffset + row;
            if (row >= 0 && row < visibleRows && index >= 0 && index < filtered.size()) {
                selected = filtered.get(index);
                status = "Selected " + selected.name() + "  •  " + selected.id();
                if (doubleClick) createGiantBlock();
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (mouseX >= panelX + 8 && mouseX <= panelX + panelWidth - 8
                && mouseY >= listTop && mouseY < listBottom) {
            int max = Math.max(0, filtered.size() - visibleRows);
            scrollOffset = Math.max(0, Math.min(max, scrollOffset + (verticalAmount > 0 ? -3 : 3)));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent event) {
        if (event.key() == 256) {
            minecraft.gui.setScreen(parent);
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public void onClose() {
        if (minecraft != null) minecraft.gui.setScreen(parent);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        graphics.fill(0, 0, width, height, 0xA8000000);
        graphics.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xFF17130F);
        graphics.fill(panelX + 2, panelY + 2, panelX + panelWidth - 2, panelY + panelHeight - 2, 0xFF30261C);
        graphics.fill(panelX + 4, panelY + 4, panelX + panelWidth - 4, panelY + 29, 0xFF44301F);
        graphics.fill(panelX + 4, panelY + 4, panelX + panelWidth - 4, panelY + 5, 0xFF70B9E8);
        graphics.text(font, "NOTECLIENT  /  GIANT BLOCK BUILDER", panelX + 12, panelY + 12, 0xFFEAF6FF, true);
        graphics.text(font, "ALL REGISTERED BLOCKS  •  " + allEntries.size(), panelX + 12, panelY + 61, 0xFFB8D7EF, true);
        graphics.text(font, "16³ = 1 voxel / texel  •  32³ = HD", panelX + panelWidth - 202,
                panelY + 61, 0xFF9FB0C0, false);
        graphics.fill(panelX + 8, listTop - 2, panelX + panelWidth - 8, listBottom + 2, 0xFF111820);

        if (filtered.isEmpty()) {
            graphics.text(font, "No blocks match that search.", panelX + 18, listTop + 12, 0xFFCDD6DF, false);
        } else {
            int end = Math.min(filtered.size(), scrollOffset + visibleRows);
            for (int i = scrollOffset; i < end; i++) {
                Entry entry = filtered.get(i);
                int row = i - scrollOffset;
                int y = listTop + row * rowHeight;
                boolean isSelected = entry.equals(selected);
                boolean hovered = mouseX >= panelX + 8 && mouseX < panelX + panelWidth - 8
                        && mouseY >= y && mouseY < y + rowHeight;
                int fill = isSelected ? 0xFF42627A : hovered ? 0xFF394A5A
                        : (row % 2 == 0 ? 0xFF222D38 : 0xFF1B252E);
                graphics.fill(panelX + 11, y + 1, panelX + panelWidth - 11, y + rowHeight - 1, fill);
                graphics.text(font, entry.name(), panelX + 18, y + 4, 0xFFEAF0F6, true);
                graphics.text(font, entry.id(), panelX + 18, y + 16, 0xFF9FB0C0, false);
            }
        }

        String statusLine = generating ? "GENERATING: " + status : status;
        graphics.text(font, clip(statusLine, panelWidth - 24), panelX + 12, panelY + panelHeight - 43,
                generating ? 0xFFFFD36B : 0xFFB9C2CC, false);
        int shownStart = filtered.isEmpty() ? 0 : scrollOffset + 1;
        int shownEnd = Math.min(filtered.size(), scrollOffset + visibleRows);
        graphics.text(font, shownStart + "–" + shownEnd + " / " + filtered.size(),
                panelX + panelWidth - 94, panelY + panelHeight - 43, 0xFFBDB09B, false);
        super.extractRenderState(graphics, mouseX, mouseY, delta);
    }

    private String clip(String value, int maxWidth) {
        if (value == null || font.width(value) <= maxWidth) return value == null ? "" : value;
        String result = value;
        while (!result.isEmpty() && font.width(result + "…") > maxWidth) result = result.substring(0, result.length() - 1);
        return result + "…";
    }
}
