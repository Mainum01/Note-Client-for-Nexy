package dev.noteclient.voxel.core;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** Converts 64x64 / legacy 64x32 Minecraft skins into a real 3D, layered voxel model. */
public final class SkinVoxelizer {
    private record Uv(int x, int y, int width, int height) {}
    private record Cuboid(int x, int y, int z, int width, int height, int depth,
                          Uv front, Uv back, Uv top, Uv bottom, Uv left, Uv right) {}

    private static final int FRONT = 1;
    private static final int BACK = 1 << 1;
    private static final int TOP = 1 << 2;
    private static final int BOTTOM = 1 << 3;
    private static final int LEFT = 1 << 4;
    private static final int RIGHT = 1 << 5;
    private static final int ALL_FACES = FRONT | BACK | TOP | BOTTOM | LEFT | RIGHT;

    // Dependency-free fallback palette for core smoke tests and an offline editor
    // fallback. In Minecraft, runtime imports use MinecraftBlockPalette instead.
    private static final int[][] FALLBACK_RGB = {
            {0xE9ECEC,0xF07613,0xBD44B3,0x3AAFD9,0xF8C627,0x70B919,0xED8DAC,0x3E4447,
             0x8E8E86,0x158791,0x792AAC,0x35399D,0x724728,0x546D1B,0xA12722,0x141519},
            {0xF0F0F0,0xD87F33,0xB24CD8,0x6699D8,0xE5E533,0x7FCC19,0xF27FA5,0x4C4C4C,
             0x999999,0x4C7F99,0x7F3FB2,0x334CB2,0x664C33,0x667F33,0x993333,0x191919},
            {0xD1B1A1,0xA15325,0x95576C,0x706C8A,0xBA8524,0x677535,0xA14E4E,0x392A24,
             0x876B62,0x575C5C,0x764656,0x4A3B5B,0x4D3323,0x4C522A,0x8E3C2E,0x251610}
    };
    private static final String[] DYES = {"white","orange","magenta","light_blue","yellow","lime","pink","gray",
            "light_gray","cyan","purple","blue","brown","green","red","black"};
    private static final List<VoxelModel.PaletteEntry> FALLBACK_PALETTE = makeFallbackPalette();

    private SkinVoxelizer() {}

    private static List<VoxelModel.Layer> layers() {
        // Keep the stable semantic IDs (0..7) used by saved .voxel.json skins,
        // but put the base body and the left-sleeve shell next to each other in
        // the editor's layer cycler. This makes the inner-arm -> outer-sleeve
        // relationship easy to inspect without changing old saved layer IDs.
        return List.of(
                new VoxelModel.Layer(0, "Base skin / inner body", 0,0,0, true, true),
                new VoxelModel.Layer(4, "Left sleeve / outer +1", 0,0,0, true, true),
                new VoxelModel.Layer(1, "Hat / head overlay", 0,0,0, true, true),
                new VoxelModel.Layer(2, "Jacket", 0,0,0, true, true),
                new VoxelModel.Layer(3, "Right sleeve / outer +1", 0,0,0, true, true),
                new VoxelModel.Layer(5, "Right pant", 0,0,0, true, true),
                new VoxelModel.Layer(6, "Left pant", 0,0,0, true, true),
                new VoxelModel.Layer(7, "Custom accessories", 0,0,0, true, true));
    }

    public static VoxelModel emptyModel(String name) {
        return new VoxelModel(26, 34, 12, name, FALLBACK_PALETTE, layers(), false);
    }

    /** A separate white mannequin used as the Studio paint target. */
    public static VoxelModel whitePlayerModel(String name) {
        return whitePlayerModel(name, FALLBACK_PALETTE);
    }

    /** Runtime overload uses the best white full-cube block from the game registry. */
    public static VoxelModel whitePlayerModel(String name, List<VoxelModel.PaletteEntry> palette) {
        if (palette == null || palette.isEmpty()) throw new IllegalArgumentException("White model palette cannot be empty");
        VoxelModel model = new VoxelModel(26, 34, 12,
                name == null || name.isBlank() ? "My Character" : name,
                palette, layers(), false);
        // Use hollow cuboid shells for the paint mannequin. It keeps all six
        // outside faces available as paint targets without filling hidden cells.
        fillHollowCuboid(model, 9, 0, 4, 4, 12, 4, 1, 0);  // right leg
        fillHollowCuboid(model, 13, 0, 4, 4, 12, 4, 1, 0); // left leg
        fillHollowCuboid(model, 9, 12, 4, 8, 12, 4, 1, 0);// torso
        fillHollowCuboid(model, 4, 12, 4, 4, 12, 4, 1, 0);// right arm
        fillHollowCuboid(model, 18, 12, 4, 4, 12, 4, 1, 0);// left arm
        fillHollowCuboid(model, 9, 24, 2, 8, 8, 8, 1, 0); // head
        return model;
    }

    private static void fillHollowCuboid(VoxelModel model, int x, int y, int z,
                                         int width, int height, int depth,
                                         int paletteIndex, int layerId) {
        int maxX = x + width - 1;
        int maxY = y + height - 1;
        int maxZ = z + depth - 1;
        for (int yy = y; yy <= maxY; yy++) {
            for (int zz = z; zz <= maxZ; zz++) {
                for (int xx = x; xx <= maxX; xx++) {
                    if (xx == x || xx == maxX || yy == y || yy == maxY || zz == z || zz == maxZ) {
                        model.setVoxel(xx, yy, zz, paletteIndex, layerId);
                    }
                }
            }
        }
    }

    /** Offline/test overload. The integrated client passes its registry-derived palette. */
    public static VoxelModel fromSkin(BufferedImage source, String name, boolean slimArms) {
        return fromSkin(source, name, slimArms, FALLBACK_PALETTE);
    }

    public static VoxelModel fromSkin(BufferedImage source, String name, boolean slimArms,
                                      List<VoxelModel.PaletteEntry> palette) {
        Objects.requireNonNull(source, "source");
        if (palette == null || palette.isEmpty() || palette.size() > VoxelStudioConfig.MAX_PALETTE) {
            throw new IllegalArgumentException("Skin palette must contain 1.." + VoxelStudioConfig.MAX_PALETTE + " materials");
        }
        BufferedImage skin = normalize(source);
        VoxelModel model = new VoxelModel(26, 34, 12, name == null ? "Imported skin" : name,
                palette, layers(), slimArms);

        int armWidth = slimArms ? 3 : 4;
        // The torso occupies X=9..16. Arms must touch it at both shoulders:
        // classic arms sit at 5..8 and 17..20; slim arms tuck one pixel inward.
        // The previous 4/18 offsets left a visible one-block gap at each side.
        int rightArmX = slimArms ? 6 : 5;
        int leftArmX = 17;

        // BASE SKIN (layer 0): all six faces of each independent body cuboid.
        draw(model, skin, new Cuboid(9,0,4,4,12,4,
                uv(4,20,4,12),uv(12,20,4,12),uv(4,16,4,4),uv(8,16,4,4),uv(0,20,4,12),uv(8,20,4,12)), 0, ALL_FACES);
        draw(model, skin, new Cuboid(13,0,4,4,12,4,
                uv(20,52,4,12),uv(28,52,4,12),uv(20,48,4,4),uv(24,48,4,4),uv(16,52,4,12),uv(24,52,4,12)), 0, ALL_FACES);
        draw(model, skin, new Cuboid(9,12,4,8,12,4,
                uv(20,20,8,12),uv(32,20,8,12),uv(20,16,8,4),uv(28,16,8,4),uv(16,20,4,12),uv(28,20,4,12)), 0, ALL_FACES);
        draw(model, skin, new Cuboid(rightArmX,12,4,armWidth,12,4,
                uv(44,20,armWidth,12),uv(52,20,armWidth,12),uv(44,16,armWidth,4),uv(48,16,armWidth,4),uv(40,20,4,12),uv(48,20,4,12)), 0, ALL_FACES);
        draw(model, skin, new Cuboid(leftArmX,12,4,armWidth,12,4,
                uv(36,52,armWidth,12),uv(44,52,armWidth,12),uv(36,48,armWidth,4),uv(40,48,armWidth,4),uv(32,52,4,12),uv(40,52,4,12)), 0, ALL_FACES);
        draw(model, skin, new Cuboid(9,24,2,8,8,8,
                uv(8,8,8,8),uv(24,8,8,8),uv(8,0,8,8),uv(16,0,8,8),uv(0,8,8,8),uv(16,8,8,8)), 0, ALL_FACES);

        // HAT / HEAD OVERLAY (layer 1). Front/back and side shells are one block
        // beyond the base cuboid; the bottom face is omitted to avoid occupying
        // the exact same cells as the base head's bottom face.
        Cuboid hatFrontBack = new Cuboid(9,24,1,8,10,10,
                uv(40,8,8,8),uv(56,8,8,8),uv(40,0,8,8),uv(48,0,8,8),uv(32,8,8,8),uv(48,8,8,8));
        draw(model, skin, hatFrontBack, 1, FRONT | BACK | TOP);
        Cuboid hatSides = new Cuboid(8,24,2,10,10,8,
                uv(40,8,8,8),uv(56,8,8,8),uv(40,0,8,8),uv(48,0,8,8),uv(32,8,8,8),uv(48,8,8,8));
        draw(model, skin, hatSides, 1, LEFT | RIGHT);

        // JACKET (layer 2): front/back expanded in depth; side faces occupy the
        // one-block lateral shell outside the torso, with no shared cells.
        Cuboid jacketFrontBack = new Cuboid(9,12,3,8,12,6,
                uv(20,36,8,12),uv(32,36,8,12),uv(20,32,8,4),uv(28,32,8,4),uv(16,36,4,12),uv(28,36,4,12));
        draw(model, skin, jacketFrontBack, 2, FRONT | BACK);
        // Keep the torso's side seams open where the inner arms attach. Drawing
        // a full jacket side here would overwrite the first/base arm voxels and
        // make the sleeves appear detached or merged into the torso.
        // RIGHT SLEEVE (layer 3). The outward-facing side is independent. The
        // inner side faces the torso and is left to the jacket/body seam.
        Cuboid rightSleeveFrontBack = new Cuboid(rightArmX-1,11,3,armWidth+2,14,6,
                uv(44,36,armWidth,12),uv(52,36,armWidth,12),uv(44,32,armWidth,4),uv(48,32,armWidth,4),uv(40,36,4,12),uv(48,36,4,12));
        draw(model, skin, rightSleeveFrontBack, 3, FRONT | BACK);
        Cuboid rightSleeveOuterSide = new Cuboid(rightArmX-1,11,4,armWidth+2,14,4,
                uv(44,36,armWidth,12),uv(52,36,armWidth,12),uv(44,32,armWidth,4),uv(48,32,armWidth,4),uv(40,36,4,12),uv(48,36,4,12));
        draw(model, skin, rightSleeveOuterSide, 3, LEFT);
        Cuboid rightSleeveCaps = new Cuboid(rightArmX-1,11,4,armWidth+1,14,4,
                uv(44,36,armWidth,12),uv(52,36,armWidth,12),uv(44,32,armWidth,4),uv(48,32,armWidth,4),uv(40,36,4,12),uv(48,36,4,12));
        draw(model, skin, rightSleeveCaps, 3, TOP | BOTTOM);
        // LEFT SLEEVE (layer 4), mirrored independent shell. It is a real
        // second shell around the inner left arm: front/back, outward side,
        // cuff and shoulder all sit exactly one voxel outside the base arm.
        Cuboid leftSleeveFrontBack = new Cuboid(leftArmX-1,11,3,armWidth+2,14,6,
                uv(52,52,armWidth,12),uv(60,52,armWidth,12),uv(52,48,armWidth,4),uv(56,48,armWidth,4),uv(48,52,4,12),uv(56,52,4,12));
        draw(model, skin, leftSleeveFrontBack, 4, FRONT | BACK);
        Cuboid leftSleeveOuterSide = new Cuboid(leftArmX-1,11,4,armWidth+2,14,4,
                uv(52,52,armWidth,12),uv(60,52,armWidth,12),uv(52,48,armWidth,4),uv(56,48,armWidth,4),uv(48,52,4,12),uv(56,52,4,12));
        draw(model, skin, leftSleeveOuterSide, 4, RIGHT);
        Cuboid leftSleeveCaps = new Cuboid(leftArmX,11,4,armWidth+1,14,4,
                uv(52,52,armWidth,12),uv(60,52,armWidth,12),uv(52,48,armWidth,4),uv(56,48,armWidth,4),uv(48,52,4,12),uv(56,52,4,12));
        draw(model, skin, leftSleeveCaps, 4, TOP | BOTTOM);
        // RIGHT PANT (layer 5), then LEFT PANT (layer 6). Both are separate
        // shells/layer IDs; they are not merged into a single trouser layer.
        Cuboid rightPantFrontBack = new Cuboid(9,0,3,4,12,6,
                uv(4,36,4,12),uv(12,36,4,12),uv(4,32,4,4),uv(8,32,4,4),uv(0,36,4,12),uv(8,36,4,12));
        draw(model, skin, rightPantFrontBack, 5, FRONT | BACK);
        Cuboid rightPantOuterSide = new Cuboid(8,0,4,6,12,4,
                uv(4,36,4,12),uv(12,36,4,12),uv(4,32,4,4),uv(8,32,4,4),uv(0,36,4,12),uv(8,36,4,12));
        draw(model, skin, rightPantOuterSide, 5, LEFT);
        Cuboid leftPantFrontBack = new Cuboid(13,0,3,4,12,6,
                uv(4,52,4,12),uv(12,52,4,12),uv(4,48,4,4),uv(8,48,4,4),uv(0,52,4,12),uv(8,52,4,12));
        draw(model, skin, leftPantFrontBack, 6, FRONT | BACK);
        Cuboid leftPantOuterSide = new Cuboid(12,0,4,6,12,4,
                uv(4,52,4,12),uv(12,52,4,12),uv(4,48,4,4),uv(8,48,4,4),uv(0,52,4,12),uv(8,52,4,12));
        draw(model, skin, leftPantOuterSide, 6, RIGHT);
        if (model.occupiedCount() > VoxelStudioConfig.MAX_OCCUPIED_VOXELS) {
            throw new IllegalArgumentException("Skin produced too many voxels");
        }
        return model;
    }

    private static void draw(VoxelModel model, BufferedImage image, Cuboid c, int layer, int mask) {
        if ((mask & FRONT) != 0) face(model,image,c,c.front,c.width,c.height,layer,0);
        if ((mask & BACK) != 0) face(model,image,c,c.back,c.width,c.height,layer,1);
        if ((mask & TOP) != 0) face(model,image,c,c.top,c.width,c.depth,layer,2);
        if ((mask & BOTTOM) != 0) face(model,image,c,c.bottom,c.width,c.depth,layer,3);
        if ((mask & LEFT) != 0) face(model,image,c,c.left,c.depth,c.height,layer,4);
        if ((mask & RIGHT) != 0) face(model,image,c,c.right,c.depth,c.height,layer,5);
    }

    /** face: 0 front, 1 back, 2 top, 3 bottom, 4 left, 5 right */
    private static void face(VoxelModel model, BufferedImage image, Cuboid c, Uv uv,
                             int outputWidth, int outputHeight, int layer, int face) {
        for (int v = 0; v < outputHeight; v++) {
            for (int u = 0; u < outputWidth; u++) {
                int sx = uv.x + Math.min(uv.width-1, u * uv.width / outputWidth);
                int sy = uv.y + Math.min(uv.height-1, v * uv.height / outputHeight);
                int argb = image.getRGB(sx, sy);
                if ((argb >>> 24) < 32) continue;
                int paletteIndex = nearestPalette(argb, model.palette());
                int x, y, z;
                switch (face) {
                    case 0 -> { x = c.x + u; y = c.y + c.height - 1 - v; z = c.z; }
                    case 1 -> { x = c.x + c.width - 1 - u; y = c.y + c.height - 1 - v; z = c.z + c.depth - 1; }
                    case 2 -> { x = c.x + u; y = c.y + c.height - 1; z = c.z + v; }
                    case 3 -> { x = c.x + u; y = c.y; z = c.z + c.depth - 1 - v; }
                    case 4 -> { x = c.x; y = c.y + c.height - 1 - v; z = c.z + u; }
                    case 5 -> { x = c.x + c.width - 1; y = c.y + c.height - 1 - v; z = c.z + c.depth - 1 - u; }
                    default -> throw new IllegalArgumentException("Unknown face");
                }
                if (x >= 0 && x < model.width() && y >= 0 && y < model.height() && z >= 0 && z < model.depth()) {
                    model.setVoxel(x, y, z, paletteIndex, layer);
                }
            }
        }
    }

    private static int nearestPalette(int argb, List<VoxelModel.PaletteEntry> palette) {
        int best = 0;
        double bestDistance = Double.POSITIVE_INFINITY;
        for (int i = 0; i < palette.size(); i++) {
            double distance = VoxelColorMath.distanceSquared(argb, palette.get(i).argb());
            if (distance < bestDistance) { bestDistance = distance; best = i; }
        }
        return best + 1;
    }

    private static BufferedImage normalize(BufferedImage source) {
        if (source.getWidth() != 64 || (source.getHeight() != 64 && source.getHeight() != 32)) {
            throw new IllegalArgumentException("Skin PNG must be 64x64 or legacy 64x32 pixels");
        }
        BufferedImage out = new BufferedImage(64,64,BufferedImage.TYPE_INT_ARGB);
        var g = out.createGraphics();
        g.drawImage(source,0,0,null);
        g.dispose();
        if (source.getHeight() == 32) {
            copy(out,44,20,4,12,36,52,4,12,true);
            copy(out,52,20,4,12,44,52,4,12,true);
            copy(out,44,16,4,4,36,48,4,4,true);
            copy(out,48,16,4,4,40,48,4,4,true);
            copy(out,40,20,4,12,32,52,4,12,true);
            copy(out,48,20,4,12,40,52,4,12,true);
            copy(out,4,20,4,12,20,52,4,12,true);
            copy(out,12,20,4,12,28,52,4,12,true);
            copy(out,4,16,4,4,20,48,4,4,true);
            copy(out,8,16,4,4,24,48,4,4,true);
            copy(out,0,20,4,12,16,52,4,12,true);
            copy(out,8,20,4,12,24,52,4,12,true);
        }
        return out;
    }

    private static void copy(BufferedImage image, int sx, int sy, int width, int height,
                             int dx, int dy, int dw, int dh, boolean mirrorX) {
        for (int y=0;y<dh;y++) for (int x=0;x<dw;x++) {
            int sourceX = sx + (mirrorX ? width - 1 - x*width/dw : x*width/dw);
            int sourceY = sy + y*height/dh;
            image.setRGB(dx+x,dy+y,image.getRGB(sourceX,sourceY));
        }
    }

    private static Uv uv(int x,int y,int width,int height) { return new Uv(x,y,width,height); }

    private static List<VoxelModel.PaletteEntry> makeFallbackPalette() {
        String[] materials = {"wool","concrete","terracotta"};
        List<VoxelModel.PaletteEntry> result = new ArrayList<>(48);
        for (int material=0;material<3;material++) for (int dye=0;dye<16;dye++) {
            result.add(new VoxelModel.PaletteEntry("minecraft:"+DYES[dye]+"_"+materials[material],
                    0xFF000000 | FALLBACK_RGB[material][dye]));
        }
        return List.copyOf(result);
    }
}
