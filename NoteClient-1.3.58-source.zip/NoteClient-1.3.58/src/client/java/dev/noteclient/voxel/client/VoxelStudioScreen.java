package dev.noteclient.voxel.client;

import com.mojang.blaze3d.platform.NativeImage;
import dev.noteclient.PlayerSkinBrowserScreen;
import dev.noteclient.PlayerStatueBuilder;
import dev.noteclient.voxel.core.SkinVoxelizer;
import dev.noteclient.voxel.core.VoxelCamera;
import dev.noteclient.voxel.core.VoxelModel;
import dev.noteclient.voxel.core.VoxelStudioConfig;
import dev.noteclient.voxel.core.VoxelStudioDocument;
import dev.noteclient.voxel.core.VoxelStudioDocument.Tool;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Client-side 3D voxel editor. Expensive meshing/rasterization runs on a small
 * daemon pool; the render thread only uploads the finished preview texture.
 */
public final class VoxelStudioScreen extends Screen {
    private static final ExecutorService PREVIEW_EXECUTOR = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "NoteClient-VoxelPreview");
        thread.setDaemon(true);
        return thread;
    });
    private static final AtomicLong PREVIEW_IDS = new AtomicLong();

    private final Screen parent;
    private final VoxelStudioDocument document;
    private final boolean giantBlockMode;
    private final VoxelCamera camera = new VoxelCamera();

    private int previewX, previewY, previewWidth, previewHeight;
    private int panelX, panelY, panelWidth, listTop, listBottom, rowHeight, visibleRows;
    private int wheelX, wheelY, wheelSize;
    private EditBox searchBox;
    private EditBox saveNameBox;
    private List<VoxelSkinLibrary.Entry> entries = List.of();
    private VoxelSkinLibrary.Entry selectedEntry;
    private int scrollOffset;
    private int selectedWheelColor = 0xFFFFFFFF;
    private int wheelCursorX;
    private int wheelCursorY;
    private String status = "Paint the white player with the color wheel.";

    private long requestedPreview;
    private volatile BufferedImage completedPreview;
    private volatile long completedPreviewId;
    private volatile boolean previewTaskRunning;
    private DynamicTexture previewTexture;
    private Identifier previewTextureId;
    private DynamicTexture wheelTexture;
    private Identifier wheelTextureId;
    private boolean previewDirty = true;
    private boolean removed;
    private boolean closingToGameplay;
    private boolean externalImportPending;
    private int externalSkinStartToken;
    private int externalImportTicks;
    private BufferedImage importedSource;

    private boolean leftPainting;
    private boolean wheelDragging;
    private boolean brushPending;
    private boolean paletteWaitRegistered;
    private int latestBrushArgb = 0xFFFFFFFF;
    private boolean rotating;
    private boolean panning;
    private double lastMouseX, lastMouseY;

    public VoxelStudioScreen(Screen parent) {
        this(parent, SkinVoxelizer.whitePlayerModel("My Character", MinecraftBlockPalette.whitePalette()), false);
    }

    public VoxelStudioScreen(Screen parent, VoxelModel initialModel, boolean giantBlockMode) {
        super(Component.literal(giantBlockMode ? "NoteClient Giant Block Painter" : "NoteClient Character Painter"));
        this.parent = parent;
        this.document = new VoxelStudioDocument(initialModel);
        this.giantBlockMode = giantBlockMode;
        this.status = giantBlockMode
                ? "Pixel-mapped " + initialModel.width() + "³ giant block shell. Exterior texture faces are editable."
                : "Paint the white player with the color wheel.";
    }

    @Override
    protected void init() {
        removed = false;
        int margin = 12;
        int top = 48;
        int bottom = 60;
        previewX = margin;
        previewY = top;
        previewHeight = Math.max(160, height - top - bottom);
        previewWidth = (int)Math.min(Math.max(220, width - 350), previewHeight * (VoxelStudioConfig.PREVIEW_WIDTH / (double)VoxelStudioConfig.PREVIEW_HEIGHT));
        previewWidth = Math.max(180, previewWidth);

        panelX = previewX + previewWidth + 12;
        panelY = top;
        panelWidth = Math.max(220, width - panelX - margin);
        addButton("GIANT BLOCKS", Math.max(8, width - 132), 12, 120, 22, this::openGiantBlockPicker);

        int rowY = panelY;
        int gap = 4;
        int toolWidth = Math.max(38, (panelWidth - 4 * gap) / 5);
        addButton("PAINT", panelX, rowY, toolWidth, 18, () -> setTool(Tool.PAINT));
        addButton("ERASE", panelX + toolWidth + gap, rowY, toolWidth, 18, () -> setTool(Tool.ERASE));
        addButton("PICK", panelX + (toolWidth + gap) * 2, rowY, toolWidth, 18, () -> setTool(Tool.PICK));
        addButton("CAM", panelX + (toolWidth + gap) * 3, rowY, toolWidth, 18, () -> { camera.reset(); dirty(); });
        addButton(giantBlockMode ? "BLOCK" : "WHITE", panelX + (toolWidth + gap) * 4, rowY, toolWidth, 18,
                giantBlockMode ? this::openGiantBlockPicker : this::resetWhiteModel);

        rowY += 23;
        int smallWidth = (panelWidth - 3 * gap) / 4;
        addButton("UNDO", panelX, rowY, smallWidth, 18, () -> { if (document.undo()) dirty(); });
        addButton("REDO", panelX + smallWidth + gap, rowY, smallWidth, 18, () -> { if (document.redo()) dirty(); });
        addButton("LAYER -", panelX + (smallWidth + gap) * 2, rowY, smallWidth, 18, () -> changeLayer(-1));
        addButton("LAYER +", panelX + (smallWidth + gap) * 3, rowY, smallWidth, 18, () -> changeLayer(1));

        // The editor's primary interaction is a real HSV color wheel. The chosen
        // RGB color is quantized to the closest safe vanilla block in the model palette.
        wheelSize = Math.max(84, Math.min(112, Math.min(panelWidth - 20, height / 5)));
        wheelX = panelX + (panelWidth - wheelSize) / 2;
        wheelY = rowY + 12;
        createColorWheelTexture();
        // Build the texture-derived vanilla block palette on a daemon worker so
        // opening the editor never blocks the render thread on registry sampling.
        MinecraftBlockPalette.prepareAsync();
        wheelCursorX = wheelX + wheelSize / 2;
        wheelCursorY = wheelY + wheelSize / 2;

        rowY = wheelY + wheelSize + 21;
        int half = (panelWidth - gap) / 2;
        addButton("TOGGLE LAYER", panelX, rowY, half, 18, this::toggleActiveLayer);
        addButton("ISOLATE ACTIVE", panelX + half + gap, rowY, half, 18, this::isolateActiveLayer);

        rowY += 23;
        searchBox = new EditBox(font, panelX, rowY, panelWidth, 19, Component.literal("Search local models"));
        searchBox.setMaxLength(80);
        searchBox.setHint(Component.literal("Search saved skins / voxel templates…"));
        searchBox.setResponder(value -> scrollOffset = 0);
        addRenderableWidget(searchBox);

        listTop = rowY + 23;
        listBottom = Math.max(listTop + 28, height - 143);
        rowHeight = 27;
        visibleRows = Math.max(1, (listBottom - listTop) / rowHeight);

        rowY = height - 136;
        addButton("LOAD SELECTED", panelX, rowY, panelWidth, 18, this::loadSelected);
        rowY += 22;
        int third = (panelWidth - 2 * gap) / 3;
        addButton("PNG FILES", panelX, rowY, third, 18, this::openPngBrowser);
        addButton("PRESETS", panelX + third + gap, rowY, third, 18, this::openPresetBrowser);
        addButton("PLAYERS", panelX + (third + gap) * 2, rowY, third, 18, this::openOnlineBrowser);
        rowY += 22;
        saveNameBox = new EditBox(font, panelX, rowY, Math.max(90, panelWidth - 86), 18, Component.literal("Save as"));
        saveNameBox.setMaxLength(48);
        saveNameBox.setValue(document.model().name());
        saveNameBox.setHint(Component.literal("Model name"));
        addRenderableWidget(saveNameBox);
        addButton("SAVE", panelX + panelWidth - 80, rowY, 80, 18, this::saveModel);
        rowY += 22;
        int actionWidth = (panelWidth - 2 * gap) / 3;
        addButton("BUILD", panelX, rowY, actionWidth, 20, () -> VoxelStudioClient.build(document.model()));
        addButton("REBUILD [R]", panelX + actionWidth + gap, rowY, actionWidth, 20,
                () -> VoxelStudioClient.rebuild(document.model()));
        addButton("STOP", panelX + (actionWidth + gap) * 2, rowY, actionWidth, 20,
                VoxelStudioClient::stop);
        rowY += 23;
        addButton("UNDO LAST BUILD [LEFT SHIFT]", panelX, rowY, panelWidth, 18, VoxelStudioClient::remove);

        VoxelSkinLibrary.scanAsync().thenAccept(found -> {
            Minecraft.getInstance().execute(() -> {
                if (!removed) entries = found;
            });
        }).exceptionally(error -> {
            Minecraft.getInstance().execute(() -> status = "Skin scan failed: " + rootMessage(error));
            return null;
        });
        dirty();
    }

    private void addButton(String label, int x, int y, int w, int h, Runnable action) {
        addRenderableWidget(Button.builder(Component.literal(label), ignored -> action.run())
                .bounds(x, y, Math.max(1,w), h).build());
    }

    private void resetWhiteModel() {
        document.replaceModel(SkinVoxelizer.whitePlayerModel("My Character", MinecraftBlockPalette.whitePalette()));
        if (saveNameBox != null) saveNameBox.setValue(document.model().name());
        selectedWheelColor = 0xFFFFFFFF;
        latestBrushArgb = selectedWheelColor;
        brushPending = false;
        document.setActivePaletteIndex(1);
        wheelCursorX = wheelX + wheelSize / 2;
        wheelCursorY = wheelY + wheelSize / 2;
        status = "Reset to a solid white 3D player";
        dirty();
    }

    private void createColorWheelTexture() {
        if (wheelTextureId != null && minecraft != null) {
            minecraft.getTextureManager().release(wheelTextureId);
            wheelTextureId = null;
            wheelTexture = null;
        }
        int resolution = 128;
        BufferedImage wheel = new BufferedImage(resolution, resolution, BufferedImage.TYPE_INT_ARGB);
        double center = (resolution - 1) * 0.5;
        double radius = center - 1.0;
        for (int y = 0; y < resolution; y++) {
            for (int x = 0; x < resolution; x++) {
                double dx = (x - center) / radius;
                double dy = (y - center) / radius;
                double distance = Math.sqrt(dx * dx + dy * dy);
                if (distance > 1.0) {
                    wheel.setRGB(x, y, 0x00000000);
                    continue;
                }
                float hue = (float)((Math.atan2(-dy, dx) / (Math.PI * 2.0) + 1.0) % 1.0);
                float saturation = (float)Math.min(1.0, distance);
                wheel.setRGB(x, y, Color.HSBtoRGB(hue, saturation, 1.0f) | 0xFF000000);
            }
        }
        NativeImage nativeImage = toNativeImage(wheel);
        wheelTexture = new DynamicTexture(() -> "noteclient_color_wheel_" + PREVIEW_IDS.incrementAndGet(), nativeImage);
        wheelTextureId = Identifier.fromNamespaceAndPath(
                "noteclient", "color_wheel/" + PREVIEW_IDS.incrementAndGet());
        Minecraft.getInstance().getTextureManager().register(wheelTextureId, wheelTexture);
    }

    private static NativeImage toNativeImage(BufferedImage image) {
        NativeImage nativeImage = new NativeImage(image.getWidth(), image.getHeight(), false);
        for (int y = 0; y < image.getHeight(); y++) {
            for (int x = 0; x < image.getWidth(); x++) {
                nativeImage.setPixel(x, y, image.getRGB(x, y));
            }
        }
        return nativeImage;
    }

    private void pickWheelColor(double mouseX, double mouseY) {
        double cx = wheelX + wheelSize * 0.5;
        double cy = wheelY + wheelSize * 0.5;
        double dx = (mouseX - cx) / (wheelSize * 0.5);
        double dy = (mouseY - cy) / (wheelSize * 0.5);
        double distance = Math.sqrt(dx * dx + dy * dy);
        if (distance > 1.0) return;
        float hue = (float)((Math.atan2(-dy, dx) / (Math.PI * 2.0) + 1.0) % 1.0);
        float saturation = (float)Math.min(1.0, distance);
        selectedWheelColor = Color.HSBtoRGB(hue, saturation, 1.0f) | 0xFF000000;
        wheelCursorX = (int)Math.round(mouseX);
        wheelCursorY = (int)Math.round(mouseY);
        setBrushFromRgb(selectedWheelColor);
    }

    private void setBrushFromRgb(int argb) {
        latestBrushArgb = argb;
        if (MinecraftBlockPalette.isReady()) {
            brushPending = false;
            applyMatchedBrush(argb);
            return;
        }

        brushPending = true;
        status = "Sampling vanilla block textures for the color palette…";
        if (paletteWaitRegistered) return;
        paletteWaitRegistered = true;
        MinecraftBlockPalette.prepareAsync().whenComplete((ignored, error) ->
                Minecraft.getInstance().execute(() -> {
                    paletteWaitRegistered = false;
                    if (removed) return;
                    if (error != null) {
                        brushPending = false;
                        status = "Block texture palette failed: " + rootMessage(error);
                        return;
                    }
                    if (brushPending) {
                        brushPending = false;
                        // Use the newest wheel position, not a stale color from
                        // earlier mouse-drag events that arrived during sampling.
                        applyMatchedBrush(latestBrushArgb);
                        dirty();
                    }
                }));
    }

    private void applyMatchedBrush(int argb) {
        VoxelModel.PaletteEntry best = MinecraftBlockPalette.nearest(argb);
        int bestIndex = document.model().ensurePaletteEntry(best);
        document.setActivePaletteIndex(bestIndex);
        String appliedBlock = document.model().palette().get(bestIndex - 1).blockId();
        status = "Brush: " + appliedBlock + " (" + MinecraftBlockPalette.textureCandidateCount()
                + " texture-sampled / " + MinecraftBlockPalette.candidateCount() + " safe vanilla full blocks)";
    }

    public void closeToParent() {
        if (minecraft != null) minecraft.gui.setScreen(parent);
    }

    /** Leaves the complete editor/menu stack and returns directly to gameplay. */
    public void closeToGameplay() {
        closingToGameplay = true;
        if (minecraft != null) minecraft.gui.setScreen(null);
    }

    public VoxelModel modelForBuild() {
        document.endStroke();
        return document.model().copy();
    }

    public void beginExternalSkinImport() {
        externalSkinStartToken = PlayerStatueBuilder.loadedSkinToken();
        externalImportPending = true;
        externalImportTicks = 0;
        status = "Waiting for selected player/preset skin to load…";
    }

    @Override
    public void tick() {
        super.tick();
        if (externalImportPending) {
            externalImportTicks++;
            int token = PlayerStatueBuilder.loadedSkinToken();
            if (PlayerStatueBuilder.hasSkin() && token != externalSkinStartToken) {
                BufferedImage image = PlayerStatueBuilder.copyLoadedSkinImage();
                if (image != null) {
                    importedSource = image;
                    VoxelModel imported = SkinVoxelizer.fromSkin(image,
                            PlayerStatueBuilder.loadedUsername().isBlank() ? "Imported Player" : PlayerStatueBuilder.loadedUsername(),
                            PlayerStatueBuilder.loadedSkinSlim(), MinecraftBlockPalette.paletteForSkin(image));
                    document.replaceModel(imported);
                    if (saveNameBox != null) saveNameBox.setValue(imported.name());
                    status = "Loaded 3D skin: " + imported.name();
                    dirty();
                }
                externalImportPending = false;
            } else if (externalImportTicks > 20 * 60) {
                externalImportPending = false;
                status = "Skin import timed out. Check the skin browser status and try again.";
            }
        }
        if (previewDirty) requestPreview();
        // DynamicTexture uploads through the GPU command encoder. Do this during
        // the client tick, before render extraction opens a render pass.
        if (completedPreview != null) uploadCompletedPreview();
    }

    private void requestPreview() {
        if (previewTaskRunning) return;
        previewDirty = false;
        previewTaskRunning = true;
        long id = ++requestedPreview;
        VoxelModel modelSnapshot = document.model().copy();
        VoxelCamera cameraSnapshot = camera.copy();
        PREVIEW_EXECUTOR.execute(() -> {
            try {
                BufferedImage image = VoxelPreviewRenderer.render(modelSnapshot, cameraSnapshot,
                        VoxelStudioConfig.PREVIEW_WIDTH, VoxelStudioConfig.PREVIEW_HEIGHT);
                if (id == requestedPreview) {
                    completedPreview = image;
                    completedPreviewId = id;
                }
            } catch (Throwable error) {
                Minecraft.getInstance().execute(() -> status = "Preview error: " + rootMessage(error));
            } finally {
                Minecraft.getInstance().execute(() -> {
                    previewTaskRunning = false;
                    if (id != requestedPreview) previewDirty = true;
                });
            }
        });
    }

    private void uploadCompletedPreview() {
        BufferedImage image = completedPreview;
        if (image == null || completedPreviewId != requestedPreview) return;
        completedPreview = null;
        NativeImage nativeImage = new NativeImage(image.getWidth(), image.getHeight(), false);
        for (int y = 0; y < image.getHeight(); y++) {
            for (int x = 0; x < image.getWidth(); x++) {
                nativeImage.setPixel(x, y, image.getRGB(x, y));
            }
        }
        Minecraft client = Minecraft.getInstance();
        DynamicTexture texture = new DynamicTexture(() -> "noteclient_voxel_preview_" + PREVIEW_IDS.incrementAndGet(), nativeImage);
        Identifier id = Identifier.fromNamespaceAndPath(
                "noteclient", "voxel_preview/" + PREVIEW_IDS.incrementAndGet());
        client.getTextureManager().register(id, texture);
        if (previewTextureId != null) client.getTextureManager().release(previewTextureId);
        previewTexture = texture;
        previewTextureId = id;
    }

    private void setTool(Tool tool) {
        document.endStroke();
        document.setTool(tool);
        status = "Tool: " + tool.name();
    }

    private void changePalette(int delta) {
        int next = Math.floorMod(document.activePaletteIndex() - 1 + delta, document.model().palette().size()) + 1;
        document.setActivePaletteIndex(next);
        status = "Brush material: " + document.model().palette().get(next - 1).blockId();
    }

    private void changeLayer(int delta) {
        List<VoxelModel.Layer> layers = document.model().layers();
        int current = 0;
        for (int i=0;i<layers.size();i++) if (layers.get(i).id() == document.activeLayerId()) { current=i; break; }
        VoxelModel.Layer layer = layers.get(Math.floorMod(current + delta, layers.size()));
        document.setActiveLayer(layer.id());
        status = "Active layer: " + layer.name();
    }

    private void toggleActiveLayer() {
        VoxelModel.Layer layer = document.model().layer(document.activeLayerId());
        document.setLayerVisible(layer.id(), !layer.visible());
        status = layer.name() + (layer.visible() ? " hidden" : " visible");
        dirty();
    }

    private void isolateActiveLayer() {
        VoxelModel model = document.model();
        boolean isolate = model.layers().stream().anyMatch(layer -> layer.visible() && layer.id() != document.activeLayerId());
        for (VoxelModel.Layer layer : model.layers()) {
            boolean visible = !isolate || layer.id() == document.activeLayerId();
            if (layer.visible() != visible) document.setLayerVisible(layer.id(), visible);
        }
        status = isolate ? "Showing active layer only" : "All layers visible";
        dirty();
    }

    private void openGiantBlockPicker() {
        if (minecraft != null) minecraft.gui.setScreen(new GiantBlockPickerScreen(this));
    }

    private void openPngBrowser() {
        beginExternalSkinImport();
        minecraft.gui.setScreen(new PlayerSkinBrowserScreen(this, PlayerSkinBrowserScreen.Mode.PNG_FILES));
    }
    private void openPresetBrowser() { VoxelStudioClient.openPresetBrowser(this); }
    private void openOnlineBrowser() { VoxelStudioClient.openOnlinePlayerBrowser(this); }

    private void loadSelected() {
        if (selectedEntry == null) {
            status = "Select a skin file from the list first.";
            return;
        }
        status = "Loading " + selectedEntry.relativePath() + "…";
        VoxelSkinLibrary.loadAsync(selectedEntry).thenAccept(model -> Minecraft.getInstance().execute(() -> {
            if (removed) return;
            importedSource = null;
            document.replaceModel(model);
            if (saveNameBox != null) saveNameBox.setValue(model.name());
            status = "Loaded " + selectedEntry.relativePath();
            dirty();
        })).exceptionally(error -> {
            Minecraft.getInstance().execute(() -> status = "Skin load failed: " + rootMessage(error));
            return null;
        });
    }

    private void saveModel() {
        String name = saveNameBox == null ? document.model().name() : saveNameBox.getValue();
        document.model().setName(name);
        VoxelModel copy = document.model().copy();
        status = "Saving " + copy.name() + "…";
        VoxelSkinLibrary.saveAsync(copy, name).thenAccept(path -> Minecraft.getInstance().execute(() -> {
            if (removed) return;
            document.markSaved();
            status = "Saved: " + path.getFileName();
            VoxelSkinLibrary.scanAsync().thenAccept(found -> Minecraft.getInstance().execute(() -> entries = found));
        })).exceptionally(error -> {
            Minecraft.getInstance().execute(() -> status = "Save failed: " + rootMessage(error));
            return null;
        });
    }

    private List<VoxelSkinLibrary.Entry> filteredEntries() {
        String query = searchBox == null ? "" : searchBox.getValue().trim().toLowerCase(java.util.Locale.ROOT);
        if (query.isEmpty()) return entries;
        return entries.stream().filter(entry -> entry.relativePath().toLowerCase(java.util.Locale.ROOT).contains(query)).toList();
    }

    private void dirty() { previewDirty = true; }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        if (event.button() == 0 && insideColorWheel(mx, my)) {
            wheelDragging = true;
            pickWheelColor(mx, my);
            return true;
        }
        if (insidePreview(mx,my)) {
            lastMouseX = mx; lastMouseY = my;
            if (event.button() == 0) {
                leftPainting = true;
                document.beginStroke();
                applyPreviewRay(mx,my);
                return true;
            }
            if (event.button() == 1) { rotating = true; return true; }
            if (event.button() == 2) { panning = true; return true; }
        }
        if (event.button() == 0 && mx >= panelX && mx <= panelX + panelWidth && my >= listTop && my < listBottom) {
            int row = (int)((my - listTop) / rowHeight);
            int index = scrollOffset + row;
            List<VoxelSkinLibrary.Entry> filtered = filteredEntries();
            if (row >= 0 && row < visibleRows && index >= 0 && index < filtered.size()) {
                selectedEntry = filtered.get(index);
                status = "Selected: " + selectedEntry.relativePath();
                if (doubleClick) loadSelected();
                return true;
            }
        }
        return super.mouseClicked(event,doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double deltaX, double deltaY) {
        if (wheelDragging && event.button() == 0) {
            pickWheelColor(event.x(), event.y());
            return true;
        }
        if (rotating && event.button() == 1) {
            camera.orbit(deltaX,deltaY); lastMouseX=event.x(); lastMouseY=event.y(); dirty(); return true;
        }
        if (panning && event.button() == 2) {
            camera.pan(deltaX,deltaY); lastMouseX=event.x(); lastMouseY=event.y(); dirty(); return true;
        }
        if (leftPainting && event.button() == 0 && insidePreview(event.x(),event.y())) {
            applyPreviewRay(event.x(),event.y()); return true;
        }
        return super.mouseDragged(event,deltaX,deltaY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (event.button() == 0 && wheelDragging) {
            wheelDragging = false;
            return true;
        }
        if (event.button() == 0 && leftPainting) {
            leftPainting = false;
            document.endStroke();
            return true;
        }
        if (event.button() == 1) { rotating = false; return true; }
        if (event.button() == 2) { panning = false; return true; }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (insidePreview(mouseX,mouseY)) {
            camera.zoom(verticalAmount); dirty(); return true;
        }
        if (mouseX >= panelX && mouseX <= panelX + panelWidth && mouseY >= listTop && mouseY < listBottom) {
            int max = Math.max(0, filteredEntries().size() - visibleRows);
            scrollOffset = Math.max(0,Math.min(max,scrollOffset + (verticalAmount > 0 ? -2 : 2)));
            return true;
        }
        return super.mouseScrolled(mouseX,mouseY,horizontalAmount,verticalAmount);
    }

    private void applyPreviewRay(double mouseX, double mouseY) {
        if (brushPending && document.tool() != Tool.PICK) return;
        VoxelCamera.Ray ray = camera.rayFromScreen(document.model(), mouseX, mouseY,
                previewX,previewY,previewWidth,previewHeight);
        var hit = document.apply(ray);
        if (hit != null) {
            if (document.tool() == Tool.PICK) {
                selectedWheelColor = document.model().palette().get(document.activePaletteIndex() - 1).argb();
                status = "Picked palette " + hit.paletteIndex() + " from layer " + hit.layerId();
            }
            else if (document.tool() == Tool.PAINT) status = "Painted voxel " + hit.x() + "," + hit.y() + "," + hit.z();
            else status = "Erased voxel " + hit.x() + "," + hit.y() + "," + hit.z();
            dirty();
        }
    }

    private boolean insideColorWheel(double x, double y) {
        double cx = wheelX + wheelSize * 0.5;
        double cy = wheelY + wheelSize * 0.5;
        double dx = x - cx, dy = y - cy;
        double radius = wheelSize * 0.5;
        return dx * dx + dy * dy <= radius * radius;
    }

    private boolean insidePreview(double x, double y) {
        return x >= previewX && x < previewX + previewWidth && y >= previewY && y < previewY + previewHeight;
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent event) {
        if (event.key() == 256) { closeToParent(); return true; } // Escape
        if (event.key() == 90) { if (document.undo()) dirty(); return true; }
        return super.keyPressed(event);
    }

    @Override
    public void onClose() {
        if (closingToGameplay) {
            closingToGameplay = false;
            return;
        }
        closeToParent();
    }

    @Override
    public void removed() {
        removed = true;
        document.endStroke();
        if (previewTextureId != null && minecraft != null) minecraft.getTextureManager().release(previewTextureId);
        if (wheelTextureId != null && minecraft != null) minecraft.getTextureManager().release(wheelTextureId);
        previewTexture = null; previewTextureId = null;
        wheelTexture = null; wheelTextureId = null;
        super.removed();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        graphics.fill(0,0,width,height,0xE810151C);
        graphics.fill(previewX - 3,previewY - 3,previewX + previewWidth + 3,previewY + previewHeight + 3,0xFF536170);
        graphics.fill(previewX - 1,previewY - 1,previewX + previewWidth + 1,previewY + previewHeight + 1,0xFF090C10);
        if (previewTextureId != null) {
            graphics.blit(RenderPipelines.GUI_TEXTURED,previewTextureId,previewX,previewY,
                    0f,0f,previewWidth,previewHeight,VoxelStudioConfig.PREVIEW_WIDTH,VoxelStudioConfig.PREVIEW_HEIGHT,0xFFFFFFFF);
        } else {
            graphics.fill(previewX,previewY,previewX+previewWidth,previewY+previewHeight,0xFF111820);
            graphics.text(font,"Building 3D preview…",previewX+14,previewY+18,0xFFE6EAF0,true);
        }
        graphics.fill(panelX - 4,panelY - 3,panelX + panelWidth + 4,height - 12,0xD8202933);
        graphics.fill(panelX - 4,panelY - 3,panelX + panelWidth + 4,panelY + 22,0xFF334454);
        graphics.text(font, giantBlockMode ? "NOTECLIENT  /  GIANT BLOCK BUILDER" : "NOTECLIENT  /  CHARACTER PAINTER",
                panelX + 5, panelY + 5, 0xFFFFFFFF, true);
        graphics.text(font,"COLOR WHEEL",wheelX,wheelY-12,0xFFF0F4F8,true);
        if (wheelTextureId != null) {
            graphics.blit(RenderPipelines.GUI_TEXTURED, wheelTextureId, wheelX, wheelY,
                    0f, 0f, wheelSize, wheelSize, 128, 128, 0xFFFFFFFF);
            graphics.fill(wheelCursorX-3,wheelCursorY-3,wheelCursorX+4,wheelCursorY+4,0xFF111820);
            graphics.fill(wheelCursorX-2,wheelCursorY-2,wheelCursorX+3,wheelCursorY+3,selectedWheelColor);
        }
        graphics.fill(panelX+4,wheelY+wheelSize+3,panelX+16,wheelY+wheelSize+15,selectedWheelColor);
        String brushBlock = document.model().palette().get(document.activePaletteIndex()-1).blockId();
        while (!brushBlock.isEmpty() && font.width(brushBlock) > panelWidth-24) brushBlock=brushBlock.substring(1);
        graphics.text(font,brushBlock,wheelX+18,wheelY+wheelSize+5,0xFFE8EDF2,false);

        int labelY = listTop - 16;
        graphics.text(font,(giantBlockMode ? "LOCAL VOXEL MODELS  •  " : "LOCAL SKINS  •  ") + entries.size(),
                panelX + 2,labelY,0xFFB8D7EF,true);
        graphics.fill(panelX,listTop,panelX+panelWidth,listBottom,0xFF10161C);
        List<VoxelSkinLibrary.Entry> filtered = filteredEntries();
        if (filtered.isEmpty()) {
            graphics.text(font,"No PNG or .voxel.json models found.",panelX+8,listTop+12,0xFFB9C2CC,false);
            graphics.text(font,"Skins folder: " + VoxelSkinLibrary.root(),panelX+8,listTop+26,0xFF8E9AA6,false);
        } else {
            int end = Math.min(filtered.size(),scrollOffset+visibleRows);
            for (int i=scrollOffset;i<end;i++) {
                VoxelSkinLibrary.Entry entry = filtered.get(i);
                int row = i-scrollOffset, y=listTop+row*rowHeight;
                boolean selected = entry.equals(selectedEntry);
                boolean hovered = mouseX>=panelX && mouseX<panelX+panelWidth && mouseY>=y && mouseY<y+rowHeight;
                int color = selected ? 0xFF4E6378 : hovered ? 0xFF394A5A : (row%2==0 ? 0xFF222D38 : 0xFF1B252E);
                graphics.fill(panelX+3,y+1,panelX+panelWidth-3,y+rowHeight-1,color);
                String label = entry.relativePath();
                while (!label.isEmpty() && font.width(label)>panelWidth-16) label=label.substring(1);
                graphics.text(font,label,panelX+8,y+4,0xFFEAF0F6,true);
                graphics.text(font,entry.kind()==VoxelSkinLibrary.Kind.PNG_SKIN ? "PNG SKIN" : "VOXEL TEMPLATE",
                        panelX+8,y+15,0xFF9FB0C0,false);
            }
        }

        VoxelModel.Layer activeLayer = document.model().layer(document.activeLayerId());
        graphics.text(font,"TOOL: " + document.tool() + "   LAYER: " + activeLayer.name(),previewX+8,previewY+previewHeight+8,0xFFE6EDF5,true);
        graphics.text(font,"Brush: " + document.model().palette().get(document.activePaletteIndex()-1).blockId(),previewX+8,previewY+previewHeight+21,0xFFB5C3D0,false);
        graphics.text(font,"Status: " + status,previewX+8,previewY+previewHeight+34,0xFFFFD889,false);
        graphics.text(font,"Left paint • wheel select color • right orbit • middle pan • wheel zoom • Z undo",
                previewX+8,previewY+previewHeight+47,0xFF9BA9B7,false);
        super.extractRenderState(graphics,mouseX,mouseY,delta);
    }

    private static String rootMessage(Throwable error) {
        Throwable current=error;
        while (current.getCause()!=null) current=current.getCause();
        return current.getMessage()==null ? current.getClass().getSimpleName() : current.getMessage();
    }
}
