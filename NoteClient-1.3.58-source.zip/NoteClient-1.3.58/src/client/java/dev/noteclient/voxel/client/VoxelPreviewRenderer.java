package dev.noteclient.voxel.client;

import dev.noteclient.voxel.core.VoxelCamera;
import dev.noteclient.voxel.core.VoxelMeshBuilder;
import dev.noteclient.voxel.core.VoxelModel;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Small, cached software preview renderer. It renders only when the model/camera is dirty. */
public final class VoxelPreviewRenderer {
    private record DrawQuad(int[] xs, int[] ys, double depth, int argb, int shade) {}
    private VoxelPreviewRenderer() {}

    public static BufferedImage render(VoxelModel model, VoxelCamera camera, int width, int height) {
        if (width < 32 || height < 32 || width > 1024 || height > 1024) {
            throw new IllegalArgumentException("Preview dimensions outside safe range");
        }
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
            g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
            paintBackground(g, width, height);
            List<DrawQuad> faces = new ArrayList<>();
            for (VoxelMeshBuilder.Quad quad : VoxelMeshBuilder.build(model)) {
                VoxelModel.Layer layer = model.layer(quad.layerId());
                VoxelMeshBuilder.Vertex[] corners = quad.corners();
                int[] xs = new int[4], ys = new int[4];
                double depth = 0;
                boolean visible = true;
                for (int i = 0; i < 4; i++) {
                    VoxelMeshBuilder.Vertex vertex = corners[i];
                    VoxelCamera.Projection p = camera.project(model,
                            new VoxelCamera.Vec3(vertex.x() + layer.offsetX(),
                                    vertex.y() + layer.offsetY(), vertex.z() + layer.offsetZ()), width, height);
                    if (!p.visible()) { visible = false; break; }
                    xs[i] = (int)Math.round(p.x());
                    ys[i] = (int)Math.round(p.y());
                    depth += p.depth() * 0.25;
                }
                if (!visible) continue;
                int argb = model.palette().get(quad.paletteIndex() - 1).argb();
                faces.add(new DrawQuad(xs, ys, depth, argb, shade(quad.axis(), quad.sign())));
            }
            faces.sort(Comparator.comparingDouble(DrawQuad::depth).reversed());
            for (DrawQuad face : faces) {
                int rgb = shadeColor(face.argb, face.shade);
                g.setColor(new Color(rgb, true));
                g.fillPolygon(face.xs, face.ys, 4);
                g.setColor(new Color(0x28000000, true));
                g.setStroke(new BasicStroke(1f));
                g.drawPolygon(face.xs, face.ys, 4);
            }
            g.setColor(new Color(0xFF728091, true));
            g.drawRect(0, 0, width - 1, height - 1);
        } finally {
            g.dispose();
        }
        return image;
    }

    private static void paintBackground(Graphics2D g, int width, int height) {
        g.setColor(new Color(0xFF111820, true));
        g.fillRect(0,0,width,height);
        g.setColor(new Color(0xFF1A2530, true));
        for (int x = 0; x < width; x += 16) g.drawLine(x,0,x,height);
        for (int y = 0; y < height; y += 16) g.drawLine(0,y,width,y);
        g.setColor(new Color(0xFF3C4A57, true));
        int cx=width/2, cy=height*3/4;
        g.drawOval(cx-70,cy-9,140,18);
    }

    private static int shade(int axis, int sign) {
        if (axis == 1) return sign > 0 ? 126 : 54;  // bright top, deep underside
        if (axis == 0) return sign > 0 ? 86 : 68;  // side-face contrast
        return sign > 0 ? 108 : 82;
    }

    private static int shadeColor(int argb, int brightness) {
        int r=(argb>>>16)&255, g=(argb>>>8)&255, b=argb&255;
        r=Math.min(255,r*brightness/100); g=Math.min(255,g*brightness/100); b=Math.min(255,b*brightness/100);
        return 0xFF000000 | (r<<16) | (g<<8) | b;
    }
}
