package dev.noteclient.voxel.core;

import dev.noteclient.voxel.client.MinecraftBlockPalette;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelPart;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Converts the six baked face textures of a registered Minecraft block into a
 * one-voxel-per-texture-pixel cube shell. Vanilla 16px textures therefore become
 * a 16x16x16 giant block; 32px output also supports HD resource-pack textures.
 * The interior is deliberately hollow so a giant block remains affordable to
 * build on a server while every visible face retains its full pixel pattern.
 */
public final class GiantBlockVoxelizer {
    public static final int DEFAULT_SIZE = 16;
    public static final int HD_SIZE = 32;
    private static final long MODEL_SEED = 0x4749414E54424C4FL;
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "NoteClient-GiantBlockVoxelizer");
        thread.setDaemon(true);
        return thread;
    });

    private record FaceTexture(TextureAtlasSprite sprite, boolean tinted) {}

    private GiantBlockVoxelizer() {}

    public static CompletableFuture<VoxelModel> createAsync(String blockId, int size) {
        if (size != DEFAULT_SIZE && size != HD_SIZE) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("Giant block size must be 16 or 32"));
        }
        return MinecraftBlockPalette.prepareAsync().thenApplyAsync(ignored -> create(blockId, size), EXECUTOR);
    }

    /** Build a voxel shell from the current resource-pack baked block model. */
    public static VoxelModel create(String blockId, int size) {
        if (size != DEFAULT_SIZE && size != HD_SIZE) {
            throw new IllegalArgumentException("Giant block size must be 16 or 32");
        }
        Identifier id;
        try {
            id = Identifier.parse(blockId);
        } catch (RuntimeException invalidId) {
            throw new IllegalArgumentException("Invalid block identifier: " + blockId, invalidId);
        }
        Block block = BuiltInRegistries.BLOCK.getOptional(id).orElse(null);
        if (block == null || block.defaultBlockState().isAir()) {
            throw new IllegalArgumentException("Minecraft block was not found: " + blockId);
        }

        Minecraft minecraft = Minecraft.getInstance();
        BlockState state = block.defaultBlockState();
        MapColor mapColor = state.getMapColor(EmptyBlockGetter.INSTANCE, BlockPos.ZERO);
        int fallback = mapColor == null || mapColor == MapColor.NONE
                ? 0xFF808080 : 0xFF000000 | (mapColor.col & 0xFFFFFF);

        BlockStateModel baked = minecraft.getModelManager().getBlockStateModelSet().get(state);
        List<BlockStateModelPart> parts = new ArrayList<>();
        baked.collectParts(RandomSource.create(MODEL_SEED), parts);

        Map<Direction, FaceTexture> faces = collectFaceTextures(parts);
        FaceTexture anyFace = faces.values().stream().findFirst().orElse(null);
        for (Direction direction : Direction.values()) {
            faces.putIfAbsent(direction, anyFace);
        }

        int volume = size * size * size;
        double[] red = new double[volume];
        double[] green = new double[volume];
        double[] blue = new double[volume];
        int[] samples = new int[volume];

        for (Direction direction : Direction.values()) {
            FaceTexture source = faces.get(direction);
            int[][] pixels = sampleFace(source, size, fallback);
            putFace(direction, pixels, size, red, green, blue, samples);
        }

        int averageColor = averageColor(red, green, blue, samples, fallback);
        VoxelModel.PaletteEntry base = MinecraftBlockPalette.nearest(averageColor);
        VoxelModel model = new VoxelModel(size, size, size, modelName(block), List.of(base),
                List.of(new VoxelModel.Layer(0, "Giant block exterior", 0, 0, 0, true, true)), false);
        Map<Integer, VoxelModel.PaletteEntry> matched = new HashMap<>();

        int occupied = 0;
        for (int y = 0; y < size; y++) {
            for (int z = 0; z < size; z++) {
                for (int x = 0; x < size; x++) {
                    int index = x + size * (z + size * y);
                    if (samples[index] == 0) continue;
                    int argb = toArgb(red[index] / samples[index],
                            green[index] / samples[index], blue[index] / samples[index]);
                    VoxelModel.PaletteEntry material = matched.computeIfAbsent(argb, MinecraftBlockPalette::nearest);
                    int paletteIndex = model.ensurePaletteEntry(material);
                    model.setVoxel(x, y, z, paletteIndex, 0);
                    occupied++;
                }
            }
        }
        if (occupied == 0) throw new IllegalStateException("The selected block model did not contain any visible face pixels");
        return model;
    }

    private static String modelName(Block block) {
        String name = "Giant " + block.getName().getString();
        return name.length() > VoxelStudioConfig.MAX_NAME_LENGTH
                ? name.substring(0, VoxelStudioConfig.MAX_NAME_LENGTH) : name;
    }

    private static Map<Direction, FaceTexture> collectFaceTextures(List<BlockStateModelPart> parts) {
        Map<Direction, FaceTexture> result = new HashMap<>();
        Map<Identifier, FaceTexture> firstSeen = new LinkedHashMap<>();
        for (Direction direction : Direction.values()) {
            Map<Identifier, Integer> frequency = new HashMap<>();
            Map<Identifier, FaceTexture> candidates = new HashMap<>();
            for (BlockStateModelPart part : parts) {
                for (BakedQuad quad : part.getQuads(direction)) {
                    BakedQuad.MaterialInfo material = quad.materialInfo();
                    TextureAtlasSprite sprite = material.sprite();
                    Identifier spriteId = sprite.contents().name();
                    boolean tinted = material.tintIndex() >= 0;
                    frequency.merge(spriteId, 1, Integer::sum);
                    candidates.putIfAbsent(spriteId, new FaceTexture(sprite, tinted));
                    firstSeen.putIfAbsent(spriteId, new FaceTexture(sprite, tinted));
                }
            }
            candidates.entrySet().stream()
                    .max(Comparator.<Map.Entry<Identifier, FaceTexture>>comparingInt(e -> frequency.getOrDefault(e.getKey(), 0))
                            .thenComparing(e -> e.getKey().toString()))
                    .ifPresent(entry -> result.put(direction, entry.getValue()));
        }
        // Cross/plant-style models often expose their geometry as unculled quads
        // (getQuads(null)) instead of assigning a face direction. Use their first
        // real sprite as the six-face fallback so those registry entries still
        // produce a texture-based giant cube instead of a flat map-colour cube.
        for (BlockStateModelPart part : parts) {
            for (BakedQuad quad : part.getQuads(null)) {
                BakedQuad.MaterialInfo material = quad.materialInfo();
                TextureAtlasSprite sprite = material.sprite();
                Identifier spriteId = sprite.contents().name();
                firstSeen.putIfAbsent(spriteId, new FaceTexture(sprite, material.tintIndex() >= 0));
            }
        }
        if (result.isEmpty() && !firstSeen.isEmpty()) result.put(Direction.NORTH, firstSeen.values().iterator().next());
        return result;
    }

    private static int[][] sampleFace(FaceTexture face, int size, int fallback) {
        int[][] result = new int[size][size];
        if (face == null || face.sprite() == null) {
            for (int y = 0; y < size; y++) java.util.Arrays.fill(result[y], fallback);
            return result;
        }
        TextureAtlasSprite sprite = face.sprite();
        Identifier spriteId = sprite.contents().name();
        Identifier textureId = Identifier.fromNamespaceAndPath(spriteId.getNamespace(),
                "textures/" + spriteId.getPath() + ".png");
        var resource = Minecraft.getInstance().getResourceManager().getResource(textureId);
        if (resource.isEmpty()) {
            for (int y = 0; y < size; y++) java.util.Arrays.fill(result[y], fallback);
            return result;
        }
        try (var input = resource.get().open()) {
            BufferedImage image = ImageIO.read(input);
            if (image == null) throw new IOException("Texture could not be decoded");
            int logicalWidth = Math.min(image.getWidth(), Math.max(1, sprite.contents().width()));
            int logicalHeight = Math.min(image.getHeight(), Math.max(1, sprite.contents().height()));
            for (int y = 0; y < size; y++) {
                int sourceY = Math.min(logicalHeight - 1, y * logicalHeight / size);
                for (int x = 0; x < size; x++) {
                    int sourceX = Math.min(logicalWidth - 1, x * logicalWidth / size);
                    int pixel = image.getRGB(sourceX, sourceY);
                    result[y][x] = composite(pixel, fallback, face.tinted());
                }
            }
        } catch (IOException | RuntimeException exception) {
            for (int y = 0; y < size; y++) java.util.Arrays.fill(result[y], fallback);
        }
        return result;
    }

    private static int composite(int pixel, int fallback, boolean tinted) {
        int alpha = (pixel >>> 24) & 255;
        int r = ((pixel >>> 16) & 255) * alpha / 255 + ((fallback >>> 16) & 255) * (255 - alpha) / 255;
        int g = ((pixel >>> 8) & 255) * alpha / 255 + ((fallback >>> 8) & 255) * (255 - alpha) / 255;
        int b = (pixel & 255) * alpha / 255 + (fallback & 255) * (255 - alpha) / 255;
        if (tinted) {
            r = r * ((fallback >>> 16) & 255) / 255;
            g = g * ((fallback >>> 8) & 255) / 255;
            b = b * (fallback & 255) / 255;
        }
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static void putFace(Direction direction, int[][] pixels, int size,
                                double[] red, double[] green, double[] blue, int[] samples) {
        for (int v = 0; v < size; v++) {
            for (int u = 0; u < size; u++) {
                int x, y, z;
                switch (direction) {
                    case DOWN -> { x = u; y = 0; z = size - 1 - v; }
                    case UP -> { x = u; y = size - 1; z = v; }
                    case NORTH -> { x = u; y = size - 1 - v; z = 0; }
                    case SOUTH -> { x = size - 1 - u; y = size - 1 - v; z = size - 1; }
                    case WEST -> { x = 0; y = size - 1 - v; z = u; }
                    case EAST -> { x = size - 1; y = size - 1 - v; z = size - 1 - u; }
                    default -> throw new IllegalStateException("Unsupported block face: " + direction);
                }
                int index = x + size * (z + size * y);
                int color = pixels[v][u];
                red[index] += toLinear((color >>> 16) & 255);
                green[index] += toLinear((color >>> 8) & 255);
                blue[index] += toLinear(color & 255);
                samples[index]++;
            }
        }
    }

    private static int averageColor(double[] red, double[] green, double[] blue, int[] samples, int fallback) {
        double r = 0, g = 0, b = 0;
        int count = 0;
        for (int i = 0; i < samples.length; i++) {
            if (samples[i] == 0) continue;
            r += red[i] / samples[i];
            g += green[i] / samples[i];
            b += blue[i] / samples[i];
            count++;
        }
        return count == 0 ? fallback : toArgb(r / count, g / count, b / count);
    }

    private static double toLinear(int channel) {
        double value = channel / 255.0;
        return value <= 0.04045 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4);
    }

    private static int toArgb(double r, double g, double b) {
        return 0xFF000000 | (toSrgb(r) << 16) | (toSrgb(g) << 8) | toSrgb(b);
    }

    private static int toSrgb(double value) {
        double srgb = value <= 0.0031308 ? value * 12.92 : 1.055 * Math.pow(value, 1.0 / 2.4) - 0.055;
        return (int)Math.round(Math.max(0, Math.min(1, srgb)) * 255);
    }
}
