package dev.noteclient.voxel.client;

import dev.noteclient.voxel.core.VoxelColorMath;
import dev.noteclient.voxel.core.VoxelModel;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelPart;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;

import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Builds a colour database from safe vanilla full-cube blocks. Unlike MapColor,
 * candidates are measured from the active baked block model's real face textures.
 * Texture averages are compared in OKLab so close brown/gray/skin-tone shades
 * remain distinct. Tint-indexed faces use the block's map colour as a stable
 * biome-independent estimate because their final tint depends on world context.
 * MapColor.NONE does not exclude a block when its baked model has real texture pixels.
 */
public final class MinecraftBlockPalette {
    private static final int MAX_SKIN_PALETTE = 248; // leave seven slots free for later painter additions
    private static final BlockPos SAMPLE_POS = BlockPos.ZERO;
    private static final long MODEL_RANDOM_SEED = 0x4E4F5445434C4945L;
    private static final Set<String> NEVER_USE = Set.of(
            "tnt", "respawn_anchor", "command_block", "chain_command_block",
            "repeating_command_block", "structure_block", "jigsaw", "barrier",
            "light", "moving_piston", "piston_head", "end_gateway", "end_portal",
            "nether_portal", "spawner", "trial_spawner", "vault", "magma_block",
            "sand", "red_sand", "gravel", "suspicious_sand", "suspicious_gravel",
            "anvil", "chipped_anvil", "damaged_anvil", "dragon_egg", "bedrock"
    );

    private record Candidate(VoxelModel.PaletteEntry entry, double[] lab, int preference) {}
    private record SpriteSample(int argb, boolean hasVisiblePixels) {}
    private record ModelSample(int argb, boolean hasTexturePixels) {}
    private static volatile List<Candidate> cachedCandidates;
    private static volatile Object cachedModelSet;
    private static volatile int cachedTextureCandidateCount;
    private static final ExecutorService PALETTE_EXECUTOR = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "NoteClient-BlockTexturePalette");
        thread.setDaemon(true);
        return thread;
    });
    private static volatile CompletableFuture<Void> prepareFuture;

    private MinecraftBlockPalette() {}

    /** Returns the closest registered vanilla full-cube block for an RGB colour. */
    public static VoxelModel.PaletteEntry nearest(int argb) {
        Candidate candidate = nearestCandidate(argb, candidates());
        return candidate.entry();
    }

    /** Small one-entry white palette used by the blank mannequin. It must not
     * trigger a full registry/texture scan while the Studio screen is opening. */
    public static List<VoxelModel.PaletteEntry> whitePalette() {
        return List.of(new VoxelModel.PaletteEntry("minecraft:white_concrete", 0xFFE8E8E8));
    }

    /** Warm the expensive baked-texture database away from the render thread. */
    public static synchronized CompletableFuture<Void> prepareAsync() {
        if (isReady()) return CompletableFuture.completedFuture(null);
        if (prepareFuture == null || prepareFuture.isCompletedExceptionally() || prepareFuture.isDone()) {
            // A completed future can be stale after a resource-pack/model reload.
            prepareFuture = CompletableFuture.runAsync(MinecraftBlockPalette::candidates, PALETTE_EXECUTOR);
        }
        return prepareFuture;
    }

    /** True once the current block-model bake has been sampled. */
    public static boolean isReady() {
        List<Candidate> ready = cachedCandidates;
        if (ready == null) return false;
        Object current = Minecraft.getInstance().getModelManager().getBlockStateModelSet();
        return current == cachedModelSet;
    }

    /**
     * Builds a compact per-skin palette. Pixels are matched against the complete
     * texture-derived database. Frequent materials are kept first; if the model
     * would exceed its one-byte palette limit, remaining slots are chosen for
     * colour diversity so subtle highlights/shadows are not discarded merely
     * because they occur less often in the source skin.
     */
    public static List<VoxelModel.PaletteEntry> paletteForSkin(BufferedImage image) {
        return paletteForSkin(image, 1.0);
    }

    /**
     * Builds a skin palette while accounting for the directional brightness
     * variants used by the statue builder. This reserves actual dark/light
     * materials for faces and internal shading instead of only sampling the
     * unshaded front-facing pixels.
     */
    public static List<VoxelModel.PaletteEntry> paletteForSkin(BufferedImage image, double... brightnessFactors) {
        if (image == null) throw new IllegalArgumentException("Skin image is missing");
        List<Candidate> candidates = candidates();
        double[] factors = brightnessFactors == null || brightnessFactors.length == 0
                ? new double[]{1.0} : brightnessFactors.clone();
        for (double factor : factors) {
            if (!Double.isFinite(factor) || factor < 0.15 || factor > 1.75) {
                throw new IllegalArgumentException("Skin palette brightness factors must be finite and between 0.15 and 1.75");
            }
        }
        Map<String, Integer> frequency = new HashMap<>();
        Map<String, Candidate> byId = new HashMap<>();
        for (int y = 0; y < image.getHeight(); y++) {
            for (int x = 0; x < image.getWidth(); x++) {
                int argb = image.getRGB(x, y);
                if ((argb >>> 24) < 32) continue;
                for (double factor : factors) {
                    Candidate selected = nearestCandidate(adjustBrightness(argb, factor), candidates);
                    String id = selected.entry().blockId();
                    frequency.merge(id, 1, Integer::sum);
                    byId.putIfAbsent(id, selected);
                }
            }
        }
        if (frequency.isEmpty()) return whitePalette();

        List<String> allIds = new ArrayList<>(frequency.keySet());
        allIds.sort(Comparator
                .<String>comparingInt(id -> frequency.getOrDefault(id, 0)).reversed()
                .thenComparingInt(id -> byId.get(id).preference())
                .thenComparing(String::compareTo));

        List<String> selectedIds = new ArrayList<>(Math.min(MAX_SKIN_PALETTE, allIds.size()));
        int frequencySlots = Math.min(192, MAX_SKIN_PALETTE);
        selectedIds.addAll(allIds.subList(0, Math.min(frequencySlots, allIds.size())));
        Set<String> selectedSet = new HashSet<>(selectedIds);

        // Preserve rare but visually important shades after the most common 192.
        while (selectedIds.size() < MAX_SKIN_PALETTE && selectedIds.size() < allIds.size()) {
            String bestId = null;
            double bestDistance = -1.0;
            for (String id : allIds) {
                if (selectedSet.contains(id)) continue;
                int color = byId.get(id).entry().argb();
                double closest = Double.POSITIVE_INFINITY;
                for (String selected : selectedIds) {
                    double distance = VoxelColorMath.distanceSquared(color, byId.get(selected).entry().argb());
                    if (distance < closest) closest = distance;
                }
                // A small usage bonus breaks near-equal distance ties without
                // drowning out a distinctive low-frequency highlight colour.
                double usageBonus = Math.min(0.00035, frequency.get(id) * 0.0000008);
                double score = closest + usageBonus;
                if (score > bestDistance) { bestDistance = score; bestId = id; }
            }
            if (bestId == null) break;
            selectedIds.add(bestId);
            selectedSet.add(bestId);
        }

        List<VoxelModel.PaletteEntry> result = new ArrayList<>(selectedIds.size());
        for (String id : selectedIds) result.add(byId.get(id).entry());
        return List.copyOf(result);
    }

    /** For diagnostics and the Studio's palette information. */
    public static int candidateCount() { return candidates().size(); }
    /** Number of candidates matched from actual baked texture pixels rather than map colour alone. */
    public static int textureCandidateCount() { candidates(); return cachedTextureCandidateCount; }

    private static int adjustBrightness(int argb, double factor) {
        int red = adjustChannel((argb >>> 16) & 255, factor);
        int green = adjustChannel((argb >>> 8) & 255, factor);
        int blue = adjustChannel(argb & 255, factor);
        return (argb & 0xFF000000) | (red << 16) | (green << 8) | blue;
    }

    private static int adjustChannel(int channel, double factor) {
        double value = channel / 255.0;
        double linear = value <= 0.04045 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4);
        linear = Math.max(0.0, Math.min(1.0, linear * factor));
        double srgb = linear <= 0.0031308 ? linear * 12.92 : 1.055 * Math.pow(linear, 1.0 / 2.4) - 0.055;
        return (int)Math.round(Math.max(0.0, Math.min(1.0, srgb)) * 255.0);
    }

    private static Candidate nearestCandidate(int argb, List<Candidate> candidates) {
        double[] target = VoxelColorMath.toOklab(argb);
        Candidate best = null;
        double bestDistance = Double.POSITIVE_INFINITY;
        for (Candidate candidate : candidates) {
            double dl = (target[0] - candidate.lab()[0]) * 1.12;
            double da = target[1] - candidate.lab()[1];
            double db = target[2] - candidate.lab()[2];
            double distance = dl * dl + da * da + db * db;
            if (distance < bestDistance - 1.0e-10
                    || (Math.abs(distance - bestDistance) <= 1.0e-10
                    && (best == null || candidate.preference() < best.preference()))) {
                best = candidate;
                bestDistance = distance;
            }
        }
        if (best == null) throw new IllegalStateException("No safe full-cube vanilla blocks were found");
        return best;
    }

    private static List<Candidate> candidates() {
        Minecraft minecraft = Minecraft.getInstance();
        Object currentModelSet = minecraft.getModelManager().getBlockStateModelSet();
        List<Candidate> result = cachedCandidates;
        if (result != null && currentModelSet == cachedModelSet) return result;
        synchronized (MinecraftBlockPalette.class) {
            result = cachedCandidates;
            if (result != null && currentModelSet == cachedModelSet) return result;
            List<Candidate> discovered = new ArrayList<>();
            int texturedCount = 0;
            for (Block block : BuiltInRegistries.BLOCK) {
                Identifier id = BuiltInRegistries.BLOCK.getKey(block);
                if (id == null || !"minecraft".equals(id.getNamespace())) continue;
                String path = id.getPath();
                if (NEVER_USE.contains(path) || path.endsWith("_concrete_powder")) continue;

                BlockState state = block.defaultBlockState();
                if (state.isAir() || state.hasBlockEntity() || !state.getFluidState().isEmpty()) continue;
                if (!state.isCollisionShapeFullBlock(EmptyBlockGetter.INSTANCE, SAMPLE_POS)) continue;

                MapColor mapColor = state.getMapColor(EmptyBlockGetter.INSTANCE, SAMPLE_POS);
                boolean hasMapColor = mapColor != null && mapColor != MapColor.NONE;
                // Some useful vanilla blocks have no meaningful map colour. Their baked
                // texture still provides a real sample; neutral gray is only a temporary
                // fallback for tint-indexed faces and is never accepted by itself.
                int fallbackArgb = hasMapColor
                        ? 0xFF000000 | (mapColor.col & 0xFFFFFF)
                        : 0xFF808080;
                ModelSample sample = sampleModelColor(state, fallbackArgb);
                if (!hasMapColor && !sample.hasTexturePixels()) continue;
                if (sample.hasTexturePixels()) texturedCount++;

                String blockId = id.toString();
                discovered.add(new Candidate(new VoxelModel.PaletteEntry(blockId, sample.argb()),
                        VoxelColorMath.toOklab(sample.argb()), preference(path)));
            }
            discovered.sort(Comparator.comparing(c -> c.entry().blockId()));
            if (discovered.isEmpty()) throw new IllegalStateException("Vanilla block palette is empty");
            if (texturedCount == 0) {
                throw new IllegalStateException("No vanilla block textures could be sampled; refusing to silently fall back to MapColor-only matching.");
            }
            result = List.copyOf(discovered);
            cachedTextureCandidateCount = texturedCount;
            cachedModelSet = currentModelSet;
            cachedCandidates = result;
            return result;
        }
    }

    /**
     * Samples the real baked texture used on each of the six block faces.
     * Multiple quads that share a sprite on one side are sampled only once.
     * Tint-indexed quads use map colour because foliage/grass tint is contextual.
     */
    private static ModelSample sampleModelColor(BlockState state, int fallbackArgb) {
        try {
            BlockStateModel model = Minecraft.getInstance().getModelManager()
                    .getBlockStateModelSet().get(state);
            List<BlockStateModelPart> parts = new ArrayList<>();
            model.collectParts(RandomSource.create(MODEL_RANDOM_SEED), parts);
            List<Integer> faceColors = new ArrayList<>(6);
            boolean hasTexturePixels = false;

            // Unculled quads (getQuads(null)) are used by custom block models and
            // are not returned by any directional query. Capture them once and
            // include them when estimating each visible face, otherwise some
            // perfectly valid full-cube models would be matched from incomplete
            // texture data.
            List<BakedQuad> unculledQuads = new ArrayList<>();
            for (BlockStateModelPart part : parts) {
                unculledQuads.addAll(part.getQuads(null));
            }

            for (Direction direction : Direction.values()) {
                Map<Identifier, SpriteSample> faceSprites = new HashMap<>();
                List<Integer> faceSamples = new ArrayList<>();
                for (BlockStateModelPart part : parts) {
                    for (BakedQuad quad : part.getQuads(direction)) {
                        addQuadTextureSample(quad, fallbackArgb, faceSprites, faceSamples);
                    }
                }
                for (BakedQuad quad : unculledQuads) {
                    addQuadTextureSample(quad, fallbackArgb, faceSprites, faceSamples);
                }
                for (SpriteSample spriteSample : faceSprites.values()) {
                    if (spriteSample.hasVisiblePixels()) {
                        faceSamples.add(spriteSample.argb());
                        hasTexturePixels = true;
                    }
                }
                if (!faceSamples.isEmpty()) faceColors.add(averageOpaqueColors(faceSamples));
            }
            return new ModelSample(faceColors.isEmpty() ? fallbackArgb : averageOpaqueColors(faceColors),
                    hasTexturePixels);
        } catch (RuntimeException exception) {
            // A missing/broken individual resource-pack model should not prevent
            // opening the painter. If every model fails, candidates() reports that
            // texture sampling failed instead of quietly using only MapColor.
            return new ModelSample(fallbackArgb, false);
        }
    }

    private static void addQuadTextureSample(BakedQuad quad, int fallbackArgb,
                                             Map<Identifier, SpriteSample> faceSprites,
                                             List<Integer> faceSamples) {
        BakedQuad.MaterialInfo material = quad.materialInfo();
        if (material.tintIndex() >= 0) {
            faceSamples.add(fallbackArgb);
            return;
        }
        TextureAtlasSprite sprite = material.sprite();
        Identifier spriteId = sprite.contents().name();
        faceSprites.computeIfAbsent(spriteId, ignored -> sampleSprite(sprite, fallbackArgb));
    }

    /**
     * Samples the source PNG for a baked sprite. SpriteContents intentionally does
     * not expose its backing NativeImage in this Minecraft version, so load the
     * same resource through the active ResourceManager instead of reflecting into
     * private fields. ResourceManager honors the active resource-pack stack.
     * For animated sheets, only the first frame (the sprite's logical width/height)
     * is sampled so frame strips do not skew the material colour.
     */
    private static SpriteSample sampleSprite(TextureAtlasSprite sprite, int fallbackArgb) {
        Identifier spriteId = sprite.contents().name();
        Identifier textureId = Identifier.fromNamespaceAndPath(
                spriteId.getNamespace(), "textures/" + spriteId.getPath() + ".png");
        var resource = Minecraft.getInstance().getResourceManager().getResource(textureId);
        if (resource.isEmpty()) return new SpriteSample(fallbackArgb, false);
        try (var input = resource.get().open()) {
            BufferedImage image = ImageIO.read(input);
            if (image == null) return new SpriteSample(fallbackArgb, false);
            int width = Math.min(image.getWidth(), sprite.contents().width());
            int height = Math.min(image.getHeight(), sprite.contents().height());
            if (width <= 0 || height <= 0) return new SpriteSample(fallbackArgb, false);
            int stepX = Math.max(1, (int)Math.ceil(width / 16.0));
            int stepY = Math.max(1, (int)Math.ceil(height / 16.0));
            double red = 0, green = 0, blue = 0, totalWeight = 0;
            for (int y = 0; y < height; y += stepY) {
                for (int x = 0; x < width; x += stepX) {
                    int argb = image.getRGB(x, y);
                    int alpha = (argb >>> 24) & 255;
                    if (alpha < 24) continue;
                    double weight = alpha / 255.0;
                    red += srgbToLinear((argb >>> 16) & 255) * weight;
                    green += srgbToLinear((argb >>> 8) & 255) * weight;
                    blue += srgbToLinear(argb & 255) * weight;
                    totalWeight += weight;
                }
            }
            if (totalWeight <= 0) return new SpriteSample(fallbackArgb, false);
            int argb = 0xFF000000 | (linearToSrgb(red / totalWeight) << 16)
                    | (linearToSrgb(green / totalWeight) << 8) | linearToSrgb(blue / totalWeight);
            return new SpriteSample(argb, true);
        } catch (IOException | RuntimeException exception) {
            // A broken/missing individual resource-pack texture should not abort
            // discovery of every other vanilla block candidate.
            return new SpriteSample(fallbackArgb, false);
        }
    }

    private static int averageOpaqueColors(List<Integer> colors) {
        if (colors.isEmpty()) return 0xFFFFFFFF;
        double red = 0, green = 0, blue = 0;
        for (int color : colors) {
            red += srgbToLinear((color >>> 16) & 255);
            green += srgbToLinear((color >>> 8) & 255);
            blue += srgbToLinear(color & 255);
        }
        double count = colors.size();
        return 0xFF000000 | (linearToSrgb(red / count) << 16)
                | (linearToSrgb(green / count) << 8) | linearToSrgb(blue / count);
    }

    private static double srgbToLinear(int channel) {
        double value = channel / 255.0;
        return value <= 0.04045 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4);
    }

    private static int linearToSrgb(double value) {
        double srgb = value <= 0.0031308 ? 12.92 * value : 1.055 * Math.pow(value, 1.0 / 2.4) - 0.055;
        return (int)Math.round(Math.max(0.0, Math.min(1.0, srgb)) * 255.0);
    }

    private static int preference(String path) {
        if (path.endsWith("_concrete")) return 0;
        if (path.endsWith("_terracotta")) return 1;
        if (path.endsWith("_wool")) return 2;
        if (path.endsWith("_planks")) return 3;
        if (path.endsWith("_bricks")) return 4;
        if (path.endsWith("_log") || path.endsWith("_wood")) return 5;
        if (path.endsWith("_block")) return 6;
        return 10;
    }
}
