package dev.noteclient.voxel.core;

import dev.noteclient.voxel.core.VoxelCamera.Ray;
import dev.noteclient.voxel.core.VoxelRaycaster.Hit;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;

/** Mutable editing document with layer isolation, undo/redo, paint, erase and color-pick. */
public final class VoxelStudioDocument {
    public enum Tool { PAINT, ERASE, PICK }

    private VoxelModel model;
    private int activeLayerId;
    private int activePaletteIndex = 1;
    private Tool tool = Tool.PAINT;
    private final Deque<VoxelModel> undo = new ArrayDeque<>();
    private final Deque<VoxelModel> redo = new ArrayDeque<>();
    private boolean strokeOpen;
    private VoxelModel strokeSnapshot;
    private boolean dirty = true;

    public VoxelStudioDocument(VoxelModel model) {
        this.model = model;
        this.activeLayerId = model.layers().get(0).id();
    }

    public VoxelModel model() { return model; }
    public int activeLayerId() { return activeLayerId; }
    public int activePaletteIndex() { return activePaletteIndex; }
    public Tool tool() { return tool; }
    public boolean dirty() { return dirty; }
    public void markSaved() { dirty = false; }

    public void setTool(Tool tool) { this.tool = tool; }

    public void setActiveLayer(int id) {
        model.layer(id); // validate id
        activeLayerId = id;
    }

    public void setActivePaletteIndex(int index) {
        if (index < 1 || index > model.palette().size()) throw new IllegalArgumentException("Palette index out of range");
        activePaletteIndex = index;
    }

    public void setLayerVisible(int id, boolean visible) {
        checkpoint();
        model.setLayerVisible(id, visible);
        dirty = true;
    }

    public void beginStroke() {
        if (strokeOpen) return;
        strokeOpen = true;
        strokeSnapshot = model.copy();
    }

    public void endStroke() {
        if (!strokeOpen) return;
        strokeOpen = false;
        if (strokeSnapshot != null && !sameContent(strokeSnapshot, model)) {
            pushUndo(strokeSnapshot);
            redo.clear();
            dirty = true;
        }
        strokeSnapshot = null;
    }

    public Hit apply(Ray ray) {
        Hit hit = tool == Tool.PAINT
                ? VoxelRaycaster.pickPaintTarget(model, ray, activeLayerId)
                : VoxelRaycaster.pick(model, ray);
        if (hit == null) return null;
        switch (tool) {
            case PICK -> {
                if (hit.paletteIndex() > 0) activePaletteIndex = hit.paletteIndex();
            }
            case ERASE -> {
                beginStrokeIfNeeded();
                if (model.isOccupied(hit.x(), hit.y(), hit.z())) {
                    model.clearVoxel(hit.x(), hit.y(), hit.z());
                    dirty = true;
                }
            }
            case PAINT -> {
                beginStrokeIfNeeded();
                VoxelModel.Layer layer = model.layer(activeLayerId);
                if (layer.buildToWorld()) {
                    int oldPalette = model.paletteIndexAt(hit.x(), hit.y(), hit.z());
                    if (oldPalette != activePaletteIndex || model.layerAt(hit.x(), hit.y(), hit.z()) != activeLayerId) {
                        model.setVoxel(hit.x(), hit.y(), hit.z(), activePaletteIndex, activeLayerId);
                        dirty = true;
                    }
                }
            }
        }
        return hit;
    }

    public boolean undo() {
        endStroke();
        if (undo.isEmpty()) return false;
        redo.push(model.copy());
        model = undo.pop();
        validateActiveLayer();
        dirty = true;
        return true;
    }

    public boolean redo() {
        endStroke();
        if (redo.isEmpty()) return false;
        undo.push(model.copy());
        model = redo.pop();
        validateActiveLayer();
        dirty = true;
        return true;
    }

    public void replaceModel(VoxelModel newModel) {
        endStroke();
        model = newModel;
        undo.clear();
        redo.clear();
        activeLayerId = newModel.layers().get(0).id();
        activePaletteIndex = 1;
        dirty = true;
    }

    private void beginStrokeIfNeeded() {
        if (!strokeOpen) beginStroke();
    }

    private void checkpoint() {
        endStroke();
        pushUndo(model.copy());
        redo.clear();
    }

    private void pushUndo(VoxelModel snapshot) {
        undo.push(snapshot);
        while (undo.size() > VoxelStudioConfig.UNDO_HISTORY_LIMIT) undo.removeLast();
    }

    private void validateActiveLayer() {
        try { model.layer(activeLayerId); }
        catch (IllegalArgumentException ignored) { activeLayerId = model.layers().get(0).id(); }
        activePaletteIndex = Math.min(activePaletteIndex, model.palette().size());
        if (activePaletteIndex < 1) activePaletteIndex = 1;
    }

    private static boolean sameContent(VoxelModel a, VoxelModel b) {
        if (a.width() != b.width() || a.height() != b.height() || a.depth() != b.depth()) return false;
        return java.util.Arrays.equals(a.copyPaletteIndexes(), b.copyPaletteIndexes())
                && java.util.Arrays.equals(a.copyLayerIndexes(), b.copyLayerIndexes());
    }
}
