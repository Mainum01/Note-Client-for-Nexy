package dev.noteclient.voxel.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Greedy surface mesher. Adjacent exposed faces with the same color/layer/normal
 * are merged into one rectangle. The output is only a render mesh; the server
 * still receives individual voxels because real Minecraft blocks are discrete.
 */
public final class VoxelMeshBuilder {
    public record Vertex(double x, double y, double z) {}
    public record Quad(int axis, int sign, double plane,
                       double u, double v, double width, double height,
                       int paletteIndex, int layerId) {
        /** Returns corners in a stable order. Back-face culling is not assumed. */
        public Vertex[] corners() {
            int uAxis = (axis + 1) % 3;
            int vAxis = (axis + 2) % 3;
            double[] p0 = new double[3];
            p0[axis] = plane;
            p0[uAxis] = u;
            p0[vAxis] = v;
            double[] p1 = p0.clone();
            p1[uAxis] += width;
            double[] p2 = p1.clone();
            p2[vAxis] += height;
            double[] p3 = p0.clone();
            p3[vAxis] += height;
            if (sign < 0) {
                return new Vertex[]{vertex(p0), vertex(p3), vertex(p2), vertex(p1)};
            }
            return new Vertex[]{vertex(p0), vertex(p1), vertex(p2), vertex(p3)};
        }
        private static Vertex vertex(double[] p) { return new Vertex(p[0], p[1], p[2]); }
    }

    private record FaceKey(int paletteIndex, int layerId, int sign) {}

    private VoxelMeshBuilder() {}

    public static List<Quad> build(VoxelModel model) {
        List<Quad> quads = new ArrayList<>();
        int[] dims = {model.width(), model.height(), model.depth()};

        for (int axis = 0; axis < 3; axis++) {
            int uAxis = (axis + 1) % 3;
            int vAxis = (axis + 2) % 3;
            int uSize = dims[uAxis];
            int vSize = dims[vAxis];
            FaceKey[] mask = new FaceKey[uSize * vSize];

            for (int slice = -1; slice < dims[axis]; slice++) {
                // Build the face mask on the plane between slice and slice+1.
                for (int v = 0; v < vSize; v++) {
                    for (int u = 0; u < uSize; u++) {
                        int[] a = new int[3];
                        int[] b = new int[3];
                        a[axis] = slice;
                        b[axis] = slice + 1;
                        a[uAxis] = b[uAxis] = u;
                        a[vAxis] = b[vAxis] = v;
                        FaceKey left = getVisibleCell(model, a);
                        FaceKey right = getVisibleCell(model, b);
                        FaceKey face = null;
                        if (left != null && right == null) face = new FaceKey(left.paletteIndex, left.layerId, 1);
                        else if (left == null && right != null) face = new FaceKey(right.paletteIndex, right.layerId, -1);
                        mask[u + uSize * v] = face;
                    }
                }

                // Greedily merge equal keys into rectangles.
                for (int v = 0; v < vSize; v++) {
                    for (int u = 0; u < uSize;) {
                        FaceKey key = mask[u + uSize * v];
                        if (key == null) {
                            u++;
                            continue;
                        }

                        int width = 1;
                        while (u + width < uSize && key.equals(mask[u + width + uSize * v])) width++;

                        int height = 1;
                        outer:
                        while (v + height < vSize) {
                            for (int k = 0; k < width; k++) {
                                if (!key.equals(mask[u + k + uSize * (v + height)])) break outer;
                            }
                            height++;
                        }

                        quads.add(new Quad(axis, key.sign, slice + 1.0, u, v,
                                width, height, key.paletteIndex, key.layerId));
                        if (quads.size() > VoxelStudioConfig.PREVIEW_MAX_FACES) {
                            throw new IllegalStateException("Preview mesh exceeds face safety limit");
                        }

                        // Clear the consumed mask rectangle.
                        for (int dv = 0; dv < height; dv++) {
                            for (int du = 0; du < width; du++) {
                                mask[u + du + uSize * (v + dv)] = null;
                            }
                        }
                        u += width;
                    }
                }
            }
        }
        return List.copyOf(quads);
    }

    private static FaceKey getVisibleCell(VoxelModel model, int[] pos) {
        int x = pos[0], y = pos[1], z = pos[2];
        if (x < 0 || x >= model.width() || y < 0 || y >= model.height() || z < 0 || z >= model.depth()) return null;
        int paletteIndex = model.paletteIndexAt(x, y, z);
        if (paletteIndex == 0) return null;
        int layerId = model.layerAt(x, y, z);
        if (!model.layerVisible(layerId)) return null;
        return new FaceKey(paletteIndex, layerId, 0);
    }
}
