package dev.noteclient.voxel.client;

import dev.noteclient.voxel.core.SkinVoxelizer;
import dev.noteclient.voxel.core.VoxelModel;
import dev.noteclient.voxel.core.VoxelModelCodec;
import dev.noteclient.voxel.core.VoxelStudioConfig;
import net.fabricmc.loader.api.FabricLoader;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.util.Iterator;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Profile-local skins directory, recursive scanner, validator, importer and atomic exporter. */
public final class VoxelSkinLibrary {
    public enum Kind { PNG_SKIN, VOXEL_TEMPLATE }
    public record Entry(String name, String relativePath, Path path, Kind kind, long sizeBytes) {}

    private static final ExecutorService IO = Executors.newFixedThreadPool(2, runnable -> {
        Thread thread = new Thread(runnable, "NoteClient-VoxelSkinIO");
        thread.setDaemon(true);
        return thread;
    });

    private VoxelSkinLibrary() {}

    public static Path root() {
        return FabricLoader.getInstance().getGameDir().resolve("noteclient").resolve("skins").toAbsolutePath().normalize();
    }

    public static CompletableFuture<Path> ensureDirectory() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Files.createDirectories(root());
                return root();
            } catch (IOException exception) {
                throw new java.util.concurrent.CompletionException(exception);
            }
        }, IO);
    }

    public static CompletableFuture<List<Entry>> scanAsync() {
        return CompletableFuture.supplyAsync(() -> {
            Path root = root();
            try {
                Files.createDirectories(root);
                List<Entry> entries = new ArrayList<>();
                try (var stream = Files.walk(root, VoxelStudioConfig.MAX_SKIN_SCAN_DEPTH)) {
                    stream.filter(path -> !path.equals(root))
                            .filter(path -> Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS))
                            .filter(path -> !Files.isSymbolicLink(path))
                            .filter(path -> {
                                String name = path.getFileName().toString().toLowerCase(Locale.ROOT);
                                return name.endsWith(".png") || name.endsWith(".voxel.json");
                            })
                            .limit(2048)
                            .forEach(path -> {
                                try {
                                    long size = Files.size(path);
                                    if (size < 1 || size > VoxelStudioConfig.MAX_SKIN_FILE_BYTES) return;
                                    String lower = path.getFileName().toString().toLowerCase(Locale.ROOT);
                                    Kind kind = lower.endsWith(".png") ? Kind.PNG_SKIN : Kind.VOXEL_TEMPLATE;
                                    entries.add(new Entry(stripExtension(path.getFileName().toString()),
                                            root.relativize(path).toString().replace('\\','/'), path, kind, size));
                                } catch (IOException ignored) { }
                            });
                }
                entries.sort(Comparator.comparing(Entry::relativePath, String.CASE_INSENSITIVE_ORDER));
                return List.copyOf(entries);
            } catch (IOException exception) {
                throw new java.util.concurrent.CompletionException(exception);
            }
        }, IO);
    }

    public static CompletableFuture<VoxelModel> loadAsync(Entry entry) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Path safe = safeEntry(entry.path());
                if (Files.size(safe) > VoxelStudioConfig.MAX_SKIN_FILE_BYTES) throw new IOException("Skin file exceeds size limit");
                if (entry.kind() == Kind.VOXEL_TEMPLATE) {
                    String json = Files.readString(safe);
                    return VoxelModelCodec.fromJson(json);
                }
                BufferedImage image = readSkinImage(safe);
                return SkinVoxelizer.fromSkin(image, entry.name(), guessSlim(image), MinecraftBlockPalette.paletteForSkin(image));
            } catch (IOException | IllegalArgumentException exception) {
                throw new java.util.concurrent.CompletionException(exception);
            }
        }, IO);
    }

    public static CompletableFuture<Path> saveAsync(VoxelModel model, String requestedName) {
        return CompletableFuture.supplyAsync(() -> {
            String fileName = sanitizeFileName(requestedName == null ? model.name() : requestedName) + ".voxel.json";
            Path destination = root().resolve(fileName).normalize();
            try {
                Files.createDirectories(root());
                if (!destination.startsWith(root())) throw new IOException("Invalid skin save path");
                Path temporary = Files.createTempFile(root(), ".voxel-save-", ".tmp");
                try {
                    Files.writeString(temporary, VoxelModelCodec.toJson(model));
                    try {
                        Files.move(temporary, destination, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                    } catch (java.nio.file.AtomicMoveNotSupportedException unsupported) {
                        Files.move(temporary, destination, StandardCopyOption.REPLACE_EXISTING);
                    }
                } catch (IOException | RuntimeException failure) {
                    try {
                        Files.deleteIfExists(temporary);
                    } catch (IOException cleanupFailure) {
                        failure.addSuppressed(cleanupFailure);
                    }
                    throw new java.util.concurrent.CompletionException(failure);
                }
                return destination;
            } catch (Throwable error) {
                throw new java.util.concurrent.CompletionException(error);
            }
        }, IO);
    }

    public static void shutdown() { IO.shutdown(); }

    /** Reads only supported skin dimensions before allocating the decoded pixels. */
    private static BufferedImage readSkinImage(Path path) throws IOException {
        try (ImageInputStream input = ImageIO.createImageInputStream(path.toFile())) {
            if (input == null) throw new IOException("Could not open skin image");
            Iterator<ImageReader> readers = ImageIO.getImageReaders(input);
            if (!readers.hasNext()) throw new IOException("File is not a supported PNG image");
            ImageReader reader = readers.next();
            try {
                if (!"png".equalsIgnoreCase(reader.getFormatName())) {
                    throw new IOException("Skin file must be a PNG image");
                }
                reader.setInput(input, true, true);
                int width = reader.getWidth(0);
                int height = reader.getHeight(0);
                if (width != 64 || (height != 64 && height != 32)) {
                    throw new IOException("Skin PNG must be exactly 64x64 or 64x32 pixels");
                }
                BufferedImage image = reader.read(0);
                if (image == null) throw new IOException("Skin image could not be decoded");
                return image;
            } finally {
                reader.dispose();
            }
        }
    }

    private static Path safeEntry(Path path) throws IOException {
        Path root = root().toRealPath();
        Path real = path.toRealPath(LinkOption.NOFOLLOW_LINKS);
        if (!real.startsWith(root) || Files.isSymbolicLink(path)) throw new IOException("Skin path escaped library folder");
        return real;
    }

    private static String sanitizeFileName(String input) {
        String value = input == null ? "skin" : input.trim();
        value = value.replaceAll("[^A-Za-z0-9._ -]", "_").replaceAll("\\s+", "_");
        value = value.replaceAll("\\.+$", "");
        if (value.isBlank()) value = "skin";
        return value.substring(0, Math.min(48, value.length()));
    }

    private static String stripExtension(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".voxel.json")) return name.substring(0, name.length()-11);
        if (lower.endsWith(".png")) return name.substring(0, name.length()-4);
        return name;
    }

    private static boolean guessSlim(BufferedImage image) {
        // A PNG alone does not encode the arm model reliably. This conservative default
        // can be changed in the studio's model properties after import.
        return false;
    }
}
