package dev.noteclient.voxel.core;

/** 360-degree orbit camera and perspective ray construction for the studio. */
public final class VoxelCamera {
    public record Vec3(double x, double y, double z) {
        public Vec3 add(Vec3 b) { return new Vec3(x + b.x, y + b.y, z + b.z); }
        public Vec3 subtract(Vec3 b) { return new Vec3(x - b.x, y - b.y, z - b.z); }
        public Vec3 multiply(double s) { return new Vec3(x * s, y * s, z * s); }
        public double dot(Vec3 b) { return x * b.x + y * b.y + z * b.z; }
        public Vec3 cross(Vec3 b) { return new Vec3(y * b.z - z * b.y, z * b.x - x * b.z, x * b.y - y * b.x); }
        public double length() { return Math.sqrt(dot(this)); }
        public Vec3 normalized() {
            double len = length();
            return len < 1.0e-10 ? new Vec3(0, 0, 1) : multiply(1.0 / len);
        }
    }

    public record Ray(Vec3 origin, Vec3 direction) {}
    public record Projection(double x, double y, double depth, boolean visible) {}

    private double yawRadians = Math.toRadians(30);
    private double pitchRadians = Math.toRadians(12);
    private double distance = 48.0;
    private double panX;
    private double panY;
    private double fovRadians = Math.toRadians(VoxelStudioConfig.CAMERA_FOV_DEGREES);

    public void orbit(double deltaX, double deltaY) {
        yawRadians = wrap(yawRadians - deltaX * 0.008);
        pitchRadians = clamp(pitchRadians + deltaY * 0.008,
                VoxelStudioConfig.CAMERA_MIN_PITCH, VoxelStudioConfig.CAMERA_MAX_PITCH);
    }

    public void zoom(double wheelSteps) {
        distance = clamp(distance * Math.pow(0.90, wheelSteps),
                VoxelStudioConfig.CAMERA_MIN_DISTANCE, VoxelStudioConfig.CAMERA_MAX_DISTANCE);
    }

    public void pan(double deltaX, double deltaY) {
        panX += deltaX * distance * 0.003;
        panY -= deltaY * distance * 0.003;
    }

    public void reset() {
        yawRadians = Math.toRadians(30);
        pitchRadians = Math.toRadians(12);
        distance = 48;
        panX = 0;
        panY = 0;
    }

    public Vec3 target(VoxelModel model) {
        return new Vec3(model.width() * 0.5 + panX,
                model.height() * 0.5 + panY, model.depth() * 0.5);
    }

    public Vec3 position(VoxelModel model) {
        Vec3 target = target(model);
        double cp = Math.cos(pitchRadians);
        Vec3 offset = new Vec3(Math.sin(yawRadians) * cp,
                Math.sin(pitchRadians), Math.cos(yawRadians) * cp).multiply(distance);
        return target.add(offset);
    }

    public Vec3 forward(VoxelModel model) {
        return target(model).subtract(position(model)).normalized();
    }

    public Vec3 right(VoxelModel model) {
        return forward(model).cross(new Vec3(0, 1, 0)).normalized();
    }

    public Vec3 up(VoxelModel model) {
        return right(model).cross(forward(model)).normalized();
    }

    public Ray rayFromScreen(VoxelModel model, double mouseX, double mouseY,
                             double viewportX, double viewportY, double viewportWidth, double viewportHeight) {
        if (viewportWidth <= 0 || viewportHeight <= 0) throw new IllegalArgumentException("Invalid viewport");
        double ndcX = ((mouseX - viewportX) / viewportWidth) * 2.0 - 1.0;
        double ndcY = 1.0 - ((mouseY - viewportY) / viewportHeight) * 2.0;
        double aspect = viewportWidth / viewportHeight;
        double halfHeight = Math.tan(fovRadians * 0.5);
        Vec3 f = forward(model);
        Vec3 r = right(model);
        Vec3 u = up(model);
        Vec3 direction = f.add(r.multiply(ndcX * aspect * halfHeight))
                .add(u.multiply(ndcY * halfHeight)).normalized();
        return new Ray(position(model), direction);
    }

    public Projection project(VoxelModel model, Vec3 point, int viewportWidth, int viewportHeight) {
        Vec3 camera = position(model);
        Vec3 relative = point.subtract(camera);
        Vec3 f = forward(model), r = right(model), u = up(model);
        double depth = relative.dot(f);
        if (depth <= 0.01) return new Projection(0, 0, depth, false);
        double aspect = (double) viewportWidth / Math.max(1, viewportHeight);
        double focal = 0.5 * viewportHeight / Math.tan(fovRadians * 0.5);
        double px = viewportWidth * 0.5 + relative.dot(r) * focal / depth;
        double py = viewportHeight * 0.5 - relative.dot(u) * focal / depth;
        return new Projection(px, py, depth, Double.isFinite(px) && Double.isFinite(py));
    }

    public VoxelCamera copy() {
        VoxelCamera copy = new VoxelCamera();
        copy.yawRadians = yawRadians;
        copy.pitchRadians = pitchRadians;
        copy.distance = distance;
        copy.panX = panX;
        copy.panY = panY;
        copy.fovRadians = fovRadians;
        return copy;
    }

    public double distance() { return distance; }
    public double yawRadians() { return yawRadians; }
    public double pitchRadians() { return pitchRadians; }

    private static double wrap(double radians) {
        double tau = Math.PI * 2.0;
        radians %= tau;
        return radians < 0 ? radians + tau : radians;
    }
    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
