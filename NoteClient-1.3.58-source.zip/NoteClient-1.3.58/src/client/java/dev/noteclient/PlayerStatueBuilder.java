package dev.noteclient;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.authlib.properties.Property;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.EmptyBlockGetter;
import dev.noteclient.voxel.client.MinecraftBlockPalette;
import dev.noteclient.voxel.core.VoxelColorMath;
import dev.noteclient.voxel.core.VoxelModel;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Comparator;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.UUID;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.stream.Stream;
import java.util.concurrent.CompletableFuture;
import javax.imageio.ImageIO;

/** Public Java-skin lookup and a six-face, layered 3D Minecraft player-model statue builder. */
public final class PlayerStatueBuilder {
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(8))
            .followRedirects(HttpClient.Redirect.NEVER)
            .build();
    private static final int MODEL_WIDTH = 16;
    private static final int MODEL_HEIGHT = 32;
    // Integrated-server writes and remote interactions use the same user-selected
    // build budget. Remote acknowledgements still bound the pending queue.
    private static final int SINGLEPLAYER_VERIFY_DELAY_TICKS = 3;
    // Remote statue cells get one normal placement and one conditional retry.
    // The retry is skipped as soon as the desired block is visible at the target.
    private static final int PLACEMENT_ATTEMPTS_PER_CELL = 2;
    private static final int INITIAL_PENDING_LIMIT = 6;
    private static final int MAX_PENDING_LIMIT = 128;
    private static final int UNKNOWN_PING_CONFIRM_GRACE_TICKS = 2;
    private static final int MIN_CONFIRM_GRACE_TICKS = 1;
    private static final int MAX_CONFIRM_GRACE_TICKS = 6;
    private static final int MIN_PLACEMENT_INTERVAL_TICKS = 1;
    private static final int MAX_PLACEMENT_INTERVAL_TICKS = 6;
    // Hazardous, falling, or non-placeable materials are not accepted in models.
    private static final Set<String> UNSAFE_VOXEL_MATERIAL_IDS = Set.of(
            "tnt", "respawn_anchor", "command_block", "chain_command_block",
            "repeating_command_block", "structure_block", "jigsaw", "barrier",
            "light", "moving_piston", "piston_head", "end_gateway", "end_portal",
            "nether_portal", "spawner", "trial_spawner", "vault", "magma_block",
            "sand", "red_sand", "gravel", "suspicious_sand", "suspicious_gravel",
            "anvil", "chipped_anvil", "damaged_anvil", "dragon_egg", "bedrock"
    );
    // These blocks open a menu or consume a right-click instead of acting as a
    // normal placement face. Workstation blocks are included even when they do
    // not own a block entity (e.g. crafting/cartography/smithing tables).
    private static final Set<String> MENU_OPENING_ANCHOR_BLOCKS = Set.of(
            "crafting_table", "cartography_table", "smithing_table", "fletching_table",
            "loom", "stonecutter", "grindstone", "anvil", "chipped_anvil", "damaged_anvil",
            "enchanting_table", "lectern", "furnace", "blast_furnace", "smoker",
            "brewing_stand", "crafter", "chest", "trapped_chest", "ender_chest", "barrel",
            "dispenser", "dropper", "hopper", "jukebox", "beacon"
    );
    private static final int MAX_STATUE_REMOVAL_RETRIES = 4;
    private static final int STATUE_REMOVAL_CONFIRM_GRACE_TICKS = 2;
    // Creative-mode statue cleanup is batched. Waiting for one round-trip per
    // block made a large statue take minutes to remove on a high-ping server.
    private static final int MAX_PENDING_STATUE_REMOVALS = 128;
    private static final int MIN_ACK_TIMEOUT_TICKS = 8;
    private static final int MAX_ACK_TIMEOUT_TICKS = 80;
    private static final int INTEGRITY_SCAN_PER_TICK = 512;

    // Count-only preview palette. Actual statue materials are selected from the
    // complete texture-sampled vanilla full-cube palette when Build is pressed.
    // Resolve by registry ID instead of a generated Blocks field. Newer Minecraft
    // mappings do not expose every registered block as a named Blocks constant.
    private static final Block COUNT_PREVIEW_BLOCK = BuiltInRegistries.BLOCK
            .getOptional(Identifier.parse("minecraft:white_concrete"))
            .orElse(Blocks.CALCITE);
    private static final List<PaletteColor> COUNT_PALETTE = List.of(
            new PaletteColor(COUNT_PREVIEW_BLOCK, 0xFFE8E8E8,
                    VoxelColorMath.toOklab(0xFFE8E8E8), 0));
    private static final int MAX_TRACKED_STATUES = 16;
    private static final Deque<StatueJob> undoHistory = new ArrayDeque<>();


    private static volatile String status = "Load a Java username, PNG file, or Minecraft preset skin.";
    private static volatile String loadedUsername = "";
    private static volatile SkinData loadedSkin;
    private static volatile boolean loading;
    private static volatile long lookupGeneration;
    private static volatile Path lastSkinFile;
    private static StatueJob activeBuild;

    private PlayerStatueBuilder() {}

    public static String status() { return status; }
    public static String loadedUsername() { return loadedUsername; }
    public static boolean isLoading() { return loading; }
    public static boolean hasSkin() { return loadedSkin != null; }

    /** Stable-enough change token for companion screens waiting on an async skin lookup. */
    public static int loadedSkinToken() {
        SkinData skin = loadedSkin;
        return skin == null ? 0 : System.identityHashCode(skin);
    }

    public static boolean loadedSkinSlim() {
        SkinData skin = loadedSkin;
        return skin != null && skin.slim;
    }

    /** Returns a defensive copy so editor workers never read the builder's mutable image. */
    public static BufferedImage copyLoadedSkinImage() {
        SkinData skin = loadedSkin;
        if (skin == null || skin.sourceImage == null) return null;
        BufferedImage copy = new BufferedImage(skin.sourceImage.getWidth(), skin.sourceImage.getHeight(), BufferedImage.TYPE_INT_ARGB);
        var graphics = copy.createGraphics();
        graphics.drawImage(skin.sourceImage, 0, 0, null);
        graphics.dispose();
        return copy;
    }
    public static boolean isBuilding() {
        return activeBuild != null && !activeBuild.completed && !activeBuild.removeRequested;
    }
    public static boolean hasTrackedStatue() { return activeBuild != null || !undoHistory.isEmpty(); }
    public static boolean isPaused() { return activeBuild != null && activeBuild.paused; }
    public static boolean isRemoving() { return activeBuild != null && activeBuild.removeRequested && !activeBuild.completed; }
    public static int progressTotal() { return activeBuild == null ? 0 : activeBuild.blocks.size(); }
    public static int progressCount() {
        if (activeBuild == null) return 0;
        return activeBuild.removeRequested ? activeBuild.removedCount
                : activeBuild.confirmedPositions.size();
    }
    public static int progressPercent() {
        if (activeBuild == null || activeBuild.blocks.isEmpty()) return 0;
        if (activeBuild.removeRequested) {
            return Math.max(0, Math.min(100,
                    activeBuild.removedCount * 100 / Math.max(1, activeBuild.removalInitialCount)));
        }
        return Math.max(0, Math.min(100,
                activeBuild.confirmedPositions.size() * 100 / activeBuild.blocks.size()));
    }
    public static int repairPass() { return activeBuild == null ? 0 : activeBuild.repairPass; }
    public static int blockedCount() {
        return activeBuild == null ? 0 : activeBuild.blockedPositions.size();
    }
    public static String progressPhase() {
        StatueJob job = activeBuild;
        if (job == null) return "";
        if (job.stopRequested) return "STOPPING";
        if (job.paused) return "PAUSED";
        if (job.removeRequested) return "REMOVING";
        if (job.awaitingReach) return "WAITING FOR REACH";
        if (job.awaitingChanges) return "WAITING FOR CELLS";
        if (job.completed) return job.blockedPositions.isEmpty() ? "COMPLETE" : "PARTIAL";
        if (job.verifying) return "VERIFYING";
        return job.repairPass > 0 ? "REPAIR " + job.repairPass : "BUILDING";
    }
    public static String progressDetail() {
        StatueJob job = activeBuild;
        if (job == null) return "";
        if (job.stopRequested) return "No new placements • waiting for " + job.pending.size()
                + " sent placement(s) and " + job.integratedBatchesInFlight + " local batch(es) to settle";
        if (job.paused) return "P resume • R retry • O undo newest";
        if (job.removeRequested) return "Fast batched cleanup • " + job.pendingRemovals.size()
                + " breaks awaiting server confirmation";
        if (job.awaitingReach) return "Move closer/higher, or request /reach 100 if the server allows it";
        if (job.awaitingChanges) return "" + job.blockedPositions.size()
                + " occupied cells • clear them and NoteClient will automatically resume";
        if (job.completed) return job.blockedPositions.isEmpty()
                ? "P pause • R verify/repair • O undo newest"
                : job.blockedPositions.size() + " occupied cells left untouched • clear them, then press R";
        int ping = job.lastPingMs;
        String pass = job.repairPass == 0 ? "First pass" : "Repair " + job.repairPass;
        String queue = job.maxInFlight > 0
                ? " • confirmed queue " + job.pending.size() + "/" + job.maxInFlight : "";
        String misses = job.repairPass > 0
                ? " • last misses " + Math.round(job.lastMissingRatio * 100) + "%" : "";
        return pass + (job.integratedSingleplayer ? " • local server batch " + NoteClientConfig.buildActionsPerTick() + "/tick"
                : " • server pipeline " + job.placementsPerTick + "/tick • up to 2 tries/cell")
                + queue + misses + (job.blockedPositions.isEmpty() ? ""
                : " • " + job.blockedPositions.size() + " occupied cells")
                + (ping >= 0 ? " • " + ping + "ms" : "")
                + " • P pause • R retry • O undo newest";
    }

    /** Creates the local PNG import folder. */
    public static void initialize() {
        try {
            Files.createDirectories(skinsFolder());
        } catch (IOException exception) {
            status = "Could not create skins folder: " + exception.getMessage();
        }
    }

    /** Modrinth keeps each profile's game directory separate, so this is profile-local. */
    public static Path skinsFolder() {
        return FabricLoader.getInstance().getGameDir().resolve("noteclient").resolve("skins");
    }

    /** Lists PNG files recursively so users can organize skins into subfolders. */
    public static List<Path> listSkinFiles() {
        try {
            Files.createDirectories(skinsFolder());
            try (Stream<Path> stream = Files.walk(skinsFolder(), 8)) {
                return stream.filter(Files::isRegularFile)
                        .filter(path -> path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png"))
                        .sorted(Comparator.comparing(path -> skinsFolder().relativize(path).toString()
                                .replace('\\', '/').toLowerCase(Locale.ROOT)))
                        .toList();
            }
        } catch (IOException exception) {
            status = "Could not scan skins folder: " + exception.getMessage();
            return List.of();
        }
    }

    /** The nine built-in character skins shipped in the vanilla Java client. */
    public static List<String> defaultSkinNames() {
        return List.of("Steve", "Alex", "Sunny", "Efe", "Zuri", "Noor", "Ari", "Makena", "Kai");
    }

    public static boolean defaultSkinUsesSlimArms(String name) {
        return name != null && List.of("alex", "efe", "makena", "noor")
                .contains(name.toLowerCase(Locale.ROOT));
    }

    public static String skinSourceName() {
        SkinData skin = loadedSkin;
        return skin == null ? "" : skin.sourceName;
    }

    /** Online players currently listed by the connected server. */
    public record OnlinePlayer(String username, UUID id, int latencyMs, String textureProperty) {}

    public static List<OnlinePlayer> onlinePlayers(Minecraft client) {
        if (client == null || client.getConnection() == null) return List.of();
        List<OnlinePlayer> result = new ArrayList<>();
        for (PlayerInfo info : client.getConnection().getOnlinePlayers()) {
            if (info == null || info.getProfile() == null) continue;
            // Minecraft 26.2 ships the newer Authlib profile/property accessors.
            // GameProfile and Property expose record-style accessors (name/id/properties/value)
            // rather than the legacy JavaBean getName/getId/getProperties/getValue methods.
            var profile = info.getProfile();
            String username = profile.name();
            UUID id = profile.id();
            if (username == null || username.isBlank() || id == null) continue;
            String textureProperty = profile.properties().get("textures").stream()
                    .map(Property::value)
                    .filter(value -> value != null && !value.isBlank())
                    .findFirst().orElse(null);
            result.add(new OnlinePlayer(username, id, Math.max(0, info.getLatency()), textureProperty));
        }
        result.sort(Comparator.comparing(OnlinePlayer::username, String.CASE_INSENSITIVE_ORDER));
        return List.copyOf(result);
    }

    /**
     * Loads an online player's skin using the UUID and texture property already
     * supplied in the server player list. The UUID avoids resolving the name to a
     * possibly different account. The server-list profile's texture property is preferred so a
     * server-supplied skin can work too; a Mojang lookup is the fallback.
     */
    public static void lookupOnlinePlayer(Minecraft client, UUID playerId, String username,
                                          String serverTextureProperty) {
        if (client == null || playerId == null || username == null || username.isBlank()) return;
        long generation = ++lookupGeneration;
        loading = true;
        loadedSkin = null;
        loadedUsername = username;
        status = "Reading the server-listed skin for " + username + "…";
        CompletableFuture.supplyAsync(() -> {
            try {
                if (serverTextureProperty != null && !serverTextureProperty.isBlank()) {
                    try {
                        return fetchSkinFromTextureProperty(serverTextureProperty, username);
                    } catch (Exception ignored) {
                        // A server may include a malformed or unsupported property;
                        // use the official profile lookup as a safe fallback.
                    }
                }
                return fetchSkinById(playerId.toString().replace("-", ""), username);
            } catch (Exception exception) {
                throw new RuntimeException(exception.getMessage() == null
                        ? exception.getClass().getSimpleName() : exception.getMessage(), exception);
            }
        }).whenComplete((skin, error) -> client.execute(() -> {
            if (generation != lookupGeneration) return;
            loading = false;
            if (error != null || skin == null) {
                loadedSkin = null;
                Throwable cause = error;
                while (cause != null && cause.getCause() != null) cause = cause.getCause();
                String reason = cause == null || cause.getMessage() == null
                        ? "unknown skin lookup error" : cause.getMessage();
                status = "Could not read the skin for " + username + ": " + reason
                        + ". This server may use an offline/custom skin; try importing its PNG.";
                NoteClientHud.warn(status);
                return;
            }
            loadedSkin = skin;
            loadedUsername = username;
            lastSkinFile = null;
            status = "Loaded the server-listed skin for " + username + " • "
                    + (skin.slim ? "slim" : "classic") + " arms • "
                    + skin.blockCount + " statue blocks planned.";
            NoteClientHud.show("Loaded the server-listed skin for " + username + ".");
        }));
    }

    public static void lookupSelf(Minecraft client) {
        if (client == null || client.getUser() == null || client.getUser().getName() == null
                || client.getUser().getName().isBlank()) {
            status = "Your launcher account has no Java username. Use a PNG skin from the skins folder instead.";
            NoteClientHud.warn(status);
            return;
        }
        lookup(client, client.getUser().getName());
    }

    public static void loadNextSkinFile(Minecraft client) {
        List<Path> files = listSkinFiles();
        if (files.isEmpty()) {
            NoteClientHud.warn("No PNG skins found. Add 64×64 or 64×32 PNG files to " + skinsFolder());
            return;
        }
        int current = lastSkinFile == null ? -1 : files.indexOf(lastSkinFile);
        loadSkinFile(client, files.get(current < 0 ? 0 : (current + 1) % files.size()));
    }

    public static void loadPreviousSkinFile(Minecraft client) {
        List<Path> files = listSkinFiles();
        if (files.isEmpty()) {
            NoteClientHud.warn("No PNG skins found. Add 64×64 or 64×32 PNG files to " + skinsFolder());
            return;
        }
        int current = lastSkinFile == null ? -1 : files.indexOf(lastSkinFile);
        loadSkinFile(client, files.get(current < 0 ? files.size() - 1
                : Math.floorMod(current - 1, files.size())));
    }

    /** Loads one selected PNG from the profile-local NoteClient skin library. */
    public static void loadSkinFile(Minecraft client, Path requestedFile) {
        if (client == null || requestedFile == null) return;
        Path root = skinsFolder().toAbsolutePath().normalize();
        Path file = requestedFile.toAbsolutePath().normalize();
        if (!file.startsWith(root) || !Files.isRegularFile(file)
                || !file.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png")) {
            NoteClientHud.warn("That is not a PNG inside the NoteClient skins folder.");
            return;
        }

        long generation = ++lookupGeneration;
        loading = true;
        loadedSkin = null;
        status = "Loading PNG skin " + root.relativize(file) + "…";
        CompletableFuture.supplyAsync(() -> {
            try {
                BufferedImage raw = ImageIO.read(file.toFile());
                if (raw == null) throw new IllegalArgumentException("Could not read " + file.getFileName() + " as a PNG skin.");
                BufferedImage normalized = normalizeSkinImage(raw);
                boolean slim = file.getFileName().toString().toLowerCase(Locale.ROOT).contains("slim");
                String displayName = root.relativize(file).toString().replace('\\', '/');
                SkinData skin = createSkinData(displayName, normalized, slim, true, displayName);
                return new LocalSkinResult(file, skin);
            } catch (Exception exception) {
                throw new RuntimeException(exception.getMessage() == null
                        ? exception.getClass().getSimpleName() : exception.getMessage(), exception);
            }
        }).whenComplete((result, error) -> client.execute(() -> {
            if (generation != lookupGeneration) return;
            loading = false;
            if (error != null || result == null) {
                Throwable cause = error;
                while (cause != null && cause.getCause() != null) cause = cause.getCause();
                String reason = cause == null || cause.getMessage() == null
                        ? "unknown PNG loading error" : cause.getMessage();
                status = "Local skin load failed: " + reason;
                NoteClientHud.warn(status);
                return;
            }
            lastSkinFile = result.path;
            loadedSkin = result.skin;
            loadedUsername = result.skin.username;
            status = "Loaded local PNG " + result.skin.sourceName + " • "
                    + (result.skin.slim ? "slim" : "classic") + " arms • "
                    + result.skin.blockCount + " statue blocks planned.";
            NoteClientHud.show("Loaded skin file " + result.skin.sourceName + ".");
        }));
    }

    /** Loads a built-in vanilla skin texture directly from the active resource manager. */
    public static void loadDefaultSkin(Minecraft client, String requestedName) {
        if (requestedName == null) return;
        String name = defaultSkinNames().stream()
                .filter(value -> value.equalsIgnoreCase(requestedName))
                .findFirst().orElse(null);
        if (name == null) {
            NoteClientHud.warn("Unknown Minecraft preset skin: " + requestedName);
            return;
        }
        loadDefaultSkin(client, name, defaultSkinUsesSlimArms(name));
    }

    private static void loadDefaultSkin(Minecraft client, String name, boolean slim) {
        if (client == null || name == null) return;
        String model = slim ? "slim" : "wide";
        Identifier texture = Identifier.fromNamespaceAndPath("minecraft",
                "textures/entity/player/" + model + "/" + name.toLowerCase(Locale.ROOT) + ".png");
        try (var input = client.getResourceManager().getResource(texture)
                .orElseThrow(() -> new IOException("Vanilla skin texture was not found: " + texture)).open()) {
            BufferedImage image = ImageIO.read(input);
            if (image == null) throw new IOException("Vanilla skin texture could not be decoded: " + texture);
            BufferedImage normalized = normalizeSkinImage(image);
            loadedSkin = createSkinData(name, normalized, slim, false,
                    "Minecraft preset • " + name);
            loadedUsername = name;
            loading = false;
            lookupGeneration++;
            lastSkinFile = null;
            status = "Loaded Minecraft preset " + name + " • "
                    + (slim ? "slim" : "classic") + " arms • "
                    + loadedSkin.blockCount + " statue blocks planned.";
            NoteClientHud.show("Loaded Minecraft preset skin " + name + ".");
        } catch (Exception exception) {
            loadedSkin = null;
            status = "Could not load Minecraft preset " + name + ": " + exception.getMessage();
            NoteClientHud.warn(status);
        }
    }

    private static BufferedImage normalizeSkinImage(BufferedImage source) {
        int width = source.getWidth();
        int height = source.getHeight();
        if (width < 64 || width % 64 != 0 || (height != width && height * 2 != width)) {
            throw new IllegalArgumentException("Unsupported PNG size " + width + "×" + height
                    + ". Use 64×64, legacy 64×32, or an evenly scaled version such as 128×128.");
        }
        int targetHeight = height == width ? 64 : 32;
        BufferedImage normalized = new BufferedImage(64, targetHeight, BufferedImage.TYPE_INT_ARGB);
        var graphics = normalized.createGraphics();
        graphics.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION,
                java.awt.RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        graphics.drawImage(source, 0, 0, 64, targetHeight, null);
        graphics.dispose();
        return targetHeight == 32 ? expandLegacySkin(normalized) : normalized;
    }

    public static int previewBasePixel(int x, int y) {
        SkinData skin = loadedSkin;
        if (skin == null || x < 0 || x >= MODEL_WIDTH || y < 0 || y >= MODEL_HEIGHT) return 0;
        return skin.basePixels[(MODEL_HEIGHT - 1 - y) * MODEL_WIDTH + x];
    }

    public static int previewOuterPixel(int x, int y) {
        SkinData skin = loadedSkin;
        if (skin == null || x < 0 || x >= MODEL_WIDTH || y < 0 || y >= MODEL_HEIGHT) return 0;
        return skin.outerPixels[(MODEL_HEIGHT - 1 - y) * MODEL_WIDTH + x];
    }

    public static boolean slimArms() {
        SkinData skin = loadedSkin;
        return skin != null && skin.slim;
    }

    /** Rebuilds the skin's UV projection using the alternate 3px/4px arm layout. */
    public static void toggleArmModel(Minecraft client) {
        SkinData current = loadedSkin;
        if (current == null) {
            NoteClientHud.warn("Load a skin before changing its arm model.");
            return;
        }
        boolean slim = !current.slim;
        if (current.sourceName.startsWith("Minecraft preset • ")) {
            loadDefaultSkin(client, current.username, slim);
            return;
        }
        loadedSkin = createSkinData(current.username, current.sourceImage, slim,
                current.localFile, current.sourceName);
        status = "Arm model changed to " + (slim ? "slim (3px)" : "classic (4px)")
                + " • " + loadedSkin.blockCount + " statue blocks planned.";
        NoteClientHud.show("Skin arm model: " + (slim ? "slim" : "classic") + ".");
    }

    public static void lookup(Minecraft client, String rawUsername) {
        String username = rawUsername == null ? "" : rawUsername.trim();
        if (!username.matches("[A-Za-z0-9_]{3,16}")) {
            status = "Invalid Java username. Use 3–16 letters, numbers, or underscores.";
            NoteClientHud.warn(status);
            return;
        }
        long generation = ++lookupGeneration;
        loading = true;
        loadedSkin = null;
        loadedUsername = username;
        status = "Looking up " + username + " on Mojang services…";
        CompletableFuture.supplyAsync(() -> {
            try {
                return fetchSkin(username);
            } catch (Exception exception) {
                throw new RuntimeException(exception.getMessage() == null
                        ? exception.getClass().getSimpleName() : exception.getMessage(), exception);
            }
        }).whenComplete((skin, error) -> client.execute(() -> {
            if (generation != lookupGeneration) return;
            loading = false;
            if (error != null || skin == null) {
                loadedSkin = null;
                Throwable cause = error;
                while (cause != null && cause.getCause() != null) cause = cause.getCause();
                String reason = cause == null || cause.getMessage() == null
                        ? "unknown lookup error" : cause.getMessage();
                status = "Skin lookup failed: " + reason;
                NoteClientHud.warn(status);
            } else {
                loadedSkin = skin;
                loadedUsername = skin.username;
                status = "Loaded " + skin.username + " • " + (skin.slim ? "Alex / slim arms" : "Steve / classic arms")
                        + " • " + skin.blockCount + " statue blocks planned.";
                NoteClientHud.show("Loaded public Minecraft skin for " + skin.username + ".");
            }
        }));
    }

    private static SkinData fetchSkin(String username) throws Exception {
        JsonObject profile = getJson("https://api.mojang.com/users/profiles/minecraft/" + username);
        if (profile == null || !profile.has("id")) throw new IllegalArgumentException("username was not found");
        String uuid = profile.get("id").getAsString();
        String canonicalName = profile.has("name") ? profile.get("name").getAsString() : username;
        return fetchSkinById(uuid, canonicalName);
    }

    private static SkinData fetchSkinById(String uuid, String username) throws Exception {
        String cleanUuid = uuid.replace("-", "");
        if (!cleanUuid.matches("[0-9a-fA-F]{32}")) {
            throw new IllegalArgumentException("the online player UUID is not a standard Java profile UUID");
        }
        JsonObject session = getJson("https://sessionserver.mojang.com/session/minecraft/profile/" + cleanUuid + "?unsigned=false");
        if (session == null || !session.has("properties")) throw new IllegalArgumentException("profile has no public skin data");
        JsonArray properties = session.getAsJsonArray("properties");
        String encodedTextures = null;
        for (JsonElement element : properties) {
            JsonObject property = element.getAsJsonObject();
            if (property.has("name") && "textures".equals(property.get("name").getAsString())) {
                encodedTextures = property.get("value").getAsString();
                break;
            }
        }
        if (encodedTextures == null) throw new IllegalArgumentException("profile has no public textures property");
        return fetchSkinFromTextureProperty(encodedTextures, username);
    }

    /** Reads a textures property sent in the server player-list profile. */
    private static SkinData fetchSkinFromTextureProperty(String encodedTextures, String username) throws Exception {
        String textureJson = new String(Base64.getDecoder().decode(encodedTextures), java.nio.charset.StandardCharsets.UTF_8);
        JsonObject texturesRoot = JsonParser.parseString(textureJson).getAsJsonObject();
        JsonObject textures = texturesRoot.getAsJsonObject("textures");
        if (textures == null || !textures.has("SKIN")) throw new IllegalArgumentException("profile does not include a skin texture");
        JsonObject skinObject = textures.getAsJsonObject("SKIN");
        String skinUrl = skinObject.get("url").getAsString();
        URI skinUri = URI.create(skinUrl);
        if (!"textures.minecraft.net".equalsIgnoreCase(skinUri.getHost()) || !"https".equalsIgnoreCase(skinUri.getScheme())) {
            throw new IllegalArgumentException("skin URL was not on the official Minecraft texture host");
        }
        boolean slim = skinObject.has("metadata")
                && skinObject.getAsJsonObject("metadata").has("model")
                && "slim".equalsIgnoreCase(skinObject.getAsJsonObject("metadata").get("model").getAsString());

        HttpResponse<byte[]> skinResponse = HTTP.send(HttpRequest.newBuilder(skinUri)
                .timeout(Duration.ofSeconds(12)).GET().build(), HttpResponse.BodyHandlers.ofByteArray());
        if (skinResponse.statusCode() != 200) throw new IllegalArgumentException("skin texture download returned HTTP " + skinResponse.statusCode());
        BufferedImage image = ImageIO.read(new ByteArrayInputStream(skinResponse.body()));
        if (image == null) throw new IllegalArgumentException("the public skin texture was not a readable PNG");
        image = normalizeSkinImage(image);
        return createSkinData(username, image, slim, false, username);
    }

    private static JsonObject getJson(String url) throws Exception {
        URI uri = URI.create(url);
        String host = uri.getHost();
        if (!"api.mojang.com".equalsIgnoreCase(host)
                && !"sessionserver.mojang.com".equalsIgnoreCase(host)) {
            throw new IllegalArgumentException("refusing an unexpected profile service host");
        }
        HttpResponse<String> response = HTTP.send(HttpRequest.newBuilder(uri)
                .timeout(Duration.ofSeconds(12))
                .header("Accept", "application/json")
                .GET().build(), HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() == 204 || response.statusCode() == 404) return null;
        if (response.statusCode() != 200) throw new IllegalArgumentException("Mojang profile lookup returned HTTP " + response.statusCode());
        return JsonParser.parseString(response.body()).getAsJsonObject();
    }

    private static BufferedImage expandLegacySkin(BufferedImage source) {
        BufferedImage expanded = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        var graphics = expanded.createGraphics();
        graphics.drawImage(source, 0, 0, null);
        graphics.dispose();
        // Pre-1.8 skins have no separate left-limb atlas islands. Copy the full
        // 16x16 arm and leg UV islands, not just their front faces, so the new
        // 3D model also has valid back, side, top, and bottom textures.
        for (int y = 0; y < 16; y++) {
            for (int x = 0; x < 16; x++) {
                expanded.setRGB(32 + x, 48 + y, source.getRGB(40 + x, 16 + y));
                expanded.setRGB(16 + x, 48 + y, source.getRGB(x, 16 + y));
            }
        }
        return expanded;
    }

    private static SkinData createSkinData(String username, BufferedImage image, boolean slim,
                                           boolean localFile, String sourceName) {
        // Keep the front projection for the GUI preview, but build the statue
        // from the complete six-face Minecraft skin atlas below.
        int[] base = new int[MODEL_WIDTH * MODEL_HEIGHT];
        int[] outer = new int[MODEL_WIDTH * MODEL_HEIGHT];
        int armWidth = slim ? 3 : 4;
        copyFace(image, base, 4, 24, 8, 8, 8, 8);       // head front
        copyFace(image, base, 4, 12, 8, 12, 20, 20);   // torso front
        copyFace(image, base, 4 - armWidth, 12, armWidth, 12, 44, 20); // right arm front
        copyFace(image, base, 12, 12, armWidth, 12, 36, 52); // left arm front
        copyFace(image, base, 4, 0, 4, 12, 4, 20);     // right leg front
        copyFace(image, base, 8, 0, 4, 12, 20, 52);    // left leg front

        // The outer atlas is a separate set of cuboids, not a flat decal layer.
        copyFace(image, outer, 4, 24, 8, 8, 40, 8);    // hat front
        copyFace(image, outer, 4, 12, 8, 12, 20, 36);  // jacket front
        copyFace(image, outer, 4 - armWidth, 12, armWidth, 12, 44, 36);
        copyFace(image, outer, 12, 12, armWidth, 12, 52, 52);
        copyFace(image, outer, 4, 0, 4, 12, 4, 36);
        copyFace(image, outer, 8, 0, 4, 12, 4, 52);

        List<LocalStatueBlock> modelBlocks = makeLocalStatueBlocks(image, slim, COUNT_PALETTE);
        return new SkinData(username, slim, base, outer, modelBlocks.size(), image,
                localFile, sourceName, modelBlocks);
    }

    private static void copyFace(BufferedImage image, int[] target, int dx, int dy,
                                 int width, int height, int sx, int sy) {
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int tx = dx + x;
                // Skin PNG rows run top-to-bottom; model Y increases upward.
                int ty = dy + (height - 1 - y);
                int px = sx + x;
                int py = sy + y;
                if (tx < 0 || tx >= MODEL_WIDTH || ty < 0 || ty >= MODEL_HEIGHT
                        || px < 0 || px >= image.getWidth() || py < 0 || py >= image.getHeight()) continue;
                target[ty * MODEL_WIDTH + tx] = image.getRGB(px, py);
            }
        }
    }

    /**
     * Builds an arbitrary Voxel Studio model through ordinary client block
     * interactions. No NoteClient server companion is needed: on remote
     * servers the server still decides whether each normal placement is kept.
     */
    public static boolean startVoxelBuild(Minecraft client, VoxelModel model) {
        if (model == null) {
            status = "No voxel model is loaded.";
            NoteClientHud.warn(status);
            return false;
        }
        if (client == null || client.player == null || client.level == null || client.gameMode == null) {
            status = "Join a world before building a voxel model.";
            NoteClientHud.warn(status);
            return false;
        }
        if (client.gameMode.getPlayerMode() != GameType.CREATIVE) {
            status = "Voxel models require Creative mode for block palette staging.";
            NoteClientHud.warn(status);
            return false;
        }
        if (activeBuild != null && (!activeBuild.completed || activeBuild.removeRequested)) {
            NoteClientHud.warn(activeBuild.removeRequested
                    ? "The newest statue is still being undone. Let cleanup finish first."
                    : "A NoteClient model is already being built. Stop or finish it before starting another.");
            return false;
        }
        if (undoHistory.size() + (activeBuild == null ? 0 : 1) >= MAX_TRACKED_STATUES) {
            NoteClientHud.warn("Build history is full. Undo an older model or statue first.");
            return false;
        }
        if (VanillaServerBuilder.hasActiveJob()) {
            NoteClientHud.warn("Finish or cancel the current NoteClient song job before building a model.");
            return false;
        }

        LocalPlayer player = client.player;
        Direction forward = Direction.fromYRot(player.getYRot());
        BlockPos anchor = player.blockPosition().relative(forward, 3);
        Map<BlockPos, Block> modelBlocks = new LinkedHashMap<>();
        int skippedLayers = 0;

        try {
            for (VoxelModel.Cell cell : model.cells()) {
                VoxelModel.Layer layer = model.layer(cell.layerId());
                if (!layer.buildToWorld()) {
                    skippedLayers++;
                    continue;
                }
                String blockId = model.palette().get(cell.paletteIndex() - 1).blockId();
                Identifier id = Identifier.parse(blockId);
                Block block = BuiltInRegistries.BLOCK.getOptional(id).orElse(null);
                if (!isSafeVoxelMaterial(block)) {
                    status = "Cannot build " + model.name() + ": " + blockId
                            + " is missing, non-solid, has block data, or cannot be placed as a full cube.";
                    NoteClientHud.warn(status);
                    return false;
                }
                BlockPos position = anchor.offset(
                        cell.x() + Math.round(layer.offsetX()),
                        cell.y() + Math.round(layer.offsetY()),
                        cell.z() + Math.round(layer.offsetZ())).immutable();
                modelBlocks.put(position, block);
            }
        } catch (RuntimeException invalidModel) {
            status = "Could not prepare voxel model: " + invalidModel.getMessage();
            NoteClientHud.warn(status);
            return false;
        }

        if (modelBlocks.isEmpty()) {
            status = "No model layers are enabled for building. Enable Build to World on at least one layer.";
            NoteClientHud.warn(status);
            return false;
        }

        List<StatueBlock> unordered = new ArrayList<>(modelBlocks.size());
        for (Map.Entry<BlockPos, Block> entry : modelBlocks.entrySet()) {
            BlockPos pos = entry.getKey();
            if (client.level.isOutsideBuildHeight(pos) || !client.level.getWorldBorder().isWithinBounds(pos)
                    || !client.level.hasChunkAt(pos)) {
                status = "The model reaches outside loaded chunks, the world border, or build height. No blocks were placed.";
                NoteClientHud.warn(status);
                return false;
            }
            if (!client.level.getBlockState(pos).isAir()) {
                status = "The model footprint is obstructed at " + pos.getX() + ", "
                        + pos.getY() + ", " + pos.getZ() + ". Existing blocks were left untouched.";
                NoteClientHud.warn(status);
                return false;
            }
            unordered.add(new StatueBlock(pos, entry.getValue()));
        }

        boolean integratedSingleplayer = client.getSingleplayerServer() != null;
        List<StatueBlock> ordered = orderVoxelModelBlocks(client, unordered, integratedSingleplayer);
        if (ordered == null || ordered.isEmpty()) {
            status = "No starting block is beside a sturdy surface within normal reach. Move closer to a floor or wall and try again.";
            NoteClientHud.warn(status);
            return false;
        }

        Map<Item, Integer> requiredMaterials = new LinkedHashMap<>();
        for (StatueBlock block : ordered) requiredMaterials.merge(block.block.asItem(), 1, Integer::sum);
        CreativeMaterialStager.Result inventory = CreativeMaterialStager.stage(client, requiredMaterials);

        int originalSlot = player.getInventory().getSelectedSlot();
        ItemStack originalStack = player.getInventory().getItem(originalSlot).copy();
        if (activeBuild != null) {
            undoHistory.addLast(activeBuild);
            activeBuild = null;
        }
        activeBuild = new StatueJob("Model: " + model.name(), client.level, ordered,
                originalSlot, originalStack, integratedSingleplayer);
        if (integratedSingleplayer) {
            activeBuild.placementsPerTick = NoteClientConfig.buildActionsPerTick();
            activeBuild.placementIntervalTicks = 1;
        }
        status = "Building model " + model.name() + " • 0/" + ordered.size()
                + " blocks • " + (integratedSingleplayer
                ? "local world batches"
                : "normal server interactions • " + NoteClientConfig.buildActionsPerTick() + "/tick")
                + " • " + inventory.summary()
                + (skippedLayers > 0 ? " • " + skippedLayers + " non-build layers ignored" : "");
        NoteClientHud.show(status);
        return true;
    }

    private static boolean isSafeVoxelMaterial(Block block) {
        if (block == null || block == Blocks.AIR || block.asItem() == Items.AIR) return false;
        Identifier id = BuiltInRegistries.BLOCK.getKey(block);
        if (id == null || UNSAFE_VOXEL_MATERIAL_IDS.contains(id.getPath())
                || id.getPath().endsWith("_concrete_powder")) return false;
        BlockState state = block.defaultBlockState();
        return !state.isAir() && !state.hasBlockEntity() && state.getFluidState().isEmpty()
                && state.isCollisionShapeFullBlock(EmptyBlockGetter.INSTANCE, BlockPos.ZERO);
    }

    /**
     * Produces a placement order that grows outward from real, reachable support
     * faces. Disconnected model pieces must each have their own reachable support.
     */
    private static List<StatueBlock> orderVoxelModelBlocks(Minecraft client,
                                                            List<StatueBlock> unordered,
                                                            boolean integratedSingleplayer) {
        Map<BlockPos, StatueBlock> remaining = new LinkedHashMap<>();
        for (StatueBlock block : unordered) remaining.put(block.position.immutable(), block);
        List<StatueBlock> ordered = new ArrayList<>(unordered.size());

        while (!remaining.isEmpty()) {
            StatueBlock seed = null;
            double bestDistance = Double.MAX_VALUE;
            for (StatueBlock candidate : remaining.values()) {
                if (!integratedSingleplayer && findPlacementHit(client, candidate.position) == null) continue;
                double distance = client.player.getEyePosition().distanceTo(
                        Vec3.atCenterOf(candidate.position));
                if (distance < bestDistance) {
                    seed = candidate;
                    bestDistance = distance;
                }
            }
            if (seed == null) return null;

            Deque<StatueBlock> queue = new ArrayDeque<>();
            remaining.remove(seed.position);
            queue.addLast(seed);
            while (!queue.isEmpty()) {
                StatueBlock current = queue.removeFirst();
                ordered.add(current);
                for (Direction direction : Direction.values()) {
                    BlockPos neighborPos = current.position.relative(direction).immutable();
                    StatueBlock neighbor = remaining.remove(neighborPos);
                    if (neighbor != null) queue.addLast(neighbor);
                }
            }
        }
        return ordered;
    }

    public static boolean startBuild(Minecraft client) {
        SkinData skin = loadedSkin;
        if (skin == null) {
            status = "Load a Java username, PNG file, or Minecraft preset before building a statue.";
            NoteClientHud.warn(status);
            return false;
        }
        if (client == null || client.player == null || client.level == null || client.gameMode == null) {
            status = "Join a world before building a statue.";
            NoteClientHud.warn(status);
            return false;
        }
        if (activeBuild != null && (!activeBuild.completed || activeBuild.removeRequested)) {
            NoteClientHud.warn(activeBuild.removeRequested
                    ? "The newest statue is still being undone. Let cleanup finish first."
                    : "A player statue is still being built. Let it finish before starting another.");
            return false;
        }
        if (undoHistory.size() + (activeBuild == null ? 0 : 1) >= MAX_TRACKED_STATUES) {
            NoteClientHud.warn("Statue undo history is full. Press Undo Last to remove an older statue first.");
            return false;
        }
        if (VanillaServerBuilder.hasActiveJob()) {
            NoteClientHud.warn("Finish or cancel the current NoteClient song job before building a statue.");
            return false;
        }
        if (client.gameMode.getPlayerMode() != GameType.CREATIVE) {
            status = "Player statues require Creative mode so colored building blocks can be staged without consuming survival inventory.";
            NoteClientHud.warn(status);
            return false;
        }

        if (!MinecraftBlockPalette.isReady()) {
            MinecraftBlockPalette.prepareAsync();
            status = "Preparing the full texture-sampled vanilla block palette. Click Build Statue again when it is ready.";
            NoteClientHud.show(status);
            return false;
        }

        final List<LocalStatueBlock> texturedBlocks;
        try {
            List<PaletteColor> skinPalette = createSkinPalette(skin.sourceImage);
            texturedBlocks = makeLocalStatueBlocks(skin.sourceImage, skin.slim, skinPalette);
        } catch (RuntimeException paletteError) {
            status = "Could not prepare the skin's block shades: " + paletteError.getMessage();
            NoteClientHud.warn(status);
            return false;
        }

        LocalPlayer player = client.player;
        Direction forward = Direction.fromYRot(player.getYRot());
        Direction right = forward.getClockWise();
        BlockPos anchor = player.blockPosition().relative(forward, 1).relative(right, -8);
        List<StatueBlock> blocks = makeStatueBlocks(texturedBlocks, anchor, right, forward);
        // Validate the complete statue footprint before placing any part of it.
        for (StatueBlock placement : blocks) {
            BlockPos pos = placement.position;
            if (client.level.isOutsideBuildHeight(pos) || !client.level.getWorldBorder().isWithinBounds(pos)) {
                status = "The full statue would cross the world border or build height. Move to a taller, clearer area.";
                NoteClientHud.warn(status);
                return false;
            }
            if (!client.level.getBlockState(pos).isAir()) {
                status = "The statue footprint is obstructed at " + pos.getX() + ", " + pos.getY() + ", " + pos.getZ() + ". No blocks were placed.";
                NoteClientHud.warn(status);
                return false;
            }
        }

        boolean integratedSingleplayer = client.getSingleplayerServer() != null;
        if (!integratedSingleplayer && !blocks.isEmpty()) {
            BlockHitResult firstHit = findPlacementHit(client, blocks.get(0).position);
            if (firstHit == null) {
                status = "Move closer to the statue's lower center before starting. The first statue block must be within normal server reach.";
                NoteClientHud.warn(status);
                return false;
            }
        }

        // Require a sturdy floor beneath both 3D legs across their full depth.
        // The statue is a set of independent cuboids, not a single flat extrusion.
        for (int x = 4; x < 12; x++) {
            for (int z = 2; z < 6; z++) {
                BlockPos floor = worldPosition(anchor, right, forward, x, 0, z).below();
                if (!client.level.getBlockState(floor).isFaceSturdy(client.level, floor, Direction.UP)) {
                    status = "The statue needs a solid floor beneath both feet. No blocks were placed.";
                    NoteClientHud.warn(status);
                    return false;
                }
            }
        }

        Map<Item, Integer> requiredMaterials = new LinkedHashMap<>();
        for (StatueBlock block : blocks) requiredMaterials.merge(block.block.asItem(), 1, Integer::sum);
        CreativeMaterialStager.Result inventory = CreativeMaterialStager.stage(client, requiredMaterials);

        int originalSlot = player.getInventory().getSelectedSlot();
        ItemStack originalStack = player.getInventory().getItem(originalSlot).copy();
        if (activeBuild != null) {
            // Keep each completed build as a distinct entry in the undo stack.
            undoHistory.addLast(activeBuild);
            activeBuild = null;
        }
        activeBuild = new StatueJob(skin.username, client.level, blocks, originalSlot, originalStack,
                integratedSingleplayer);
        if (integratedSingleplayer) {
            activeBuild.placementsPerTick = NoteClientConfig.buildActionsPerTick();
            activeBuild.placementIntervalTicks = 1;
        }
        status = "Building " + skin.username + " • 0/" + blocks.size() + " blocks • "
                + (integratedSingleplayer ? "local server batches • " : NoteClientConfig.buildActionsPerTick() + " placements/tick • up to 2 tries/cell • ")
                + inventory.summary() + " • " + (undoHistory.size() + 1) + " statue(s) tracked";
        NoteClientHud.show(status);
        return true;
    }

    /**
     * Converts the textured six-face skin cuboids into server-placeable blocks.
     * Each limb, torso, and head is its own rectangular prism. The skin overlay
     * is another larger prism, so hats, jackets, sleeves, and pants have real
     * depth instead of being painted onto a flat picture.
     */
    private static List<StatueBlock> makeStatueBlocks(List<LocalStatueBlock> localBlocks, BlockPos anchor,
                                                      Direction right, Direction forward) {
        List<StatueBlock> result = new ArrayList<>(localBlocks.size());
        for (LocalStatueBlock local : localBlocks) {
            result.add(new StatueBlock(worldPosition(anchor, right, forward,
                    local.x, local.y, local.z), local.block));
        }
        return result;
    }

    /**
     * Keep each garment as an ordered layer. The solid inner body is placed first;
     * hat/jacket follow, then sleeves and trousers are built as separate expanded
     * shells so an outer sleeve visibly sits one block beyond its inner arm.
     */
    private static List<LocalStatueBlock> makeLocalStatueBlocks(BufferedImage image, boolean slim,
                                                                 List<PaletteColor> palette) {
        Map<Integer, Map<BlockPos, Block>> layers = new LinkedHashMap<>();
        for (CuboidTexture part : skinCuboids(slim)) {
            Map<BlockPos, Block> layer = layers.computeIfAbsent(part.layerId, ignored -> new LinkedHashMap<>());
            addCuboidSurface(layer, image, part, palette);
        }
        Map<BlockPos, LayeredBlock> combined = new LinkedHashMap<>();
        for (Map.Entry<Integer, Map<BlockPos, Block>> layer : layers.entrySet()) {
            for (Map.Entry<BlockPos, Block> voxel : layer.getValue().entrySet()) {
                combined.put(voxel.getKey(), new LayeredBlock(voxel.getValue(), layer.getKey()));
            }
        }
        List<LocalStatueBlock> result = new ArrayList<>(combined.size());
        for (Map.Entry<BlockPos, LayeredBlock> entry : combined.entrySet()) {
            BlockPos pos = entry.getKey();
            LayeredBlock voxel = entry.getValue();
            result.add(new LocalStatueBlock(pos.getX(), pos.getY(), pos.getZ(), voxel.block, voxel.layerId));
        }
        result.sort(Comparator
                .comparingInt((LocalStatueBlock block) -> block.layerId)
                .thenComparingInt(block -> block.y)
                .thenComparingInt(block -> Math.abs(block.x - 8))
                .thenComparingInt(block -> block.z));
        return List.copyOf(result);
    }

    /** Full Java 64x64 skin atlas layout for the six faces of each model part. */
    private static List<CuboidTexture> skinCuboids(boolean slim) {
        int armWidth = slim ? 3 : 4;
        // Center slim arms against the torso: the 3px arms sit at X=1..3
        // and X=12..14, with no one-block gap beside the 8px torso.
        int rightArmX = 4 - armWidth;
        int leftArmX = 12;
        List<CuboidTexture> parts = new ArrayList<>(12);

        // Base cuboids. Local Z=0 is the face looking toward the player.
        parts.add(cuboid("head", 4, 24, 0, 8, 8, 8,
                uv(8, 8, 8, 8), uv(24, 8, 8, 8), uv(8, 0, 8, 8), uv(16, 0, 8, 8),
                uv(0, 8, 8, 8), uv(16, 8, 8, 8), false, true, 0));
        parts.add(cuboid("torso", 4, 12, 2, 8, 12, 4,
                uv(20, 20, 8, 12), uv(32, 20, 8, 12), uv(20, 16, 8, 4), uv(28, 16, 8, 4),
                uv(16, 20, 4, 12), uv(28, 20, 4, 12), false, false, 0));
        parts.add(cuboid("right_arm", rightArmX, 12, 2, armWidth, 12, 4,
                uv(44, 20, armWidth, 12), uv(52, 20, armWidth, 12), uv(44, 16, armWidth, 4),
                uv(48, 16, armWidth, 4), uv(40, 20, 4, 12), uv(48, 20, 4, 12), false, false, 0));
        parts.add(cuboid("left_arm", leftArmX, 12, 2, armWidth, 12, 4,
                uv(36, 52, armWidth, 12), uv(44, 52, armWidth, 12), uv(36, 48, armWidth, 4),
                uv(40, 48, armWidth, 4), uv(32, 52, 4, 12), uv(40, 52, 4, 12), false, false, 0));
        parts.add(cuboid("right_leg", 4, 0, 2, 4, 12, 4,
                uv(4, 20, 4, 12), uv(12, 20, 4, 12), uv(4, 16, 4, 4), uv(8, 16, 4, 4),
                uv(0, 20, 4, 12), uv(8, 20, 4, 12), false, false, 0));
        parts.add(cuboid("left_leg", 8, 0, 2, 4, 12, 4,
                uv(20, 52, 4, 12), uv(28, 52, 4, 12), uv(20, 48, 4, 4), uv(24, 48, 4, 4),
                uv(16, 52, 4, 12), uv(24, 52, 4, 12), false, false, 0));

        // Outer cuboids. The head hat grows one block on every side. Clothing
        // grows one block sideways/depth-wise and upward, without going below
        // the feet, so the model remains grounded on a normal floor.
        parts.add(cuboid("hat", 4, 24, 0, 8, 8, 8,
                uv(40, 8, 8, 8), uv(56, 8, 8, 8), uv(40, 0, 8, 8), uv(48, 0, 8, 8),
                uv(32, 8, 8, 8), uv(48, 8, 8, 8), true, true, 1));
        parts.add(cuboid("jacket", 4, 12, 2, 8, 12, 4,
                uv(20, 36, 8, 12), uv(32, 36, 8, 12), uv(20, 32, 8, 4), uv(28, 32, 8, 4),
                uv(16, 36, 4, 12), uv(28, 36, 4, 12), true, false, 2));
        parts.add(cuboid("right_sleeve", rightArmX, 12, 2, armWidth, 12, 4,
                uv(44, 36, armWidth, 12), uv(52, 36, armWidth, 12), uv(44, 32, armWidth, 4),
                uv(48, 32, armWidth, 4), uv(40, 36, 4, 12), uv(48, 36, 4, 12), true, false, 3));
        parts.add(cuboid("left_sleeve", leftArmX, 12, 2, armWidth, 12, 4,
                uv(52, 52, armWidth, 12), uv(60, 52, armWidth, 12), uv(52, 48, armWidth, 4),
                uv(56, 48, armWidth, 4), uv(48, 52, 4, 12), uv(56, 52, 4, 12), true, false, 4));
        parts.add(cuboid("right_pants", 4, 0, 2, 4, 12, 4,
                uv(4, 36, 4, 12), uv(12, 36, 4, 12), uv(4, 32, 4, 4), uv(8, 32, 4, 4),
                uv(0, 36, 4, 12), uv(8, 36, 4, 12), true, false, 5));
        parts.add(cuboid("left_pants", 8, 0, 2, 4, 12, 4,
                uv(4, 52, 4, 12), uv(12, 52, 4, 12), uv(4, 48, 4, 4), uv(8, 48, 4, 4),
                uv(0, 52, 4, 12), uv(8, 52, 4, 12), true, false, 6));
        return parts;
    }

    private static CuboidTexture cuboid(String name, int x, int y, int z,
                                        int width, int height, int depth,
                                        FaceUv front, FaceUv back, FaceUv top, FaceUv bottom,
                                        FaceUv left, FaceUv right, boolean outer, boolean head, int layerId) {
        return new CuboidTexture(name, x, y, z, width, height, depth,
                front, back, top, bottom, left, right, outer, head, layerId);
    }

    private static FaceUv uv(int x, int y, int width, int height) {
        return new FaceUv(x, y, width, height);
    }

    private static void addCuboidSurface(Map<BlockPos, Block> output,
                                         BufferedImage image, CuboidTexture part,
                                         List<PaletteColor> palette) {
        int inflateMinX = part.outer ? 1 : 0;
        int inflateMaxX = part.outer ? 1 : 0;
        // Arms already meet the torso. Only expand a sleeve away from the
        // torso: right sleeve toward -X, left sleeve toward +X. This leaves
        // the inner arm as layer 0 and adds exactly one outward sleeve voxel.
        if (part.layerId == 3 || part.layerId == 5) inflateMaxX = 0;
        if (part.layerId == 4 || part.layerId == 6) inflateMinX = 0;
        int inflateZ = part.outer ? 1 : 0;
        int inflateBottom = part.outer && part.head ? 1 : 0;
        int inflateTop = part.outer && part.layerId != 2 && part.layerId != 5 && part.layerId != 6 ? 1 : 0;
        int x0 = part.x - inflateMinX;
        int y0 = part.y - inflateBottom;
        int z0 = part.z - inflateZ;
        int width = part.width + inflateMinX + inflateMaxX;
        int height = part.height + inflateBottom + inflateTop;
        int depth = part.depth + inflateZ * 2;

        // Build only the visible boundary of every cuboid. The front, back,
        // left/right sides and caps below form a hollow shell; no interior depth
        // layers are emitted. This substantially reduces statue placement count
        // while preserving the full outside silhouette and per-face skin shading.
        // Transparent pixels remain transparent on every face.
        putFace(output, image, part, part.front, width, height, (u, v) ->
                new BlockPos(x0 + u, y0 + height - 1 - v, z0), 1.00, palette);
        putFace(output, image, part, part.back, width, height, (u, v) ->
                new BlockPos(x0 + u, y0 + height - 1 - v, z0 + depth - 1), 0.72, palette);

        // Left/right faces (depth x height).
        if (part.layerId == 3 || part.layerId == 5) {
            // Right sleeve / right pant: the outward side points toward -X.
            putFace(output, image, part, part.left, depth, height, (u, v) ->
                    new BlockPos(x0, y0 + height - 1 - v, z0 + u), 0.78, palette);
        } else if (part.layerId == 4 || part.layerId == 6) {
            // Left sleeve / left pant: the outward side points toward +X.
            putFace(output, image, part, part.right, depth, height, (u, v) ->
                    new BlockPos(x0 + width - 1, y0 + height - 1 - v, z0 + u), 0.86, palette);
        } else if (part.layerId != 2) {
            // The jacket intentionally has no lateral walls: those positions
            // belong to the inner arms and should remain separate at the seams.
            putFace(output, image, part, part.left, depth, height, (u, v) ->
                    new BlockPos(x0, y0 + height - 1 - v, z0 + u), 0.78, palette);
            putFace(output, image, part, part.right, depth, height, (u, v) ->
                    new BlockPos(x0 + width - 1, y0 + height - 1 - v, z0 + u), 0.86, palette);
        }

        // The body, hat and sleeve shells need their caps. The jacket and pants
        // are surface layers; omitting their caps avoids covering the neck,
        // waist and opposite leg with an extra horizontal slab.
        if (part.layerId == 0 || part.layerId == 1 || part.layerId == 3 || part.layerId == 4) {
            putFace(output, image, part, part.top, width, depth, (u, v) ->
                    new BlockPos(x0 + u, y0 + height - 1, z0 + v), 1.12, palette);
            putFace(output, image, part, part.bottom, width, depth, (u, v) ->
                    new BlockPos(x0 + u, y0, z0 + v), 0.58, palette);
        }
    }

    private static void putFace(Map<BlockPos, Block> output, BufferedImage image,
                                CuboidTexture part, FaceUv uv, int width, int height,
                                FacePosition position, double shade, List<PaletteColor> palette) {
        for (int v = 0; v < height; v++) {
            int sampleY = uv.y + Math.min(uv.height - 1, (v * uv.height) / height);
            for (int u = 0; u < width; u++) {
                int sampleX = uv.x + Math.min(uv.width - 1, (u * uv.width) / width);
                if (sampleX < 0 || sampleX >= image.getWidth()
                        || sampleY < 0 || sampleY >= image.getHeight()) continue;
                int argb = image.getRGB(sampleX, sampleY);
                if (((argb >>> 24) & 255) <= 24) continue;
                int shaded = shade(argb, shade * (part.outer ? 1.06 : 1.0));
                Block block = closestPaletteBlock(shaded, palette);
                output.put(position.at(u, v), block);
            }
        }
    }

    private static BlockPos worldPosition(BlockPos anchor, Direction right, Direction forward,
                                          int x, int y, int z) {
        return anchor.relative(right, x).relative(forward, z).above(y);
    }

    private static int shade(int argb, double factor) {
        int alpha = (argb >>> 24) & 255;
        return (alpha << 24)
                | (shadeChannel((argb >>> 16) & 255, factor) << 16)
                | (shadeChannel((argb >>> 8) & 255, factor) << 8)
                | shadeChannel(argb & 255, factor);
    }

    private static int shadeChannel(int channel, double factor) {
        double value = channel / 255.0;
        double linear = value <= 0.04045 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4);
        linear = Math.max(0.0, Math.min(1.0, linear * factor));
        double srgb = linear <= 0.0031308 ? linear * 12.92 : 1.055 * Math.pow(linear, 1.0 / 2.4) - 0.055;
        return (int) Math.round(Math.max(0.0, Math.min(1.0, srgb)) * 255.0);
    }

    private static List<PaletteColor> createSkinPalette(BufferedImage image) {
        List<PaletteColor> result = new ArrayList<>();
        List<dev.noteclient.voxel.core.VoxelModel.PaletteEntry> entries = MinecraftBlockPalette.paletteForSkin(
                image, 0.58, 0.72, 0.78, 0.86, 0.93, 0.95, 1.0, 1.06, 1.12);
        for (var entry : entries) {
            Identifier id = Identifier.parse(entry.blockId());
            Block block = BuiltInRegistries.BLOCK.getOptional(id).orElse(null);
            if (block == null) continue;
            BlockState state = block.defaultBlockState();
            if (state.isAir() || state.hasBlockEntity() || !state.getFluidState().isEmpty()
                    || !state.isCollisionShapeFullBlock(EmptyBlockGetter.INSTANCE, BlockPos.ZERO)) continue;
            result.add(new PaletteColor(block, entry.argb(), VoxelColorMath.toOklab(entry.argb()), 0));
        }
        if (result.isEmpty()) throw new IllegalStateException("No safe full-cube vanilla materials were found for this skin");
        return List.copyOf(result);
    }

    private static Block closestPaletteBlock(int argb, List<PaletteColor> palette) {
        double[] target = VoxelColorMath.toOklab(argb);
        PaletteColor best = palette.get(0);
        double bestScore = Double.POSITIVE_INFINITY;
        for (PaletteColor candidate : palette) {
            double dl = (target[0] - candidate.lab[0]) * 1.12;
            double da = target[1] - candidate.lab[1];
            double db = target[2] - candidate.lab[2];
            double score = dl * dl + da * da + db * db;
            if (score < bestScore) {
                bestScore = score;
                best = candidate;
            }
        }
        return best.block;
    }

    public static void tick(Minecraft client) {
        if (client != null && client.level != null && !MinecraftBlockPalette.isReady()) {
            MinecraftBlockPalette.prepareAsync();
        }
        StatueJob job = activeBuild;
        if (job == null || job.completed && !job.removeRequested) return;
        if (client == null || client.player == null || client.level == null || client.gameMode == null) {
            activeBuild = null;
            undoHistory.clear();
            status = "Statue job stopped after disconnect. Server-confirmed blocks remain in the world.";
            return;
        }
        if (client.level != job.level) {
            activeBuild = null;
            undoHistory.clear();
            status = "Statue job stopped after a dimension change. Blocks in the previous dimension were left untouched.";
            NoteClientHud.warn(status);
            return;
        }
        if (client.gameMode.getPlayerMode() != GameType.CREATIVE) {
            finishBuild(client, job, "Statue job stopped because the server changed your game mode. Confirmed blocks remain; use Creative to retry or remove them.");
            return;
        }
        // A Stop request must always drain already-sent placements and finish,
        // even if a nested editor screen did not disappear correctly. Normal
        // construction still waits for gameplay to resume before sending blocks.
        if (job.paused || (client.gui.screen() != null && !job.stopRequested && !job.removeRequested)) return;

        if (job.integratedSingleplayer && client.getSingleplayerServer() == null) {
            finishBuild(client, job, "The integrated server closed before the statue finished. Placed blocks remain tracked; use Undo Last to clean them up.");
            return;
        }

        long now = client.level.getGameTime();
        int pingMs = job.integratedSingleplayer ? 0 : currentPingMs(client);
        job.lastPingMs = pingMs;
        int requestedBuildRate = NoteClientConfig.buildActionsPerTick();
        if (job.configuredBuildRate != requestedBuildRate) {
            // A manual setting change takes effect on the active job immediately.
            job.configuredBuildRate = requestedBuildRate;
            job.placementsPerTick = requestedBuildRate;
            job.maxInFlight = job.integratedSingleplayer ? 0 : pendingLimit(pingMs, requestedBuildRate);
        }
        if (job.integratedSingleplayer) {
            job.placementsPerTick = requestedBuildRate;
        } else {
            if (job.placementsPerTick <= 0) job.placementsPerTick = requestedBuildRate;
            // Adaptive recovery may lower the requested rate after rejected
            // interactions, but never exceeds the user's configured ceiling.
            job.placementsPerTick = Math.min(job.placementsPerTick, requestedBuildRate);
        }
        int ackTimeout = job.integratedSingleplayer ? SINGLEPLAYER_VERIFY_DELAY_TICKS
                : acknowledgementTimeoutTicks(pingMs, job.repairPass);
        int confirmGrace = job.integratedSingleplayer ? 0 : placementConfirmationGraceTicks(pingMs);

        // Resolve in-flight placement interactions before deciding whether to
        // start another pass or safely remove the statue.
        for (int i = 0; i < job.pending.size();) {
            PendingPlacement pending = job.pending.get(i);
            BlockState actual = client.level.getBlockState(pending.placement.position);
            long age = now - pending.sentAt;
            if (actual.is(pending.placement.block) && age >= confirmGrace) {
                job.confirmedPositions.add(pending.placement.position.immutable());
                job.blockedPositions.remove(pending.placement.position);
                job.pending.remove(i);
                continue;
            }
            if (!actual.isAir() && !actual.is(pending.placement.block)) {
                // A multiplayer server may replace/revert one attempted cell
                // while accepting the rest of the statue. Treat that position
                // as temporarily occupied instead of aborting the entire job.
                // The next full scan will retry it automatically if it becomes air.
                job.confirmedPositions.remove(pending.placement.position);
                job.blockedPositions.add(pending.placement.position.immutable());
                job.pending.remove(i);
                continue;
            }
            if (age >= ackTimeout) {
                job.pending.remove(i);
                // The first interaction did not survive the server confirmation
                // window. Retry this exact cell once, but only if it is still air.
                // If the server accepted the first interaction, the correct-state
                // check above confirms it and this retry is never queued.
                if (!job.removeRequested && !job.stopRequested && actual.isAir()) {
                    enqueuePlacementRetry(job, pending.placement, now, 0);
                }
                continue;
            }
            i++;
        }

        if (job.stopRequested) {
            if (job.pending.isEmpty() && job.integratedBatchesInFlight <= 0) {
                finishBuild(client, job, "Stopped building. All already-sent placements have settled; existing blocks remain in the world. Press O to undo the newest build.");
            } else {
                status = "Stopping • waiting for " + job.pending.size() + " sent placement(s) and "
                        + job.integratedBatchesInFlight + " local batch(es). No new placements will be sent.";
            }
            return;
        }

        if (job.removeRequested) {
            tickRemoval(client, job, now, pingMs, ackTimeout, confirmGrace);
            return;
        }

        if (job.retryRequested && job.pending.isEmpty() && job.retryPlacements.isEmpty()) {
            job.retryRequested = false;
            job.awaitingChanges = false;
            job.awaitingReach = false;
            job.verifying = true;
            job.verifyCursor = 0;
            job.missingBlocks.clear();
            job.retryPlacements.clear();
            job.retryQueuedPositions.clear();
            job.passPlacementAttempts.clear();
            job.nextRetryAt = now + Math.max(1, confirmGrace);
            status = "Manual statue integrity scan queued. NoteClient will retry only cells the server did not keep.";
            NoteClientHud.show(status);
            return;
        }

        // A different block at a statue coordinate is never overwritten. Keep
        // checking those positions in the background, though, so a server or
        // player clearing the obstruction automatically restarts construction.
        if (job.awaitingChanges) {
            if (now < job.nextRetryAt) return;
            job.awaitingChanges = false;
            job.verifying = true;
            job.verifyCursor = 0;
            job.missingBlocks.clear();
            job.stableScans = 0;
            job.nextRetryAt = now + 1;
            status = "Rechecking occupied statue cells • any cells now clear will be repaired automatically.";
            return;
        }

        if (job.awaitingReach) {
            if (now < job.nextRetryAt) return;
            List<StatueBlock> newlyReachable = job.missingBlocks.stream()
                    .filter(block -> findPlacementHit(client, block.position) != null)
                    .toList();
            if (newlyReachable.isEmpty()) {
                job.nextRetryAt = now + 10;
                if (now % 40 == 0) {
                    status = "Waiting for reach • " + job.missingBlocks.size()
                            + " statue blocks remain. Move closer/higher, or request /reach 100 in Settings if the server allows it; retries are automatic.";
                    NoteClientHud.warn(status);
                }
                return;
            }
            job.passBlocks = List.copyOf(newlyReachable);
            snapshotWorkingSlot(client, job);
            job.repairPass++;
            job.missingBlocks.clear();
            job.retryPlacements.clear();
            job.retryQueuedPositions.clear();
            job.passPlacementAttempts.clear();
            job.passAttemptedPositions.clear();
            job.unreachablePositions.clear();
            job.cursor = 0;
            job.verifying = false;
            job.awaitingReach = false;
            job.nextRetryAt = now + 1;
            status = "Reach restored • automatically continuing with " + newlyReachable.size()
                    + " missing statue blocks.";
            NoteClientHud.show(status);
            return;
        }

        if (now < job.nextRetryAt) return;

        if (job.verifying) {
            int scanned = 0;
            while (job.verifyCursor < job.blocks.size() && scanned < INTEGRITY_SCAN_PER_TICK) {
                StatueBlock expected = job.blocks.get(job.verifyCursor++);
                BlockState actual = client.level.getBlockState(expected.position);
                if (actual.is(expected.block)) {
                    job.confirmedPositions.add(expected.position.immutable());
                    job.blockedPositions.remove(expected.position);
                } else if (actual.isAir()) {
                    job.confirmedPositions.remove(expected.position);
                    job.blockedPositions.remove(expected.position);
                    job.missingBlocks.add(expected);
                } else {
                    // Never overwrite someone else's block, but don't allow one
                    // occupied cell to stop construction of the other limbs or
                    // the head. Keep it tracked as a conflict for later scans.
                    job.confirmedPositions.remove(expected.position);
                    job.blockedPositions.add(expected.position.immutable());
                }
                scanned++;
            }
            if (job.verifyCursor >= job.blocks.size()) {
                job.confirmed = job.confirmedPositions.size();
                if (job.missingBlocks.isEmpty()) {
                    // The integrated server path writes to the owner's own world
                    // directly and waits for its chunk updates before this scan.
                    // Remote servers retain two separated scans to catch rollbacks.
                    if (!job.integratedSingleplayer && job.stableScans == 0) {
                        job.stableScans = 1;
                        job.verifyCursor = 0;
                        job.missingBlocks.clear();
                        job.nextRetryAt = now + Math.max(4, Math.min(12, ackTimeout / 2));
                        status = "All current placements are present • checking remote server stability • scan 2/2…";
                        NoteClientHud.show(status);
                        return;
                    }
                    if (job.blockedPositions.isEmpty()) {
                        finishBuild(client, job, "Finished the 3D layered statue of " + job.username + " • all "
                                + job.blocks.size() + (job.integratedSingleplayer
                                ? " blocks applied on the local server."
                                : " blocks confirmed in two server-stability scans."));
                    } else {
                        restoreWorkingSlot(client, job);
                        job.awaitingChanges = true;
                        job.verifying = false;
                        job.stableScans = 0;
                        job.nextRetryAt = now + 20;
                        status = "Statue mostly built • " + job.blockedPositions.size()
                                + " occupied cells left untouched. Clear them and NoteClient will automatically finish the statue.";
                        NoteClientHud.warn(status);
                    }
                    return;
                }
                // A missing cell means the previous clean scan can no longer be
                // used as a stability confirmation. Repair first, then require
                // two fresh, separated scans again.
                job.stableScans = 0;

                int missingCount = job.missingBlocks.size();
                Set<BlockPos> missingPositions = new HashSet<>();
                for (StatueBlock missing : job.missingBlocks) {
                    missingPositions.add(missing.position.immutable());
                }
                int passTargetCount = job.passAttemptedPositions.size();
                long missedThisPass = job.passAttemptedPositions.stream()
                        .filter(missingPositions::contains).count();
                // Only count cells for which an interaction was actually sent.
                // Blocks skipped because they were out of reach must not make the
                // network look unreliable and collapse the rate to one/tick.
                double missingRatio = passTargetCount == 0 ? 0.0
                        : Math.min(1.0, missedThisPass / (double) passTargetCount);
                job.lastMissingRatio = missingRatio;

                List<StatueBlock> reachableMissing = job.integratedSingleplayer
                        ? List.copyOf(job.missingBlocks)
                        : job.missingBlocks.stream()
                                .filter(block -> findPlacementHit(client, block.position) != null)
                                .toList();
                if (reachableMissing.isEmpty()) {
                    // Keep every missing cell for periodic automatic reach checks.
                    // Once the player climbs/approaches the upper section, the
                    // next scan resumes repairs without requiring R.
                    job.awaitingReach = true;
                    restoreWorkingSlot(client, job);
                    job.passBlocks = List.copyOf(job.missingBlocks);
                    job.retryPlacements.clear();
                    job.retryQueuedPositions.clear();
                    job.passPlacementAttempts.clear();
                    job.passAttemptedPositions.clear();
                    job.unreachablePositions.clear();
                    job.verifying = false;
                    job.cursor = 0;
                    job.nextRetryAt = now + 10;
                    status = "Waiting for reach • " + missingCount + " statue blocks remain, likely including the upper head. "
                            + "Move closer/higher, or request /reach 100 in Settings if the server allows it; automatic retry is enabled.";
                    NoteClientHud.warn(status);
                    return;
                }

                snapshotWorkingSlot(client, job);
                // Stronger server rejection means a stronger backoff. A clean
                // repair pass can recover the normal two-per-tick pipeline.
                int currentRate = Math.max(1, job.placementsPerTick);
                int nextRate;
                if (missingRatio >= 0.75) {
                    nextRate = Math.max(1, (int) Math.floor(currentRate * 0.50));
                } else if (missingRatio >= 0.50) {
                    nextRate = Math.max(1, (int) Math.floor(currentRate * 0.65));
                } else if (missingRatio >= 0.20) {
                    nextRate = Math.max(1, (int) Math.floor(currentRate * 0.80));
                } else {
                    nextRate = Math.min(NoteClientConfig.buildActionsPerTick(), currentRate + 1);
                }
                job.placementsPerTick = Math.min(NoteClientConfig.buildActionsPerTick(), nextRate);
                // If the server only accepts part of a batch, fall back to a
                // single placement per tick—not one placement every several
                // seconds. The severe-rejection case gets one extra tick between
                // placements before the next integrity scan.
                job.placementIntervalTicks = missingRatio >= 0.75
                        ? Math.min(2, MAX_PLACEMENT_INTERVAL_TICKS)
                        : MIN_PLACEMENT_INTERVAL_TICKS;

                int pingWindow = pendingLimit(pingMs, job.placementsPerTick);
                double windowScale = Math.max(0.10, 1.0 - (0.45 + missingRatio * 0.45));
                int adaptiveWindow = Math.max(1, (int) Math.floor(pingWindow * windowScale));
                if (missingRatio < 0.20) {
                    job.maxInFlight = pingWindow;
                } else {
                    job.maxInFlight = Math.max(1, Math.min(job.maxInFlight <= 0
                            ? pingWindow : job.maxInFlight, adaptiveWindow));
                }
                job.repairPass++;
                job.passBlocks = List.copyOf(reachableMissing);
                job.missingBlocks.clear();
                job.retryPlacements.clear();
                job.retryQueuedPositions.clear();
                job.passPlacementAttempts.clear();
                job.passAttemptedPositions.clear();
                job.unreachablePositions.clear();
                job.cursor = 0;
                job.verifying = false;
                job.awaitingReach = false;
                job.noFaceRetries = 0;
                long settle = Math.max(2, Math.min(10,
                        ackTimeout / 3L + job.repairPass + (long) Math.ceil(missingRatio * 4)));
                job.nextRetryAt = now + settle;
                status = "Automatic repair pass " + job.repairPass + " • " + missingCount + " total missing, "
                        + reachableMissing.size() + " currently reachable • " + Math.round(missingRatio * 100)
                        + "% of attempted cells missed • " + job.confirmed + "/" + job.blocks.size()
                        + " confirmed • server-paced multiplayer placement • max "
                        + job.maxInFlight + " in flight.";
                NoteClientHud.show(status);
                return;
            }
            status = "Verifying statue • " + job.verifyCursor + "/" + job.blocks.size()
                    + " scanned • " + job.confirmedPositions.size() + " confirmed";
            return;
        }

        // A full verification always follows a complete pass and an empty
        // acknowledgement queue. It is the server's resulting world state—not
        // the number of client interactions sent—that controls progress.
        if (job.cursor >= job.passBlocks.size() && job.pending.isEmpty()
                && job.retryPlacements.isEmpty()) {
            if (job.integratedSingleplayer && job.integratedBatchesInFlight > 0) {
                status = "Building on local server • waiting for " + job.integratedBatchesInFlight + " block batch(es)…";
                return;
            }
            job.verifying = true;
            job.verifyCursor = 0;
            job.missingBlocks.clear();
            job.nextRetryAt = now + (job.integratedSingleplayer
                    ? SINGLEPLAYER_VERIFY_DELAY_TICKS : Math.max(2, ackTimeout));
            status = job.integratedSingleplayer
                    ? "Local server batches applied • checking all " + job.blocks.size() + " statue cells…"
                    : "Waiting for multiplayer server updates • then scanning all " + job.blocks.size() + " statue cells…";
            return;
        }

        int budget = job.integratedSingleplayer ? NoteClientConfig.buildActionsPerTick() : job.placementsPerTick;
        int pingPendingLimit = job.integratedSingleplayer ? NoteClientConfig.buildActionsPerTick()
                : pendingLimit(pingMs, job.placementsPerTick);
        if (!job.integratedSingleplayer) {
            if (job.maxInFlight <= 0) job.maxInFlight = pingPendingLimit;
            job.maxInFlight = Math.max(1, Math.min(job.maxInFlight, pingPendingLimit));
        }
        int pendingLimit = job.integratedSingleplayer ? Integer.MAX_VALUE : job.maxInFlight;
        List<StatueBlock> integratedBatch = job.integratedSingleplayer ? new ArrayList<>() : null;
        int sent = 0;
        int examined = 0;
        // Failed/out-of-reach cells are deferred, not allowed to pin the cursor.
        // This is essential for tall statues: the client can finish all nearby
        // cells, run the automatic integrity scan, and wait for the player to
        // move within reach of the upper body/head.
        int examineBudget = Math.max(32, budget * 8);
        if (job.placementsPerTick == 1 && now < job.nextPlacementAt) return;
        while ((job.cursor < job.passBlocks.size() || !job.retryPlacements.isEmpty())
                && sent < budget && examined < examineBudget
                && job.pending.size() < pendingLimit) {
            // A timed-out cell gets priority as soon as its retry is ready. If
            // its delay has not elapsed, keep filling the normal build queue.
            PlacementRetry queuedRetry = job.retryPlacements.peekFirst();
            boolean isRetry = queuedRetry != null && now >= queuedRetry.readyAt;
            StatueBlock placement;
            if (isRetry) {
                queuedRetry = job.retryPlacements.removeFirst();
                job.retryQueuedPositions.remove(queuedRetry.placement.position);
                placement = queuedRetry.placement;
            } else if (job.cursor < job.passBlocks.size()) {
                placement = job.passBlocks.get(job.cursor);
            } else {
                break;
            }
            examined++;
            BlockPos key = placement.position.immutable();
            BlockState current = client.level.getBlockState(placement.position);
            if (current.is(placement.block)) {
                // This is the key idempotency check: a successful first attempt
                // makes the second attempt a no-op. Never place over a correct cell.
                job.confirmedPositions.add(key);
                job.blockedPositions.remove(key);
                if (!isRetry) job.cursor++;
                continue;
            }
            if (!current.isAir()) {
                // A different block occupies the cell. Never overwrite it, and
                // never spend the second attempt against another player's block.
                job.blockedPositions.add(key);
                job.confirmedPositions.remove(key);
                if (!isRetry) job.cursor++;
                continue;
            }

            if (job.integratedSingleplayer) {
                // Local singleplayer uses direct authoritative writes, so it does
                // not need duplicate simulated interactions or multiplayer retries.
                integratedBatch.add(placement);
                if (!isRetry) job.cursor++;
                sent++;
                continue;
            }

            // Remote servers still receive ordinary vanilla block interactions.
            // Each cell may be interacted with twice in this pass: once normally,
            // then one retry only if the target remains empty after confirmation.
            if (findPlacementHit(client, placement.position) == null) {
                job.unreachablePositions.add(key);
                if (!isRetry) job.cursor++;
                continue;
            }

            boolean interactionAccepted = sendPlacement(client, job, placement);
            int attemptNumber = job.passPlacementAttempts.merge(key, 1, Integer::sum);
            job.passAttemptedPositions.add(key);
            if (!isRetry) job.cursor++;
            sent++;
            if (job.placementsPerTick == 1) job.nextPlacementAt = now + job.placementIntervalTicks;
            if (!interactionAccepted) {
                // PASS/no local acceptance gets one short retry, but never a
                // tight same-tick click loop.
                if (attemptNumber < PLACEMENT_ATTEMPTS_PER_CELL) {
                    enqueuePlacementRetry(job, placement, now, 1);
                }
                continue;
            }

            job.attemptedPositions.add(key);
            job.unreachablePositions.remove(key);
            job.pending.add(new PendingPlacement(placement, now));
        }

        if (job.integratedSingleplayer && !integratedBatch.isEmpty()) {
            if (!queueIntegratedServerBatch(client, job, integratedBatch)) {
                job.cursor = Math.max(0, job.cursor - integratedBatch.size());
                status = "Local server batch could not be queued • retrying automatically…";
                return;
            }
        }

        job.confirmed = job.confirmedPositions.size();
        status = (job.repairPass == 0 ? "Building " : "Repair pass " + job.repairPass + " • ")
                + job.username + " • " + job.confirmed + "/" + job.blocks.size()
                + " confirmed • " + (job.integratedSingleplayer
                ? "local server batch " + NoteClientConfig.buildActionsPerTick() + "/tick"
                : job.pending.size() + " awaiting server • " + job.placementsPerTick + "/tick • up to 2 tries/cell • " + pingLabel(pingMs));
    }

    /**
     * Apply a chunk of statue blocks on the player's own integrated server.
     * Remote multiplayer never calls this method: it always uses useItemOn().
     */
    private static boolean queueIntegratedServerBatch(Minecraft client, StatueJob job,
                                                       List<StatueBlock> blocks) {
        var server = client == null ? null : client.getSingleplayerServer();
        if (server == null || blocks == null || blocks.isEmpty()) return false;
        List<StatueBlock> immutableBatch = List.copyOf(blocks);
        var dimension = job.level.dimension();
        job.integratedBatchesInFlight++;
        try {
            server.execute(() -> {
                Set<BlockPos> placed = new HashSet<>();
                Set<BlockPos> occupied = new HashSet<>();
                try {
                    ServerLevel serverLevel = server.getLevel(dimension);
                    if (serverLevel != null) {
                        for (StatueBlock expected : immutableBatch) {
                            BlockPos pos = expected.position;
                            if (serverLevel.isOutsideBuildHeight(pos)
                                    || !serverLevel.getWorldBorder().isWithinBounds(pos)
                                    || !serverLevel.hasChunkAt(pos)) continue;
                            BlockState actual = serverLevel.getBlockState(pos);
                            if (actual.is(expected.block)
                                    || (actual.isAir() && serverLevel.setBlock(
                                            pos, expected.block.defaultBlockState(), 3))) {
                                placed.add(pos.immutable());
                            } else if (!actual.isAir()) {
                                occupied.add(pos.immutable());
                            }
                        }
                    }
                } catch (Throwable failure) {
                    System.err.println("[NoteClient] Integrated statue batch failed: " + failure.getMessage());
                }

                client.execute(() -> {
                    job.integratedBatchesInFlight = Math.max(0, job.integratedBatchesInFlight - 1);
                    if (client.level != job.level) return;
                    for (StatueBlock expected : immutableBatch) {
                        BlockPos pos = expected.position.immutable();
                        if (placed.contains(pos)) {
                            job.attemptedPositions.add(pos);
                            job.passAttemptedPositions.add(pos);
                            job.blockedPositions.remove(pos);
                        } else if (occupied.contains(pos)) {
                            job.blockedPositions.add(pos);
                            job.confirmedPositions.remove(pos);
                        }
                    }
                });
            });
            return true;
        } catch (Throwable failure) {
            job.integratedBatchesInFlight = Math.max(0, job.integratedBatchesInFlight - 1);
            System.err.println("[NoteClient] Could not queue integrated statue batch: " + failure.getMessage());
            return false;
        }
    }

    private static void tickRemoval(Minecraft client, StatueJob job, long now,
                                    int pingMs, int ackTimeout, int confirmGrace) {
        if (job.integratedSingleplayer && job.integratedBatchesInFlight > 0) {
            status = "Undo queued • waiting for " + job.integratedBatchesInFlight
                    + " local server batch(es) to finish before removing blocks…";
            return;
        }
        // Creative breaks are immediate, but the client predicts the air state
        // before the server confirms it. Keep a ping-aware confirmation grace so
        // a rejected break is not mistaken for a successful deletion. The grace
        // applies to the whole batch in parallel, not once per block.
        int removalConfirmGrace = pingMs < 0 ? 10
                : Math.max(STATUE_REMOVAL_CONFIRM_GRACE_TICKS,
                Math.min(80, (int) Math.ceil(pingMs / 50.0) + 4));
        confirmGrace = removalConfirmGrace;
        if (!job.removalInitialized) {
            if (!job.pending.isEmpty()) {
                status = "Removal queued • waiting for " + job.pending.size()
                        + " in-flight placements to settle before breaking anything…";
                return;
            }
            if (now < job.removalWaitUntil) return;
            job.removalQueue.clear();
            job.removalDeferred.clear();
            job.pendingRemovals.clear();
            for (StatueBlock block : job.blocks) {
                if (!job.attemptedPositions.contains(block.position)) continue;
                BlockState actual = client.level.getBlockState(block.position);
                if (actual.is(block.block)) job.removalQueue.add(block);
                else job.attemptedPositions.remove(block.position);
            }
            job.removalInitialCount = job.removalQueue.size();
            job.removedCount = 0;
            job.removalCursor = 0;
            job.removalInitialized = true;
            status = "Removing statue • " + job.removalInitialCount
                    + " tracked blocks • fast batched cleanup enabled. Unrelated blocks will be left alone.";
            NoteClientHud.show(status);
        }

        // Process acknowledgements/retries for every outstanding break together.
        for (int i = 0; i < job.pendingRemovals.size();) {
            PendingRemoval pending = job.pendingRemovals.get(i);
            BlockState actual = client.level.getBlockState(pending.block.position);
            long age = now - pending.sentAt;
            if (actual.isAir() && age >= confirmGrace) {
                job.attemptedPositions.remove(pending.block.position);
                job.confirmedPositions.remove(pending.block.position);
                job.removedCount++;
                job.pendingRemovals.remove(i);
                continue;
            }
            if (!actual.isAir() && !actual.is(pending.block.block)) {
                // Someone changed the position after our break request. Never
                // continue breaking a replacement block.
                job.attemptedPositions.remove(pending.block.position);
                job.pendingRemovals.remove(i);
                continue;
            }
            if (age >= ackTimeout) {
                if (!withinStatueReach(client, pending.block.position)) {
                    job.pendingRemovals.remove(i);
                    job.removalDeferred.add(pending.block);
                    continue;
                }
                if (pending.attempts >= MAX_STATUE_REMOVAL_RETRIES) {
                    job.paused = true;
                    status = "Removal paused • server has not confirmed "
                            + pending.block.position.toShortString()
                            + ". Check reach/permissions, then press O to retry removal.";
                    NoteClientHud.warn(status);
                    return;
                }
                sendStatueBreak(client, pending.block.position);
                pending.attempts++;
                pending.sentAt = now;
            }
            i++;
        }

        int sent = 0;
        while (job.removalCursor < job.removalQueue.size()
                && sent < NoteClientConfig.buildActionsPerTick()
                && job.pendingRemovals.size() < MAX_PENDING_STATUE_REMOVALS) {
            StatueBlock block = job.removalQueue.get(job.removalCursor++);
            BlockState actual = client.level.getBlockState(block.position);
            if (actual.isAir() || !actual.is(block.block)) {
                job.attemptedPositions.remove(block.position);
                continue;
            }
            if (!withinStatueReach(client, block.position)) {
                job.removalDeferred.add(block);
                continue;
            }
            if (sendStatueBreak(client, block.position)) {
                job.pendingRemovals.add(new PendingRemoval(block, now));
                sent++;
            } else {
                job.removalDeferred.add(block);
            }
        }

        // Retry deferred blocks in the same batched pipeline when they enter reach.
        int deferredToCheck = job.removalDeferred.size();
        for (int checked = 0; checked < deferredToCheck
                && sent < NoteClientConfig.buildActionsPerTick()
                && job.pendingRemovals.size() < MAX_PENDING_STATUE_REMOVALS; checked++) {
            StatueBlock block = job.removalDeferred.remove(0);
            BlockState actual = client.level.getBlockState(block.position);
            if (actual.isAir() || !actual.is(block.block)) {
                job.attemptedPositions.remove(block.position);
                continue;
            }
            if (!withinStatueReach(client, block.position)) {
                job.removalDeferred.add(block);
                continue;
            }
            if (sendStatueBreak(client, block.position)) {
                job.pendingRemovals.add(new PendingRemoval(block, now));
                sent++;
            } else {
                job.removalDeferred.add(block);
            }
        }

        if (job.attemptedPositions.isEmpty() && job.pendingRemovals.isEmpty()
                && job.removalDeferred.isEmpty() && job.removalCursor >= job.removalQueue.size()) {
            restoreWorkingSlot(client, job);
            activeBuild = undoHistory.pollLast();
            status = activeBuild == null
                    ? "Undid the newest statue • undo history is now empty."
                    : "Undid the newest statue • " + (undoHistory.size() + 1)
                    + " older statue(s) remain. Press Undo Last again to remove the previous one.";
            NoteClientHud.show(status);
            return;
        }

        if (now % 10 == 0) {
            status = "Undoing newest statue • " + job.removedCount + "/" + job.removalInitialCount
                    + " confirmed • " + job.pendingRemovals.size() + " awaiting server • "
                    + job.removalDeferred.size() + " out of reach";
        }
    }

    private static boolean withinStatueReach(Minecraft client, BlockPos position) {
        if (client == null || client.player == null) return false;
        double reach = client.player.getAttributeValue(Attributes.BLOCK_INTERACTION_RANGE);
        if (NoteClientConfig.serverReachOverride() == 100) reach = Math.max(reach, 100.0);
        return client.player.getEyePosition().distanceTo(Vec3.atCenterOf(position))
                <= Math.max(0.5, reach - 0.5);
    }

    private static boolean sendStatueBreak(Minecraft client, BlockPos position) {
        if (client == null || client.gameMode == null || !withinStatueReach(client, position)) return false;
        boolean started = client.gameMode.startDestroyBlock(position, Direction.UP);
        if (started) client.gameMode.stopDestroyBlock();
        return started;
    }

    private static int initialPlacementsPerTick(int pingMs) {
        // The manual setting is the requested pace for every builder. Ping and
        // server-confirmed integrity scans still regulate the remote in-flight window.
        return NoteClientConfig.buildActionsPerTick();
    }

    private static int initialPlacementIntervalTicks(int pingMs) {
        // The server pipeline is paced by available acknowledgement slots, not
        // by a blanket multi-tick sleep between every successful placement.
        return MIN_PLACEMENT_INTERVAL_TICKS;
    }

    private static int placementConfirmationGraceTicks(int pingMs) {
        if (pingMs < 0) return UNKNOWN_PING_CONFIRM_GRACE_TICKS;
        int halfRoundTripTicks = (int) Math.ceil(pingMs / 100.0);
        return Math.max(MIN_CONFIRM_GRACE_TICKS,
                Math.min(MAX_CONFIRM_GRACE_TICKS, halfRoundTripTicks));
    }

    private static int currentPingMs(Minecraft client) {
        try {
            if (client == null || client.player == null || client.getConnection() == null) return -1;
            PlayerInfo info = client.getConnection().getPlayerInfo(client.player.getUUID());
            return info == null || info.getLatency() < 0 ? -1 : info.getLatency();
        } catch (Throwable ignored) {
            return -1;
        }
    }

    private static String pingLabel(int pingMs) {
        return pingMs < 0 ? "ping unknown" : pingMs + " ms ping";
    }

    private static int acknowledgementTimeoutTicks(int pingMs, int repairPass) {
        int networkTicks = pingMs < 0 ? 12 : (int) Math.ceil(pingMs / 50.0) + 6;
        return Math.max(MIN_ACK_TIMEOUT_TICKS,
                Math.min(MAX_ACK_TIMEOUT_TICKS, networkTicks + Math.max(0, repairPass) * 2));
    }

    private static int pendingLimit(int pingMs, int placementsPerTick) {
        // Keep enough room for the normal network round trip without allowing an
        // unlimited backlog. Each extra RTT tick adds at most two queued cells.
        int roundTripTicks = pingMs < 0 ? 2 : (int) Math.ceil(pingMs / 50.0);
        int latencyWindow = Math.max(INITIAL_PENDING_LIMIT,
                placementsPerTick * (roundTripTicks + 2));
        return Math.min(MAX_PENDING_LIMIT, latencyWindow);
    }

    public static void togglePause(Minecraft client) {
        StatueJob job = activeBuild;
        if (job == null) {
            NoteClientHud.warn("No statue job is available to pause.");
            return;
        }
        if (job.completed && !job.removeRequested) {
            NoteClientHud.show(job.blockedPositions.isEmpty()
                    ? "Statue is complete • press R to verify/repair or O to undo this newest statue."
                    : "Statue is partial • clear " + job.blockedPositions.size()
                    + " occupied cells, then press R to finish; O undoes the newest statue first.");
            return;
        }
        if (!job.paused) {
            job.paused = true;
            job.pausedAt = client == null || client.level == null ? 0 : client.level.getGameTime();
            if (client != null && client.gameMode != null) client.gameMode.stopDestroyBlock();
            status = "Statue paused • P resume • R retry missing cells • O undo newest statue.";
            NoteClientHud.show(status);
            return;
        }
        resumeJob(client, job);
    }

    public static void retry(Minecraft client) {
        StatueJob job = activeBuild;
        if (job == null) {
            NoteClientHud.warn("No tracked statue to retry. Load a skin and build a statue first.");
            return;
        }
        if (client == null || client.player == null || client.level != job.level
                || client.gameMode == null || client.gameMode.getPlayerMode() != GameType.CREATIVE) {
            NoteClientHud.warn("Join the statue's world in Creative mode before retrying it.");
            return;
        }
        if (job.removeRequested) {
            job.paused = false;
            for (PendingRemoval pending : job.pendingRemovals) {
                pending.attempts = 0;
                pending.sentAt = client.level.getGameTime();
            }
            status = "Statue removal resumed. Press O to restart removal checks.";
            NoteClientHud.show(status);
            return;
        }
        // An explicit R action starts a fresh integrity cycle rather than
        // inheriting the previous pass's clean-scan counter.
        job.stableScans = 0;
        if (job.completed) {
            int slot = client.player.getInventory().getSelectedSlot();
            job.originalSlot = slot;
            job.workingSlot = slot;
            job.originalStack = client.player.getInventory().getItem(slot).copy();
            job.slotSnapshotActive = true;
            job.completed = false;
            job.verifying = true;
            job.verifyCursor = 0;
            job.missingBlocks.clear();
            job.pending.clear();
            job.retryPlacements.clear();
            job.retryQueuedPositions.clear();
            job.passPlacementAttempts.clear();
            job.passAttemptedPositions.clear();
            job.unreachablePositions.clear();
            job.blockedPositions.clear();
            job.awaitingReach = false;
            int pingMs = job.integratedSingleplayer ? 0 : currentPingMs(client);
            job.placementsPerTick = job.integratedSingleplayer
                    ? NoteClientConfig.buildActionsPerTick() : initialPlacementsPerTick(pingMs);
            job.maxInFlight = job.integratedSingleplayer ? 0 : pendingLimit(pingMs, job.placementsPerTick);
            job.lastMissingRatio = 0.0;
            job.placementIntervalTicks = initialPlacementIntervalTicks(pingMs);
            job.nextPlacementAt = client.level.getGameTime() + job.placementIntervalTicks;
        } else if (job.verifying) {
            job.awaitingReach = false;
            job.verifyCursor = 0;
            job.missingBlocks.clear();
        } else {
            job.awaitingReach = false;
            job.retryRequested = true;
        }
        job.paused = false;
        job.nextRetryAt = client.level.getGameTime() + 1;
        status = "Manual retry requested • scanning the complete statue and retrying only missing cells.";
        NoteClientHud.show(status);
    }

    public static void remove(Minecraft client) {
        StatueJob job = activeBuild;
        if (job == null) {
            activeBuild = undoHistory.pollLast();
            job = activeBuild;
        }
        if (job == null) {
            NoteClientHud.warn("No statue remains in the undo history.");
            return;
        }
        if (client == null || client.player == null || client.level != job.level
                || client.gameMode == null || client.gameMode.getPlayerMode() != GameType.CREATIVE) {
            NoteClientHud.warn("Join the statue's world in Creative mode before removing it.");
            return;
        }
        if (job.removeRequested && job.paused) {
            job.paused = false;
            for (PendingRemoval pending : job.pendingRemovals) {
                pending.attempts = 0;
                pending.sentAt = client.level.getGameTime();
            }
            status = "Undo Last retry started. Only matching blocks from the newest statue will be broken.";
            NoteClientHud.show(status);
            return;
        }
        restoreWorkingSlot(client, job);
        job.removeRequested = true;
        job.retryPlacements.clear();
        job.retryQueuedPositions.clear();
        job.paused = false;
        job.retryRequested = false;
        job.awaitingReach = false;
        job.verifying = false;
        job.stableScans = 0;
        job.blockedPositions.clear();
        job.removalInitialized = false;
        job.removalCursor = 0;
        // tick() already waits for in-flight placements to settle. Only a short
        // grace is needed before starting the first batch of Creative breaks.
        job.removalWaitUntil = client.level.getGameTime() + STATUE_REMOVAL_CONFIRM_GRACE_TICKS;
        job.removalQueue.clear();
        job.removalDeferred.clear();
        job.pendingRemovals.clear();
        status = "Undo Last queued • waiting for in-flight placements, then safely removing only the newest statue.";
        NoteClientHud.warn(status);
    }

    private static void resumeJob(Minecraft client, StatueJob job) {
        long now = client == null || client.level == null ? job.pausedAt : client.level.getGameTime();
        for (int i = 0; i < job.pending.size(); i++) {
            PendingPlacement old = job.pending.get(i);
            job.pending.set(i, new PendingPlacement(old.placement, now));
        }
        for (PendingRemoval pending : job.pendingRemovals) pending.sentAt = now;
        job.nextRetryAt = now + 1;
        job.removalWaitUntil = now + 1;
        job.paused = false;
        status = "Statue resumed • P pause • R retry missing cells • O undo newest statue.";
        NoteClientHud.show(status);
    }

    private static void enqueuePlacementRetry(StatueJob job, StatueBlock placement, long now, int delayTicks) {
        if (job == null || placement == null) return;
        BlockPos key = placement.position.immutable();
        int attempts = job.passPlacementAttempts.getOrDefault(key, 0);
        if (attempts >= PLACEMENT_ATTEMPTS_PER_CELL || !job.retryQueuedPositions.add(key)) return;
        job.retryPlacements.addLast(new PlacementRetry(placement, now + Math.max(0, delayTicks)));
    }

    private static boolean sendPlacement(Minecraft client, StatueJob job, StatueBlock placement) {
        LocalPlayer player = client.player;
        Item item = placement.block.asItem();
        int slot = job.workingSlot;
        if (player.getInventory().getSelectedSlot() != slot) player.getInventory().setSelectedSlot(slot);
        ItemStack held = player.getInventory().getItem(slot);
        if (!held.is(item)) {
            ItemStack replacement = new ItemStack(item, 64);
            player.getInventory().setItem(slot, replacement.copy());
            client.gameMode.handleCreativeModeItemAdd(replacement.copy(), 36 + slot);
        }

        BlockHitResult hit = findPlacementHit(client, placement.position);
        if (hit == null || !isSafePlacementAnchor(client.level.getBlockState(hit.getBlockPos()))) return false;
        double reach = player.getAttributeValue(Attributes.BLOCK_INTERACTION_RANGE);
        if (NoteClientConfig.serverReachOverride() == 100) reach = Math.max(reach, 100.0);
        if (player.getEyePosition().distanceTo(hit.getLocation()) > Math.max(0.5, reach - 0.5)) return false;
        net.minecraft.world.InteractionResult result = client.gameMode.useItemOn(
                player, InteractionHand.MAIN_HAND, hit);
        return result != null && result.consumesAction();
    }

    /** Re-snapshot the selected slot when an automatic repair resumes after waiting. */
    private static void snapshotWorkingSlot(Minecraft client, StatueJob job) {
        if (job.slotSnapshotActive || client == null || client.player == null) return;
        int slot = client.player.getInventory().getSelectedSlot();
        job.originalSlot = slot;
        job.workingSlot = slot;
        job.originalStack = client.player.getInventory().getItem(slot).copy();
        job.slotSnapshotActive = true;
    }

    /**
     * A use-item-on packet against a workstation can open its GUI instead of
     * placing the held block. Never use a block entity or a known menu-opening
     * workstation/container as the clicked support face.
     */
    private static boolean isSafePlacementAnchor(BlockState state) {
        if (state == null || state.isAir() || state.hasBlockEntity()) return false;
        Identifier id = BuiltInRegistries.BLOCK.getKey(state.getBlock());
        return id != null && !MENU_OPENING_ANCHOR_BLOCKS.contains(id.getPath());
    }

    /** Pick the closest reachable sturdy, non-interactive face, not a workstation menu. */
    private static BlockHitResult findPlacementHit(Minecraft client, BlockPos target) {
        if (client == null || client.player == null || client.level == null) return null;
        LocalPlayer player = client.player;
        double reach = player.getAttributeValue(Attributes.BLOCK_INTERACTION_RANGE);
        if (NoteClientConfig.serverReachOverride() == 100) reach = Math.max(reach, 100.0);
        double maxDistance = Math.max(0.5, reach - 0.5);
        Vec3 eye = player.getEyePosition();
        BlockHitResult best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Direction offset : Direction.values()) {
            BlockPos neighbor = target.relative(offset);
            BlockState state = client.level.getBlockState(neighbor);
            Direction face = offset.getOpposite();
            if (!isSafePlacementAnchor(state)
                    || !state.isFaceSturdy(client.level, neighbor, face)) continue;
            Vec3 location = Vec3.atCenterOf(neighbor).add(
                    face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5);
            double distance = eye.distanceTo(location);
            if (distance > maxDistance || distance >= bestDistance) continue;
            best = new BlockHitResult(location, face, neighbor, false);
            bestDistance = distance;
        }
        return best;
    }

    /** Stops construction but retains ownership records so R can repair or O can undo the newest statue. */
    public static void cancel(Minecraft client) {
        StatueJob job = activeBuild;
        if (job == null || job.completed || job.removeRequested) {
            status = "No statue/model build is currently running.";
            NoteClientHud.show(status);
            return;
        }
        job.stopRequested = true;
        job.paused = false;
        job.retryRequested = false;
        job.retryPlacements.clear();
        job.retryQueuedPositions.clear();
        job.awaitingReach = false;
        job.awaitingChanges = false;
        job.verifying = false;
        status = "Stopping • no new placements will be sent. Waiting for already-sent placements to settle.";
        NoteClientHud.show(status);
        if (job.pending.isEmpty() && job.integratedBatchesInFlight <= 0) {
            finishBuild(client, job, "Stopped building. Existing blocks remain in the world; press O to undo the newest build.");
        }
    }

    public static void onDisconnect() {
        activeBuild = null;
        undoHistory.clear();
        loading = false;
        lookupGeneration++;
        if (loadedSkin != null) status = "Disconnected. The loaded skin preview is still available.";
    }

    private static void restoreWorkingSlot(Minecraft client, StatueJob job) {
        if (!job.slotSnapshotActive || client == null || client.player == null) return;
        LocalPlayer player = client.player;
        ItemStack restore = job.originalStack.copy();
        player.getInventory().setItem(job.workingSlot, restore.copy());
        if (client.gameMode != null && client.gameMode.getPlayerMode() == GameType.CREATIVE) {
            client.gameMode.handleCreativeModeItemAdd(restore.copy(), 36 + job.workingSlot);
        }
        player.getInventory().setSelectedSlot(job.originalSlot);
        job.slotSnapshotActive = false;
    }

    private static void finishBuild(Minecraft client, StatueJob job, String message) {
        restoreWorkingSlot(client, job);
        job.completed = true;
        job.stopRequested = false;
        job.paused = false;
        job.verifying = false;
        job.retryRequested = false;
        job.awaitingReach = false;
        job.pending.clear();
        if (job.attemptedPositions.isEmpty() && job.confirmedPositions.isEmpty()
                && job.blockedPositions.isEmpty()) activeBuild = undoHistory.pollLast();
        status = message;
        // Statue jobs share the HUD progress surface with song/schematic jobs.
        // Mark this job finished so a stale song progress counter cannot leave a
        // progress panel visible after Stop has fully settled.
        BuildClientState.updateLocal(job.confirmedPositions.size(), job.blocks.size(), 0,
                4, true, false, message);
        NoteClientHud.show(message);
    }

    private record SkinData(String username, boolean slim, int[] basePixels, int[] outerPixels,
                            int blockCount, BufferedImage sourceImage, boolean localFile, String sourceName,
                            List<LocalStatueBlock> modelBlocks) {}
    private record LocalSkinResult(Path path, SkinData skin) {}
    private record LocalStatueBlock(int x, int y, int z, Block block, int layerId) {}
    private record LayeredBlock(Block block, int layerId) {}
    private record FaceUv(int x, int y, int width, int height) {}
    private record CuboidTexture(String name, int x, int y, int z, int width, int height, int depth,
                                 FaceUv front, FaceUv back, FaceUv top, FaceUv bottom,
                                 FaceUv left, FaceUv right, boolean outer, boolean head, int layerId) {}
    @FunctionalInterface
    private interface FacePosition {
        BlockPos at(int u, int v);
    }
    private record PaletteColor(Block block, int rgb, double[] lab, int preference) {}
    private record StatueBlock(BlockPos position, Block block) {}

    private static final class PlacementRetry {
        private final StatueBlock placement;
        private final long readyAt;

        private PlacementRetry(StatueBlock placement, long readyAt) {
            this.placement = placement;
            this.readyAt = readyAt;
        }
    }

    private static final class PendingPlacement {
        private final StatueBlock placement;
        private final long sentAt;

        private PendingPlacement(StatueBlock placement, long sentAt) {
            this.placement = placement;
            this.sentAt = sentAt;
        }
    }

    private static final class PendingRemoval {
        private final StatueBlock block;
        private long sentAt;
        private int attempts;

        private PendingRemoval(StatueBlock block, long sentAt) {
            this.block = block;
            this.sentAt = sentAt;
            this.attempts = 1;
        }
    }

    private static final class StatueJob {
        private final String username;
        private final ClientLevel level;
        private final List<StatueBlock> blocks;
        private final boolean integratedSingleplayer;
        private List<StatueBlock> passBlocks;
        private final List<PendingPlacement> pending = new ArrayList<>();
        private final Deque<PlacementRetry> retryPlacements = new ArrayDeque<>();
        private final Set<BlockPos> retryQueuedPositions = new HashSet<>();
        private final Map<BlockPos, Integer> passPlacementAttempts = new LinkedHashMap<>();
        private final List<StatueBlock> missingBlocks = new ArrayList<>();
        private final Set<BlockPos> confirmedPositions = new HashSet<>();
        private final Set<BlockPos> attemptedPositions = new HashSet<>();
        private final Set<BlockPos> passAttemptedPositions = new HashSet<>();
        private final Set<BlockPos> unreachablePositions = new HashSet<>();
        private final Set<BlockPos> blockedPositions = new HashSet<>();
        private final List<StatueBlock> removalQueue = new ArrayList<>();
        private final List<StatueBlock> removalDeferred = new ArrayList<>();
        private final List<PendingRemoval> pendingRemovals = new ArrayList<>();
        private int originalSlot;
        private int workingSlot;
        private ItemStack originalStack;
        private int cursor;
        private int verifyCursor;
        private int confirmed;
        private int repairPass;
        private int noFaceRetries;
        private int placementsPerTick;
        private int configuredBuildRate = NoteClientConfig.buildActionsPerTick();
        private int maxInFlight;
        private int integratedBatchesInFlight;
        private double lastMissingRatio;
        private int lastPingMs = -1;
        private int placementIntervalTicks = 1;
        private int removalCursor;
        private int removalInitialCount;
        private int removedCount;
        private int stableScans;
        private boolean verifying;
        private boolean retryRequested;
        private boolean awaitingReach;
        private boolean awaitingChanges;
        private boolean paused;
        private boolean stopRequested;
        private boolean completed;
        private boolean slotSnapshotActive = true;
        private boolean removeRequested;
        private boolean removalInitialized;
        private long pausedAt;
        private long removalWaitUntil;
        private long nextPlacementAt;
        private long nextRetryAt;

        private StatueJob(String username, ClientLevel level, List<StatueBlock> blocks,
                          int originalSlot, ItemStack originalStack, boolean integratedSingleplayer) {
            this.username = username;
            this.level = level;
            this.blocks = List.copyOf(blocks);
            this.integratedSingleplayer = integratedSingleplayer;
            this.passBlocks = this.blocks;
            this.originalSlot = originalSlot;
            this.workingSlot = originalSlot;
            this.originalStack = originalStack.copy();
        }
    }
}
