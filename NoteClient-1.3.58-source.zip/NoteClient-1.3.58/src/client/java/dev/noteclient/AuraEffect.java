package dev.noteclient;

import dev.noteclient.network.AuraControlPayload;
import dev.noteclient.network.AuraStatusPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;

/** Client UI/controller for the owner-authorized server-visible block Aura. */
public final class AuraEffect {
    private static volatile boolean active;
    private static volatile boolean pending;
    private static long pendingAt = Long.MIN_VALUE;

    private AuraEffect() {}

    public static boolean isActive() {
        return active;
    }

    public static boolean isPending() {
        return pending;
    }

    /**
     * Requests the server companion to create or remove the real Aura blocks.
     * A client-only visual fallback is intentionally not used: it would not be
     * visible to other players and would misrepresent the requested behavior.
     */
    public static void toggle(Minecraft client) {
        if (client == null || client.player == null || client.level == null) {
            NoteClientHud.warn("Join a multiplayer world before enabling server Aura.");
            return;
        }
        if (pending) {
            NoteClientHud.warn("Waiting for the server to answer the previous Aura request.");
            return;
        }
        if (!ClientPlayNetworking.canSend(AuraControlPayload.TYPE)) {
            NoteClientHud.warn("Server-visible Aura needs the NoteClient Server Companion installed on this server.");
            return;
        }

        boolean enable = !active;
        ClientPlayNetworking.send(new AuraControlPayload(enable));
        pending = true;
        pendingAt = client.level.getGameTime();
        NoteClientHud.show(enable
                ? "Requesting server-visible Aura…"
                : "Requesting server Aura cleanup…");
    }

    public static void acceptServerStatus(Minecraft client, AuraStatusPayload payload) {
        if (payload == null) return;
        active = payload.active();
        pending = false;
        pendingAt = Long.MIN_VALUE;
        if (payload.message() == null || payload.message().isBlank()) return;
        if (payload.active()) NoteClientHud.show(payload.message());
        else NoteClientHud.warn(payload.message());
        SongBrowserScreen.refreshIfOpen(client);
    }

    public static void tick(Minecraft client) {
        if (!pending) return;
        if (client == null || client.player == null || client.level == null) {
            onDisconnect();
            return;
        }
        if (pendingAt != Long.MIN_VALUE && client.level.getGameTime() - pendingAt > 100) {
            pending = false;
            pendingAt = Long.MIN_VALUE;
            NoteClientHud.warn("No Aura response arrived. Check that the server companion is installed and enabled.");
        }
    }

    public static void onDisconnect() {
        active = false;
        pending = false;
        pendingAt = Long.MIN_VALUE;
    }
}
