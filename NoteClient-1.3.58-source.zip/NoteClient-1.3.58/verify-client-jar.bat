@echo off
setlocal
set "JAR=%~dp0build\release\NoteClient-1.3.57-Minecraft-26.2.jar"

if not exist "%JAR%" (
    echo ERROR: Client release JAR not found:
    echo %JAR%
    echo Run gradlew.bat build first.
    exit /b 1
)

jar tf "%JAR%" | findstr /x /c:"dev/noteclient/NoteClient.class" >nul
if errorlevel 1 (
    echo ERROR: NoteClient client entrypoint is missing from the release JAR.
    exit /b 1
)

jar tf "%JAR%" | findstr /x /c:"dev/noteclient/NoteClientCommon.class" >nul
if not errorlevel 1 (
    echo ERROR: The server-only NoteClientCommon class is still in the client JAR.
    exit /b 1
)

jar tf "%JAR%" | findstr /x /c:"dev/noteclient/AuraServerEffect.class" >nul
if not errorlevel 1 (
    echo ERROR: The server-only Aura controller is still in the client JAR.
    exit /b 1
)

echo OK: Client JAR contains NoteClient and excludes the server-only initializer and Aura controller.
echo Install this file in your Modrinth client profile:
echo %JAR%
exit /b 0
