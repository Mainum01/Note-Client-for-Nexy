package dev.noteclient.voxel;

import dev.noteclient.voxel.core.SkinVoxelizer;
import dev.noteclient.voxel.core.VoxelCamera;
import dev.noteclient.voxel.core.VoxelMeshBuilder;
import dev.noteclient.voxel.core.VoxelModel;
import dev.noteclient.voxel.core.VoxelRaycaster;
import dev.noteclient.voxel.core.VoxelStudioDocument;

import java.awt.image.BufferedImage;

/** Dependency-free smoke test for the engine-independent voxel math and skin pipeline. */
public final class VoxelCoreSmokeTest {
    public static void main(String[] args) {
        BufferedImage skin = new BufferedImage(64,64,BufferedImage.TYPE_INT_ARGB);
        for (int y=0;y<64;y++) for (int x=0;x<64;x++) {
            int r=(x*13+y*3)&255, g=(x*5+y*11)&255, b=(x*7+y*17)&255;
            skin.setRGB(x,y,0xFF000000|(r<<16)|(g<<8)|b);
        }
        VoxelModel model = SkinVoxelizer.fromSkin(skin,"Smoke Test",false);
        String[] expectedLayersById = {"Base skin / inner body", "Hat / head overlay", "Jacket",
                "Right sleeve / outer +1", "Left sleeve / outer +1", "Right pant", "Left pant", "Custom accessories"};
        require(model.layers().size() == expectedLayersById.length,
                "expected a base skin plus six separate Minecraft clothing layers and accessories");
        for (int id = 0; id < expectedLayersById.length; id++) {
            require(model.layer(id).name().equals(expectedLayersById[id]),
                    "skin layer id " + id + " must be " + expectedLayersById[id]);
        }
        require(model.layers().get(0).id() == 0 && model.layers().get(1).id() == 4,
                "the editor should show the inner body first and the outer left sleeve second");
        int[] layerCounts = new int[8];
        for (VoxelModel.Cell cell : model.cells()) layerCounts[cell.layerId()]++;
        for (int layer = 1; layer <= 6; layer++) {
            require(layerCounts[layer] > 0, "skin overlay layer " + layer + " must contain voxels");
            require(model.layer(layer).buildToWorld(), "skin overlay layer " + layer + " must be enabled for client-side model construction");
        }
        require(model.occupiedCount() > 100,"skin voxelization produced too few cells");
        require(model.paletteIndexAt(12, 18, 4) > 0, "imported skin torso front must remain visible");
        require(model.paletteIndexAt(12, 18, 5) == 0, "imported skin torso interior must remain hollow");
        require(model.paletteIndexAt(10, 6, 5) == 0, "imported skin leg interior must remain hollow");
        require(model.paletteIndexAt(6, 18, 5) == 0, "imported skin arm interior must remain hollow");
        require(model.layerAt(8,18,4) == 0 && model.layerAt(9,18,4) == 0,
                "right inner arm must touch the torso without a one-block gap");
        require(model.layerAt(16,18,4) == 0 && model.layerAt(17,18,4) == 0,
                "left inner arm must touch the torso without a one-block gap");
        require(model.layerAt(17,18,4) == 0 && model.layerAt(17,18,3) == 4,
                "left sleeve front shell must be a separate second editor layer beyond the inner arm");
        require(model.layerAt(21,18,4) == 4 && model.layerAt(16,18,4) == 0,
                "left sleeve must extrude exactly one voxel outward without filling the inner torso seam");
        require(!VoxelMeshBuilder.build(model).isEmpty(),"greedy mesh should contain exposed faces");

        VoxelCamera camera = new VoxelCamera();
        VoxelCamera.Ray centerRay = camera.rayFromScreen(model,128,160,0,0,256,320);
        require(VoxelRaycaster.pick(model,centerRay) != null,"center ray should hit the 3D skin model");

        VoxelModel slimModel = SkinVoxelizer.fromSkin(skin,"Slim Smoke Test",true);
        require(slimModel.layerAt(8,18,4) == 0 && slimModel.layerAt(9,18,4) == 0,
                "slim right arm must still attach to the torso");
        require(slimModel.layerAt(17,18,4) == 0,
                "slim left arm must still attach to the torso");
        require(slimModel.layerAt(20,18,4) == 4,
                "slim left sleeve must still extend exactly one voxel beyond the arm");

        VoxelModel whitePlayer = SkinVoxelizer.whitePlayerModel("White Player");
        require(whitePlayer.occupiedCount() > 1_000,"white player should retain its full visible surface shell");
        require(whitePlayer.layers().size() == 8,"white player should keep all independent clothing layer groups");
        require(whitePlayer.paletteIndexAt(12, 27, 2) > 0, "white mannequin head should retain its front surface");
        require(whitePlayer.paletteIndexAt(12, 27, 5) == 0, "white mannequin head interior should be hollow");
        require(whitePlayer.paletteIndexAt(12, 18, 4) > 0, "white mannequin torso should retain its front surface");
        require(whitePlayer.paletteIndexAt(12, 18, 5) == 0, "white mannequin torso interior should be hollow");
        require(whitePlayer.paletteIndexAt(10, 6, 5) == 0, "white mannequin leg interior should be hollow");
        require(whitePlayer.paletteIndexAt(6, 18, 5) == 0, "white mannequin arm interior should be hollow");
        require(!VoxelMeshBuilder.build(whitePlayer).isEmpty(),"white player should produce a visible 3D mesh");

        VoxelStudioDocument paintDocument = new VoxelStudioDocument(whitePlayer);
        paintDocument.setActivePaletteIndex(2); // orange wool is a supported vanilla block color.
        VoxelCamera paintCamera = new VoxelCamera();
        VoxelCamera.Ray playerRay = paintCamera.rayFromScreen(whitePlayer,128,160,0,0,256,320);
        var paintedHit = paintDocument.apply(playerRay);
        require(paintedHit != null,"center ray should hit the white player surface");
        require(paintDocument.model().paletteIndexAt(paintedHit.x(),paintedHit.y(),paintedHit.z()) == 2,
                "painting should recolor the hit surface voxel, not create a voxel in front of the player");
        require(paintDocument.undo(),"surface paint should be undoable");
        require(paintDocument.model().paletteIndexAt(paintedHit.x(),paintedHit.y(),paintedHit.z()) == 1,
                "undo should restore the white surface voxel");
        require(paintDocument.redo(),"surface paint should be redoable");

        VoxelModel blank = SkinVoxelizer.emptyModel("Blank Paint Test");
        VoxelStudioDocument blankDocument = new VoxelStudioDocument(blank);
        VoxelCamera blankCamera = new VoxelCamera();
        VoxelCamera.Ray blankRay = blankCamera.rayFromScreen(blank,128,160,0,0,256,320);
        blankDocument.setTool(VoxelStudioDocument.Tool.PAINT);
        blankDocument.beginStroke();
        require(blankDocument.apply(blankRay) != null,"blank template must expose a paint target");
        blankDocument.endStroke();
        require(blank.occupiedCount() == 1,"painting a blank template should create a voxel");
        require(blankDocument.undo(),"paint should be undoable");
        require(blankDocument.model().occupiedCount() == 0,"undo should clear the new voxel");
        require(blankDocument.redo(),"paint should be redoable");
        require(blankDocument.model().occupiedCount() == 1,"redo should restore the voxel");

        double brownMatch = dev.noteclient.voxel.core.VoxelColorMath.distanceSquared(0xFF4A2B1D, 0xFF4D3323);
        double grayMatch = dev.noteclient.voxel.core.VoxelColorMath.distanceSquared(0xFF4A2B1D, 0xFF4C4C4C);
        require(brownMatch < grayMatch, "perceptual colour matching must prefer dark brown over gray for dark brown skin pixels");

        System.out.println("Voxel core smoke test passed: connected arms, separate +1 left/right sleeve shells, stable clothing layer IDs, expanded palette math, hollow head/torso shells, 3D model, OKLab, raycast, paint, undo/redo.");
    }

    private static void require(boolean condition,String message) {
        if (!condition) throw new AssertionError(message);
    }
}
