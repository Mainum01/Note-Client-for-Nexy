@echo off
setlocal
set ROOT=%~dp0..
set OUT=%ROOT%\build\voxel-smoke-classes
if exist "%OUT%" rmdir /s /q "%OUT%"
mkdir "%OUT%"
javac -encoding UTF-8 -d "%OUT%" ^
 "%ROOT%\src\main\java\dev\noteclient\voxel\core\VoxelStudioConfig.java" ^
 "%ROOT%\src\main\java\dev\noteclient\voxel\core\VoxelModel.java" ^
 "%ROOT%\src\main\java\dev\noteclient\voxel\core\VoxelColorMath.java" ^
 "%ROOT%\src\client\java\dev\noteclient\voxel\core\VoxelCamera.java" ^
 "%ROOT%\src\client\java\dev\noteclient\voxel\core\VoxelMeshBuilder.java" ^
 "%ROOT%\src\client\java\dev\noteclient\voxel\core\VoxelRaycaster.java" ^
 "%ROOT%\src\client\java\dev\noteclient\voxel\core\VoxelStudioDocument.java" ^
 "%ROOT%\src\client\java\dev\noteclient\voxel\core\SkinVoxelizer.java" ^
 "%ROOT%\tools\VoxelCoreSmokeTest.java"
if errorlevel 1 exit /b 1
java -Djava.awt.headless=true -cp "%OUT%" dev.noteclient.voxel.VoxelCoreSmokeTest
exit /b %errorlevel%
