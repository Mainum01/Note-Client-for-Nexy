# NoteClient 1.3.58 — Minecraft 26.2 / Fabric

NoteClient is a Fabric client mod with an optional, separately packaged server companion. The **Character Painter is built directly into the NoteClient client mod**: it is registered by `NoteClient`, uses the `noteclient` key category and is included in the normal NoteClient client JAR. There is no separate Voxel Studio mod to install.

## Performance controls and player statue builder

Open **N → Settings** to set two independent, persistent performance limits:

- **Build actions/tick: 1–128** controls song layouts, schematic placements, physical redstone sequencers, player statues, and tracked statue/arrangement cleanup. The default is **16**.
- **Tune interactions/tick: 1–4096** controls note-block pitch interactions independently from building. The default is **2048**. Creative song builds automatically send pre-tuned Note Block item state so most builds skip pitch-click tuning entirely. If a server strips that state, the client falls back to a time-sliced click pipeline and verifies each observed pitch before retrying.
- **Playback** retains its own separate rate control. Changing either speed while a supported build is active updates its configured ceiling immediately. The optional owner-authorized server companion also receives the build rate and clamps it to the server owner’s maxBlockChangesPerTick limit.

The Player tab uses one build-speed setting in both environments. Singleplayer can use the integrated server's local block-write path; remote multiplayer uses ordinary vanilla interactions and a bounded acknowledgement queue. Both honor the configured build ceiling, but a remote server may accept fewer actions because of latency, reach, protection, permissions, rate limits or anti-cheat. Correctly occupied target cells are skipped and different occupied blocks are never overwritten.

Creative builds also stock the player's inventory with their required block materials before construction. Schematics, physical redstone circuits, skin statues, and Character Painter / Giant Block Builder models top up existing matching stacks or use empty slots; unrelated items are preserved. The stager now honors the full required quantity, including multiple stacks for builds that need more than 64 of one block. Song arrangements also stock their support and Note Block materials, and automatically request a missing Creative material again if a server inventory correction removes it during construction. If no empty inventory slot is available, the builder asks for space instead of replacing the player's existing items. This uses normal Creative inventory updates, so the server still decides whether to accept the inventory changes; Survival materials must already be in the player's inventory or be supplied by an authorized server-side feature.

## Built-in Character Painter and Giant Block Builder

Press **C** (rebindable in `Options → Controls → NoteClient`) to open the Character Painter. Use the **GIANT BLOCKS** button in the top-right to open the separate Giant Block Builder. The block picker searches every non-air block registered by Minecraft and installed mods, including ores, logs, leaves, glass, workstations, plants, fluids and decorative blocks. Pick a block and generate a giant exterior shell from its baked default-state face textures. Cube blocks use their six directional face sprites; cross/plant models can use their unculled sprite as the shell texture. Special-rendered blocks or fluids without baked face sprites fall back to a map-colour cube. The normal 16³ size maps vanilla 16×16 textures at one world voxel per source texel; 32³ is available for 32px HD resource-pack textures and upscales vanilla pixels with nearest-neighbour sampling. Texture layout and pixel boundaries are preserved, while each texel's colour is approximated by the closest safe full-cube block material available in Minecraft. All six faces are sampled independently from the active resource-pack stack. Edge and corner cells average the face colours that meet at that voxel, because one world block must serve more than one face. The output uses only safe, solid vanilla full-cube materials from the existing texture-matched palette, so source blocks from mods, plants, fluids, block entities and workstation blocks can still be represented without placing those potentially interactive source blocks into the world. Model construction runs from the client using ordinary placement interactions; the generated model uses safe full-cube materials available in the local palette. The exterior is a hollow shell to keep the build within normal server limits; it reproduces the selected block's visible cube texture rather than placing a solid filled 16³/32³ interior.

The Character Painter starts with a solid white, fully 3D Minecraft player made from separate cuboids for the head, torso, arms and legs. Click the color wheel to choose a brush color, then click or drag over the 3D character to paint its surface. The `WHITE` button restores the original white player.

The color wheel can select continuous RGB colors, but Minecraft world blocks have a finite palette. NoteClient asynchronously scans the vanilla block registry and considers all safe, solid full-cube blocks—not only wool or concrete. It does not require a MapColor entry when a block has a real visible baked texture. For each candidate it inspects the active block model, samples the real sprite pixels used on all six faces, averages them in linear light, and compares the result in OKLab. This allows wood, stripped wood, planks, stones, bricks, ores, terracotta, wool, concrete, and other suitable full cubes to compete by their texture colours. Per-voxel matching chooses different materials for dark and light parts of a skin, while the preview adds directional face lighting. The scan is cached and runs on a daemon worker rather than blocking the render thread when the Character Painter opens. Context-tinted faces use map colour as a stable biome-independent estimate. The imported skin palette keeps up to 248 distinct material IDs: the most-used matches first, followed by perceptually diverse rarer shades. Partial shapes, block entities, fluids, falling blocks, hazards and special destructive blocks are excluded because they cannot safely represent a full voxel. The chosen block ID and sampled colour are stored together so preview and client-side construction use the same material. The brush status reports how many candidates were sampled from real textures.

Controls:

- **C** — open/close Character Painter.
- **Left click / drag on the model** — paint the selected color.
- **Click / drag on the color wheel** — choose hue and saturation; the center is white.
- **ERASE / PICK** — erase a surface voxel or sample its block color.
- **Right-drag** — orbit the 3D preview.
- **Middle-drag** — pan the camera.
- **Mouse wheel over preview** — zoom.
- **Z / UNDO / REDO** — edit history.
- **WHITE** — reset to the white 3D player.
- **R / BUILD / REBUILD** — start a client-side build of the current character/model.
- **STOP** — stop sending new placements and close the editor; already placed blocks stay in the world.
- **Left Shift / UNDO LAST BUILD** — remove only the newest tracked client-built model. Press again to undo the previous one.

The editor retains optional PNG skin, built-in preset, online-player skin and saved-template import. These are secondary import choices; the default canvas is always the white player model.

The Player tab's automatic statue builder and the Character Painter share the same client-side build journal. Both use texture-sampled vanilla full-cube materials rather than a fixed wool/concrete palette. It selects skin-specific shades for darker, midtone and highlighted pixels, then builds the inner body and arms before the separate jacket, sleeve and pants shells. The left sleeve is its own second editor layer and extrudes one voxel outward from the inner arm.

On ordinary multiplayer servers, the Player-tab builder sends a small ping-sized pipeline of normal vanilla placements. Each target can be attempted twice per repair pass, but the second interaction is conditional: the builder waits for the first acknowledgement window, checks the target again, and skips the retry if the correct block is already present. It never overwrites a different occupied block. The placement-face search skips block entities and menu-opening workstations (including crafting, cartography and smithing tables), so it uses another sturdy face instead of opening their screens. A client cannot force a server to accept a placement or guarantee compatibility with every protection/anti-cheat plugin; only an authorized server-side build can provide authoritative placement.

## Character Painter architecture

| Module | Location | Responsibility |
|---|---|---|
| Shared voxel model and codec | `src/main/java/dev/noteclient/voxel/core` | Bounded model data, palette/layers, compressed local serialization |
| Client model, camera, voxelizer and picking | `src/client/java/dev/noteclient/voxel/core` | White player cuboids, skin UV mapping, pixel-mapped giant block shells, layer generation, perspective camera, greedy mesh and DDA ray-picking |
| Client library, preview and editor UI | `src/client/java/dev/noteclient/voxel/client` | Vanilla block picker, profile-local skin/template library, color wheel, asynchronous loading/saving, 3D preview and editor input |
| Shared client placement journal | `src/client/java/dev/noteclient/PlayerStatueBuilder.java` | Creative item staging, ordinary remote-server interactions, acknowledgement checks, stop/pause/retry and newest-first undo |

The editor prepares its model and preview off the render thread. Model construction uses the same client-side placement journal as the Player tab: singleplayer uses the local integrated world, while remote multiplayer sends ordinary vanilla block interactions and waits for server block updates. It requires Creative mode and normal reach; the server still decides whether a placement is accepted. No server companion is needed for the Character Painter, Giant Block Builder, or Player-tab skin statues. STOP halts future placements and leaves the partial model in place; Undo Last is a separate action that removes only the newest tracked build.

**No program can promise literal zero lag.** Client-side builds are rate-limited and wait for world confirmation, but the server's own tick rate and network conditions still affect placement speed.

## Note-block songs, physical redstone and schematics

The song scanner offers two build modes. Both can be used without installing the NoteClient server companion. Ordinary arrangement construction can use the optional companion for its faster server-authorized path, or fall back to normal player interactions. Physical Redstone Setup is always built client-side through ordinary Creative block interactions:

- **Build arrangement** places an ordinary note-block layout and plays it through real note-block interactions; the optional owner companion provides its server-authoritative playback path. Completed arrangements remain until the owner selects Destroy.
- **Redstone setup** creates a same-level repeater/redstone-dust chain, instrument supports, note blocks and a stone button two blocks in front of the player. Any player who can reach the button can start the circuit. The client waits for server-confirmed placements and pauses when the next block is outside normal reach; follow alongside the growing chain. This mode requires Creative mode, never replaces occupied cells, and does not need the companion. Physical timing is quantized to 0.1-second redstone ticks, simultaneous chords are limited to 28 notes (14 on each of two dust branches), and long songs are limited to 255 repeater stages. Vanilla note blocks cannot preserve NBS volume, panning, fine cents, or custom samples, so this is a physical approximation; use **Build arrangement** for NoteClient's more faithful NBS playback.

The schematic browser is available from **N → Library → Schematics**. It creates this folder in the active game/Modrinth profile:

```text
<GameDirectory>/noteclient/schematics/
```

Supported imports are Litematica `.litematic` (including multiple regions and packed block states), Sponge `.schem` v2/v3, vanilla Java structure `.nbt`, and legacy MCEdit `.schematic` for the legacy numeric block IDs mapped by the importer. Put files in this folder or its subfolders. Bedrock `.mcstructure`, Java world-region `.mca`, compressed archives, entities, and block-entity payloads (such as chest inventories or sign text) are not imported by this release. Unknown legacy numeric IDs are skipped rather than guessed.

When you click a file, NoteClient snapshots your exact block position and facing at that moment. The preview stays there even if you walk away or select a different file; selecting another file clears the previous ghost immediately. The player's clicked block position is always the schematic's bottom-right footprint corner and bottom Y anchor. Rotate changes the facing without moving that anchor. Press **Left Arrow** or **Build (←)** to construct from that exact preview position. Construction requires Creative mode and ordinary block-interaction reach. The preview marks empty cells and cells already containing the expected block green, and conflicting occupied blocks red. Placement acknowledgement checks the expected block type instead of requiring every state property to stay unchanged after neighbor updates. The builder starts with the blocks closest to the player's eyes and works outward. It defers blocks without valid support, out-of-reach cells, and unloaded chunks rather than letting one cell stall the entire build; deferred cells are retried automatically. For a server that permits `/reach 100`, open **N → Settings → Request /reach 100** to enable the matching client-side planning hint for that connection. This does not grant reach or bypass validation: the builder still sends ordinary interactions and the server decides whether to accept them. Gravity-affected blocks such as sand and gravel are only attempted after a sturdy block is directly underneath. Other support-dependent blocks use Minecraft's survival check. The client skips occupied cells and keeps confirmed blocks if cancelled.

## Skin and template files

The local library is created automatically at the active Minecraft/Modrinth profile game directory:

```text
<GameDirectory>/noteclient/skins/
```

The recursive scanner indexes standard 64×64 and legacy 64×32 Minecraft skin PNG files plus NoteClient `.voxel.json` templates. The PNG importer supports modern/legacy skin layouts, distinct head/torso/arm/leg cuboids, classic/slim arms and separate hat/head, jacket, right sleeve, left sleeve, right pant and left pant overlay layers. The body/inner arms are the first layer; the left sleeve is the second editor layer and extends one voxel outward from its inner arm. Each clothing region has its own model layer ID and can be toggled or isolated independently. Transparent pixels are skipped. Online skin lookup first uses profile texture properties and falls back only to the official `textures.minecraft.net` host.

Saved `.voxel.json` templates contain the compact, versioned model (palette, layer settings and voxel cells) in a compressed Base64 representation.

## Optional Owner Mode server features

For Character Painter, Giant Block Builder, Player-tab skin statues and schematic construction, a client-only installation places blocks through ordinary vanilla interactions; no NoteClient server companion is needed. The server remains authoritative and can reject interactions according to its normal reach, permissions, claims, rate limits and anti-cheat rules.

The optional server companion is still used for Owner Mode features such as server-side Aura and server-authoritative note-block arrangement operations. Its build/cleanup throughput honors the client-requested build rate up to the server owner’s configured maxBlockChangesPerTick ceiling; old companion payload versions are not sent, and the client falls back to normal interactions. Physical Redstone Setup is not part of this companion path. It:

- Requires the integrated singleplayer host or operator permission by default; LAN guests are not implicitly trusted.
- Enforces model, voxel-count, packet-size, distance, world-border and loaded-chunk limits.
- Accepts safe vanilla solid full-cube blocks from the expanded palette, including wood, stone, brick, ore, wool, concrete and terracotta materials; modded IDs, block entities, fluid blocks, falling blocks and hazardous/special blocks are rejected.
- Refuses occupied target cells by default.
- Applies a bounded number of real block changes per server tick.
- Removes only cells whose live state still equals the state the job placed.
- Keeps completed note-block arrangements on disconnect and normal shutdown; unfinished server jobs are cleaned up. The retained arrangement journal is in memory only and is not saved across restarts.

A hard JVM/server crash cannot execute cleanup. Use the world editor only on a server you administer and keep backups. Server world changes are real blocks and have normal collision.

See [`VOXEL_STUDIO.md`](VOXEL_STUDIO.md) for implementation notes and [`SERVER_SETUP.md`](SERVER_SETUP.md) for companion installation/configuration.

## Build

Requirements: **JDK 25**, Fabric Loom 1.17.21, Fabric Loader 0.19.3, Fabric API 0.161.0+26.2.

Windows:

```bat
gradlew.bat clean build
```

The build task creates:

```text
build/release/NoteClient-1.3.58-Minecraft-26.2.jar
build/release/NoteClientServer-1.3.58-Minecraft-26.2.jar
```

The first JAR is NoteClient, including Character Painter, the searchable Giant Block picker and their preview/editor screens. The second is the optional dedicated-server companion. Do not put the client JAR on a dedicated server.

## Core smoke test

The engine-independent voxelizer, model, OKLab colour comparison, camera, mesher, raycaster and document can be tested with a Java 21+ JDK without compiling Minecraft/Fabric:

```bat
tools\run-voxel-smoke-test.bat
```

This checks imported skins, the solid white player, surface recoloring, greedy meshing, raycasting, blank painting and undo/redo. It is not a substitute for the full JDK 25 Fabric Gradle build.

## Compatibility / limitations

- The 3D editor preview is a perspective-rendered image generated from a greedy surface mesh, not a `BlockDisplay` entity renderer.
- Shared world builds use real Minecraft block states; each occupied voxel still requires a real block-state update, bounded per tick.
- The white character is fully voxel-filled. Imported PNG skin models use the visible cuboid surfaces and separate expanded overlay shells to limit world edit counts.
- The color wheel's RGB selection is quantized to the supported vanilla full-cube block palette; arbitrary RGB values cannot be represented exactly by a finite set of Minecraft blocks. The colour reference is sampled from the current resource-pack baked model's face textures. Context-tinted faces use the vanilla map colour fallback because their final tint depends on biome/world context.
- The server validates every cell and skips unloaded, occupied, out-of-bounds or unsafe positions rather than forcing edits.
