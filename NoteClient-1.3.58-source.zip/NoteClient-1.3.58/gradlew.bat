@echo off
setlocal
set GRADLE_VERSION=9.5.1
set BASE_DIR=%LOCALAPPDATA%\NoteClient
set GRADLE_HOME=%BASE_DIR%\gradle-%GRADLE_VERSION%
set GRADLE_BIN=%GRADLE_HOME%\bin\gradle.bat
if exist "%GRADLE_BIN%" goto runGradle
if not exist "%BASE_DIR%" mkdir "%BASE_DIR%"
set ZIP_PATH=%TEMP%\gradle-%GRADLE_VERSION%-bin.zip
echo Downloading Gradle %GRADLE_VERSION%...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP_PATH%'; Expand-Archive -LiteralPath '%ZIP_PATH%' -DestinationPath '%BASE_DIR%' -Force"
if errorlevel 1 exit /b %ERRORLEVEL%
:runGradle
call "%GRADLE_BIN%" %*
exit /b %ERRORLEVEL%
