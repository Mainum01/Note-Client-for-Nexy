# NoteClient Character Painter — implementation notes

The Character Painter is not a separate mod. Its client screen, keybind, skin library and preview renderer are part of the normal NoteClient client source set and client JAR.

## Giant Block Builder

The Character Painter's top-right **GIANT BLOCKS** control opens a searchable block registry picker. It enumerates every non-air block ID registered by Minecraft and installed mods at runtime, so new content does not require a manually maintained list. It searches by localized display name or namespaced ID. Source blocks are sampled from their default block state; this includes complex or interactive source blocks, but the resulting world structure is always assembled from safe full-cube materials rather than placing the source block itself. Cube blocks use their directional face sprites; cross/plant models can use unculled sprites as the shell texture. Fluids and special-rendered blocks that do not expose baked face sprites fall back to their map colour.

`GiantBlockVoxelizer` reads the selected block's baked model, collects its six directional quad sprites, loads each sprite PNG through the active resource manager (including resource packs), and maps texture pixels onto the corresponding outside face. A 16³ shell maps vanilla 16×16 textures one source pixel per world voxel. A 32³ shell is intended for 32px HD resource packs; ordinary 16px textures are enlarged with nearest-neighbour sampling. The texel layout is preserved, but source colours are approximated by the closest safe full-cube material in the active Minecraft palette. Shared edge and corner voxels average all face samples that occupy the same world position. The model remains hollow behind the textured exterior, keeping the generated block count practical for ordinary client placement. Each voxel colour is matched with the existing OKLab palette of safe vanilla full-cube materials.

The picker and texture sampling run independently of the skin import pipeline. Even when a source block comes from a mod, the generated voxels use the safe vanilla material palette, so the placed model uses the local safe full-cube material palette rather than the potentially interactive source block. When the model is generated, the same voxel preview/editor, local save format, compressed model codec and client-side build/undo journal are used.

## Default white 3D player

When C opens the screen, `SkinVoxelizer.whitePlayerModel` creates a solid white character in a 26×34×12 model volume. The head (8×8×8), torso (8×12×4), arms (4×12×4 each) and legs (4×12×4 each) are distinct cuboids on the `Base skin` layer. The blank mannequin starts with `minecraft:white_concrete` so opening the Studio is instant; the full texture-derived block palette is warmed on a daemon worker. The `WHITE` action recreates this model.

## Color wheel and painting

The editor generates one small HSV wheel texture per screen. Mouse position determines hue and saturation; the center is white. The selected RGB color is mapped to the closest entry among all safe vanilla full-cube blocks. A map colour is not required when a block has visible model texture pixels. The client queries the active baked block-state model, collects the six directional face quads, samples each distinct face sprite, averages opaque texels in linear light, and compares the resulting colour in OKLab. Tint-indexed faces use map colour as a biome-independent fallback. This captures wood grain, bark, stone, bricks, ores, terracotta, wool, concrete and other solid-block textures rather than ranking only by broad map-colour swatches. Every skin pixel is matched independently, preserving light/dark gradients. The skin importer keeps up to 248 distinct material IDs, prioritizing common matches and then perceptually diverse rare shades. The registry/model scan is cached and prewarmed asynchronously, so opening the Studio does not perform the full texture scan on the render thread. The Studio brush status reports how many candidates were sampled from real textures. The same palette entry supplies both preview colour and the block ID used for client-side placement.

`VoxelRaycaster` uses bounded Amanatides–Woo traversal. On the base layer, paint returns the actual first solid surface voxel, so painting changes its palette index instead of adding a new voxel in front of the character. When an outer clothing/accessory layer is active, the raycaster can choose the adjacent empty voxel to keep that layer independently editable. Erase and color-pick target occupied voxels. `VoxelStudioDocument` groups drag strokes into snapshots and provides bounded undo/redo.

## Preview and performance

`VoxelMeshBuilder` emits only visible faces and merges same-material, same-layer coplanar faces into greedy quads. `VoxelPreviewRenderer` renders the quads to a small image on a daemon executor, applying stronger directional light contrast to top, side, and underside faces so the mannequin reads as a 3D model. The Minecraft render thread only uploads the finished image to a `DynamicTexture`. Camera orbit, pan, zoom and preview projection are implemented in `VoxelCamera`.

## Local skin library

The root is resolved from Fabric Loader's active game directory:

```text
<GameDirectory>/noteclient/skins/
```

The loader creates the directory, recursively scans it with depth and file-count limits, avoids symlinks, validates supported skin/template files, and performs I/O on a bounded daemon pool. Saved models are written using a temporary file and atomic move.

## Server authority

World construction is client-side and does not use the NoteClient server companion. In singleplayer, the client batches writes through the local integrated world. On remote servers, it stages the matching Creative block item and sends ordinary vanilla placement interactions, waiting for the server's block updates before confirming progress. The build never replaces occupied cells and is limited by normal interaction reach and whatever permissions/rules the server enforces.

The build journal tracks attempted/confirmed positions so Stop can halt future placements without deleting the partial model, while Undo Last removes only the newest matching NoteClient-created blocks. A server may reject or rate-limit a placement; the client cannot make a remote server accept a block write.

Literal zero lag cannot be guaranteed. Client placement pacing is bounded and acknowledgement-driven, but server tick rate and network conditions still affect construction speed.
